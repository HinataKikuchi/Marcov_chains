window.YTD.device_token.part0 = [ {
  "deviceToken" : {
    "clientApplicationId" : "-1",
    "token" : "hYLLh0nSeXVtAumslCyQAYYJK1NKgloBN3Q8c2Oe",
    "createdAt" : "1970-01-01T00:00:00.000Z",
    "lastSeenAt" : "2020-06-13T07:01:35.939Z",
    "clientApplicationName" : ""
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "2ePkLDdw7vYIMzh1NxSB80tiUSTrXyYiA36Su10B",
    "createdAt" : "2020-07-15T13:16:18.724Z",
    "lastSeenAt" : "2020-07-15T13:16:18.726Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "49152",
    "token" : "uCCncELzZJDOw1Ztz1xcavKEaO5upC3YHFqQ8Iil",
    "createdAt" : "2020-09-01T06:13:59.636Z",
    "lastSeenAt" : "2020-09-01T06:13:59.638Z",
    "clientApplicationName" : "Mobile Web (Twitter)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "5bUHtdqWMR12Rm7z6mRX0xH5MmCnKhf1R93jW7n3",
    "createdAt" : "2020-09-04T12:55:21.120Z",
    "lastSeenAt" : "2020-09-06T14:21:36.268Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "268278",
    "token" : "DCSTIG9MrXqAcboUuNw1w5TkmXnkwdbkTG17fI3K",
    "createdAt" : "2020-10-07T05:48:57.183Z",
    "lastSeenAt" : "2020-10-07T05:48:57.185Z",
    "clientApplicationName" : "Twitter Web Client (Twitter, Inc.)"
  }
} ]