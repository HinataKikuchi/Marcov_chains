window.YTD.connected_application.part0 = [ {
  "connectedApplication" : {
    "organization" : {
      "name" : "Twitter",
      "url" : ""
    },
    "name" : "Twitter for iPhone",
    "description" : "Twitter for iPhone",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2020-02-15T05:58:41.000Z",
    "id" : "129032"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Increments株式会社",
      "url" : "http://increments.co.jp"
    },
    "name" : "Qiita",
    "description" : "Log and Share programmers' knowledge - Qiita(キータ)は、プログラマの持つ知識、コード、ハックを記録、共有するサービスです。",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2020-10-07T04:51:29.000Z",
    "id" : "1247290"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Nintendo Co., Ltd.",
      "url" : "https://www.nintendo.com/countryselector",
      "privacyPolicyUrl" : "https://accounts.nintendo.com/term_chooser/privacy_policy",
      "termsAndConditionsUrl" : "https://accounts.nintendo.com/term_chooser/eula"
    },
    "name" : "Nintendo Switch Share",
    "description" : "This is one of the services of Nintendo Switch.",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2020-10-07T05:48:58.000Z",
    "id" : "12495528"
  }
} ]