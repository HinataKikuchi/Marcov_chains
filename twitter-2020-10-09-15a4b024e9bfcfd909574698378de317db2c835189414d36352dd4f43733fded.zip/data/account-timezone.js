window.YTD.account_timezone.part0 = [ {
  "accountTimezone" : {
    "accountId" : "1228559135093821441"
  }
} ]