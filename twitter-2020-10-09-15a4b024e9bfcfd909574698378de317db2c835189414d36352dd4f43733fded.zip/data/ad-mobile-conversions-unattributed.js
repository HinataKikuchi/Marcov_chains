window.YTD.ad_mobile_conversions_unattributed.part0 = [ {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-09 08:49:58"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-09 16:18:55"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-10 06:12:31"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-10 00:01:56"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-14 14:42:48"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-14 22:22:44"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-15 04:43:30"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-15 10:52:39"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-15 22:44:55"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-18 06:05:55"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-18 12:13:34"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-18 22:59:42"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "バンドルカード:簡単Visaプリペイドカード、Visaカード",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-20 02:40:47"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-20 04:29:23"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "バンドルカード:簡単Visaプリペイドカード、Visaカード",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-20 04:29:47"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-20 17:48:13"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "バンドルカード:簡単Visaプリペイドカード、Visaカード",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-20 09:28:37"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "バンドルカード:簡単Visaプリペイドカード、Visaカード",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-20 08:44:29"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-20 23:50:23"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-10 12:13:01"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-22 04:51:22"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-22 10:57:42"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-23 06:28:25"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-22 22:26:41"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "バンドルカード:簡単Visaプリペイドカード、Visaカード",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-24 00:28:39"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "バンドルカード:簡単Visaプリペイドカード、Visaカード",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-24 09:33:06"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-24 11:04:13"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "バンドルカード:簡単Visaプリペイドカード、Visaカード",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-24 11:04:09"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "バンドルカード:簡単Visaプリペイドカード、Visaカード",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-24 12:44:38"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-24 21:58:16"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-25 06:05:54"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-25 14:10:40"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-25 22:41:22"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-10-05 00:52:53"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-10-05 14:48:29"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-10-05 07:17:54"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-11 05:58:14"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-10 22:21:36"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-10-06 00:05:23"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-10-06 09:17:49"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-10-07 05:55:02"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-10-06 23:36:01"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-11 16:10:43"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-12 01:23:58"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-12 07:24:46"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-12 14:44:01"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-13 00:41:08"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-13 15:45:24"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-13 07:53:58"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-13 22:28:57"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2020-09-14 05:12:07"
        } ]
      }
    }
  }
} ]