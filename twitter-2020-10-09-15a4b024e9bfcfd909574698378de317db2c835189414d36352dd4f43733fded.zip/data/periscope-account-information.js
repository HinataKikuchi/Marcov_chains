window.YTD.periscope_account_information.part0 = [ {
  "periscopeAccountInformation" : {
    "displayName" : "Hinata",
    "digitsId" : "",
    "username" : "Hinata72279726",
    "twitterId" : "1228559135093821441",
    "id" : "1wBEArygMRDQP",
    "twitterScreenName" : "Hinata72279726",
    "isTwitterUser" : true,
    "createdAt" : "2020-09-18T12:22:20.939469748Z"
  }
} ]