window.YTD.following.part0 = [ {
  "following" : {
    "accountId" : "1060552633059033088",
    "userLink" : "https://twitter.com/intent/user?user_id=1060552633059033088"
  }
}, {
  "following" : {
    "accountId" : "1312951389677477888",
    "userLink" : "https://twitter.com/intent/user?user_id=1312951389677477888"
  }
}, {
  "following" : {
    "accountId" : "222596625",
    "userLink" : "https://twitter.com/intent/user?user_id=222596625"
  }
}, {
  "following" : {
    "accountId" : "1293792323692670976",
    "userLink" : "https://twitter.com/intent/user?user_id=1293792323692670976"
  }
}, {
  "following" : {
    "accountId" : "3800289018",
    "userLink" : "https://twitter.com/intent/user?user_id=3800289018"
  }
}, {
  "following" : {
    "accountId" : "1138034781977841665",
    "userLink" : "https://twitter.com/intent/user?user_id=1138034781977841665"
  }
}, {
  "following" : {
    "accountId" : "903092159582158848",
    "userLink" : "https://twitter.com/intent/user?user_id=903092159582158848"
  }
}, {
  "following" : {
    "accountId" : "1280295123725635584",
    "userLink" : "https://twitter.com/intent/user?user_id=1280295123725635584"
  }
}, {
  "following" : {
    "accountId" : "1151372870829789184",
    "userLink" : "https://twitter.com/intent/user?user_id=1151372870829789184"
  }
}, {
  "following" : {
    "accountId" : "266546862",
    "userLink" : "https://twitter.com/intent/user?user_id=266546862"
  }
}, {
  "following" : {
    "accountId" : "1256503275093757954",
    "userLink" : "https://twitter.com/intent/user?user_id=1256503275093757954"
  }
}, {
  "following" : {
    "accountId" : "1179205024485765126",
    "userLink" : "https://twitter.com/intent/user?user_id=1179205024485765126"
  }
}, {
  "following" : {
    "accountId" : "46359871",
    "userLink" : "https://twitter.com/intent/user?user_id=46359871"
  }
}, {
  "following" : {
    "accountId" : "2482023492",
    "userLink" : "https://twitter.com/intent/user?user_id=2482023492"
  }
}, {
  "following" : {
    "accountId" : "1271647278676103170",
    "userLink" : "https://twitter.com/intent/user?user_id=1271647278676103170"
  }
}, {
  "following" : {
    "accountId" : "1174684632295583746",
    "userLink" : "https://twitter.com/intent/user?user_id=1174684632295583746"
  }
}, {
  "following" : {
    "accountId" : "1274275520054571009",
    "userLink" : "https://twitter.com/intent/user?user_id=1274275520054571009"
  }
}, {
  "following" : {
    "accountId" : "1231132817196642306",
    "userLink" : "https://twitter.com/intent/user?user_id=1231132817196642306"
  }
}, {
  "following" : {
    "accountId" : "1289525542446698497",
    "userLink" : "https://twitter.com/intent/user?user_id=1289525542446698497"
  }
}, {
  "following" : {
    "accountId" : "717891703",
    "userLink" : "https://twitter.com/intent/user?user_id=717891703"
  }
}, {
  "following" : {
    "accountId" : "20843552",
    "userLink" : "https://twitter.com/intent/user?user_id=20843552"
  }
}, {
  "following" : {
    "accountId" : "1281824169278058498",
    "userLink" : "https://twitter.com/intent/user?user_id=1281824169278058498"
  }
}, {
  "following" : {
    "accountId" : "67756188",
    "userLink" : "https://twitter.com/intent/user?user_id=67756188"
  }
}, {
  "following" : {
    "accountId" : "958264156683091969",
    "userLink" : "https://twitter.com/intent/user?user_id=958264156683091969"
  }
}, {
  "following" : {
    "accountId" : "1268751606893260807",
    "userLink" : "https://twitter.com/intent/user?user_id=1268751606893260807"
  }
}, {
  "following" : {
    "accountId" : "63808232",
    "userLink" : "https://twitter.com/intent/user?user_id=63808232"
  }
}, {
  "following" : {
    "accountId" : "1286128540748922881",
    "userLink" : "https://twitter.com/intent/user?user_id=1286128540748922881"
  }
}, {
  "following" : {
    "accountId" : "2920199443",
    "userLink" : "https://twitter.com/intent/user?user_id=2920199443"
  }
}, {
  "following" : {
    "accountId" : "1020586855207600129",
    "userLink" : "https://twitter.com/intent/user?user_id=1020586855207600129"
  }
}, {
  "following" : {
    "accountId" : "1300579343903539200",
    "userLink" : "https://twitter.com/intent/user?user_id=1300579343903539200"
  }
}, {
  "following" : {
    "accountId" : "1296393604559065093",
    "userLink" : "https://twitter.com/intent/user?user_id=1296393604559065093"
  }
}, {
  "following" : {
    "accountId" : "4724352572",
    "userLink" : "https://twitter.com/intent/user?user_id=4724352572"
  }
}, {
  "following" : {
    "accountId" : "1850780540",
    "userLink" : "https://twitter.com/intent/user?user_id=1850780540"
  }
}, {
  "following" : {
    "accountId" : "129578179",
    "userLink" : "https://twitter.com/intent/user?user_id=129578179"
  }
}, {
  "following" : {
    "accountId" : "1203697758370029568",
    "userLink" : "https://twitter.com/intent/user?user_id=1203697758370029568"
  }
}, {
  "following" : {
    "accountId" : "1248112788246900739",
    "userLink" : "https://twitter.com/intent/user?user_id=1248112788246900739"
  }
}, {
  "following" : {
    "accountId" : "968385122293698560",
    "userLink" : "https://twitter.com/intent/user?user_id=968385122293698560"
  }
}, {
  "following" : {
    "accountId" : "1206502514897477632",
    "userLink" : "https://twitter.com/intent/user?user_id=1206502514897477632"
  }
}, {
  "following" : {
    "accountId" : "1303628116468797440",
    "userLink" : "https://twitter.com/intent/user?user_id=1303628116468797440"
  }
}, {
  "following" : {
    "accountId" : "1302766029177679873",
    "userLink" : "https://twitter.com/intent/user?user_id=1302766029177679873"
  }
}, {
  "following" : {
    "accountId" : "147231398",
    "userLink" : "https://twitter.com/intent/user?user_id=147231398"
  }
}, {
  "following" : {
    "accountId" : "158032216",
    "userLink" : "https://twitter.com/intent/user?user_id=158032216"
  }
}, {
  "following" : {
    "accountId" : "180787187",
    "userLink" : "https://twitter.com/intent/user?user_id=180787187"
  }
}, {
  "following" : {
    "accountId" : "977185865649680384",
    "userLink" : "https://twitter.com/intent/user?user_id=977185865649680384"
  }
}, {
  "following" : {
    "accountId" : "923093426773487616",
    "userLink" : "https://twitter.com/intent/user?user_id=923093426773487616"
  }
}, {
  "following" : {
    "accountId" : "2328878924",
    "userLink" : "https://twitter.com/intent/user?user_id=2328878924"
  }
}, {
  "following" : {
    "accountId" : "1298899014562099200",
    "userLink" : "https://twitter.com/intent/user?user_id=1298899014562099200"
  }
}, {
  "following" : {
    "accountId" : "1297209490333249537",
    "userLink" : "https://twitter.com/intent/user?user_id=1297209490333249537"
  }
}, {
  "following" : {
    "accountId" : "1302579062695579650",
    "userLink" : "https://twitter.com/intent/user?user_id=1302579062695579650"
  }
}, {
  "following" : {
    "accountId" : "2269701410",
    "userLink" : "https://twitter.com/intent/user?user_id=2269701410"
  }
}, {
  "following" : {
    "accountId" : "3410177293",
    "userLink" : "https://twitter.com/intent/user?user_id=3410177293"
  }
}, {
  "following" : {
    "accountId" : "984367814889779200",
    "userLink" : "https://twitter.com/intent/user?user_id=984367814889779200"
  }
}, {
  "following" : {
    "accountId" : "1301122199760240641",
    "userLink" : "https://twitter.com/intent/user?user_id=1301122199760240641"
  }
}, {
  "following" : {
    "accountId" : "855651284006785024",
    "userLink" : "https://twitter.com/intent/user?user_id=855651284006785024"
  }
}, {
  "following" : {
    "accountId" : "1303203760097783808",
    "userLink" : "https://twitter.com/intent/user?user_id=1303203760097783808"
  }
}, {
  "following" : {
    "accountId" : "1199683722787713026",
    "userLink" : "https://twitter.com/intent/user?user_id=1199683722787713026"
  }
}, {
  "following" : {
    "accountId" : "1259464500631109632",
    "userLink" : "https://twitter.com/intent/user?user_id=1259464500631109632"
  }
}, {
  "following" : {
    "accountId" : "1284518123954008067",
    "userLink" : "https://twitter.com/intent/user?user_id=1284518123954008067"
  }
}, {
  "following" : {
    "accountId" : "1301335035807555585",
    "userLink" : "https://twitter.com/intent/user?user_id=1301335035807555585"
  }
}, {
  "following" : {
    "accountId" : "1301507810392334337",
    "userLink" : "https://twitter.com/intent/user?user_id=1301507810392334337"
  }
}, {
  "following" : {
    "accountId" : "1300964966317436928",
    "userLink" : "https://twitter.com/intent/user?user_id=1300964966317436928"
  }
}, {
  "following" : {
    "accountId" : "1213999669321203712",
    "userLink" : "https://twitter.com/intent/user?user_id=1213999669321203712"
  }
}, {
  "following" : {
    "accountId" : "1243876701949423617",
    "userLink" : "https://twitter.com/intent/user?user_id=1243876701949423617"
  }
}, {
  "following" : {
    "accountId" : "1298260594743631873",
    "userLink" : "https://twitter.com/intent/user?user_id=1298260594743631873"
  }
}, {
  "following" : {
    "accountId" : "1101683448433934337",
    "userLink" : "https://twitter.com/intent/user?user_id=1101683448433934337"
  }
}, {
  "following" : {
    "accountId" : "1299903838409768962",
    "userLink" : "https://twitter.com/intent/user?user_id=1299903838409768962"
  }
}, {
  "following" : {
    "accountId" : "1191722237994426374",
    "userLink" : "https://twitter.com/intent/user?user_id=1191722237994426374"
  }
}, {
  "following" : {
    "accountId" : "1289220638117257217",
    "userLink" : "https://twitter.com/intent/user?user_id=1289220638117257217"
  }
}, {
  "following" : {
    "accountId" : "1213257727100633089",
    "userLink" : "https://twitter.com/intent/user?user_id=1213257727100633089"
  }
}, {
  "following" : {
    "accountId" : "1296405268461494274",
    "userLink" : "https://twitter.com/intent/user?user_id=1296405268461494274"
  }
}, {
  "following" : {
    "accountId" : "1296482366265806848",
    "userLink" : "https://twitter.com/intent/user?user_id=1296482366265806848"
  }
}, {
  "following" : {
    "accountId" : "1119468023557967872",
    "userLink" : "https://twitter.com/intent/user?user_id=1119468023557967872"
  }
}, {
  "following" : {
    "accountId" : "1292736568453550083",
    "userLink" : "https://twitter.com/intent/user?user_id=1292736568453550083"
  }
}, {
  "following" : {
    "accountId" : "994606316667600896",
    "userLink" : "https://twitter.com/intent/user?user_id=994606316667600896"
  }
}, {
  "following" : {
    "accountId" : "1120294241387696129",
    "userLink" : "https://twitter.com/intent/user?user_id=1120294241387696129"
  }
}, {
  "following" : {
    "accountId" : "1190160488648200192",
    "userLink" : "https://twitter.com/intent/user?user_id=1190160488648200192"
  }
}, {
  "following" : {
    "accountId" : "1284568106854002688",
    "userLink" : "https://twitter.com/intent/user?user_id=1284568106854002688"
  }
}, {
  "following" : {
    "accountId" : "1285928845875396608",
    "userLink" : "https://twitter.com/intent/user?user_id=1285928845875396608"
  }
}, {
  "following" : {
    "accountId" : "1251179846392143873",
    "userLink" : "https://twitter.com/intent/user?user_id=1251179846392143873"
  }
}, {
  "following" : {
    "accountId" : "1295258233683116032",
    "userLink" : "https://twitter.com/intent/user?user_id=1295258233683116032"
  }
}, {
  "following" : {
    "accountId" : "1196027845836824578",
    "userLink" : "https://twitter.com/intent/user?user_id=1196027845836824578"
  }
}, {
  "following" : {
    "accountId" : "1294077412368556034",
    "userLink" : "https://twitter.com/intent/user?user_id=1294077412368556034"
  }
}, {
  "following" : {
    "accountId" : "1293010297926479872",
    "userLink" : "https://twitter.com/intent/user?user_id=1293010297926479872"
  }
}, {
  "following" : {
    "accountId" : "1293281231027617792",
    "userLink" : "https://twitter.com/intent/user?user_id=1293281231027617792"
  }
}, {
  "following" : {
    "accountId" : "1215191126103097344",
    "userLink" : "https://twitter.com/intent/user?user_id=1215191126103097344"
  }
}, {
  "following" : {
    "accountId" : "1207828277521338368",
    "userLink" : "https://twitter.com/intent/user?user_id=1207828277521338368"
  }
}, {
  "following" : {
    "accountId" : "1232418604928225280",
    "userLink" : "https://twitter.com/intent/user?user_id=1232418604928225280"
  }
}, {
  "following" : {
    "accountId" : "1285091071676960768",
    "userLink" : "https://twitter.com/intent/user?user_id=1285091071676960768"
  }
}, {
  "following" : {
    "accountId" : "941430860229656576",
    "userLink" : "https://twitter.com/intent/user?user_id=941430860229656576"
  }
}, {
  "following" : {
    "accountId" : "1275085692410843137",
    "userLink" : "https://twitter.com/intent/user?user_id=1275085692410843137"
  }
}, {
  "following" : {
    "accountId" : "1283004063886372864",
    "userLink" : "https://twitter.com/intent/user?user_id=1283004063886372864"
  }
}, {
  "following" : {
    "accountId" : "1280326248523169793",
    "userLink" : "https://twitter.com/intent/user?user_id=1280326248523169793"
  }
}, {
  "following" : {
    "accountId" : "1284139705273995265",
    "userLink" : "https://twitter.com/intent/user?user_id=1284139705273995265"
  }
}, {
  "following" : {
    "accountId" : "1280989051965693954",
    "userLink" : "https://twitter.com/intent/user?user_id=1280989051965693954"
  }
}, {
  "following" : {
    "accountId" : "944514353008480257",
    "userLink" : "https://twitter.com/intent/user?user_id=944514353008480257"
  }
}, {
  "following" : {
    "accountId" : "1234191471600787457",
    "userLink" : "https://twitter.com/intent/user?user_id=1234191471600787457"
  }
}, {
  "following" : {
    "accountId" : "1228647482114138112",
    "userLink" : "https://twitter.com/intent/user?user_id=1228647482114138112"
  }
}, {
  "following" : {
    "accountId" : "1154443439234150400",
    "userLink" : "https://twitter.com/intent/user?user_id=1154443439234150400"
  }
}, {
  "following" : {
    "accountId" : "1233684911925497858",
    "userLink" : "https://twitter.com/intent/user?user_id=1233684911925497858"
  }
}, {
  "following" : {
    "accountId" : "1157252356947369985",
    "userLink" : "https://twitter.com/intent/user?user_id=1157252356947369985"
  }
}, {
  "following" : {
    "accountId" : "865116795291619328",
    "userLink" : "https://twitter.com/intent/user?user_id=865116795291619328"
  }
}, {
  "following" : {
    "accountId" : "1260204314812809216",
    "userLink" : "https://twitter.com/intent/user?user_id=1260204314812809216"
  }
}, {
  "following" : {
    "accountId" : "1246281168871292928",
    "userLink" : "https://twitter.com/intent/user?user_id=1246281168871292928"
  }
}, {
  "following" : {
    "accountId" : "1228376336588107776",
    "userLink" : "https://twitter.com/intent/user?user_id=1228376336588107776"
  }
}, {
  "following" : {
    "accountId" : "1254342479211421702",
    "userLink" : "https://twitter.com/intent/user?user_id=1254342479211421702"
  }
}, {
  "following" : {
    "accountId" : "379232830",
    "userLink" : "https://twitter.com/intent/user?user_id=379232830"
  }
}, {
  "following" : {
    "accountId" : "125579725",
    "userLink" : "https://twitter.com/intent/user?user_id=125579725"
  }
}, {
  "following" : {
    "accountId" : "1224900019150438400",
    "userLink" : "https://twitter.com/intent/user?user_id=1224900019150438400"
  }
}, {
  "following" : {
    "accountId" : "1067021869805559809",
    "userLink" : "https://twitter.com/intent/user?user_id=1067021869805559809"
  }
}, {
  "following" : {
    "accountId" : "1221974655348592640",
    "userLink" : "https://twitter.com/intent/user?user_id=1221974655348592640"
  }
}, {
  "following" : {
    "accountId" : "155814794",
    "userLink" : "https://twitter.com/intent/user?user_id=155814794"
  }
}, {
  "following" : {
    "accountId" : "1218147165429628937",
    "userLink" : "https://twitter.com/intent/user?user_id=1218147165429628937"
  }
}, {
  "following" : {
    "accountId" : "1223171273804533760",
    "userLink" : "https://twitter.com/intent/user?user_id=1223171273804533760"
  }
}, {
  "following" : {
    "accountId" : "4839435614",
    "userLink" : "https://twitter.com/intent/user?user_id=4839435614"
  }
}, {
  "following" : {
    "accountId" : "1236227622188662784",
    "userLink" : "https://twitter.com/intent/user?user_id=1236227622188662784"
  }
}, {
  "following" : {
    "accountId" : "2565786552",
    "userLink" : "https://twitter.com/intent/user?user_id=2565786552"
  }
}, {
  "following" : {
    "accountId" : "1184239768227340289",
    "userLink" : "https://twitter.com/intent/user?user_id=1184239768227340289"
  }
}, {
  "following" : {
    "accountId" : "1175310221238890497",
    "userLink" : "https://twitter.com/intent/user?user_id=1175310221238890497"
  }
}, {
  "following" : {
    "accountId" : "2427465823",
    "userLink" : "https://twitter.com/intent/user?user_id=2427465823"
  }
}, {
  "following" : {
    "accountId" : "747034745477857280",
    "userLink" : "https://twitter.com/intent/user?user_id=747034745477857280"
  }
}, {
  "following" : {
    "accountId" : "1230381648115462144",
    "userLink" : "https://twitter.com/intent/user?user_id=1230381648115462144"
  }
}, {
  "following" : {
    "accountId" : "1074550476979429376",
    "userLink" : "https://twitter.com/intent/user?user_id=1074550476979429376"
  }
}, {
  "following" : {
    "accountId" : "1229319132333477888",
    "userLink" : "https://twitter.com/intent/user?user_id=1229319132333477888"
  }
}, {
  "following" : {
    "accountId" : "1136877060624748544",
    "userLink" : "https://twitter.com/intent/user?user_id=1136877060624748544"
  }
}, {
  "following" : {
    "accountId" : "839813133715718144",
    "userLink" : "https://twitter.com/intent/user?user_id=839813133715718144"
  }
}, {
  "following" : {
    "accountId" : "1228669226174435328",
    "userLink" : "https://twitter.com/intent/user?user_id=1228669226174435328"
  }
}, {
  "following" : {
    "accountId" : "855631594911973376",
    "userLink" : "https://twitter.com/intent/user?user_id=855631594911973376"
  }
}, {
  "following" : {
    "accountId" : "1232585665155461121",
    "userLink" : "https://twitter.com/intent/user?user_id=1232585665155461121"
  }
}, {
  "following" : {
    "accountId" : "1183536314",
    "userLink" : "https://twitter.com/intent/user?user_id=1183536314"
  }
}, {
  "following" : {
    "accountId" : "1231600326953721856",
    "userLink" : "https://twitter.com/intent/user?user_id=1231600326953721856"
  }
}, {
  "following" : {
    "accountId" : "1231618474515894272",
    "userLink" : "https://twitter.com/intent/user?user_id=1231618474515894272"
  }
}, {
  "following" : {
    "accountId" : "1221387693671608321",
    "userLink" : "https://twitter.com/intent/user?user_id=1221387693671608321"
  }
}, {
  "following" : {
    "accountId" : "260687283",
    "userLink" : "https://twitter.com/intent/user?user_id=260687283"
  }
}, {
  "following" : {
    "accountId" : "1118967160951304192",
    "userLink" : "https://twitter.com/intent/user?user_id=1118967160951304192"
  }
}, {
  "following" : {
    "accountId" : "1229983781919936513",
    "userLink" : "https://twitter.com/intent/user?user_id=1229983781919936513"
  }
}, {
  "following" : {
    "accountId" : "1229371317276725248",
    "userLink" : "https://twitter.com/intent/user?user_id=1229371317276725248"
  }
}, {
  "following" : {
    "accountId" : "1195993548199350272",
    "userLink" : "https://twitter.com/intent/user?user_id=1195993548199350272"
  }
}, {
  "following" : {
    "accountId" : "1197208908399464449",
    "userLink" : "https://twitter.com/intent/user?user_id=1197208908399464449"
  }
}, {
  "following" : {
    "accountId" : "1033030946478419973",
    "userLink" : "https://twitter.com/intent/user?user_id=1033030946478419973"
  }
}, {
  "following" : {
    "accountId" : "1221574370558005249",
    "userLink" : "https://twitter.com/intent/user?user_id=1221574370558005249"
  }
}, {
  "following" : {
    "accountId" : "1086216031998074880",
    "userLink" : "https://twitter.com/intent/user?user_id=1086216031998074880"
  }
}, {
  "following" : {
    "accountId" : "1216724186023919616",
    "userLink" : "https://twitter.com/intent/user?user_id=1216724186023919616"
  }
}, {
  "following" : {
    "accountId" : "1190869429854199808",
    "userLink" : "https://twitter.com/intent/user?user_id=1190869429854199808"
  }
}, {
  "following" : {
    "accountId" : "2814768398",
    "userLink" : "https://twitter.com/intent/user?user_id=2814768398"
  }
}, {
  "following" : {
    "accountId" : "9646822",
    "userLink" : "https://twitter.com/intent/user?user_id=9646822"
  }
}, {
  "following" : {
    "accountId" : "4802617320",
    "userLink" : "https://twitter.com/intent/user?user_id=4802617320"
  }
}, {
  "following" : {
    "accountId" : "1173930799550197762",
    "userLink" : "https://twitter.com/intent/user?user_id=1173930799550197762"
  }
}, {
  "following" : {
    "accountId" : "150093359",
    "userLink" : "https://twitter.com/intent/user?user_id=150093359"
  }
}, {
  "following" : {
    "accountId" : "1228524226140762113",
    "userLink" : "https://twitter.com/intent/user?user_id=1228524226140762113"
  }
}, {
  "following" : {
    "accountId" : "1139422452147056641",
    "userLink" : "https://twitter.com/intent/user?user_id=1139422452147056641"
  }
}, {
  "following" : {
    "accountId" : "1239287030",
    "userLink" : "https://twitter.com/intent/user?user_id=1239287030"
  }
} ]