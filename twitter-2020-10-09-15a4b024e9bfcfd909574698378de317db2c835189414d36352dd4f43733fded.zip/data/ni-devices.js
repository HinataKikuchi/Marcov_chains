window.YTD.ni_devices.part0 = [ {
  "niDeviceResponse" : {
    "messagingDevice" : {
      "deviceType" : "Full",
      "carrier" : "jp.au",
      "phoneNumber" : "+819057980486",
      "createdDate" : "2020.02.15"
    }
  }
} ]