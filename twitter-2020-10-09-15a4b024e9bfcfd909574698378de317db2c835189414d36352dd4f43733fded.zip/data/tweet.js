window.YTD.tweet.part0 = [ {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "73" ],
    "favorite_count" : "0",
    "id_str" : "1235591124409929731",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1235591124409929731",
    "created_at" : "Thu Mar 05 15:40:54 +0000 2020",
    "favorited" : false,
    "full_text" : "4月…ピシン本当にやるの？\nってか、学校始められるのかな…\nホテル勤めの友人は仕事がどんどん有給なってくし、街に人はいないし、これいつまで続くの？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "モトキ@42piscine",
        "screen_name" : "mtnn7j",
        "indices" : [ "0", "7" ],
        "id_str" : "1231618474515894272",
        "id" : "1231618474515894272"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "75" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1234417092033576960",
    "id_str" : "1234463537860239361",
    "in_reply_to_user_id" : "1231618474515894272",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1234463537860239361",
    "in_reply_to_status_id" : "1234417092033576960",
    "created_at" : "Mon Mar 02 13:00:17 +0000 2020",
    "favorited" : false,
    "full_text" : "@mtnn7j お気遣いありがとうございます😭\nできるだけ勉強を先にして、滞在時間が短くなってしまってもなんとかなるようにできたらと思います…🙇‍♀️",
    "lang" : "ja",
    "in_reply_to_screen_name" : "mtnn7j",
    "in_reply_to_user_id_str" : "1231618474515894272"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "7" ],
    "favorite_count" : "0",
    "id_str" : "1234365198602919937",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1234365198602919937",
    "created_at" : "Mon Mar 02 06:29:31 +0000 2020",
    "favorited" : false,
    "full_text" : "自分でやるか…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "69" ],
    "favorite_count" : "1",
    "id_str" : "1234364896474624001",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1234364896474624001",
    "created_at" : "Mon Mar 02 06:28:19 +0000 2020",
    "favorited" : false,
    "full_text" : "来月から学校で、地方にいるので\npiscine通うなら新幹線使わなくても定期代は5万5千円\n\nこれでもやばいのに、授業がかぶればいけない。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "48" ],
    "favorite_count" : "1",
    "id_str" : "1234307803818233856",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1234307803818233856",
    "created_at" : "Mon Mar 02 02:41:27 +0000 2020",
    "favorited" : false,
    "full_text" : "あー…4月に開催されるとフルコミットは不可能…\nそして定期代金は3倍にはね上がる…\n…落ちる系？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1233583691525345280/photo/1",
        "indices" : [ "33", "56" ],
        "url" : "https://t.co/HycCx0b4PJ",
        "media_url" : "http://pbs.twimg.com/media/ER6R0h5UcAAwx0l.jpg",
        "id_str" : "1233583679584104448",
        "id" : "1233583679584104448",
        "media_url_https" : "https://pbs.twimg.com/media/ER6R0h5UcAAwx0l.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/HycCx0b4PJ"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "56" ],
    "favorite_count" : "0",
    "id_str" : "1233583691525345280",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1233583691525345280",
    "possibly_sensitive" : false,
    "created_at" : "Sat Feb 29 02:44:05 +0000 2020",
    "favorited" : false,
    "full_text" : "掘り返したら昔の授業出てきた…\nアセンブラとか読めてもかけない… https://t.co/HycCx0b4PJ",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1233583691525345280/photo/1",
        "indices" : [ "33", "56" ],
        "url" : "https://t.co/HycCx0b4PJ",
        "media_url" : "http://pbs.twimg.com/media/ER6R0h5UcAAwx0l.jpg",
        "id_str" : "1233583679584104448",
        "id" : "1233583679584104448",
        "media_url_https" : "https://pbs.twimg.com/media/ER6R0h5UcAAwx0l.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/HycCx0b4PJ"
      }, {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1233583691525345280/photo/1",
        "indices" : [ "33", "56" ],
        "url" : "https://t.co/HycCx0b4PJ",
        "media_url" : "http://pbs.twimg.com/media/ER6R0h4VUAA1Uc-.jpg",
        "id_str" : "1233583679579967488",
        "id" : "1233583679579967488",
        "media_url_https" : "https://pbs.twimg.com/media/ER6R0h4VUAA1Uc-.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/HycCx0b4PJ"
      }, {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1233583691525345280/photo/1",
        "indices" : [ "33", "56" ],
        "url" : "https://t.co/HycCx0b4PJ",
        "media_url" : "http://pbs.twimg.com/media/ER6R0iAVUAAF6gj.jpg",
        "id_str" : "1233583679613521920",
        "id" : "1233583679613521920",
        "media_url_https" : "https://pbs.twimg.com/media/ER6R0iAVUAAF6gj.jpg",
        "sizes" : {
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/HycCx0b4PJ"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Wolke",
        "screen_name" : "Wolke0225",
        "indices" : [ "0", "10" ],
        "id_str" : "1052117719",
        "id" : "1052117719"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "61" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1233288581013131264",
    "id_str" : "1233309583667412992",
    "in_reply_to_user_id" : "1052117719",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1233309583667412992",
    "in_reply_to_status_id" : "1233288581013131264",
    "created_at" : "Fri Feb 28 08:34:53 +0000 2020",
    "favorited" : false,
    "full_text" : "@Wolke0225 @OdashimaTats 集まることでコロナの可能性が高まるかもしれないので、ここはskypeで…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Wolke0225",
    "in_reply_to_user_id_str" : "1052117719"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "",
        "screen_name" : "oz1aBSgWCmMvmY6",
        "indices" : [ "3", "19" ],
        "id_str" : "-1",
        "id" : "-1"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/oz1aBSgWCmMvmY6/status/1233280439005020160/photo/1",
        "source_status_id" : "1233280439005020160",
        "indices" : [ "37", "60" ],
        "url" : "https://t.co/Z80COcRaqD",
        "media_url" : "http://pbs.twimg.com/media/ER1-BYUUEAA5MhG.jpg",
        "id_str" : "1233280435142004736",
        "source_user_id" : "1215846687039557632",
        "id" : "1233280435142004736",
        "media_url_https" : "https://pbs.twimg.com/media/ER1-BYUUEAA5MhG.jpg",
        "source_user_id_str" : "1215846687039557632",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "750",
            "h" : "1334",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "675",
            "h" : "1200",
            "resize" : "fit"
          },
          "small" : {
            "w" : "382",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1233280439005020160",
        "display_url" : "pic.twitter.com/Z80COcRaqD"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "60" ],
    "favorite_count" : "0",
    "id_str" : "1233308697318658048",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1233308697318658048",
    "possibly_sensitive" : false,
    "created_at" : "Fri Feb 28 08:31:21 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @oz1aBSgWCmMvmY6: 残念だ、、\n拡散お願いします。 https://t.co/Z80COcRaqD",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/oz1aBSgWCmMvmY6/status/1233280439005020160/photo/1",
        "source_status_id" : "1233280439005020160",
        "indices" : [ "37", "60" ],
        "url" : "https://t.co/Z80COcRaqD",
        "media_url" : "http://pbs.twimg.com/media/ER1-BYUUEAA5MhG.jpg",
        "id_str" : "1233280435142004736",
        "source_user_id" : "1215846687039557632",
        "id" : "1233280435142004736",
        "media_url_https" : "https://pbs.twimg.com/media/ER1-BYUUEAA5MhG.jpg",
        "source_user_id_str" : "1215846687039557632",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "750",
            "h" : "1334",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "675",
            "h" : "1200",
            "resize" : "fit"
          },
          "small" : {
            "w" : "382",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1233280439005020160",
        "display_url" : "pic.twitter.com/Z80COcRaqD"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "70" ],
    "favorite_count" : "2",
    "id_str" : "1233305575242358785",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1233305575242358785",
    "created_at" : "Fri Feb 28 08:18:57 +0000 2020",
    "favorited" : false,
    "full_text" : "ここはポジティブに…\n定期はまだ買ってなかったし、休日使ってお金稼げるし、お勉強できる…\n\nでもやっぱり、まだみぬ仲間に会いたかった感ある😭",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "42Tokyo",
        "indices" : [ "37", "45" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Wolke",
        "screen_name" : "Wolke0225",
        "indices" : [ "3", "13" ],
        "id_str" : "1052117719",
        "id" : "1052117719"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "45" ],
    "favorite_count" : "0",
    "id_str" : "1233304173824729089",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1233304173824729089",
    "created_at" : "Fri Feb 28 08:13:23 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Wolke0225: もう３月組で集まってなんかしたらいいのか？ #42Tokyo",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/tZ7PEWz0XU",
        "expanded_url" : "https://twitter.com/nhigh_info/status/1233274654434873344",
        "display_url" : "twitter.com/nhigh_info/sta…",
        "indices" : [ "9", "32" ]
      } ]
    },
    "display_text_range" : [ "0", "32" ],
    "favorite_count" : "0",
    "id_str" : "1233304055264370688",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1233304055264370688",
    "possibly_sensitive" : false,
    "created_at" : "Fri Feb 28 08:12:55 +0000 2020",
    "favorited" : false,
    "full_text" : "ありだなぁこれ… https://t.co/tZ7PEWz0XU",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "16" ],
    "favorite_count" : "0",
    "id_str" : "1233303627793485825",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1233303627793485825",
    "created_at" : "Fri Feb 28 08:11:13 +0000 2020",
    "favorited" : false,
    "full_text" : "ワンちゃん、夏休み開催なら…？🤔",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "67" ],
    "favorite_count" : "1",
    "id_str" : "1233301929381392384",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1233301929381392384",
    "created_at" : "Fri Feb 28 08:04:28 +0000 2020",
    "favorited" : false,
    "full_text" : "あー…まずいな…\n春休みは3月で終わってしまう…\n普段は地方大に通ってるのにこれでは次のpiscineがあっても参加できないのでは……",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "こーよん",
        "screen_name" : "kouykibi",
        "indices" : [ "0", "9" ],
        "id_str" : "1183536314",
        "id" : "1183536314"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1232621756487127046",
    "id_str" : "1232688141103820800",
    "in_reply_to_user_id" : "1183536314",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1232688141103820800",
    "in_reply_to_status_id" : "1232621756487127046",
    "created_at" : "Wed Feb 26 15:25:29 +0000 2020",
    "favorited" : false,
    "full_text" : "@kouykibi 是非是非よろしくお願いします🤲",
    "lang" : "ja",
    "in_reply_to_screen_name" : "kouykibi",
    "in_reply_to_user_id_str" : "1183536314"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "109" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1230082149543378944",
    "id_str" : "1230091887320547328",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1230091887320547328",
    "in_reply_to_status_id" : "1230082149543378944",
    "created_at" : "Wed Feb 19 11:28:54 +0000 2020",
    "favorited" : false,
    "full_text" : "pyなんてリファレンス読めばできる🤬と心の中で愚痴を言いつつも\n実際に何か作りたい時に自分が必要とするのはCとかではなくて、言い返せなかったので\n\npiscineでなにかCについて得られたらってのを目標に強く生きます😂",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "100" ],
    "favorite_count" : "0",
    "id_str" : "1230082149543378944",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1230082149543378944",
    "created_at" : "Wed Feb 19 10:50:12 +0000 2020",
    "favorited" : false,
    "full_text" : "だって！かっこいいじゃん！\n自分の作りたいもの作れたら！ってのと\n\n「へーお前の学校Cしかやんねーのださー。俺の学校pyもやってるしC#だぜー？」とかいう上から男子をみかえしたかったんですよ\n↓つづく",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "96" ],
    "favorite_count" : "2",
    "id_str" : "1230071443594956802",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1230071443594956802",
    "created_at" : "Wed Feb 19 10:07:40 +0000 2020",
    "favorited" : false,
    "full_text" : "どうしよう、Twitterにいるpiscine生みんな自分のしたいことあってきてる…\n私長年解決しないkotlin習得問題と学校以外の世界を見たいってだけでエントリーしたのってダメだったかな…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1229377103272923136",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1229377103272923136",
    "created_at" : "Mon Feb 17 12:08:36 +0000 2020",
    "favorited" : false,
    "full_text" : "未だに&amp;と*とがごったになるのやめたい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "3",
    "id_str" : "1229376708614057985",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1229376708614057985",
    "created_at" : "Mon Feb 17 12:07:02 +0000 2020",
    "favorited" : false,
    "full_text" : "piscine全く勉強してない…やばいかな……\nやばいよな🤔",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "ぶんどき@GooglePixel4aを愛でる垢",
        "screen_name" : "bundoki360",
        "indices" : [ "0", "11" ],
        "id_str" : "150093359",
        "id" : "150093359"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1228631154699333632",
    "id_str" : "1228668838868242432",
    "in_reply_to_user_id" : "150093359",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1228668838868242432",
    "in_reply_to_status_id" : "1228631154699333632",
    "created_at" : "Sat Feb 15 13:14:13 +0000 2020",
    "favorited" : false,
    "full_text" : "@bundoki360 こちらこそ！",
    "lang" : "ja",
    "in_reply_to_screen_name" : "bundoki360",
    "in_reply_to_user_id_str" : "150093359"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "42tokyo",
        "indices" : [ "0", "8" ]
      }, {
        "text" : "42トーキョー",
        "indices" : [ "9", "17" ]
      }, {
        "text" : "piscine",
        "indices" : [ "18", "26" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "26" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1228569734519476224",
    "id_str" : "1228595563035103232",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1228595563035103232",
    "in_reply_to_status_id" : "1228569734519476224",
    "created_at" : "Sat Feb 15 08:23:03 +0000 2020",
    "favorited" : false,
    "full_text" : "#42tokyo #42トーキョー #piscine",
    "lang" : "und",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "78" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1228572042401738752",
    "id_str" : "1228573868874293248",
    "in_reply_to_user_id" : "1228524226140762113",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1228573868874293248",
    "in_reply_to_status_id" : "1228572042401738752",
    "created_at" : "Sat Feb 15 06:56:50 +0000 2020",
    "favorited" : false,
    "full_text" : "@shinichi__fire すごかったですね…応援したくなる雰囲気と自分もあの中に入ってやっていけるかの不安が…w\n是非是非！3/2楽しみにしています💪",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Shinichi_0style",
    "in_reply_to_user_id_str" : "1228524226140762113"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "57" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1228569292628615169",
    "id_str" : "1228571286445510656",
    "in_reply_to_user_id" : "1228524226140762113",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1228571286445510656",
    "in_reply_to_status_id" : "1228569292628615169",
    "created_at" : "Sat Feb 15 06:46:35 +0000 2020",
    "favorited" : false,
    "full_text" : "@shinichi__fire ついさっき行ってしまいました…コミュ障発揮してる内に誰とも会話できず終了しました😭",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Shinichi_0style",
    "in_reply_to_user_id_str" : "1228524226140762113"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "67" ],
    "favorite_count" : "5",
    "id_str" : "1228569734519476224",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1228569734519476224",
    "created_at" : "Sat Feb 15 06:40:25 +0000 2020",
    "favorited" : false,
    "full_text" : "42tokyoのタグで見つけた人を無言フォローしてます…嫌だったらごめんなさい🙇‍♀️\nブロッコリー畑に埋められても大丈夫です🙆‍♀️",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1228527852649271296",
    "id_str" : "1228568169498857474",
    "in_reply_to_user_id" : "1228524226140762113",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1228568169498857474",
    "in_reply_to_status_id" : "1228527852649271296",
    "created_at" : "Sat Feb 15 06:34:11 +0000 2020",
    "favorited" : false,
    "full_text" : "@shinichi__fire 私も3月参加するのでよろしくお願いします🤲",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Shinichi_0style",
    "in_reply_to_user_id_str" : "1228524226140762113"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "85" ],
    "favorite_count" : "0",
    "id_str" : "1245918885041197056",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1245918885041197056",
    "created_at" : "Fri Apr 03 03:39:44 +0000 2020",
    "favorited" : false,
    "full_text" : "今こそmmt理論使ったら良いのでは？\nもちろん、お金の流通量は国も本当の意味で(貯蓄など)は自由にできないだろうけど\nそれでも今は人を助けるためにお金必要なのでは？？？？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "17" ],
    "favorite_count" : "0",
    "id_str" : "1245172411617538050",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1245172411617538050",
    "created_at" : "Wed Apr 01 02:13:31 +0000 2020",
    "favorited" : false,
    "full_text" : "あー、背脂こってりラーメン食べたい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "20" ],
    "favorite_count" : "0",
    "id_str" : "1244891243902951425",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1244891243902951425",
    "created_at" : "Tue Mar 31 07:36:16 +0000 2020",
    "favorited" : false,
    "full_text" : "フーリエ解析の授業もう一度受けたいかも…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "66" ],
    "favorite_count" : "0",
    "id_str" : "1244891067264065537",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1244891067264065537",
    "created_at" : "Tue Mar 31 07:35:34 +0000 2020",
    "favorited" : false,
    "full_text" : "マスクにハッカ油かけたら、まさか目にしみるという副作用\n\nすーすーするーくらいで済んでくれたらよかったが、さすがにこれは使えぬ(((",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1244515437909389312/photo/1",
        "indices" : [ "19", "42" ],
        "url" : "https://t.co/55Z2kL5Mfj",
        "media_url" : "http://pbs.twimg.com/media/EUVoC-VUcAUruWf.jpg",
        "id_str" : "1244515272339255301",
        "id" : "1244515272339255301",
        "media_url_https" : "https://pbs.twimg.com/media/EUVoC-VUcAUruWf.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/55Z2kL5Mfj"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "42" ],
    "favorite_count" : "0",
    "id_str" : "1244515437909389312",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1244515437909389312",
    "possibly_sensitive" : false,
    "created_at" : "Mon Mar 30 06:42:57 +0000 2020",
    "favorited" : false,
    "full_text" : "家のマスクが切れたので手作りしました https://t.co/55Z2kL5Mfj",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1244515437909389312/photo/1",
        "indices" : [ "19", "42" ],
        "url" : "https://t.co/55Z2kL5Mfj",
        "media_url" : "http://pbs.twimg.com/media/EUVoC-VUcAUruWf.jpg",
        "id_str" : "1244515272339255301",
        "id" : "1244515272339255301",
        "media_url_https" : "https://pbs.twimg.com/media/EUVoC-VUcAUruWf.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/55Z2kL5Mfj"
      }, {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1244515437909389312/photo/1",
        "indices" : [ "19", "42" ],
        "url" : "https://t.co/55Z2kL5Mfj",
        "media_url" : "http://pbs.twimg.com/media/EUVoDHRU0AM76L5.jpg",
        "id_str" : "1244515274738421763",
        "id" : "1244515274738421763",
        "media_url_https" : "https://pbs.twimg.com/media/EUVoDHRU0AM76L5.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/55Z2kL5Mfj"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/OA3M9UeoVq",
        "expanded_url" : "https://www.cybergadget.co.jp/products/4544859028823.html",
        "display_url" : "cybergadget.co.jp/products/45448…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "58" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1243957113962913792",
    "id_str" : "1243957545938505733",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1243957545938505733",
    "in_reply_to_status_id" : "1243957113962913792",
    "possibly_sensitive" : false,
    "created_at" : "Sat Mar 28 17:46:05 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/OA3M9UeoVq\n\n日本製だし大丈夫だろうと思って高い値段出したらこれってもう、あの…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "169" ],
    "favorite_count" : "0",
    "id_str" : "1243957113962913792",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1243957113962913792",
    "created_at" : "Sat Mar 28 17:44:22 +0000 2020",
    "favorited" : false,
    "full_text" : "いまNintendo Switch Liteを使う時、Bluetoothイヤフォンが使えないのでアダプターにcyber bluetoothオーディオトランスミッターを使っている。\nが、1週間ちょいで壊れた。¥5,000もしたのに。イヤフォンはふつうにスマホにつながるし、switchも問題ない。\n製品が壊れるようなことしてないのに…なぜ…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "52" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1242293321252233216",
    "id_str" : "1243417289036156930",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1243417289036156930",
    "in_reply_to_status_id" : "1242293321252233216",
    "created_at" : "Fri Mar 27 05:59:17 +0000 2020",
    "favorited" : false,
    "full_text" : "piscine運営の中の人もコロナに対して同じこと思ってそう…\n誰が悪いとかではないので悪しからず(((",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "83" ],
    "favorite_count" : "3",
    "id_str" : "1243416952300699649",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1243416952300699649",
    "created_at" : "Fri Mar 27 05:57:57 +0000 2020",
    "favorited" : false,
    "full_text" : "延期ってわかったので、とりあえずはバイトを入れて隙間でお勉強…\n\n大学も始業延期だし、ピシンもいつ始まるかわからないし、春休みが多くなったと思ってお金稼いで勉強しよう",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/XnXwx7nDEz",
        "expanded_url" : "https://m.youtube.com/watch?v=QNJL6nfu__Q",
        "display_url" : "m.youtube.com/watch?v=QNJL6n…",
        "indices" : [ "97", "120" ]
      } ]
    },
    "display_text_range" : [ "0", "120" ],
    "favorite_count" : "0",
    "id_str" : "1242798475667845128",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1242798475667845128",
    "possibly_sensitive" : false,
    "created_at" : "Wed Mar 25 13:00:21 +0000 2020",
    "favorited" : false,
    "full_text" : "最近この曲を聴きながらバイトに行くけれど、政府のコロナ対策が発表されてそれが的外れだったりするときのツイッター民の心情はこれなのかなと思う。\n\n国民が憤ってしまった時の声はこんな音がしそう。\n\nhttps://t.co/XnXwx7nDEz",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "32" ],
    "favorite_count" : "8",
    "id_str" : "1242293321252233216",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1242293321252233216",
    "created_at" : "Tue Mar 24 03:33:03 +0000 2020",
    "favorited" : false,
    "full_text" : "あの、42tokyoあるかわからないと全く予定が立たないんですが",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "43" ],
    "favorite_count" : "0",
    "id_str" : "1239536242728955904",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239536242728955904",
    "created_at" : "Mon Mar 16 12:57:24 +0000 2020",
    "favorited" : false,
    "full_text" : "あれ？matplotlibで作ったグラフの拡張子って何？\nファイルに作成されないの何？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "13" ],
    "favorite_count" : "1",
    "id_str" : "1239493156069978112",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1239493156069978112",
    "created_at" : "Mon Mar 16 10:06:11 +0000 2020",
    "favorited" : false,
    "full_text" : "え、結局ピシンどうなるの？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "138" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1237746474672250881",
    "id_str" : "1237747331144896512",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1237747331144896512",
    "in_reply_to_status_id" : "1237746474672250881",
    "created_at" : "Wed Mar 11 14:28:54 +0000 2020",
    "favorited" : false,
    "full_text" : "今回、コロナの影響で、ファンタズミックは最後の公演を待つことなく終了するかもしれません。\nけどこれから始まる違うショーもまた、誰かの人生を変えるかもしれません。\nでも叶うならまたファンタズミックが見たいです。私の人生を変えてくれてありがとう、また次の機会を楽しみにしています。",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1237746474672250881/photo/1",
        "indices" : [ "139", "162" ],
        "url" : "https://t.co/Gv4g5tU8cZ",
        "media_url" : "http://pbs.twimg.com/media/ES1b0LvU4AUmeRQ.jpg",
        "id_str" : "1237746424659369989",
        "id" : "1237746424659369989",
        "media_url_https" : "https://pbs.twimg.com/media/ES1b0LvU4AUmeRQ.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/Gv4g5tU8cZ"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "162" ],
    "favorite_count" : "6",
    "id_str" : "1237746474672250881",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1237746474672250881",
    "possibly_sensitive" : false,
    "created_at" : "Wed Mar 11 14:25:30 +0000 2020",
    "favorited" : false,
    "full_text" : "このアカウントで言うのは違うかもしれませんが他に場所がないので一度だけ。\n\n高校1年生の2学期に初めてファンタズミックを見ました。感動で大泣きして、いつかこのシステムを作る人になりたいと思い3年生で物理学系の理系に進級しました。\nあの時の体験がなければ今の私はいません。→続く https://t.co/Gv4g5tU8cZ",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1237746474672250881/photo/1",
        "indices" : [ "139", "162" ],
        "url" : "https://t.co/Gv4g5tU8cZ",
        "media_url" : "http://pbs.twimg.com/media/ES1b0LvU4AUmeRQ.jpg",
        "id_str" : "1237746424659369989",
        "id" : "1237746424659369989",
        "media_url_https" : "https://pbs.twimg.com/media/ES1b0LvU4AUmeRQ.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/Gv4g5tU8cZ"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1237409676771250177",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1237409676771250177",
    "created_at" : "Tue Mar 10 16:07:11 +0000 2020",
    "favorited" : false,
    "full_text" : "あー、フォトナ とmonsterで優勝したい\nついでにスナックも食いながら一徹フォトナやりたい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "45" ],
    "favorite_count" : "0",
    "id_str" : "1237269944204578817",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1237269944204578817",
    "created_at" : "Tue Mar 10 06:51:56 +0000 2020",
    "favorited" : false,
    "full_text" : "相関調べられるなら\nMARS,SARSのデータからコロナの収束時期とか予測できないかなぁー",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "101" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1237257899174289408",
    "id_str" : "1237260259225264128",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1237260259225264128",
    "in_reply_to_status_id" : "1237257899174289408",
    "created_at" : "Tue Mar 10 06:13:27 +0000 2020",
    "favorited" : false,
    "full_text" : "考えてみたらメソッドの中身を理解できてる気がしない。\nバラバラのデータのフーリエ変換ってどうやってるんだろう…\n関数のフーリエ変換しかやったことないや…\n\nそもそも無限大とか複素数とかどうしてるんだ…？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "55" ],
    "favorite_count" : "0",
    "id_str" : "1237257899174289408",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1237257899174289408",
    "created_at" : "Tue Mar 10 06:04:04 +0000 2020",
    "favorited" : false,
    "full_text" : "データの正規化ができるとかいう記事も見つけたけれど\nこちらはメソッドがpyに認識してもらえなかったので持ち越し",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "79" ],
    "favorite_count" : "0",
    "id_str" : "1237257604272775168",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1237257604272775168",
    "created_at" : "Tue Mar 10 06:02:54 +0000 2020",
    "favorited" : false,
    "full_text" : "pyでexcelデータ触れるようになったので、試しに株価とか漁ってたら\nフーリエ変換で株価予想とか面白そうな記事を発見…\n\n前学期の復習がてら試しにやってみよ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "\\ ほんまるひなた /",
        "screen_name" : "hinatazaurusu",
        "indices" : [ "0", "14" ],
        "id_str" : "855631594911973376",
        "id" : "855631594911973376"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "22" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1236182413371293696",
    "id_str" : "1236596100070436866",
    "in_reply_to_user_id" : "855631594911973376",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1236596100070436866",
    "in_reply_to_status_id" : "1236182413371293696",
    "created_at" : "Sun Mar 08 10:14:19 +0000 2020",
    "favorited" : false,
    "full_text" : "@hinatazaurusu 深呼吸しましょ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hinatazaurusu",
    "in_reply_to_user_id_str" : "855631594911973376"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "45" ],
    "favorite_count" : "0",
    "id_str" : "1236595988648747008",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1236595988648747008",
    "created_at" : "Sun Mar 08 10:13:53 +0000 2020",
    "favorited" : false,
    "full_text" : "エクセルからpyに送れるなら\ngoogleのスプレッドシートからpyに送れないかな\nだめ？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "0",
    "id_str" : "1236595390922649600",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1236595390922649600",
    "created_at" : "Sun Mar 08 10:11:30 +0000 2020",
    "favorited" : false,
    "full_text" : "脳みそが溶けて耳から流れてる気がする",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "48" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1235591124409929731",
    "id_str" : "1235592161871179777",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1235592161871179777",
    "in_reply_to_status_id" : "1235591124409929731",
    "created_at" : "Thu Mar 05 15:45:02 +0000 2020",
    "favorited" : false,
    "full_text" : "と、後ろ向きなこと話しても不安しか募らないから今日は寝て\n明日ゲームとオベンキョとバイトがんばろ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "64" ],
    "favorite_count" : "1",
    "id_str" : "1306508736152743941",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306508736152743941",
    "created_at" : "Thu Sep 17 08:22:11 +0000 2020",
    "favorited" : false,
    "full_text" : "スプラは1試合マッチング合わせても5分\n\nフォトナ は生き残っちゃうと30分、ダメなら最短3分。\n\n休むときにやるならスプラ安定",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "12" ],
    "favorite_count" : "1",
    "id_str" : "1306508473799045120",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306508473799045120",
    "created_at" : "Thu Sep 17 08:21:08 +0000 2020",
    "favorited" : false,
    "full_text" : "眠いからスプラやる(?)",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "さにー",
        "screen_name" : "sunnylang2019",
        "indices" : [ "0", "14" ],
        "id_str" : "1199683722787713026",
        "id" : "1199683722787713026"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1306476751619407872",
    "id_str" : "1306508357394739200",
    "in_reply_to_user_id" : "1199683722787713026",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306508357394739200",
    "in_reply_to_status_id" : "1306476751619407872",
    "created_at" : "Thu Sep 17 08:20:40 +0000 2020",
    "favorited" : false,
    "full_text" : "@sunnylang2019 同じく",
    "lang" : "ja",
    "in_reply_to_screen_name" : "sunnylang2019",
    "in_reply_to_user_id_str" : "1199683722787713026"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "フォートナイト",
        "screen_name" : "FortniteJP",
        "indices" : [ "3", "14" ],
        "id_str" : "958264156683091969",
        "id" : "958264156683091969"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/FortniteJP/status/1306411357114265601/video/1",
        "source_status_id" : "1306411357114265601",
        "indices" : [ "94", "117" ],
        "url" : "https://t.co/sREsRD0uz0",
        "media_url" : "http://pbs.twimg.com/media/EiFN31TUwAEBFAE.jpg",
        "id_str" : "1306410869253758976",
        "source_user_id" : "958264156683091969",
        "id" : "1306410869253758976",
        "media_url_https" : "https://pbs.twimg.com/media/EiFN31TUwAEBFAE.jpg",
        "source_user_id_str" : "958264156683091969",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1280",
            "h" : "720",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1306411357114265601",
        "display_url" : "pic.twitter.com/sREsRD0uz0"
      } ],
      "hashtags" : [ {
        "text" : "UE4",
        "indices" : [ "28", "32" ]
      } ]
    },
    "display_text_range" : [ "0", "117" ],
    "favorite_count" : "0",
    "id_str" : "1306442177866653696",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306442177866653696",
    "possibly_sensitive" : false,
    "created_at" : "Thu Sep 17 03:57:42 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @FortniteJP: プレイステーション5上、#UE4 で撮影されたフォートナイトのゲームプレイを初公開 ！👀\n\n発売日から進行度・購入したものを引き継いで無料プレイ可能です！ https://t.co/sREsRD0uz0",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/FortniteJP/status/1306411357114265601/video/1",
        "source_status_id" : "1306411357114265601",
        "indices" : [ "94", "117" ],
        "url" : "https://t.co/sREsRD0uz0",
        "media_url" : "http://pbs.twimg.com/media/EiFN31TUwAEBFAE.jpg",
        "id_str" : "1306410869253758976",
        "video_info" : {
          "aspect_ratio" : [ "16", "9" ],
          "duration_millis" : "35534",
          "variants" : [ {
            "content_type" : "application/x-mpegURL",
            "url" : "https://video.twimg.com/amplify_video/1306410869253758976/pl/yydlEX-N6aVR_Ehq.m3u8?tag=13"
          }, {
            "bitrate" : "832000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/amplify_video/1306410869253758976/vid/640x360/1bXLGimkfXP7rbql.mp4?tag=13"
          }, {
            "bitrate" : "288000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/amplify_video/1306410869253758976/vid/480x270/ab5yj-7NRUyAi7pS.mp4?tag=13"
          }, {
            "bitrate" : "2176000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/amplify_video/1306410869253758976/vid/1280x720/785albeVEcyifQwa.mp4?tag=13"
          } ]
        },
        "source_user_id" : "958264156683091969",
        "additional_media_info" : {
          "title" : "",
          "description" : "",
          "embeddable" : true,
          "monetizable" : false
        },
        "id" : "1306410869253758976",
        "media_url_https" : "https://pbs.twimg.com/media/EiFN31TUwAEBFAE.jpg",
        "source_user_id_str" : "958264156683091969",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1280",
            "h" : "720",
            "resize" : "fit"
          }
        },
        "type" : "video",
        "source_status_id_str" : "1306411357114265601",
        "display_url" : "pic.twitter.com/sREsRD0uz0"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "46" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1306222446601629696",
    "id_str" : "1306374244926812161",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306374244926812161",
    "in_reply_to_status_id" : "1306222446601629696",
    "created_at" : "Wed Sep 16 23:27:45 +0000 2020",
    "favorited" : false,
    "full_text" : "4.寝る前1時間は画面見ない。布団入ってから何故かドキドキしちゃうから…(トゥンク)))))",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "14" ],
    "favorite_count" : "0",
    "id_str" : "1306362840303808512",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306362840303808512",
    "created_at" : "Wed Sep 16 22:42:26 +0000 2020",
    "favorited" : false,
    "full_text" : "さて、よく寝たし仕事するか。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "88" ],
    "favorite_count" : "6",
    "id_str" : "1306222446601629696",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306222446601629696",
    "created_at" : "Wed Sep 16 13:24:34 +0000 2020",
    "favorited" : false,
    "full_text" : "piscineを泳いで分かったこと。\n\n1.自分の機嫌は自分で取る。そのためには罪悪感を顧みず休む。\n\n2.休んだら、二言はなし。休んだ分仕事する。\n\n3．休むために仕事する。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "11" ],
    "favorite_count" : "0",
    "id_str" : "1306222149288427521",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306222149288427521",
    "created_at" : "Wed Sep 16 13:23:23 +0000 2020",
    "favorited" : false,
    "full_text" : "すげぇ今日よく眠れそう",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "27" ],
    "favorite_count" : "1",
    "id_str" : "1306181216618512384",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306181216618512384",
    "created_at" : "Wed Sep 16 10:40:44 +0000 2020",
    "favorited" : false,
    "full_text" : "と、言うことで自立神経を回復させるために\n\n銭湯へ行く",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "11" ],
    "favorite_count" : "1",
    "id_str" : "1306179782262939648",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306179782262939648",
    "created_at" : "Wed Sep 16 10:35:02 +0000 2020",
    "favorited" : false,
    "full_text" : "そうだよ、運動してない",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "40" ],
    "favorite_count" : "4",
    "id_str" : "1306132850425491457",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306132850425491457",
    "created_at" : "Wed Sep 16 07:28:32 +0000 2020",
    "favorited" : false,
    "full_text" : "韓国語試験と中国語試験とフランス語試験どうしよう、同時に受けるとすげぇかねとぶぞ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "7" ],
    "favorite_count" : "1",
    "id_str" : "1306063431552753664",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306063431552753664",
    "created_at" : "Wed Sep 16 02:52:42 +0000 2020",
    "favorited" : false,
    "full_text" : "tds行きたい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "1",
    "id_str" : "1306062818081292290",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306062818081292290",
    "created_at" : "Wed Sep 16 02:50:15 +0000 2020",
    "favorited" : false,
    "full_text" : "あー、キーキャップ買ったところで所持金尽きる未来が見えた",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "11", "21" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1306043736204349442",
    "id_str" : "1306045104893747201",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306045104893747201",
    "in_reply_to_status_id" : "1306043736204349442",
    "created_at" : "Wed Sep 16 01:39:52 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @_unlimish おは",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "3", "13" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "Hinata",
        "screen_name" : "Hinata72279726",
        "indices" : [ "15", "30" ],
        "id_str" : "1228559135093821441",
        "id" : "1228559135093821441"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "49" ],
    "favorite_count" : "0",
    "id_str" : "1306044678303694848",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306044678303694848",
    "created_at" : "Wed Sep 16 01:38:11 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @luna_yuta: @Hinata72279726 --exclude-unlimish",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "17" ],
    "favorite_count" : "1",
    "id_str" : "1306003062423564288",
    "truncated" : false,
    "retweet_count" : "1",
    "id" : "1306003062423564288",
    "created_at" : "Tue Sep 15 22:52:49 +0000 2020",
    "favorited" : false,
    "full_text" : "今日はみんなちゃんと起きてるらしい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "じゃみー",
        "screen_name" : "zmallik2",
        "indices" : [ "0", "9" ],
        "id_str" : "1302766029177679873",
        "id" : "1302766029177679873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1306001121672966144",
    "id_str" : "1306001258369576960",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306001258369576960",
    "in_reply_to_status_id" : "1306001121672966144",
    "created_at" : "Tue Sep 15 22:45:38 +0000 2020",
    "favorited" : false,
    "full_text" : "@zmallik2 ただし私がいる時だけなのだが大丈夫？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "じゃみー",
        "screen_name" : "zmallik2",
        "indices" : [ "0", "9" ],
        "id_str" : "1302766029177679873",
        "id" : "1302766029177679873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "14" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1305883728464343046",
    "id_str" : "1306001121672966144",
    "in_reply_to_user_id" : "1302766029177679873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306001121672966144",
    "in_reply_to_status_id" : "1305883728464343046",
    "created_at" : "Tue Sep 15 22:45:06 +0000 2020",
    "favorited" : false,
    "full_text" : "@zmallik2 いーおー",
    "lang" : "ja",
    "in_reply_to_screen_name" : "zmallik2",
    "in_reply_to_user_id_str" : "1302766029177679873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "☃",
        "screen_name" : "jpnykw",
        "indices" : [ "3", "10" ],
        "id_str" : "4802617320",
        "id" : "4802617320"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "63" ],
    "favorite_count" : "0",
    "id_str" : "1305878816955330560",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305878816955330560",
    "created_at" : "Tue Sep 15 14:39:06 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @jpnykw: ねこは人間には理解できないことを常に考えています、だから猫は何を考えているのかわかりません、人間が愚か",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "17" ],
    "favorite_count" : "1",
    "id_str" : "1305877317596585984",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305877317596585984",
    "created_at" : "Tue Sep 15 14:33:09 +0000 2020",
    "favorited" : false,
    "full_text" : "コミットができないので寝ますお休み",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "じゃみー",
        "screen_name" : "zmallik2",
        "indices" : [ "0", "9" ],
        "id_str" : "1302766029177679873",
        "id" : "1302766029177679873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1305866352075341827",
    "id_str" : "1305877170032500737",
    "in_reply_to_user_id" : "1302766029177679873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305877170032500737",
    "in_reply_to_status_id" : "1305866352075341827",
    "created_at" : "Tue Sep 15 14:32:34 +0000 2020",
    "favorited" : false,
    "full_text" : "@zmallik2 _(┐「ε:)_助けに来た",
    "lang" : "ja",
    "in_reply_to_screen_name" : "zmallik2",
    "in_reply_to_user_id_str" : "1302766029177679873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "5" ],
    "favorite_count" : "0",
    "id_str" : "1305824236443824128",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305824236443824128",
    "created_at" : "Tue Sep 15 11:02:13 +0000 2020",
    "favorited" : false,
    "full_text" : "眠くて辛い",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "26" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1305793089466822656",
    "id_str" : "1305795330781319168",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305795330781319168",
    "in_reply_to_status_id" : "1305793089466822656",
    "created_at" : "Tue Sep 15 09:07:22 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish はぁーい(☝︎ ՞ਊ ՞)☝︎",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "26" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1305792426448023553",
    "id_str" : "1305792783647563779",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305792783647563779",
    "in_reply_to_status_id" : "1305792426448023553",
    "created_at" : "Tue Sep 15 08:57:14 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish りみおねぇさまぁ(´；Д；`)",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "19" ],
    "favorite_count" : "1",
    "id_str" : "1305792141566775296",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305792141566775296",
    "created_at" : "Tue Sep 15 08:54:41 +0000 2020",
    "favorited" : false,
    "full_text" : "外に出たいがテストで外に出るのは嫌だ。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1306863539101995014/photo/1",
        "indices" : [ "13", "36" ],
        "url" : "https://t.co/0CM9hzDL1T",
        "media_url" : "http://pbs.twimg.com/media/EiLpc_lU8AEflWO.jpg",
        "id_str" : "1306863526204469249",
        "id" : "1306863526204469249",
        "media_url_https" : "https://pbs.twimg.com/media/EiLpc_lU8AEflWO.jpg",
        "sizes" : {
          "large" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/0CM9hzDL1T"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "36" ],
    "favorite_count" : "2",
    "id_str" : "1306863539101995014",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306863539101995014",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 18 07:52:02 +0000 2020",
    "favorited" : false,
    "full_text" : "_(┐「ε:)_めもした https://t.co/0CM9hzDL1T",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1306863539101995014/photo/1",
        "indices" : [ "13", "36" ],
        "url" : "https://t.co/0CM9hzDL1T",
        "media_url" : "http://pbs.twimg.com/media/EiLpc_lU8AEflWO.jpg",
        "id_str" : "1306863526204469249",
        "id" : "1306863526204469249",
        "media_url_https" : "https://pbs.twimg.com/media/EiLpc_lU8AEflWO.jpg",
        "sizes" : {
          "large" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/0CM9hzDL1T"
      }, {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1306863539101995014/photo/1",
        "indices" : [ "13", "36" ],
        "url" : "https://t.co/0CM9hzDL1T",
        "media_url" : "http://pbs.twimg.com/media/EiLpc_lUcAIYCGL.jpg",
        "id_str" : "1306863526204436482",
        "id" : "1306863526204436482",
        "media_url_https" : "https://pbs.twimg.com/media/EiLpc_lUcAIYCGL.jpg",
        "sizes" : {
          "medium" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/0CM9hzDL1T"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1306863307735748608/photo/1",
        "indices" : [ "31", "54" ],
        "url" : "https://t.co/OKt67Wfv76",
        "media_url" : "http://pbs.twimg.com/media/EiLpPVCU8AgTrKB.jpg",
        "id_str" : "1306863291445080072",
        "id" : "1306863291445080072",
        "media_url_https" : "https://pbs.twimg.com/media/EiLpPVCU8AgTrKB.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/OKt67Wfv76"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "54" ],
    "favorite_count" : "1",
    "id_str" : "1306863307735748608",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306863307735748608",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 18 07:51:07 +0000 2020",
    "favorited" : false,
    "full_text" : "行きつけのお店が閉まってたのでまぜそばしてみた\n\nおいしかた https://t.co/OKt67Wfv76",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1306863307735748608/photo/1",
        "indices" : [ "31", "54" ],
        "url" : "https://t.co/OKt67Wfv76",
        "media_url" : "http://pbs.twimg.com/media/EiLpPVCU8AgTrKB.jpg",
        "id_str" : "1306863291445080072",
        "id" : "1306863291445080072",
        "media_url_https" : "https://pbs.twimg.com/media/EiLpPVCU8AgTrKB.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/OKt67Wfv76"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "†まりあ† 10/17バーイベ",
        "screen_name" : "mar1a_0w0",
        "indices" : [ "3", "13" ],
        "id_str" : "4120251794",
        "id" : "4120251794"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1306843758772645888",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306843758772645888",
    "created_at" : "Fri Sep 18 06:33:26 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @mar1a_0w0: そんなフェラどこで覚えたの。って言われたら明光義塾って答えてる。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "39" ],
    "favorite_count" : "1",
    "id_str" : "1306841698555682817",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306841698555682817",
    "created_at" : "Fri Sep 18 06:25:15 +0000 2020",
    "favorited" : false,
    "full_text" : "あー腹減った死ぬ\n\n唯一コントロールできない病みがお腹減ることって相当動物臭い",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "4",
    "id_str" : "1306840106179813376",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306840106179813376",
    "created_at" : "Fri Sep 18 06:18:55 +0000 2020",
    "favorited" : false,
    "full_text" : "丸亀製麺ではなく、秋葉原のラーメンになりましたまる",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "14" ],
    "favorite_count" : "2",
    "id_str" : "1306839443395887104",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306839443395887104",
    "created_at" : "Fri Sep 18 06:16:17 +0000 2020",
    "favorited" : false,
    "full_text" : "意外とわかること増えたゾー？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "8" ],
    "favorite_count" : "3",
    "id_str" : "1306771945971539970",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306771945971539970",
    "created_at" : "Fri Sep 18 01:48:05 +0000 2020",
    "favorited" : false,
    "full_text" : "電源切るわ、のし",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1306771482521907200",
    "id_str" : "1306771801398149122",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306771801398149122",
    "in_reply_to_status_id" : "1306771482521907200",
    "created_at" : "Fri Sep 18 01:47:30 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish うっ_:(´ཀ`」 ∠):",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "32" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1306770822875369474",
    "id_str" : "1306770934687178754",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306770934687178754",
    "in_reply_to_status_id" : "1306770822875369474",
    "created_at" : "Fri Sep 18 01:44:04 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish かわい子ちゃんであった、満足したので帰るか",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "20" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1306769688186114049",
    "id_str" : "1306770302148341761",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306770302148341761",
    "in_reply_to_status_id" : "1306769688186114049",
    "created_at" : "Fri Sep 18 01:41:33 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish りみちゃんみーっけ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1306767840834252804",
    "id_str" : "1306769400142336000",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306769400142336000",
    "in_reply_to_status_id" : "1306767840834252804",
    "created_at" : "Fri Sep 18 01:37:58 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish もうついたの！",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "13" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1306766002420690946",
    "id_str" : "1306767038682075136",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306767038682075136",
    "in_reply_to_status_id" : "1306766002420690946",
    "created_at" : "Fri Sep 18 01:28:35 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish はよ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "5" ],
    "favorite_count" : "0",
    "id_str" : "1306765606927040513",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306765606927040513",
    "created_at" : "Fri Sep 18 01:22:53 +0000 2020",
    "favorited" : false,
    "full_text" : "ついたー！",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "22" ],
    "favorite_count" : "1",
    "id_str" : "1306763151476621312",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306763151476621312",
    "created_at" : "Fri Sep 18 01:13:08 +0000 2020",
    "favorited" : false,
    "full_text" : "昇華印刷…_:(´ཀ`」 ∠):(ゴクリ…)",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1306759948412489728",
    "id_str" : "1306762841878192131",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306762841878192131",
    "in_reply_to_status_id" : "1306759948412489728",
    "created_at" : "Fri Sep 18 01:11:54 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish 二人暮らし_(┐「ε:)_",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "ゆかり𓂙G03-04@MFT",
        "screen_name" : "eucalyn_",
        "indices" : [ "3", "12" ],
        "id_str" : "115406666",
        "id" : "115406666"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1306755063700844549",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306755063700844549",
    "created_at" : "Fri Sep 18 00:41:00 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @eucalyn_: VARMILOのカスタムキーボードサービスやば！！！\nケース・キーキャップ・キースイッチ全部選んでカスタムオーダーできる。\n文字色は昇華印刷で6色から選択、キーキャップは18色から好きに組み合わせられるし1キーごとに設定できる。\n\nつまり\n\n「「「軽…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "マキナネット/machinanette",
        "screen_name" : "machinanette",
        "indices" : [ "3", "16" ],
        "id_str" : "2290375172",
        "id" : "2290375172"
      } ],
      "urls" : [ {
        "url" : "https://t.co/wP75aDtOSg",
        "expanded_url" : "https://www.machinanette.com/2019/05/08/%e6%98%87%e8%8f%af%e3%82%a4%e3%83%b3%e3%82%af%e3%81%a7%e3%82%ad%e3%83%bc%e3%82%ad%e3%83%a3%e3%83%83%e3%83%97%e3%81%ab%e5%8d%b0%e5%ad%97%e3%81%97%e3%81%a6%e3%81%bf%e3%82%8b/",
        "display_url" : "machinanette.com/2019/05/08/%e6…",
        "indices" : [ "47", "70" ]
      } ]
    },
    "display_text_range" : [ "0", "70" ],
    "favorite_count" : "0",
    "id_str" : "1306754844443643905",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306754844443643905",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 18 00:40:07 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @machinanette: ローコストでキーキャップに昇華印刷する方法をためしてみた https://t.co/wP75aDtOSg",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "デッドプール",
        "indices" : [ "15", "22" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Marvel",
        "screen_name" : "marvel_jp",
        "indices" : [ "3", "13" ],
        "id_str" : "800990438794489857",
        "id" : "800990438794489857"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1306753867179200512",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306753867179200512",
    "created_at" : "Fri Sep 18 00:36:14 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @marvel_jp: #デッドプール のインタラクティブヘッドが登場❗️\n\nデッドプールのヘッドの形をしたアイテムが、あなたの声や動作に反応して映画の中のフレーズや効果音を発します🔊\n\n専用アプリを使ってデッドプールヘッドとあのシーンを再現して楽しもう！\n\nhttps:…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "98" ],
    "favorite_count" : "14",
    "id_str" : "1306749692231839745",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306749692231839745",
    "created_at" : "Fri Sep 18 00:19:39 +0000 2020",
    "favorited" : false,
    "full_text" : "テストの日、正直テストのことよりそのあと食べる丸亀製麺を、大盛りにするか並にするか、卵をつけるかつけないか考えてる。\n\n決まった勉強のできないテストだし、どうせpiscineは私たちの斜め上をいく",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "11" ],
    "favorite_count" : "1",
    "id_str" : "1306749062893330432",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306749062893330432",
    "created_at" : "Fri Sep 18 00:17:09 +0000 2020",
    "favorited" : false,
    "full_text" : "Fuckin' Hot",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "34" ],
    "favorite_count" : "0",
    "id_str" : "1306748876087463937",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306748876087463937",
    "created_at" : "Fri Sep 18 00:16:24 +0000 2020",
    "favorited" : false,
    "full_text" : "あー、エチュードハウスのオラフのパウダーがないとゴンメイク崩れまる。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "FortniteRTX",
        "indices" : [ "116", "128" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "フォートナイト",
        "screen_name" : "FortniteJP",
        "indices" : [ "3", "14" ],
        "id_str" : "958264156683091969",
        "id" : "958264156683091969"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1306748633962872834",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306748633962872834",
    "created_at" : "Fri Sep 18 00:15:27 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @FortniteJP: フォートナイトが新たな光に照らされる。\n\n本日より、サポートされているNVIDIA GPUカードとDirectX12を使用しているユーザーにレイトレーシングとNVIDIA DLSSが解禁されます！\n\n#FortniteRTX に関する詳細はブログ…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "4" ],
    "favorite_count" : "1",
    "id_str" : "1306723861845536771",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306723861845536771",
    "created_at" : "Thu Sep 17 22:37:01 +0000 2020",
    "favorited" : false,
    "full_text" : "おはよー",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "1",
    "id_str" : "1306593387299045376",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306593387299045376",
    "created_at" : "Thu Sep 17 13:58:33 +0000 2020",
    "favorited" : false,
    "full_text" : "ここで優雅にアマプラ見て時間潰すと溺れ死ぬのか",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "15" ],
    "favorite_count" : "0",
    "id_str" : "1306593230939541507",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306593230939541507",
    "created_at" : "Thu Sep 17 13:57:56 +0000 2020",
    "favorited" : false,
    "full_text" : "おぉ、普段より早く布団に入れた",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chloé",
        "screen_name" : "LifeisMagicalll",
        "indices" : [ "3", "19" ],
        "id_str" : "1178884178726621186",
        "id" : "1178884178726621186"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/LifeisMagicalll/status/1307122112520425473/photo/1",
        "source_status_id" : "1307122112520425473",
        "indices" : [ "46", "69" ],
        "url" : "https://t.co/LLmGZWMP0L",
        "media_url" : "http://pbs.twimg.com/media/EiPUoaHXkAMMtCi.jpg",
        "id_str" : "1307122107537657859",
        "source_user_id" : "1178884178726621186",
        "id" : "1307122107537657859",
        "media_url_https" : "https://pbs.twimg.com/media/EiPUoaHXkAMMtCi.jpg",
        "source_user_id_str" : "1178884178726621186",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1080",
            "h" : "864",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "544",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1080",
            "h" : "864",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1307122112520425473",
        "display_url" : "pic.twitter.com/LLmGZWMP0L"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "69" ],
    "favorite_count" : "0",
    "id_str" : "1307484234882326528",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307484234882326528",
    "possibly_sensitive" : false,
    "created_at" : "Sun Sep 20 00:58:28 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @LifeisMagicalll: 超現実主義の作品はどれも見てるだけで心が落ち着く https://t.co/LLmGZWMP0L",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/LifeisMagicalll/status/1307122112520425473/photo/1",
        "source_status_id" : "1307122112520425473",
        "indices" : [ "46", "69" ],
        "url" : "https://t.co/LLmGZWMP0L",
        "media_url" : "http://pbs.twimg.com/media/EiPUoaHXkAMMtCi.jpg",
        "id_str" : "1307122107537657859",
        "source_user_id" : "1178884178726621186",
        "id" : "1307122107537657859",
        "media_url_https" : "https://pbs.twimg.com/media/EiPUoaHXkAMMtCi.jpg",
        "source_user_id_str" : "1178884178726621186",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1080",
            "h" : "864",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "544",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1080",
            "h" : "864",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1307122112520425473",
        "display_url" : "pic.twitter.com/LLmGZWMP0L"
      }, {
        "expanded_url" : "https://twitter.com/LifeisMagicalll/status/1307122112520425473/photo/1",
        "source_status_id" : "1307122112520425473",
        "indices" : [ "46", "69" ],
        "url" : "https://t.co/LLmGZWMP0L",
        "media_url" : "http://pbs.twimg.com/media/EiPUoaGWoAAOuEs.jpg",
        "id_str" : "1307122107533402112",
        "source_user_id" : "1178884178726621186",
        "id" : "1307122107533402112",
        "media_url_https" : "https://pbs.twimg.com/media/EiPUoaGWoAAOuEs.jpg",
        "source_user_id_str" : "1178884178726621186",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1080",
            "h" : "864",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1080",
            "h" : "864",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "544",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1307122112520425473",
        "display_url" : "pic.twitter.com/LLmGZWMP0L"
      }, {
        "expanded_url" : "https://twitter.com/LifeisMagicalll/status/1307122112520425473/photo/1",
        "source_status_id" : "1307122112520425473",
        "indices" : [ "46", "69" ],
        "url" : "https://t.co/LLmGZWMP0L",
        "media_url" : "http://pbs.twimg.com/media/EiPUoaJX0AAcWPZ.jpg",
        "id_str" : "1307122107546062848",
        "source_user_id" : "1178884178726621186",
        "id" : "1307122107546062848",
        "media_url_https" : "https://pbs.twimg.com/media/EiPUoaJX0AAcWPZ.jpg",
        "source_user_id_str" : "1178884178726621186",
        "sizes" : {
          "small" : {
            "w" : "680",
            "h" : "544",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1080",
            "h" : "864",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1080",
            "h" : "864",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1307122112520425473",
        "display_url" : "pic.twitter.com/LLmGZWMP0L"
      }, {
        "expanded_url" : "https://twitter.com/LifeisMagicalll/status/1307122112520425473/photo/1",
        "source_status_id" : "1307122112520425473",
        "indices" : [ "46", "69" ],
        "url" : "https://t.co/LLmGZWMP0L",
        "media_url" : "http://pbs.twimg.com/media/EiPUoaZXkAEyhmR.jpg",
        "id_str" : "1307122107613155329",
        "source_user_id" : "1178884178726621186",
        "id" : "1307122107613155329",
        "media_url_https" : "https://pbs.twimg.com/media/EiPUoaZXkAEyhmR.jpg",
        "source_user_id_str" : "1178884178726621186",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "544",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1080",
            "h" : "864",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1080",
            "h" : "864",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1307122112520425473",
        "display_url" : "pic.twitter.com/LLmGZWMP0L"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "3" ],
    "favorite_count" : "4",
    "id_str" : "1307451520502214656",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307451520502214656",
    "created_at" : "Sat Sep 19 22:48:28 +0000 2020",
    "favorited" : false,
    "full_text" : "おぎだ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "17" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1307337234262228992",
    "id_str" : "1307337430886883329",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307337430886883329",
    "in_reply_to_status_id" : "1307337234262228992",
    "created_at" : "Sat Sep 19 15:15:07 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta 承認欲求の塊",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "31" ],
    "favorite_count" : "5",
    "id_str" : "1307336597587726337",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307336597587726337",
    "created_at" : "Sat Sep 19 15:11:48 +0000 2020",
    "favorited" : false,
    "full_text" : "自分のツイートがきもくて消すことって多々あるよね。\n\nおやすみ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "2",
    "id_str" : "1307304789521231874",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307304789521231874",
    "created_at" : "Sat Sep 19 13:05:25 +0000 2020",
    "favorited" : false,
    "full_text" : "寝床に置いといて薬忘れるんだから、頭に貼る？セロテープで",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ふくぶちょー.txt",
        "screen_name" : "__DielsAlder__",
        "indices" : [ "3", "18" ],
        "id_str" : "2683821463",
        "id" : "2683821463"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/__DielsAlder__/status/1306647244787998720/photo/1",
        "source_status_id" : "1306647244787998720",
        "indices" : [ "36", "59" ],
        "url" : "https://t.co/ZNl4iWpBLr",
        "media_url" : "http://pbs.twimg.com/media/EiIkvbnUMAAl4me.jpg",
        "id_str" : "1306647239175974912",
        "source_user_id" : "2683821463",
        "id" : "1306647239175974912",
        "media_url_https" : "https://pbs.twimg.com/media/EiIkvbnUMAAl4me.jpg",
        "source_user_id_str" : "2683821463",
        "sizes" : {
          "small" : {
            "w" : "680",
            "h" : "438",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1956",
            "h" : "1259",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "772",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1306647244787998720",
        "display_url" : "pic.twitter.com/ZNl4iWpBLr"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "59" ],
    "favorite_count" : "0",
    "id_str" : "1307227870024986624",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307227870024986624",
    "possibly_sensitive" : false,
    "created_at" : "Sat Sep 19 07:59:45 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @__DielsAlder__: 言っていいことと悪いことがある https://t.co/ZNl4iWpBLr",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/__DielsAlder__/status/1306647244787998720/photo/1",
        "source_status_id" : "1306647244787998720",
        "indices" : [ "36", "59" ],
        "url" : "https://t.co/ZNl4iWpBLr",
        "media_url" : "http://pbs.twimg.com/media/EiIkvbnUMAAl4me.jpg",
        "id_str" : "1306647239175974912",
        "source_user_id" : "2683821463",
        "id" : "1306647239175974912",
        "media_url_https" : "https://pbs.twimg.com/media/EiIkvbnUMAAl4me.jpg",
        "source_user_id_str" : "2683821463",
        "sizes" : {
          "small" : {
            "w" : "680",
            "h" : "438",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1956",
            "h" : "1259",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "772",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1306647244787998720",
        "display_url" : "pic.twitter.com/ZNl4iWpBLr"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "16" ],
    "favorite_count" : "2",
    "id_str" : "1307211889605132288",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307211889605132288",
    "created_at" : "Sat Sep 19 06:56:15 +0000 2020",
    "favorited" : false,
    "full_text" : "ビルディングゲームが壊滅的に下手",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "えふ@42Tokyo 9月Piscine生",
        "screen_name" : "FPr4242",
        "indices" : [ "0", "8" ],
        "id_str" : "1251179846392143873",
        "id" : "1251179846392143873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "16" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1307189357934075906",
    "id_str" : "1307211833355374592",
    "in_reply_to_user_id" : "1251179846392143873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307211833355374592",
    "in_reply_to_status_id" : "1307189357934075906",
    "created_at" : "Sat Sep 19 06:56:02 +0000 2020",
    "favorited" : false,
    "full_text" : "@FPr4242 消毒されたの！",
    "lang" : "ja",
    "in_reply_to_screen_name" : "FPr4242",
    "in_reply_to_user_id_str" : "1251179846392143873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "3", "13" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "64" ],
    "favorite_count" : "0",
    "id_str" : "1307164681891540994",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307164681891540994",
    "created_at" : "Sat Sep 19 03:48:40 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @_unlimish: 体内のバロメーター周り全部ヘルスケアAppでリアルタイム表示できるように体のAPI開放してほしい。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "3", "13" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "43" ],
    "favorite_count" : "0",
    "id_str" : "1307164675251998720",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307164675251998720",
    "created_at" : "Sat Sep 19 03:48:39 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @_unlimish: 人間の体って結構仕組み的にバグってるのいろいろ問題だよな",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "31" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1307129433103499267",
    "id_str" : "1307143307529658369",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307143307529658369",
    "in_reply_to_status_id" : "1307129433103499267",
    "created_at" : "Sat Sep 19 02:23:44 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo 忘れた分飲んだらましなった…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "42" ],
    "favorite_count" : "0",
    "id_str" : "1307143078784847872",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307143078784847872",
    "created_at" : "Sat Sep 19 02:22:50 +0000 2020",
    "favorited" : false,
    "full_text" : "忘れた分の薬を2日分一気に飲んだら、痛みが治まった。血は止まらないが、これでまだまし",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "20" ],
    "favorite_count" : "1",
    "id_str" : "1307128148673298435",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307128148673298435",
    "created_at" : "Sat Sep 19 01:23:30 +0000 2020",
    "favorited" : false,
    "full_text" : "気持ち悪くて腰が折れそう\n病院行かなきゃ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1307125280981614593",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307125280981614593",
    "created_at" : "Sat Sep 19 01:12:06 +0000 2020",
    "favorited" : false,
    "full_text" : "薬忘れて大惨事。\n\n予想外の出血量でグロッキー",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "19" ],
    "favorite_count" : "3",
    "id_str" : "1306985124236419072",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306985124236419072",
    "created_at" : "Fri Sep 18 15:55:10 +0000 2020",
    "favorited" : false,
    "full_text" : "明日の分の体力を寝てる間にmalloc",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1306974295726403585",
    "id_str" : "1306984941838761991",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306984941838761991",
    "in_reply_to_status_id" : "1306974295726403585",
    "created_at" : "Fri Sep 18 15:54:27 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta 私のすべてを受け止めて…()",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "73" ],
    "favorite_count" : "0",
    "id_str" : "1306957876829671425",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306957876829671425",
    "created_at" : "Fri Sep 18 14:06:54 +0000 2020",
    "favorited" : false,
    "full_text" : "malloc→free\n\nnew→deleteだよな\n\nそう考えると、new→freeの方が命名にセンス感じるのに何故かCとC++はこのような設計",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "5" ],
    "favorite_count" : "1",
    "id_str" : "1306957528660455425",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306957528660455425",
    "created_at" : "Fri Sep 18 14:05:31 +0000 2020",
    "favorited" : false,
    "full_text" : "食べ過ぎた",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "36" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1306954589514555392",
    "id_str" : "1306954873376665601",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306954873376665601",
    "in_reply_to_status_id" : "1306954589514555392",
    "created_at" : "Fri Sep 18 13:54:58 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta 私の内容が濃過ぎてゆうたがmallocした分超える",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1306951660929916928",
    "id_str" : "1306952089382207489",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306952089382207489",
    "in_reply_to_status_id" : "1306951660929916928",
    "created_at" : "Fri Sep 18 13:43:54 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta HDDの間違いだろ。\n\n物理攻撃でメモリ消しとぶから",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "60" ],
    "favorite_count" : "2",
    "id_str" : "1306950373857320961",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306950373857320961",
    "created_at" : "Fri Sep 18 13:37:05 +0000 2020",
    "favorited" : false,
    "full_text" : "日本酒は本当塩辛いもので飲めちゃうもんだから高血圧引き寄せるんだよね。\n\n下80の上140。マジ死んだらみんなよろしくな",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "44" ],
    "favorite_count" : "1",
    "id_str" : "1306941931616743425",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306941931616743425",
    "created_at" : "Fri Sep 18 13:03:32 +0000 2020",
    "favorited" : false,
    "full_text" : "どんなによっててチームののメンバーに迷惑はかけられねぇ。\n\n意地でもメンバーに挨拶をば…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1306931633191182337/photo/1",
        "indices" : [ "14", "37" ],
        "url" : "https://t.co/wd2U7j4Ya1",
        "media_url" : "http://pbs.twimg.com/media/EiMnYqYU8AALNZ7.jpg",
        "id_str" : "1306931621514244096",
        "id" : "1306931621514244096",
        "media_url_https" : "https://pbs.twimg.com/media/EiMnYqYU8AALNZ7.jpg",
        "sizes" : {
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1024",
            "h" : "576",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1024",
            "h" : "576",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/wd2U7j4Ya1"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "4",
    "id_str" : "1306931633191182337",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1306931633191182337",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 18 12:22:37 +0000 2020",
    "favorited" : false,
    "full_text" : "飲んじゃってるよね、すでに https://t.co/wd2U7j4Ya1",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1306931633191182337/photo/1",
        "indices" : [ "14", "37" ],
        "url" : "https://t.co/wd2U7j4Ya1",
        "media_url" : "http://pbs.twimg.com/media/EiMnYqYU8AALNZ7.jpg",
        "id_str" : "1306931621514244096",
        "id" : "1306931621514244096",
        "media_url_https" : "https://pbs.twimg.com/media/EiMnYqYU8AALNZ7.jpg",
        "sizes" : {
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1024",
            "h" : "576",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1024",
            "h" : "576",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/wd2U7j4Ya1"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "94" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1308175685148573696",
    "id_str" : "1308175996734992385",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308175996734992385",
    "in_reply_to_status_id" : "1308175685148573696",
    "created_at" : "Mon Sep 21 22:47:17 +0000 2020",
    "favorited" : false,
    "full_text" : "人類の英知を結集し設計し尽くされた最先端の技術を使ったアトラクションの中に身を置きたい\n\nあの空間が一番勉強やる気になるし、自分もあれを作りたいと思える\n\nあーーーでぃずにーーーーーーーー",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "83" ],
    "favorite_count" : "1",
    "id_str" : "1308175685148573696",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308175685148573696",
    "created_at" : "Mon Sep 21 22:46:02 +0000 2020",
    "favorited" : false,
    "full_text" : "ディズニー行きたいディズニー行きたいディズニー行きたいディズニー行きたい\n\nマジシーのハロウィンやらないのが辛すぎるが、それでも精神の安定のためにディズニーに行きたい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "36" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1308077744803254272",
    "id_str" : "1308174969772228608",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308174969772228608",
    "in_reply_to_status_id" : "1308077744803254272",
    "created_at" : "Mon Sep 21 22:43:12 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta ひなたはどうせ君たちがうかるの見ながら落ちるから。",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "カントリーマアム忍者",
        "screen_name" : "kurakura224",
        "indices" : [ "3", "15" ],
        "id_str" : "885788387055067136",
        "id" : "885788387055067136"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/kurakura224/status/1292009607003398144/photo/1",
        "source_status_id" : "1292009607003398144",
        "indices" : [ "30", "53" ],
        "url" : "https://t.co/UrKvY3R6iz",
        "media_url" : "http://pbs.twimg.com/media/Ee4j41jUMAAwQup.jpg",
        "id_str" : "1292009602456760320",
        "source_user_id" : "885788387055067136",
        "id" : "1292009602456760320",
        "media_url_https" : "https://pbs.twimg.com/media/Ee4j41jUMAAwQup.jpg",
        "source_user_id_str" : "885788387055067136",
        "sizes" : {
          "large" : {
            "w" : "685",
            "h" : "599",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "685",
            "h" : "599",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "595",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1292009607003398144",
        "display_url" : "pic.twitter.com/UrKvY3R6iz"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "53" ],
    "favorite_count" : "0",
    "id_str" : "1308057362226270209",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308057362226270209",
    "possibly_sensitive" : false,
    "created_at" : "Mon Sep 21 14:55:52 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @kurakura224: 絵をほめてくれるロシア人 https://t.co/UrKvY3R6iz",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/kurakura224/status/1292009607003398144/photo/1",
        "source_status_id" : "1292009607003398144",
        "indices" : [ "30", "53" ],
        "url" : "https://t.co/UrKvY3R6iz",
        "media_url" : "http://pbs.twimg.com/media/Ee4j41jUMAAwQup.jpg",
        "id_str" : "1292009602456760320",
        "source_user_id" : "885788387055067136",
        "id" : "1292009602456760320",
        "media_url_https" : "https://pbs.twimg.com/media/Ee4j41jUMAAwQup.jpg",
        "source_user_id_str" : "885788387055067136",
        "sizes" : {
          "large" : {
            "w" : "685",
            "h" : "599",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "685",
            "h" : "599",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "595",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1292009607003398144",
        "display_url" : "pic.twitter.com/UrKvY3R6iz"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/qjfqZoAl3P",
        "expanded_url" : "https://twitter.com/FortniteJP/status/1308003374743171072",
        "display_url" : "twitter.com/FortniteJP/sta…",
        "indices" : [ "16", "39" ]
      } ]
    },
    "display_text_range" : [ "0", "39" ],
    "favorite_count" : "0",
    "id_str" : "1308049001028005888",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308049001028005888",
    "possibly_sensitive" : false,
    "created_at" : "Mon Sep 21 14:22:38 +0000 2020",
    "favorited" : false,
    "full_text" : "いや待てよ、ちょ\n\n絶対見る。 https://t.co/qjfqZoAl3P",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "12" ],
    "favorite_count" : "1",
    "id_str" : "1308047867026653184",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308047867026653184",
    "created_at" : "Mon Sep 21 14:18:08 +0000 2020",
    "favorited" : false,
    "full_text" : "「処理が軽過ぎて羽根！」",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "14" ],
    "favorite_count" : "1",
    "id_str" : "1308047289374572544",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308047289374572544",
    "created_at" : "Mon Sep 21 14:15:50 +0000 2020",
    "favorited" : false,
    "full_text" : "「縦列駐車みたいなコード！」",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "52" ],
    "favorite_count" : "5",
    "id_str" : "1308045878310047744",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308045878310047744",
    "created_at" : "Mon Sep 21 14:10:14 +0000 2020",
    "favorited" : false,
    "full_text" : "ボディビル大会みたいな掛け声で\n\n「そんなに書けるようになるには眠れない夜もあったよなぁ！」って叫びたい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "TOMO",
        "screen_name" : "tomozh",
        "indices" : [ "3", "10" ],
        "id_str" : "234554224",
        "id" : "234554224"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "62" ],
    "favorite_count" : "0",
    "id_str" : "1308011975809490951",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308011975809490951",
    "created_at" : "Mon Sep 21 11:55:31 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @tomozh: ある人のgithubアカウント見てたら醤油ラーメンのレシピのリポジトリがあって、無限の可能性を感じた",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "風牙",
        "screen_name" : "entzauberung",
        "indices" : [ "3", "16" ],
        "id_str" : "57743436",
        "id" : "57743436"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1307918942749376512",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307918942749376512",
    "created_at" : "Mon Sep 21 05:45:50 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @entzauberung: あとここらへんは24時のバカンスみを感じたので宝石の国クラスタにも刺さるんじゃ無いかと思いました　磁器とかいう中世からの東アジア最高級輸出品をもってしてそれは麗しいトラウマを作るのはやめろ(ありがとうございますとても美しいですね)の回 htt…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "風牙",
        "screen_name" : "entzauberung",
        "indices" : [ "3", "16" ],
        "id_str" : "57743436",
        "id" : "57743436"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/entzauberung/status/1306963589698170880/photo/1",
        "source_status_id" : "1306963589698170880",
        "indices" : [ "111", "134" ],
        "url" : "https://t.co/lepx0bGjo0",
        "media_url" : "http://pbs.twimg.com/media/EiNEcjWVoAA9b-S.jpg",
        "id_str" : "1306963574183534592",
        "source_user_id" : "57743436",
        "id" : "1306963574183534592",
        "media_url_https" : "https://pbs.twimg.com/media/EiNEcjWVoAA9b-S.jpg",
        "source_user_id_str" : "57743436",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2046",
            "h" : "2046",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1306963589698170880",
        "display_url" : "pic.twitter.com/lepx0bGjo0"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "134" ],
    "favorite_count" : "0",
    "id_str" : "1307918933597462530",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307918933597462530",
    "possibly_sensitive" : false,
    "created_at" : "Mon Sep 21 05:45:48 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @entzauberung: 鱗粉かと思うだろ………これ全部螺鈿細工なんだぜ…………あと普通に立体造形もリアルだったしだというのに箱自体の型はクラシカルなんだ……クレイジィ……気が狂う…気が狂ってしまう精度だぜ…… https://t.co/lepx0bGjo0",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/entzauberung/status/1306963589698170880/photo/1",
        "source_status_id" : "1306963589698170880",
        "indices" : [ "111", "134" ],
        "url" : "https://t.co/lepx0bGjo0",
        "media_url" : "http://pbs.twimg.com/media/EiNEcjWVoAA9b-S.jpg",
        "id_str" : "1306963574183534592",
        "source_user_id" : "57743436",
        "id" : "1306963574183534592",
        "media_url_https" : "https://pbs.twimg.com/media/EiNEcjWVoAA9b-S.jpg",
        "source_user_id_str" : "57743436",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2046",
            "h" : "2046",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1306963589698170880",
        "display_url" : "pic.twitter.com/lepx0bGjo0"
      }, {
        "expanded_url" : "https://twitter.com/entzauberung/status/1306963589698170880/photo/1",
        "source_status_id" : "1306963589698170880",
        "indices" : [ "111", "134" ],
        "url" : "https://t.co/lepx0bGjo0",
        "media_url" : "http://pbs.twimg.com/media/EiNEchUUYAMRH-j.jpg",
        "id_str" : "1306963573638193155",
        "source_user_id" : "57743436",
        "id" : "1306963573638193155",
        "media_url_https" : "https://pbs.twimg.com/media/EiNEchUUYAMRH-j.jpg",
        "source_user_id_str" : "57743436",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2046",
            "h" : "2046",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1306963589698170880",
        "display_url" : "pic.twitter.com/lepx0bGjo0"
      }, {
        "expanded_url" : "https://twitter.com/entzauberung/status/1306963589698170880/photo/1",
        "source_status_id" : "1306963589698170880",
        "indices" : [ "111", "134" ],
        "url" : "https://t.co/lepx0bGjo0",
        "media_url" : "http://pbs.twimg.com/media/EiNEchUVkAIFwCs.jpg",
        "id_str" : "1306963573638270978",
        "source_user_id" : "57743436",
        "id" : "1306963573638270978",
        "media_url_https" : "https://pbs.twimg.com/media/EiNEchUVkAIFwCs.jpg",
        "source_user_id_str" : "57743436",
        "sizes" : {
          "large" : {
            "w" : "2046",
            "h" : "2046",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "1200",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1306963589698170880",
        "display_url" : "pic.twitter.com/lepx0bGjo0"
      }, {
        "expanded_url" : "https://twitter.com/entzauberung/status/1306963589698170880/photo/1",
        "source_status_id" : "1306963589698170880",
        "indices" : [ "111", "134" ],
        "url" : "https://t.co/lepx0bGjo0",
        "media_url" : "http://pbs.twimg.com/media/EiNEch2U4AEniZP.jpg",
        "id_str" : "1306963573780832257",
        "source_user_id" : "57743436",
        "id" : "1306963573780832257",
        "media_url_https" : "https://pbs.twimg.com/media/EiNEch2U4AEniZP.jpg",
        "source_user_id_str" : "57743436",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2046",
            "h" : "2046",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1306963589698170880",
        "display_url" : "pic.twitter.com/lepx0bGjo0"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "3", "13" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1307862186350444544",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307862186350444544",
    "created_at" : "Mon Sep 21 02:00:18 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @luna_yuta: ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "NCT 127",
        "screen_name" : "NCTsmtown_127",
        "indices" : [ "3", "17" ],
        "id_str" : "869875390465982465",
        "id" : "869875390465982465"
      }, {
        "name" : "みんと",
        "screen_name" : "Mint127Choco",
        "indices" : [ "19", "32" ],
        "id_str" : "1168369632949886976",
        "id" : "1168369632949886976"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "71" ],
    "favorite_count" : "0",
    "id_str" : "1307835006601969664",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307835006601969664",
    "created_at" : "Mon Sep 21 00:12:18 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @NCTsmtown_127: @Mint127Choco これから勉強おしようとお見ます　ボクも本当に会いたいです　つぎにあいましょう",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "みんと",
        "screen_name" : "Mint127Choco",
        "indices" : [ "3", "16" ],
        "id_str" : "1168369632949886976",
        "id" : "1168369632949886976"
      }, {
        "name" : "NCT 127",
        "screen_name" : "NCTsmtown_127",
        "indices" : [ "18", "32" ],
        "id_str" : "869875390465982465",
        "id" : "869875390465982465"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "82" ],
    "favorite_count" : "0",
    "id_str" : "1307835001812127744",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307835001812127744",
    "created_at" : "Mon Sep 21 00:12:17 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Mint127Choco: @NCTsmtown_127 どよち〜！\n최근에 공부한 일본어는 있습니까?\n또 일본에서 만날 날을 기대하고 있겠어요ㅠㅠ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "コロカ",
        "screen_name" : "_koloka_",
        "indices" : [ "3", "12" ],
        "id_str" : "875940607641899008",
        "id" : "875940607641899008"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "135" ],
    "favorite_count" : "0",
    "id_str" : "1307828718908317697",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307828718908317697",
    "created_at" : "Sun Sep 20 23:47:19 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @_koloka_: 敵「休日何してるの？」\n\n語学オタク「（はぁ…またこの質問かよ）サンスクリット語なんて言っても分からないよね……？」\n\n思ったより強かった敵「てことは印欧祖語にも興味あるよね？　俺も最近自分なりに再建してみてるんだけど」\n\n語学オタク「ﾐﾟ」",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "3",
    "id_str" : "1307828315135254554",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307828315135254554",
    "created_at" : "Sun Sep 20 23:45:43 +0000 2020",
    "favorited" : false,
    "full_text" : "いっそ猫に転職したいのでだれか、猫職をください",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "38" ],
    "favorite_count" : "2",
    "id_str" : "1307825079917727748",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307825079917727748",
    "created_at" : "Sun Sep 20 23:32:51 +0000 2020",
    "favorited" : false,
    "full_text" : "aliexpressで昨日キーキャップポチったが\n\n果て、どうなるだろうかね",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "4" ],
    "favorite_count" : "1",
    "id_str" : "1307824393247047680",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307824393247047680",
    "created_at" : "Sun Sep 20 23:30:08 +0000 2020",
    "favorited" : false,
    "full_text" : "ねすぎた",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "29" ],
    "favorite_count" : "0",
    "id_str" : "1307737560584581121",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307737560584581121",
    "created_at" : "Sun Sep 20 17:45:05 +0000 2020",
    "favorited" : false,
    "full_text" : "外散歩したいが、piscine終わってからにする。\n寝る。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1307588294360756230/photo/1",
        "indices" : [ "11", "34" ],
        "url" : "https://t.co/d3YB8GOX9k",
        "media_url" : "http://pbs.twimg.com/media/EiV8nmSUwAAD-oZ.jpg",
        "id_str" : "1307588286555144192",
        "id" : "1307588286555144192",
        "media_url_https" : "https://pbs.twimg.com/media/EiV8nmSUwAAD-oZ.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/d3YB8GOX9k"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "34" ],
    "favorite_count" : "2",
    "id_str" : "1307588294360756230",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307588294360756230",
    "possibly_sensitive" : false,
    "created_at" : "Sun Sep 20 07:51:57 +0000 2020",
    "favorited" : false,
    "full_text" : "墓参りはお腹すくよね https://t.co/d3YB8GOX9k",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1307588294360756230/photo/1",
        "indices" : [ "11", "34" ],
        "url" : "https://t.co/d3YB8GOX9k",
        "media_url" : "http://pbs.twimg.com/media/EiV8nmSUwAAD-oZ.jpg",
        "id_str" : "1307588286555144192",
        "id" : "1307588286555144192",
        "media_url_https" : "https://pbs.twimg.com/media/EiV8nmSUwAAD-oZ.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/d3YB8GOX9k"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "放課後カルピス",
        "screen_name" : "calpis_houkago",
        "indices" : [ "3", "18" ],
        "id_str" : "1237336838295052288",
        "id" : "1237336838295052288"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1307542027391791104",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307542027391791104",
    "created_at" : "Sun Sep 20 04:48:06 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @calpis_houkago: この事実に気づいてしまったら、作りたい衝動を抑えられませんでした…。 \nCaps Lock専用のキーボードキャップ\n\n＿人人人人人人人人＿\n＞　CALPIS Lock　＜ \n￣Y^Y^Y^Y^Y^Y^Y￣\n\n１万ＲＴ達成でキャンペーン賞品…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "考えるOL",
        "screen_name" : "thinkingoodol",
        "indices" : [ "3", "17" ],
        "id_str" : "1125246688422064128",
        "id" : "1125246688422064128"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1307518373941579776",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307518373941579776",
    "created_at" : "Sun Sep 20 03:14:07 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @thinkingoodol: これ、男の方が楽だって言いたいわけじゃなくて、お互いにそれぞれの苦労があるわけなのだから、こちらの苦労を想像せずに、自分だけ辛いお前は楽してる、って決めつけられることにちょっと悲しくなっちゃうよね。まあ、ネクタイも辛いけど、とりあえずブラジ…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "放射線診断専門医☢️画像診断レポートの見落とし予防対策YouTuber",
        "screen_name" : "economics_dr",
        "indices" : [ "3", "16" ],
        "id_str" : "1096072578685259777",
        "id" : "1096072578685259777"
      } ],
      "urls" : [ {
        "url" : "https://t.co/LH4DL65G8u",
        "expanded_url" : "https://news.yahoo.co.jp/articles/76c85a362e8a32744f873926866da5046dd27173",
        "display_url" : "news.yahoo.co.jp/articles/76c85…",
        "indices" : [ "117", "140" ]
      } ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1307516481047941121",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1307516481047941121",
    "possibly_sensitive" : false,
    "created_at" : "Sun Sep 20 03:06:36 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @economics_dr: 藤井聡太二冠は\n1年以内に下取りに出して\n更なる魔改造マシーンに乗り換えると予想する\n\n藤井聡太二冠「自作PC」の値段にパソコンマニアもびっくり（NEWS ポストセブン） - Yahoo!ニュース https://t.co/LH4DL65G8u",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1308975686619725826/photo/1",
        "indices" : [ "104", "127" ],
        "url" : "https://t.co/MB1yTzf46Y",
        "media_url" : "http://pbs.twimg.com/media/EipqcaTX0Asjdq5.jpg",
        "id_str" : "1308975678034006027",
        "id" : "1308975678034006027",
        "media_url_https" : "https://pbs.twimg.com/media/EipqcaTX0Asjdq5.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/MB1yTzf46Y"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "127" ],
    "favorite_count" : "0",
    "id_str" : "1308975686619725826",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308975686619725826",
    "possibly_sensitive" : false,
    "created_at" : "Thu Sep 24 03:44:57 +0000 2020",
    "favorited" : false,
    "full_text" : "この問題解決したい。\n\nVs2019使ってデバッグすると、なぜか変なウィンドウが開くが、マウス以外使えなくなる。\n\n下のスタートとかも前消えでおこ。再起動で回復するが、デバッグが強制終了したおかげだと思われ https://t.co/MB1yTzf46Y",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1308975686619725826/photo/1",
        "indices" : [ "104", "127" ],
        "url" : "https://t.co/MB1yTzf46Y",
        "media_url" : "http://pbs.twimg.com/media/EipqcaTX0Asjdq5.jpg",
        "id_str" : "1308975678034006027",
        "id" : "1308975678034006027",
        "media_url_https" : "https://pbs.twimg.com/media/EipqcaTX0Asjdq5.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/MB1yTzf46Y"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "88" ],
    "favorite_count" : "2",
    "id_str" : "1308906905339867136",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308906905339867136",
    "created_at" : "Wed Sep 23 23:11:39 +0000 2020",
    "favorited" : false,
    "full_text" : "ErgoDashかlily58か、mint60か\n\nlily58の形で基板の色選べるなら余裕でlily58なんだよな…\n\nでも基板の色白しかなさそうだし…ErgoDashかな…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "ヴェルヌと@読書と旅行",
        "screen_name" : "withverne",
        "indices" : [ "3", "13" ],
        "id_str" : "940896842161717248",
        "id" : "940896842161717248"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1308904964270567424",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308904964270567424",
    "created_at" : "Wed Sep 23 23:03:56 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @withverne: 韓国の今年の小説の販売量が過去最多（昨対比30%増）らしい。しかもトップ10のうち１位から９位までが女性作家。チョン・セランやハン・ガンなど見知った名も。素晴らしいな。SFやジュブナイル小説の成長が著しく、若い女性読者がその人気を下支えしてるのだと…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "せきごん",
        "screen_name" : "_gonnoc",
        "indices" : [ "3", "11" ],
        "id_str" : "953090917216354304",
        "id" : "953090917216354304"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1308787607174742017",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308787607174742017",
    "created_at" : "Wed Sep 23 15:17:36 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @_gonnoc: ErgoDashもLPME-IO使って部分無線化できた。i2cのジャンパをショートするだけ。ハンダブリッジしようとしても穴に吸われまくったので余ってたダイオードの足を使った。これで動作例があるのはHelix,7sKB,Corneに続き4つ目かな？\n\nh…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "ぐっちー",
        "screen_name" : "Furafrafrfr",
        "indices" : [ "3", "15" ],
        "id_str" : "827876057957093379",
        "id" : "827876057957093379"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "51" ],
    "favorite_count" : "0",
    "id_str" : "1308786405145866242",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308786405145866242",
    "created_at" : "Wed Sep 23 15:12:49 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Furafrafrfr: ergo dashとlily58 lite rev2で無限に迷ってる",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "3" ],
    "favorite_count" : "0",
    "id_str" : "1308786145812082694",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308786145812082694",
    "created_at" : "Wed Sep 23 15:11:47 +0000 2020",
    "favorited" : false,
    "full_text" : "おやす",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "16" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1308769780308955142",
    "id_str" : "1308769902388338689",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308769902388338689",
    "in_reply_to_status_id" : "1308769780308955142",
    "created_at" : "Wed Sep 23 14:07:15 +0000 2020",
    "favorited" : false,
    "full_text" : "変に隣の臓器に書き込みしてるせい",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "1",
    "id_str" : "1308769780308955142",
    "truncated" : false,
    "retweet_count" : "1",
    "id" : "1308769780308955142",
    "created_at" : "Wed Sep 23 14:06:46 +0000 2020",
    "favorited" : false,
    "full_text" : "内臓、断片なしにメモリ詰め込み過ぎて明らかセグフォ起こしてる",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "おねすとちゃんねる@42Tokyo.9月Piscine生",
        "screen_name" : "honestchanel",
        "indices" : [ "0", "13" ],
        "id_str" : "855651284006785024",
        "id" : "855651284006785024"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "31" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1308742103225126914",
    "id_str" : "1308766280271323136",
    "in_reply_to_user_id" : "855651284006785024",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308766280271323136",
    "in_reply_to_status_id" : "1308742103225126914",
    "created_at" : "Wed Sep 23 13:52:51 +0000 2020",
    "favorited" : false,
    "full_text" : "@honestchanel おだいじにするのです(´･Д･)」",
    "lang" : "ja",
    "in_reply_to_screen_name" : "honestchanel",
    "in_reply_to_user_id_str" : "855651284006785024"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "26" ],
    "favorite_count" : "1",
    "id_str" : "1308758030536720384",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308758030536720384",
    "created_at" : "Wed Sep 23 13:20:04 +0000 2020",
    "favorited" : false,
    "full_text" : "あーだめだ腹痛すぎる\n\n精神より体が病む。痛い痛い。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1308730709977100290/photo/1",
        "indices" : [ "18", "41" ],
        "url" : "https://t.co/RuW9JvVtED",
        "media_url" : "http://pbs.twimg.com/media/EimLpFHUcAARNfr.jpg",
        "id_str" : "1308730704591613952",
        "id" : "1308730704591613952",
        "media_url_https" : "https://pbs.twimg.com/media/EimLpFHUcAARNfr.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "640",
            "h" : "1067",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "640",
            "h" : "1067",
            "resize" : "fit"
          },
          "small" : {
            "w" : "408",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/RuW9JvVtED"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "41" ],
    "favorite_count" : "1",
    "id_str" : "1308730709977100290",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308730709977100290",
    "possibly_sensitive" : false,
    "created_at" : "Wed Sep 23 11:31:30 +0000 2020",
    "favorited" : false,
    "full_text" : "いや、そんなすっかすかなことある？ https://t.co/RuW9JvVtED",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1308730709977100290/photo/1",
        "indices" : [ "18", "41" ],
        "url" : "https://t.co/RuW9JvVtED",
        "media_url" : "http://pbs.twimg.com/media/EimLpFHUcAARNfr.jpg",
        "id_str" : "1308730704591613952",
        "id" : "1308730704591613952",
        "media_url_https" : "https://pbs.twimg.com/media/EimLpFHUcAARNfr.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "640",
            "h" : "1067",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "640",
            "h" : "1067",
            "resize" : "fit"
          },
          "small" : {
            "w" : "408",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/RuW9JvVtED"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "0",
    "id_str" : "1308577337475203073",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308577337475203073",
    "created_at" : "Wed Sep 23 01:22:04 +0000 2020",
    "favorited" : false,
    "full_text" : "プログラミング言語に対する、チョムスキー言語学における生成文法からの観点。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "フォートナイト",
        "screen_name" : "FortniteJP",
        "indices" : [ "3", "14" ],
        "id_str" : "958264156683091969",
        "id" : "958264156683091969"
      }, {
        "name" : "Rocket League",
        "screen_name" : "RocketLeague",
        "indices" : [ "24", "37" ],
        "id_str" : "2732818747",
        "id" : "2732818747"
      }, {
        "name" : "slushii",
        "screen_name" : "SlushiiMusic",
        "indices" : [ "71", "84" ],
        "id_str" : "259986276",
        "id" : "259986276"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1308561825508675585",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308561825508675585",
    "created_at" : "Wed Sep 23 00:20:25 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @FortniteJP: ロケットリーグ @RocketLeague の無料プレイはまもなく！\n\nこれを記念にロケットリーグラジオから @SlushiiMusic が9月27日午前6時（日本時間）にパーティーロイヤルに出演します。\n\nショーのあとはロケットリーグに飛び込ん…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "12" ],
    "favorite_count" : "0",
    "id_str" : "1308533965817430017",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308533965817430017",
    "created_at" : "Tue Sep 22 22:29:43 +0000 2020",
    "favorited" : false,
    "full_text" : "さて、日経下がるっかなー",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "3" ],
    "favorite_count" : "0",
    "id_str" : "1308533378665177090",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308533378665177090",
    "created_at" : "Tue Sep 22 22:27:23 +0000 2020",
    "favorited" : false,
    "full_text" : "おはー",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "19" ],
    "favorite_count" : "1",
    "id_str" : "1308409370909323264",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308409370909323264",
    "created_at" : "Tue Sep 22 14:14:37 +0000 2020",
    "favorited" : false,
    "full_text" : "いい加減後期の時間割組まないとまずいゾ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "KOTO",
        "screen_name" : "koto_science",
        "indices" : [ "0", "13" ],
        "id_str" : "984367814889779200",
        "id" : "984367814889779200"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "19" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1308192719995432960",
    "id_str" : "1308379389260738565",
    "in_reply_to_user_id" : "984367814889779200",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308379389260738565",
    "in_reply_to_status_id" : "1308192719995432960",
    "created_at" : "Tue Sep 22 12:15:29 +0000 2020",
    "favorited" : false,
    "full_text" : "@koto_science 逃がさない",
    "lang" : "ja",
    "in_reply_to_screen_name" : "koto_science",
    "in_reply_to_user_id_str" : "984367814889779200"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "TamifuruD",
        "screen_name" : "tamifuru_d",
        "indices" : [ "3", "14" ],
        "id_str" : "815775410071838721",
        "id" : "815775410071838721"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "39" ],
    "favorite_count" : "0",
    "id_str" : "1308309329443840000",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308309329443840000",
    "created_at" : "Tue Sep 22 07:37:06 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @tamifuru_d: ディズニーシーでアリ王子のパレードやんねえかな",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      }, {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "11", "21" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "26" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1308190515486097408",
    "id_str" : "1308249203324325888",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308249203324325888",
    "in_reply_to_status_id" : "1308190515486097408",
    "created_at" : "Tue Sep 22 03:38:10 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish @luna_yuta ほんそれ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "11", "21" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "32" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1308197062098337792",
    "id_str" : "1308249123745796096",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308249123745796096",
    "in_reply_to_status_id" : "1308197062098337792",
    "created_at" : "Tue Sep 22 03:37:51 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @_unlimish 岸本学校に受かるの？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "19" ],
    "favorite_count" : "2",
    "id_str" : "1308187601753391104",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308187601753391104",
    "created_at" : "Mon Sep 21 23:33:23 +0000 2020",
    "favorited" : false,
    "full_text" : "場合によってはexam直撃台風なの…？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "ディズニーニュース",
        "screen_name" : "orange_disney1",
        "indices" : [ "3", "18" ],
        "id_str" : "757422248181411840",
        "id" : "757422248181411840"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1308185772063821825",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308185772063821825",
    "created_at" : "Mon Sep 21 23:26:07 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @orange_disney1: ９月２８日、ディズニーランドの新エリア「ニューファンタジーランド」がオープンします✨\n\n「美女と野獣“魔法のものがたり”」や「ベイマックスのハッピーライド」、「ミニーのスタイルスタジオ」が導入されます！ https://t.co/If5r…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ディズニーニュース",
        "screen_name" : "orange_disney1",
        "indices" : [ "3", "18" ],
        "id_str" : "757422248181411840",
        "id" : "757422248181411840"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/orange_disney1/status/1307984096241487874/photo/1",
        "source_status_id" : "1307984096241487874",
        "indices" : [ "91", "114" ],
        "url" : "https://t.co/3Q7bwhdKu4",
        "media_url" : "http://pbs.twimg.com/media/EibkmkFUMAA9ccZ.jpg",
        "id_str" : "1307984092969840640",
        "source_user_id" : "757422248181411840",
        "id" : "1307984092969840640",
        "media_url_https" : "https://pbs.twimg.com/media/EibkmkFUMAA9ccZ.jpg",
        "source_user_id_str" : "757422248181411840",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "651",
            "h" : "486",
            "resize" : "fit"
          },
          "large" : {
            "w" : "651",
            "h" : "486",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "651",
            "h" : "486",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1307984096241487874",
        "display_url" : "pic.twitter.com/3Q7bwhdKu4"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "114" ],
    "favorite_count" : "0",
    "id_str" : "1308179167020638208",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308179167020638208",
    "possibly_sensitive" : false,
    "created_at" : "Mon Sep 21 22:59:52 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @orange_disney1: ９月２８日に東京ディズニーランドのトゥモローランドにオープンするビッグポップにて、映画「美女と野獣」のポップコーンバケットが新発売されます✨ https://t.co/3Q7bwhdKu4",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/orange_disney1/status/1307984096241487874/photo/1",
        "source_status_id" : "1307984096241487874",
        "indices" : [ "91", "114" ],
        "url" : "https://t.co/3Q7bwhdKu4",
        "media_url" : "http://pbs.twimg.com/media/EibkmkFUMAA9ccZ.jpg",
        "id_str" : "1307984092969840640",
        "source_user_id" : "757422248181411840",
        "id" : "1307984092969840640",
        "media_url_https" : "https://pbs.twimg.com/media/EibkmkFUMAA9ccZ.jpg",
        "source_user_id_str" : "757422248181411840",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "651",
            "h" : "486",
            "resize" : "fit"
          },
          "large" : {
            "w" : "651",
            "h" : "486",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "651",
            "h" : "486",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1307984096241487874",
        "display_url" : "pic.twitter.com/3Q7bwhdKu4"
      }, {
        "expanded_url" : "https://twitter.com/orange_disney1/status/1307984096241487874/photo/1",
        "source_status_id" : "1307984096241487874",
        "indices" : [ "91", "114" ],
        "url" : "https://t.co/3Q7bwhdKu4",
        "media_url" : "http://pbs.twimg.com/media/EibkmkEUcAAGmAi.jpg",
        "id_str" : "1307984092965662720",
        "source_user_id" : "757422248181411840",
        "id" : "1307984092965662720",
        "media_url_https" : "https://pbs.twimg.com/media/EibkmkEUcAAGmAi.jpg",
        "source_user_id_str" : "757422248181411840",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "650",
            "h" : "493",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "650",
            "h" : "493",
            "resize" : "fit"
          },
          "small" : {
            "w" : "650",
            "h" : "493",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1307984096241487874",
        "display_url" : "pic.twitter.com/3Q7bwhdKu4"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "みっけ",
        "screen_name" : "qk_micke",
        "indices" : [ "3", "12" ],
        "id_str" : "1132576204303716352",
        "id" : "1132576204303716352"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/qk_micke/status/1307960919163465728/photo/1",
        "source_status_id" : "1307960919163465728",
        "indices" : [ "22", "45" ],
        "url" : "https://t.co/Zhg3Dxey2X",
        "media_url" : "http://pbs.twimg.com/media/EibPM4KU0AE_hg8.png",
        "id_str" : "1307960561938780161",
        "source_user_id" : "1132576204303716352",
        "id" : "1307960561938780161",
        "media_url_https" : "https://pbs.twimg.com/media/EibPM4KU0AE_hg8.png",
        "source_user_id_str" : "1132576204303716352",
        "sizes" : {
          "large" : {
            "w" : "899",
            "h" : "483",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "365",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "899",
            "h" : "483",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1307960919163465728",
        "display_url" : "pic.twitter.com/Zhg3Dxey2X"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "45" ],
    "favorite_count" : "0",
    "id_str" : "1308178998812270592",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308178998812270592",
    "possibly_sensitive" : false,
    "created_at" : "Mon Sep 21 22:59:12 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @qk_micke: 絵画ラベル～！ https://t.co/Zhg3Dxey2X",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/qk_micke/status/1307960919163465728/photo/1",
        "source_status_id" : "1307960919163465728",
        "indices" : [ "22", "45" ],
        "url" : "https://t.co/Zhg3Dxey2X",
        "media_url" : "http://pbs.twimg.com/media/EibPM4KU0AE_hg8.png",
        "id_str" : "1307960561938780161",
        "source_user_id" : "1132576204303716352",
        "id" : "1307960561938780161",
        "media_url_https" : "https://pbs.twimg.com/media/EibPM4KU0AE_hg8.png",
        "source_user_id_str" : "1132576204303716352",
        "sizes" : {
          "large" : {
            "w" : "899",
            "h" : "483",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "365",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "899",
            "h" : "483",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1307960919163465728",
        "display_url" : "pic.twitter.com/Zhg3Dxey2X"
      }, {
        "expanded_url" : "https://twitter.com/qk_micke/status/1307960919163465728/photo/1",
        "source_status_id" : "1307960919163465728",
        "indices" : [ "22", "45" ],
        "url" : "https://t.co/Zhg3Dxey2X",
        "media_url" : "http://pbs.twimg.com/media/EibPM5ZUwAAHJFa.png",
        "id_str" : "1307960562270126080",
        "source_user_id" : "1132576204303716352",
        "id" : "1307960562270126080",
        "media_url_https" : "https://pbs.twimg.com/media/EibPM5ZUwAAHJFa.png",
        "source_user_id_str" : "1132576204303716352",
        "sizes" : {
          "large" : {
            "w" : "899",
            "h" : "483",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "899",
            "h" : "483",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "365",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1307960919163465728",
        "display_url" : "pic.twitter.com/Zhg3Dxey2X"
      }, {
        "expanded_url" : "https://twitter.com/qk_micke/status/1307960919163465728/photo/1",
        "source_status_id" : "1307960919163465728",
        "indices" : [ "22", "45" ],
        "url" : "https://t.co/Zhg3Dxey2X",
        "media_url" : "http://pbs.twimg.com/media/EibPM7PUwAACwwz.png",
        "id_str" : "1307960562765053952",
        "source_user_id" : "1132576204303716352",
        "id" : "1307960562765053952",
        "media_url_https" : "https://pbs.twimg.com/media/EibPM7PUwAACwwz.png",
        "source_user_id_str" : "1132576204303716352",
        "sizes" : {
          "medium" : {
            "w" : "899",
            "h" : "483",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "365",
            "resize" : "fit"
          },
          "large" : {
            "w" : "899",
            "h" : "483",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1307960919163465728",
        "display_url" : "pic.twitter.com/Zhg3Dxey2X"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "11", "21" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "21" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1308077744803254272",
    "id_str" : "1308176068059082758",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308176068059082758",
    "in_reply_to_status_id" : "1308077744803254272",
    "created_at" : "Mon Sep 21 22:47:34 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @_unlimish",
    "lang" : "und",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1309390925655752704/photo/1",
        "indices" : [ "70", "93" ],
        "url" : "https://t.co/7EuDvtaSI2",
        "media_url" : "http://pbs.twimg.com/media/EivkFWPU8AEQiiX.jpg",
        "id_str" : "1309390897201606657",
        "id" : "1309390897201606657",
        "media_url_https" : "https://pbs.twimg.com/media/EivkFWPU8AEQiiX.jpg",
        "sizes" : {
          "medium" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/7EuDvtaSI2"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "93" ],
    "favorite_count" : "18",
    "id_str" : "1309390925655752704",
    "truncated" : false,
    "retweet_count" : "4",
    "id" : "1309390925655752704",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 25 07:14:58 +0000 2020",
    "favorited" : false,
    "full_text" : "塩つけ麺の灯花というお店。透き通った塩スープがやばく美味しい。恐ろしいことにただでつけられるおい飯とスープ割が秀逸で美味しい。\n\nリピ確定 https://t.co/7EuDvtaSI2",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1309390925655752704/photo/1",
        "indices" : [ "70", "93" ],
        "url" : "https://t.co/7EuDvtaSI2",
        "media_url" : "http://pbs.twimg.com/media/EivkFWPU8AEQiiX.jpg",
        "id_str" : "1309390897201606657",
        "id" : "1309390897201606657",
        "media_url_https" : "https://pbs.twimg.com/media/EivkFWPU8AEQiiX.jpg",
        "sizes" : {
          "medium" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/7EuDvtaSI2"
      }, {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1309390925655752704/photo/1",
        "indices" : [ "70", "93" ],
        "url" : "https://t.co/7EuDvtaSI2",
        "media_url" : "http://pbs.twimg.com/media/EivkFWPU0AAJKk8.jpg",
        "id_str" : "1309390897201598464",
        "id" : "1309390897201598464",
        "media_url_https" : "https://pbs.twimg.com/media/EivkFWPU0AAJKk8.jpg",
        "sizes" : {
          "large" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/7EuDvtaSI2"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "2",
    "id_str" : "1309384392322641921",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309384392322641921",
    "created_at" : "Fri Sep 25 06:49:00 +0000 2020",
    "favorited" : false,
    "full_text" : "四谷で降りて、駅の広告にあったラーメン屋に来た。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "4" ],
    "favorite_count" : "2",
    "id_str" : "1309373867098476547",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309373867098476547",
    "created_at" : "Fri Sep 25 06:07:11 +0000 2020",
    "favorited" : false,
    "full_text" : "満足した",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "3", "13" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "39" ],
    "favorite_count" : "0",
    "id_str" : "1309305926122307584",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309305926122307584",
    "created_at" : "Fri Sep 25 01:37:13 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @_unlimish: 身のふり構わずあの坂をできる限り走ろうと思います",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "3", "13" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "22" ],
    "favorite_count" : "0",
    "id_str" : "1309305918585102337",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309305918585102337",
    "created_at" : "Fri Sep 25 01:37:11 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @_unlimish: 運営許してくれ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "16" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1309305079590084608",
    "id_str" : "1309305259450224640",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309305259450224640",
    "in_reply_to_status_id" : "1309305079590084608",
    "created_at" : "Fri Sep 25 01:34:34 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish 間に合う？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "19" ],
    "favorite_count" : "2",
    "id_str" : "1309304716417929216",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309304716417929216",
    "created_at" : "Fri Sep 25 01:32:24 +0000 2020",
    "favorited" : false,
    "full_text" : "そして知り合いが増えたことに驚いている",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "20" ],
    "favorite_count" : "2",
    "id_str" : "1309304666308501506",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309304666308501506",
    "created_at" : "Fri Sep 25 01:32:12 +0000 2020",
    "favorited" : false,
    "full_text" : "ひそかにアンリミいないかとドアを見てるw",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "2",
    "id_str" : "1309300085499469824",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309300085499469824",
    "created_at" : "Fri Sep 25 01:14:00 +0000 2020",
    "favorited" : false,
    "full_text" : "ついたず\n\n地下鉄からは順調であった",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "望月和臣",
        "screen_name" : "mochi0w0omi",
        "indices" : [ "3", "15" ],
        "id_str" : "1117419554924154880",
        "id" : "1117419554924154880"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/mochi0w0omi/status/1308961364010967041/photo/1",
        "source_status_id" : "1308961364010967041",
        "indices" : [ "35", "58" ],
        "url" : "https://t.co/rFP3nag8ZB",
        "media_url" : "http://pbs.twimg.com/media/EipdNUmU8AUBpGQ.jpg",
        "id_str" : "1308961125153697797",
        "source_user_id" : "1117419554924154880",
        "id" : "1308961125153697797",
        "media_url_https" : "https://pbs.twimg.com/media/EipdNUmU8AUBpGQ.jpg",
        "source_user_id_str" : "1117419554924154880",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "977",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1000",
            "h" : "1228",
            "resize" : "fit"
          },
          "small" : {
            "w" : "554",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1308961364010967041",
        "display_url" : "pic.twitter.com/rFP3nag8ZB"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "58" ],
    "favorite_count" : "0",
    "id_str" : "1309298596970291200",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309298596970291200",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 25 01:08:05 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @mochi0w0omi: お酒飲めないのでわかんないんですが https://t.co/rFP3nag8ZB",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/mochi0w0omi/status/1308961364010967041/photo/1",
        "source_status_id" : "1308961364010967041",
        "indices" : [ "35", "58" ],
        "url" : "https://t.co/rFP3nag8ZB",
        "media_url" : "http://pbs.twimg.com/media/EipdNUmU8AUBpGQ.jpg",
        "id_str" : "1308961125153697797",
        "source_user_id" : "1117419554924154880",
        "id" : "1308961125153697797",
        "media_url_https" : "https://pbs.twimg.com/media/EipdNUmU8AUBpGQ.jpg",
        "source_user_id_str" : "1117419554924154880",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "977",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1000",
            "h" : "1228",
            "resize" : "fit"
          },
          "small" : {
            "w" : "554",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1308961364010967041",
        "display_url" : "pic.twitter.com/rFP3nag8ZB"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "3", "13" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "27" ],
    "favorite_count" : "0",
    "id_str" : "1309295037071544323",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309295037071544323",
    "created_at" : "Fri Sep 25 00:53:57 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @_unlimish: 間に合わないかもしれない",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "3", "13" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "32" ],
    "favorite_count" : "0",
    "id_str" : "1309291373946793985",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309291373946793985",
    "created_at" : "Fri Sep 25 00:39:23 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @_unlimish: こんにちは、金曜日\nって感じですね",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "9" ],
    "favorite_count" : "2",
    "id_str" : "1309291362634723328",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309291362634723328",
    "created_at" : "Fri Sep 25 00:39:20 +0000 2020",
    "favorited" : false,
    "full_text" : "遅れるな電車たのむ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "10" ],
    "favorite_count" : "1",
    "id_str" : "1309283052368007170",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309283052368007170",
    "created_at" : "Fri Sep 25 00:06:19 +0000 2020",
    "favorited" : false,
    "full_text" : "頭に鉛筆刺さってます",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "9" ],
    "favorite_count" : "1",
    "id_str" : "1309282060553519105",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309282060553519105",
    "created_at" : "Fri Sep 25 00:02:23 +0000 2020",
    "favorited" : false,
    "full_text" : "qiita書きたい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "3" ],
    "favorite_count" : "5",
    "id_str" : "1309260160687194112",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309260160687194112",
    "created_at" : "Thu Sep 24 22:35:21 +0000 2020",
    "favorited" : false,
    "full_text" : "おぎだ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1309251415961812992",
    "id_str" : "1309252663863775232",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309252663863775232",
    "in_reply_to_status_id" : "1309251415961812992",
    "created_at" : "Thu Sep 24 22:05:34 +0000 2020",
    "favorited" : false,
    "full_text" : "んなわけないわって朝起きてツッコンダ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "53" ],
    "favorite_count" : "0",
    "id_str" : "1309251415961812992",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309251415961812992",
    "created_at" : "Thu Sep 24 22:00:36 +0000 2020",
    "favorited" : false,
    "full_text" : "隠れポインターとサイズっての思い出して\n\n構造体内のchar*ってアスキー通りに足算できるのか不安になった",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/nStkXwvHuL",
        "expanded_url" : "https://twitter.com/FortniteJP/status/1309132591044407296",
        "display_url" : "twitter.com/FortniteJP/sta…",
        "indices" : [ "15", "38" ]
      } ]
    },
    "display_text_range" : [ "0", "38" ],
    "favorite_count" : "0",
    "id_str" : "1309133301110714371",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309133301110714371",
    "possibly_sensitive" : false,
    "created_at" : "Thu Sep 24 14:11:16 +0000 2020",
    "favorited" : false,
    "full_text" : "あえ、ちょ、ま、私もやりたい https://t.co/nStkXwvHuL",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "フォートナイト",
        "screen_name" : "FortniteJP",
        "indices" : [ "3", "14" ],
        "id_str" : "958264156683091969",
        "id" : "958264156683091969"
      }, {
        "name" : "Rocket League",
        "screen_name" : "RocketLeague",
        "indices" : [ "25", "38" ],
        "id_str" : "2732818747",
        "id" : "2732818747"
      } ],
      "urls" : [ {
        "url" : "https://t.co/kL92mqIifa",
        "expanded_url" : "https://www.epicgames.com/fortnite/ja/news/llama-rama-brings-fortnite-and-rocket-league-together",
        "display_url" : "epicgames.com/fortnite/ja/ne…",
        "indices" : [ "112", "135" ]
      } ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1309133257007661065",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309133257007661065",
    "possibly_sensitive" : false,
    "created_at" : "Thu Sep 24 14:11:05 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @FortniteJP: ついに！本日から @RocketLeague が基本プレイ無料になりました！\n\n日本時間9月27日午前7時より、ロケットリーグのチャレンジをクリアすれば様々なコラボアイテムが手に入ります！\n\nhttps://t.co/kL92mqIifa htt…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1309133208529891329/photo/1",
        "indices" : [ "19", "42" ],
        "url" : "https://t.co/omFZtdv5ir",
        "media_url" : "http://pbs.twimg.com/media/Eir5tdQXkAEn77i.jpg",
        "id_str" : "1309133201047261185",
        "id" : "1309133201047261185",
        "media_url_https" : "https://pbs.twimg.com/media/Eir5tdQXkAEn77i.jpg",
        "sizes" : {
          "small" : {
            "w" : "383",
            "h" : "680",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "640",
            "h" : "1136",
            "resize" : "fit"
          },
          "large" : {
            "w" : "640",
            "h" : "1136",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/omFZtdv5ir"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "42" ],
    "favorite_count" : "1",
    "id_str" : "1309133208529891329",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309133208529891329",
    "possibly_sensitive" : false,
    "created_at" : "Thu Sep 24 14:10:54 +0000 2020",
    "favorited" : false,
    "full_text" : "中国国内を移動していることはわかった https://t.co/omFZtdv5ir",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1309133208529891329/photo/1",
        "indices" : [ "19", "42" ],
        "url" : "https://t.co/omFZtdv5ir",
        "media_url" : "http://pbs.twimg.com/media/Eir5tdQXkAEn77i.jpg",
        "id_str" : "1309133201047261185",
        "id" : "1309133201047261185",
        "media_url_https" : "https://pbs.twimg.com/media/Eir5tdQXkAEn77i.jpg",
        "sizes" : {
          "small" : {
            "w" : "383",
            "h" : "680",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "640",
            "h" : "1136",
            "resize" : "fit"
          },
          "large" : {
            "w" : "640",
            "h" : "1136",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/omFZtdv5ir"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ディズニーニュース",
        "screen_name" : "orange_disney1",
        "indices" : [ "3", "18" ],
        "id_str" : "757422248181411840",
        "id" : "757422248181411840"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/orange_disney1/status/1309070369505017860/photo/1",
        "source_status_id" : "1309070369505017860",
        "indices" : [ "113", "136" ],
        "url" : "https://t.co/bpqACO2OnR",
        "media_url" : "http://pbs.twimg.com/media/EirAjzmWkAQbKxm.jpg",
        "id_str" : "1309070363083575300",
        "source_user_id" : "757422248181411840",
        "id" : "1309070363083575300",
        "media_url_https" : "https://pbs.twimg.com/media/EirAjzmWkAQbKxm.jpg",
        "source_user_id_str" : "757422248181411840",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "815",
            "h" : "1200",
            "resize" : "fit"
          },
          "small" : {
            "w" : "462",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "815",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1309070369505017860",
        "display_url" : "pic.twitter.com/bpqACO2OnR"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "136" ],
    "favorite_count" : "0",
    "id_str" : "1309099340661743617",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309099340661743617",
    "possibly_sensitive" : false,
    "created_at" : "Thu Sep 24 11:56:19 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @orange_disney1: ９月２８日よりディズニーリゾートライン フリーきっぷに３種類のデザインが新登場します✨\n\n東京ディズニーランドの新アトラクション「美女と野獣“魔法のものがたり”」デザインも加わります！ https://t.co/bpqACO2OnR",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/orange_disney1/status/1309070369505017860/photo/1",
        "source_status_id" : "1309070369505017860",
        "indices" : [ "113", "136" ],
        "url" : "https://t.co/bpqACO2OnR",
        "media_url" : "http://pbs.twimg.com/media/EirAjzmWkAQbKxm.jpg",
        "id_str" : "1309070363083575300",
        "source_user_id" : "757422248181411840",
        "id" : "1309070363083575300",
        "media_url_https" : "https://pbs.twimg.com/media/EirAjzmWkAQbKxm.jpg",
        "source_user_id_str" : "757422248181411840",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "815",
            "h" : "1200",
            "resize" : "fit"
          },
          "small" : {
            "w" : "462",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "815",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1309070369505017860",
        "display_url" : "pic.twitter.com/bpqACO2OnR"
      }, {
        "expanded_url" : "https://twitter.com/orange_disney1/status/1309070369505017860/photo/1",
        "source_status_id" : "1309070369505017860",
        "indices" : [ "113", "136" ],
        "url" : "https://t.co/bpqACO2OnR",
        "media_url" : "http://pbs.twimg.com/media/EirAjznWoAIQl_L.jpg",
        "id_str" : "1309070363087773698",
        "source_user_id" : "757422248181411840",
        "id" : "1309070363087773698",
        "media_url_https" : "https://pbs.twimg.com/media/EirAjznWoAIQl_L.jpg",
        "source_user_id_str" : "757422248181411840",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "815",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "815",
            "h" : "1200",
            "resize" : "fit"
          },
          "small" : {
            "w" : "462",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1309070369505017860",
        "display_url" : "pic.twitter.com/bpqACO2OnR"
      }, {
        "expanded_url" : "https://twitter.com/orange_disney1/status/1309070369505017860/photo/1",
        "source_status_id" : "1309070369505017860",
        "indices" : [ "113", "136" ],
        "url" : "https://t.co/bpqACO2OnR",
        "media_url" : "http://pbs.twimg.com/media/EirAj3GXkAEQ1ff.jpg",
        "id_str" : "1309070364023164929",
        "source_user_id" : "757422248181411840",
        "id" : "1309070364023164929",
        "media_url_https" : "https://pbs.twimg.com/media/EirAj3GXkAEQ1ff.jpg",
        "source_user_id_str" : "757422248181411840",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "462",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "815",
            "h" : "1200",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "815",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1309070369505017860",
        "display_url" : "pic.twitter.com/bpqACO2OnR"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "3", "19" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      }, {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "21", "31" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "48" ],
    "favorite_count" : "0",
    "id_str" : "1309059253185937409",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309059253185937409",
    "created_at" : "Thu Sep 24 09:17:01 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Kahorin_42Tokyo: @luna_yuta えろいって見えたわ。疲れてるわ。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Fall Guys 👑",
        "screen_name" : "FallGuysGame",
        "indices" : [ "3", "16" ],
        "id_str" : "1134552730146500608",
        "id" : "1134552730146500608"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1308989075249131523",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308989075249131523",
    "created_at" : "Thu Sep 24 04:38:10 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @FallGuysGame: You have 3 options:\n\n1) We pretend that the last tweet was a joke and we never talk about it again.\n\n2) It's just the way…",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Fall Guys 👑",
        "screen_name" : "FallGuysGame",
        "indices" : [ "3", "16" ],
        "id_str" : "1134552730146500608",
        "id" : "1134552730146500608"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1308988971654021121",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1308988971654021121",
    "created_at" : "Thu Sep 24 04:37:45 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @FallGuysGame: Well, you asked for it...\n\nThis is official lore now\n\nRemember: \n\n• Human shown for scale\n• Fall Guys are 183cm (6ft)\n• T…",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1309829793966301184",
    "id_str" : "1309831474539974656",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309831474539974656",
    "in_reply_to_status_id" : "1309829793966301184",
    "created_at" : "Sat Sep 26 12:25:33 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c しかしそろそろ血圧と体重が…ww",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hayasakaaaaaa",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "34" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1309828149354442752",
    "id_str" : "1309829081085612033",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309829081085612033",
    "in_reply_to_status_id" : "1309828149354442752",
    "created_at" : "Sat Sep 26 12:16:03 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c ああああ言わないデェえ:(；ﾞﾟ'ωﾟ'):",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hayasakaaaaaa",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "56" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1309824983691010049",
    "id_str" : "1309825258640138243",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309825258640138243",
    "in_reply_to_status_id" : "1309824983691010049",
    "created_at" : "Sat Sep 26 12:00:51 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c 直、隣がプリンスホテルで、裏が満喫なので、飲兵衛バタンキューが可能(☝︎ ՞ਊ ՞)☝︎",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "67" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1309823448319844352",
    "id_str" : "1309824983691010049",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309824983691010049",
    "in_reply_to_status_id" : "1309823448319844352",
    "created_at" : "Sat Sep 26 11:59:46 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c 行ったことあるー！平日はたまに並ぶのよね、夜飲んだ後とかおいラーメンするw\n飯が確か新潟のコメでそっちもうまい",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "下西 風澄",
        "screen_name" : "kazeto",
        "indices" : [ "3", "10" ],
        "id_str" : "14190096",
        "id" : "14190096"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/kazeto/status/1309680556691521536/photo/1",
        "source_status_id" : "1309680556691521536",
        "indices" : [ "96", "119" ],
        "url" : "https://t.co/vVavrsXnE7",
        "media_url" : "http://pbs.twimg.com/media/EizrhQTUMAI4qzh.jpg",
        "id_str" : "1309680548202164226",
        "source_user_id" : "14190096",
        "id" : "1309680548202164226",
        "media_url_https" : "https://pbs.twimg.com/media/EizrhQTUMAI4qzh.jpg",
        "source_user_id_str" : "14190096",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1024",
            "h" : "1024",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1024",
            "h" : "1024",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1309680556691521536",
        "display_url" : "pic.twitter.com/vVavrsXnE7"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "119" ],
    "favorite_count" : "0",
    "id_str" : "1309824245921325061",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309824245921325061",
    "possibly_sensitive" : false,
    "created_at" : "Sat Sep 26 11:56:50 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @kazeto: 危険な思想を持った哲学者は多くいるが、やはりプラトンが断トツだな。くじ引きで結婚を決める制度を作るが、実際は裏で操作するという発想がヤバイ。（ラッセル『西洋哲学史』） https://t.co/vVavrsXnE7",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/kazeto/status/1309680556691521536/photo/1",
        "source_status_id" : "1309680556691521536",
        "indices" : [ "96", "119" ],
        "url" : "https://t.co/vVavrsXnE7",
        "media_url" : "http://pbs.twimg.com/media/EizrhQTUMAI4qzh.jpg",
        "id_str" : "1309680548202164226",
        "source_user_id" : "14190096",
        "id" : "1309680548202164226",
        "media_url_https" : "https://pbs.twimg.com/media/EizrhQTUMAI4qzh.jpg",
        "source_user_id_str" : "14190096",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1024",
            "h" : "1024",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1024",
            "h" : "1024",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1309680556691521536",
        "display_url" : "pic.twitter.com/vVavrsXnE7"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/05OVwPxt9k",
        "expanded_url" : "https://twitter.com/DtimesJP/status/1309817399156174849",
        "display_url" : "twitter.com/DtimesJP/statu…",
        "indices" : [ "12", "35" ]
      } ]
    },
    "display_text_range" : [ "0", "35" ],
    "favorite_count" : "0",
    "id_str" : "1309823529081159680",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309823529081159680",
    "possibly_sensitive" : false,
    "created_at" : "Sat Sep 26 11:53:59 +0000 2020",
    "favorited" : false,
    "full_text" : "ヤバい4枚目ちょー好み https://t.co/05OVwPxt9k",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "35" ],
    "favorite_count" : "2",
    "id_str" : "1309821943596552197",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309821943596552197",
    "created_at" : "Sat Sep 26 11:47:41 +0000 2020",
    "favorited" : false,
    "full_text" : "うどんは作れるが、ラーメンは作れんな…\n\nかん水からやってみようかな…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "遊舎工房",
        "screen_name" : "yushakobo",
        "indices" : [ "3", "13" ],
        "id_str" : "968385122293698560",
        "id" : "968385122293698560"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/yushakobo/status/1309794823440723969/photo/1",
        "source_status_id" : "1309794823440723969",
        "indices" : [ "72", "95" ],
        "url" : "https://t.co/VJ8hMdtzG2",
        "media_url" : "http://pbs.twimg.com/media/Ei1TcwaUcAATQKI.jpg",
        "id_str" : "1309794820131418112",
        "source_user_id" : "968385122293698560",
        "id" : "1309794820131418112",
        "media_url_https" : "https://pbs.twimg.com/media/Ei1TcwaUcAATQKI.jpg",
        "source_user_id_str" : "968385122293698560",
        "sizes" : {
          "large" : {
            "w" : "859",
            "h" : "427",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "338",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "859",
            "h" : "427",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1309794823440723969",
        "display_url" : "pic.twitter.com/VJ8hMdtzG2"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "95" ],
    "favorite_count" : "0",
    "id_str" : "1309821337683148802",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309821337683148802",
    "possibly_sensitive" : false,
    "created_at" : "Sat Sep 26 11:45:16 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @yushakobo: [新商品]ソウルジェムキーキャップが入荷しました\n(;´･ω･).。o○（誰か足りない気がするけどまぁいいか…） https://t.co/VJ8hMdtzG2",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/yushakobo/status/1309794823440723969/photo/1",
        "source_status_id" : "1309794823440723969",
        "indices" : [ "72", "95" ],
        "url" : "https://t.co/VJ8hMdtzG2",
        "media_url" : "http://pbs.twimg.com/media/Ei1TcwaUcAATQKI.jpg",
        "id_str" : "1309794820131418112",
        "source_user_id" : "968385122293698560",
        "id" : "1309794820131418112",
        "media_url_https" : "https://pbs.twimg.com/media/Ei1TcwaUcAATQKI.jpg",
        "source_user_id_str" : "968385122293698560",
        "sizes" : {
          "large" : {
            "w" : "859",
            "h" : "427",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "338",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "859",
            "h" : "427",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1309794823440723969",
        "display_url" : "pic.twitter.com/VJ8hMdtzG2"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "121" ],
    "favorite_count" : "2",
    "in_reply_to_status_id_str" : "1309818554686951424",
    "id_str" : "1309819021399711745",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309819021399711745",
    "in_reply_to_status_id" : "1309818554686951424",
    "created_at" : "Sat Sep 26 11:36:04 +0000 2020",
    "favorited" : false,
    "full_text" : "ちなみにここは直久という都内展開のお店。入りやすい雰囲気で、とてもおいしい鶏背油ラーメンが食べられる。背脂に抵抗があっても、そこまで油ギトギトということもなく、全く気にならない。他にも背脂なしの商品や、変わり種も多く近所なのがありがたいお店。",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1309818554686951424/photo/1",
        "indices" : [ "17", "40" ],
        "url" : "https://t.co/VLyi1xIKnR",
        "media_url" : "http://pbs.twimg.com/media/Ei1pBmWU8AEYltm.jpg",
        "id_str" : "1309818542829662209",
        "id" : "1309818542829662209",
        "media_url_https" : "https://pbs.twimg.com/media/Ei1pBmWU8AEYltm.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/VLyi1xIKnR"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "40" ],
    "favorite_count" : "5",
    "id_str" : "1309818554686951424",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309818554686951424",
    "possibly_sensitive" : false,
    "created_at" : "Sat Sep 26 11:34:13 +0000 2020",
    "favorited" : false,
    "full_text" : "ああああだめ、ほんとだめ。デブ。 https://t.co/VLyi1xIKnR",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1309818554686951424/photo/1",
        "indices" : [ "17", "40" ],
        "url" : "https://t.co/VLyi1xIKnR",
        "media_url" : "http://pbs.twimg.com/media/Ei1pBmWU8AEYltm.jpg",
        "id_str" : "1309818542829662209",
        "id" : "1309818542829662209",
        "media_url_https" : "https://pbs.twimg.com/media/Ei1pBmWU8AEYltm.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/VLyi1xIKnR"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "えぐち☄︎",
        "screen_name" : "eguchi_saan",
        "indices" : [ "3", "15" ],
        "id_str" : "841994608066224128",
        "id" : "841994608066224128"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/eguchi_saan/status/1309533480124993543/photo/1",
        "source_status_id" : "1309533480124993543",
        "indices" : [ "17", "40" ],
        "url" : "https://t.co/Oq0OWkfY9N",
        "media_url" : "http://pbs.twimg.com/media/EixlwgvUYAEA0bH.jpg",
        "id_str" : "1309533475754500097",
        "source_user_id" : "841994608066224128",
        "id" : "1309533475754500097",
        "media_url_https" : "https://pbs.twimg.com/media/EixlwgvUYAEA0bH.jpg",
        "source_user_id_str" : "841994608066224128",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1395",
            "h" : "2048",
            "resize" : "fit"
          },
          "small" : {
            "w" : "463",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "817",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1309533480124993543",
        "display_url" : "pic.twitter.com/Oq0OWkfY9N"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "40" ],
    "favorite_count" : "0",
    "id_str" : "1309692824103735296",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309692824103735296",
    "possibly_sensitive" : false,
    "created_at" : "Sat Sep 26 03:14:36 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @eguchi_saan: https://t.co/Oq0OWkfY9N",
    "lang" : "und",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/eguchi_saan/status/1309533480124993543/photo/1",
        "source_status_id" : "1309533480124993543",
        "indices" : [ "17", "40" ],
        "url" : "https://t.co/Oq0OWkfY9N",
        "media_url" : "http://pbs.twimg.com/media/EixlwgvUYAEA0bH.jpg",
        "id_str" : "1309533475754500097",
        "source_user_id" : "841994608066224128",
        "id" : "1309533475754500097",
        "media_url_https" : "https://pbs.twimg.com/media/EixlwgvUYAEA0bH.jpg",
        "source_user_id_str" : "841994608066224128",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1395",
            "h" : "2048",
            "resize" : "fit"
          },
          "small" : {
            "w" : "463",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "817",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1309533480124993543",
        "display_url" : "pic.twitter.com/Oq0OWkfY9N"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "1",
    "id_str" : "1309648481154289664",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309648481154289664",
    "created_at" : "Sat Sep 26 00:18:24 +0000 2020",
    "favorited" : false,
    "full_text" : "slushiiに期待。明日朝6じから",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "66" ],
    "favorite_count" : "0",
    "id_str" : "1309647828071804928",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309647828071804928",
    "created_at" : "Sat Sep 26 00:15:48 +0000 2020",
    "favorited" : false,
    "full_text" : "epicにも余裕ないのはわかるが、みんなでPVを見る会って広めないと…\n\n初公開のライブとか宣伝してこれなら\n\nそりゃ批判もくるわ…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "EL⁷ ᵇᵉ ia 7M PREORDERS!",
        "screen_name" : "joonsace",
        "indices" : [ "3", "12" ],
        "id_str" : "1159660296073613312",
        "id" : "1159660296073613312"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1309647502476341249",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309647502476341249",
    "created_at" : "Sat Sep 26 00:14:31 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @joonsace: why fortnite did us wrong... it couldve looked like this with giant animated bts doing choreography yall 😕https://t.co/tNywfx…",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1309647179909222400/photo/1",
        "indices" : [ "75", "98" ],
        "url" : "https://t.co/XMnSn7DnB3",
        "media_url" : "http://pbs.twimg.com/media/EizNKu1VkAAL-pR.jpg",
        "id_str" : "1309647175912099840",
        "id" : "1309647175912099840",
        "media_url_https" : "https://pbs.twimg.com/media/EizNKu1VkAAL-pR.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "467",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "840",
            "h" : "577",
            "resize" : "fit"
          },
          "large" : {
            "w" : "840",
            "h" : "577",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/XMnSn7DnB3"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "98" ],
    "favorite_count" : "0",
    "id_str" : "1309647179909222400",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309647179909222400",
    "possibly_sensitive" : false,
    "created_at" : "Sat Sep 26 00:13:14 +0000 2020",
    "favorited" : false,
    "full_text" : "ちょ、まじ、ただpv流す会でした…\n\n本人たち出てこない、PV流して終わりだった…無料だししゃーないがこりゃなんとも…\n\nyoutubeでええやろ… https://t.co/XMnSn7DnB3",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1309647179909222400/photo/1",
        "indices" : [ "75", "98" ],
        "url" : "https://t.co/XMnSn7DnB3",
        "media_url" : "http://pbs.twimg.com/media/EizNKu1VkAAL-pR.jpg",
        "id_str" : "1309647175912099840",
        "id" : "1309647175912099840",
        "media_url_https" : "https://pbs.twimg.com/media/EizNKu1VkAAL-pR.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "467",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "840",
            "h" : "577",
            "resize" : "fit"
          },
          "large" : {
            "w" : "840",
            "h" : "577",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/XMnSn7DnB3"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "27" ],
    "favorite_count" : "1",
    "id_str" : "1309624556655538176",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309624556655538176",
    "created_at" : "Fri Sep 25 22:43:20 +0000 2020",
    "favorited" : false,
    "full_text" : "9じからBTSのライブじゃん\n\nフォトナ 起動しなきゃ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "32" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1309510474740822016",
    "id_str" : "1309513205857746944",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309513205857746944",
    "in_reply_to_status_id" : "1309510474740822016",
    "created_at" : "Fri Sep 25 15:20:52 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo しかしね、君。うまいんだこれが",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1309510044547915782",
    "id_str" : "1309513139143110656",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309513139143110656",
    "in_reply_to_status_id" : "1309510044547915782",
    "created_at" : "Fri Sep 25 15:20:36 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo かほりんの絡み好きだわ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "119" ],
    "favorite_count" : "1",
    "id_str" : "1309505377319317505",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309505377319317505",
    "created_at" : "Fri Sep 25 14:49:46 +0000 2020",
    "favorited" : false,
    "full_text" : "自分が相手を求める様(執着の度合い)に対して、相手のそれがハードル低いと\n\nどうしてだか不満になる。なぜか抑えることができない。\n\n相手が悪いわけではないはずなのに\n\n相手にも自分が求めるようにして欲しいと思ってしまうのは何故なんだろう。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "0",
    "id_str" : "1309504435211567104",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309504435211567104",
    "created_at" : "Fri Sep 25 14:46:01 +0000 2020",
    "favorited" : false,
    "full_text" : "結局人間なんて見たい部分以外は無いものにするのか。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "0",
    "id_str" : "1309498059622027265",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309498059622027265",
    "created_at" : "Fri Sep 25 14:20:41 +0000 2020",
    "favorited" : false,
    "full_text" : "ディズニーハロウィンが1年で一番好きなディズニーである。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "ジーユー",
        "indices" : [ "110", "115" ]
      }, {
        "text" : "GU",
        "indices" : [ "116", "119" ]
      }, {
        "text" : "Disney",
        "indices" : [ "120", "127" ]
      }, {
        "text" : "ディズニー",
        "indices" : [ "128", "134" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "GU（ジーユー）",
        "screen_name" : "gu_global",
        "indices" : [ "3", "13" ],
        "id_str" : "484629796",
        "id" : "484629796"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1309497585506287616",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309497585506287616",
    "created_at" : "Fri Sep 25 14:18:48 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @gu_global: 【販売開始】\n不思議なパワーと妖艶さを持つ、怪しくも美しいディズニーヴィランズのスペシャルコレクションが販売開始❗\nTシャツやスウェット、グッズなどハロウィンにぴったりなアイテムが登場🎃😈\n#ジーユー #GU ＃Disney #ディズニー #Hal…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "3", "19" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      }, {
        "name" : "Hinata",
        "screen_name" : "Hinata72279726",
        "indices" : [ "21", "36" ],
        "id_str" : "1228559135093821441",
        "id" : "1228559135093821441"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "56" ],
    "favorite_count" : "0",
    "id_str" : "1309496531725086721",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309496531725086721",
    "created_at" : "Fri Sep 25 14:14:37 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Kahorin_42Tokyo: @Hinata72279726 あーーーーーーーーたべたいたべたすぎる",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "35" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1309490406267056128",
    "id_str" : "1309496504009146369",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309496504009146369",
    "in_reply_to_status_id" : "1309490406267056128",
    "created_at" : "Fri Sep 25 14:14:30 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo 大盛りにおい飯にスープ割で腹パンパン",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "ぬ9円",
        "screen_name" : "endesu_",
        "indices" : [ "3", "11" ],
        "id_str" : "77690451",
        "id" : "77690451"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "57" ],
    "favorite_count" : "0",
    "id_str" : "1309392630153797634",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309392630153797634",
    "created_at" : "Fri Sep 25 07:21:45 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @endesu_: 学会ネタめっちゃあるけどフォロワー受けはそんなに良くないんだよね（自己分析のできる大人）",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "32" ],
    "favorite_count" : "1",
    "id_str" : "1310582009329197057",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310582009329197057",
    "created_at" : "Mon Sep 28 14:07:55 +0000 2020",
    "favorited" : false,
    "full_text" : "色変えると気分上がる現象に名前つけたい\n\nカスタマイズ欲がすごい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aonabi",
        "screen_name" : "Aonabi_J",
        "indices" : [ "3", "12" ],
        "id_str" : "973229219114135552",
        "id" : "973229219114135552"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Aonabi_J/status/1309806944895475712/photo/1",
        "source_status_id" : "1309806944895475712",
        "indices" : [ "21", "44" ],
        "url" : "https://t.co/QNlSJHx2cw",
        "media_url" : "http://pbs.twimg.com/media/Ei1eXu1U4AAclmD.jpg",
        "id_str" : "1309806828436381696",
        "source_user_id" : "973229219114135552",
        "id" : "1309806828436381696",
        "media_url_https" : "https://pbs.twimg.com/media/Ei1eXu1U4AAclmD.jpg",
        "source_user_id_str" : "973229219114135552",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "2048",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1309806944895475712",
        "display_url" : "pic.twitter.com/QNlSJHx2cw"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "44" ],
    "favorite_count" : "0",
    "id_str" : "1310484666806280192",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310484666806280192",
    "possibly_sensitive" : false,
    "created_at" : "Mon Sep 28 07:41:06 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Aonabi_J: ハングル時計 https://t.co/QNlSJHx2cw",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Aonabi_J/status/1309806944895475712/photo/1",
        "source_status_id" : "1309806944895475712",
        "indices" : [ "21", "44" ],
        "url" : "https://t.co/QNlSJHx2cw",
        "media_url" : "http://pbs.twimg.com/media/Ei1eXu1U4AAclmD.jpg",
        "id_str" : "1309806828436381696",
        "source_user_id" : "973229219114135552",
        "id" : "1309806828436381696",
        "media_url_https" : "https://pbs.twimg.com/media/Ei1eXu1U4AAclmD.jpg",
        "source_user_id_str" : "973229219114135552",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "2048",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1309806944895475712",
        "display_url" : "pic.twitter.com/QNlSJHx2cw"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/HAshOonWwa",
        "expanded_url" : "https://twitter.com/TDR_PR/status/1310177381894647809",
        "display_url" : "twitter.com/TDR_PR/status/…",
        "indices" : [ "29", "52" ]
      } ]
    },
    "display_text_range" : [ "0", "52" ],
    "favorite_count" : "1",
    "id_str" : "1310353107944005633",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310353107944005633",
    "possibly_sensitive" : false,
    "created_at" : "Sun Sep 27 22:58:20 +0000 2020",
    "favorited" : false,
    "full_text" : "行くと心に決めた時、すでにお前はディズニーにいる(((( https://t.co/HAshOonWwa",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1310352642950930432/photo/1",
        "indices" : [ "5", "28" ],
        "url" : "https://t.co/YZMkBIdTMC",
        "media_url" : "http://pbs.twimg.com/media/Ei9OyDoUwAAWVp5.jpg",
        "id_str" : "1310352638462967808",
        "id" : "1310352638462967808",
        "media_url_https" : "https://pbs.twimg.com/media/Ei9OyDoUwAAWVp5.jpg",
        "sizes" : {
          "large" : {
            "w" : "640",
            "h" : "1136",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "640",
            "h" : "1136",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "383",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/YZMkBIdTMC"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "0",
    "id_str" : "1310352642950930432",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310352642950930432",
    "possibly_sensitive" : false,
    "created_at" : "Sun Sep 27 22:56:29 +0000 2020",
    "favorited" : false,
    "full_text" : "おはよう https://t.co/YZMkBIdTMC",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1310352642950930432/photo/1",
        "indices" : [ "5", "28" ],
        "url" : "https://t.co/YZMkBIdTMC",
        "media_url" : "http://pbs.twimg.com/media/Ei9OyDoUwAAWVp5.jpg",
        "id_str" : "1310352638462967808",
        "id" : "1310352638462967808",
        "media_url_https" : "https://pbs.twimg.com/media/Ei9OyDoUwAAWVp5.jpg",
        "sizes" : {
          "large" : {
            "w" : "640",
            "h" : "1136",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "640",
            "h" : "1136",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "383",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/YZMkBIdTMC"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "7" ],
    "favorite_count" : "1",
    "id_str" : "1310254063271829504",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310254063271829504",
    "created_at" : "Sun Sep 27 16:24:46 +0000 2020",
    "favorited" : false,
    "full_text" : "火曜誕生日だわ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "16" ],
    "favorite_count" : "0",
    "id_str" : "1310246003124002818",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310246003124002818",
    "created_at" : "Sun Sep 27 15:52:44 +0000 2020",
    "favorited" : false,
    "full_text" : "ディズニーのイマジニアになりたい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "56" ],
    "favorite_count" : "5",
    "id_str" : "1310238455129989121",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310238455129989121",
    "created_at" : "Sun Sep 27 15:22:45 +0000 2020",
    "favorited" : false,
    "full_text" : "今までで一番、学校の授業とか恋しくなったかも知れん。\n\nあんなものと思ってたら、あんなものが一番自分を救ってる。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ちゃん★",
        "screen_name" : "mickey2017d",
        "indices" : [ "3", "15" ],
        "id_str" : "863567005542002688",
        "id" : "863567005542002688"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/mickey2017d/status/1310170280472375296/photo/1",
        "source_status_id" : "1310170280472375296",
        "indices" : [ "59", "82" ],
        "url" : "https://t.co/JBm8B3VDuT",
        "media_url" : "http://pbs.twimg.com/media/Ei6o7ADUcAArva1.jpg",
        "id_str" : "1310170273191063552",
        "source_user_id" : "863567005542002688",
        "id" : "1310170273191063552",
        "media_url_https" : "https://pbs.twimg.com/media/Ei6o7ADUcAArva1.jpg",
        "source_user_id_str" : "863567005542002688",
        "sizes" : {
          "large" : {
            "w" : "1152",
            "h" : "1728",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "453",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "800",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1310170280472375296",
        "display_url" : "pic.twitter.com/JBm8B3VDuT"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "82" ],
    "favorite_count" : "0",
    "id_str" : "1310238121695477760",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310238121695477760",
    "possibly_sensitive" : false,
    "created_at" : "Sun Sep 27 15:21:25 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @mickey2017d: 東京ディズニーシー\nTokyo Disneysea\n\nお気に入り夜景スポットの4選 https://t.co/JBm8B3VDuT",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/mickey2017d/status/1310170280472375296/photo/1",
        "source_status_id" : "1310170280472375296",
        "indices" : [ "59", "82" ],
        "url" : "https://t.co/JBm8B3VDuT",
        "media_url" : "http://pbs.twimg.com/media/Ei6o7ADUcAArva1.jpg",
        "id_str" : "1310170273191063552",
        "source_user_id" : "863567005542002688",
        "id" : "1310170273191063552",
        "media_url_https" : "https://pbs.twimg.com/media/Ei6o7ADUcAArva1.jpg",
        "source_user_id_str" : "863567005542002688",
        "sizes" : {
          "large" : {
            "w" : "1152",
            "h" : "1728",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "453",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "800",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1310170280472375296",
        "display_url" : "pic.twitter.com/JBm8B3VDuT"
      }, {
        "expanded_url" : "https://twitter.com/mickey2017d/status/1310170280472375296/photo/1",
        "source_status_id" : "1310170280472375296",
        "indices" : [ "59", "82" ],
        "url" : "https://t.co/JBm8B3VDuT",
        "media_url" : "http://pbs.twimg.com/media/Ei6o7ADU8AAe5ry.jpg",
        "id_str" : "1310170273191096320",
        "source_user_id" : "863567005542002688",
        "id" : "1310170273191096320",
        "media_url_https" : "https://pbs.twimg.com/media/Ei6o7ADU8AAe5ry.jpg",
        "source_user_id_str" : "863567005542002688",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "799",
            "h" : "1200",
            "resize" : "fit"
          },
          "small" : {
            "w" : "453",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1152",
            "h" : "1731",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1310170280472375296",
        "display_url" : "pic.twitter.com/JBm8B3VDuT"
      }, {
        "expanded_url" : "https://twitter.com/mickey2017d/status/1310170280472375296/photo/1",
        "source_status_id" : "1310170280472375296",
        "indices" : [ "59", "82" ],
        "url" : "https://t.co/JBm8B3VDuT",
        "media_url" : "http://pbs.twimg.com/media/Ei6o7B7VkAQJX08.jpg",
        "id_str" : "1310170273694453764",
        "source_user_id" : "863567005542002688",
        "id" : "1310170273694453764",
        "media_url_https" : "https://pbs.twimg.com/media/Ei6o7B7VkAQJX08.jpg",
        "source_user_id_str" : "863567005542002688",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "799",
            "h" : "1200",
            "resize" : "fit"
          },
          "small" : {
            "w" : "453",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1152",
            "h" : "1731",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1310170280472375296",
        "display_url" : "pic.twitter.com/JBm8B3VDuT"
      }, {
        "expanded_url" : "https://twitter.com/mickey2017d/status/1310170280472375296/photo/1",
        "source_status_id" : "1310170280472375296",
        "indices" : [ "59", "82" ],
        "url" : "https://t.co/JBm8B3VDuT",
        "media_url" : "http://pbs.twimg.com/media/Ei6o7EVU0AEj9RC.jpg",
        "id_str" : "1310170274340327425",
        "source_user_id" : "863567005542002688",
        "id" : "1310170274340327425",
        "media_url_https" : "https://pbs.twimg.com/media/Ei6o7EVU0AEj9RC.jpg",
        "source_user_id_str" : "863567005542002688",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "453",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1152",
            "h" : "1731",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "799",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1310170280472375296",
        "display_url" : "pic.twitter.com/JBm8B3VDuT"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "おねすとちゃんねる@42Tokyo.9月Piscine生",
        "screen_name" : "honestchanel",
        "indices" : [ "3", "16" ],
        "id_str" : "855651284006785024",
        "id" : "855651284006785024"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "81" ],
    "favorite_count" : "0",
    "id_str" : "1310238089764204545",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310238089764204545",
    "created_at" : "Sun Sep 27 15:21:18 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @honestchanel: picaineは、コロナがなければ、\n校舎で、みんなでワイワイしてたのになぁー。\nリモートは、やっぱりツラい。\n(´・ω・｀)",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "1",
    "id_str" : "1310046424575258624",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310046424575258624",
    "created_at" : "Sun Sep 27 02:39:41 +0000 2020",
    "favorited" : false,
    "full_text" : "今度は正常に腹が痛い。\n\n覚悟していても痛いものは痛い。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "17" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1310043071334080512",
    "id_str" : "1310046296762249217",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310046296762249217",
    "in_reply_to_status_id" : "1310043071334080512",
    "created_at" : "Sun Sep 27 02:39:11 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta ポークビッツ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "11", "27" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "49" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1310028487638491138",
    "id_str" : "1310034844907257856",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310034844907257856",
    "in_reply_to_status_id" : "1310028487638491138",
    "created_at" : "Sun Sep 27 01:53:40 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @Kahorin_42Tokyo mallocし過ぎても容量足りなくなりそう",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "11", "27" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "53" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1310027160137003010",
    "id_str" : "1310028262177820674",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310028262177820674",
    "in_reply_to_status_id" : "1310027160137003010",
    "created_at" : "Sun Sep 27 01:27:31 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @Kahorin_42Tokyo 相手がいないとfreeできなくてオーバーフローする",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "12" ],
    "favorite_count" : "1",
    "id_str" : "1309974000395669504",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309974000395669504",
    "created_at" : "Sat Sep 26 21:51:54 +0000 2020",
    "favorited" : false,
    "full_text" : "二度寝٩( 'ω' )و",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "LiaqN 🦁",
        "screen_name" : "LiaqN_",
        "indices" : [ "3", "10" ],
        "id_str" : "1030829821213913088",
        "id" : "1030829821213913088"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "0",
    "id_str" : "1309973578478055425",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309973578478055425",
    "created_at" : "Sat Sep 26 21:50:13 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @LiaqN_: フォートナイト3周年おめでとうです！",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "63" ],
    "favorite_count" : "0",
    "id_str" : "1309973544088907776",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309973544088907776",
    "created_at" : "Sat Sep 26 21:50:05 +0000 2020",
    "favorited" : false,
    "full_text" : "すごいなあいつ、無料で45分回した上に曲の守備範囲広過ぎてもう…\n\n朝からテンション爆上げ、脳汁染み出しまくりのせいで寝れない",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "17" ],
    "favorite_count" : "0",
    "id_str" : "1309965749021061120",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309965749021061120",
    "created_at" : "Sat Sep 26 21:19:07 +0000 2020",
    "favorited" : false,
    "full_text" : "すごくすごくすき\nあーーー回復する",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "11", "27" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "70" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1309933207521878016",
    "id_str" : "1309964503233081345",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309964503233081345",
    "in_reply_to_status_id" : "1309933207521878016",
    "created_at" : "Sat Sep 26 21:14:10 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @Kahorin_42Tokyo ゆうたのちんこはCでてきてるから、ちんこの機能だけ仮想関数でじっそうされてんだろ？か",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "49" ],
    "favorite_count" : "0",
    "id_str" : "1309964309573795840",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309964309573795840",
    "created_at" : "Sat Sep 26 21:13:24 +0000 2020",
    "favorited" : false,
    "full_text" : "昨日との落差凄すぎる\n\nslushiiやっぱすごい、このクオリティ持ってきてくれちゃうの(((((",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "11", "27" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "32" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1309859831981813760",
    "id_str" : "1309862843181719552",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309862843181719552",
    "in_reply_to_status_id" : "1309859831981813760",
    "created_at" : "Sat Sep 26 14:30:12 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @Kahorin_42Tokyo 継承…？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "🐘みょる🐘",
        "screen_name" : "suzuib",
        "indices" : [ "3", "10" ],
        "id_str" : "1177932508366700545",
        "id" : "1177932508366700545"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/suzuib/status/1309832463481319425/photo/1",
        "source_status_id" : "1309832463481319425",
        "indices" : [ "37", "60" ],
        "url" : "https://t.co/bG5tAdasHC",
        "media_url" : "http://pbs.twimg.com/media/Ei11rwkU8AA1G-Q.jpg",
        "id_str" : "1309832461266776064",
        "source_user_id" : "1177932508366700545",
        "id" : "1309832461266776064",
        "media_url_https" : "https://pbs.twimg.com/media/Ei11rwkU8AA1G-Q.jpg",
        "source_user_id_str" : "1177932508366700545",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1024",
            "h" : "479",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "318",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1024",
            "h" : "479",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1309832463481319425",
        "display_url" : "pic.twitter.com/bG5tAdasHC"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "60" ],
    "favorite_count" : "0",
    "id_str" : "1309859226139779072",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309859226139779072",
    "possibly_sensitive" : false,
    "created_at" : "Sat Sep 26 14:15:50 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @suzuib: プロンプトを顔文字にするの、めちゃめちゃ可愛いな https://t.co/bG5tAdasHC",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/suzuib/status/1309832463481319425/photo/1",
        "source_status_id" : "1309832463481319425",
        "indices" : [ "37", "60" ],
        "url" : "https://t.co/bG5tAdasHC",
        "media_url" : "http://pbs.twimg.com/media/Ei11rwkU8AA1G-Q.jpg",
        "id_str" : "1309832461266776064",
        "source_user_id" : "1177932508366700545",
        "id" : "1309832461266776064",
        "media_url_https" : "https://pbs.twimg.com/media/Ei11rwkU8AA1G-Q.jpg",
        "source_user_id_str" : "1177932508366700545",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1024",
            "h" : "479",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "318",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1024",
            "h" : "479",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1309832463481319425",
        "display_url" : "pic.twitter.com/bG5tAdasHC"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1309850382139404288",
    "id_str" : "1309855696821743619",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309855696821743619",
    "in_reply_to_status_id" : "1309850382139404288",
    "created_at" : "Sat Sep 26 14:01:48 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo あっはぁん💞",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "3", "19" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      }, {
        "name" : "Hinata",
        "screen_name" : "Hinata72279726",
        "indices" : [ "21", "36" ],
        "id_str" : "1228559135093821441",
        "id" : "1228559135093821441"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "75" ],
    "favorite_count" : "0",
    "id_str" : "1309855595818676224",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1309855595818676224",
    "created_at" : "Sat Sep 26 14:01:24 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Kahorin_42Tokyo: @Hinata72279726 なにやってんだ！！んもう、けしからん！実にけしからんっ！(いいぞ、もっとやれ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "33" ],
    "favorite_count" : "2",
    "id_str" : "1311816543374770176",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311816543374770176",
    "created_at" : "Thu Oct 01 23:53:30 +0000 2020",
    "favorited" : false,
    "full_text" : "夜中、まぶたを蚊に刺されて\n\n朝起きたらあつ森の鉢刺されみたいで草",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "8" ],
    "favorite_count" : "5",
    "id_str" : "1311672613463154689",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311672613463154689",
    "created_at" : "Thu Oct 01 14:21:35 +0000 2020",
    "favorited" : false,
    "full_text" : "おやすみなさい⭐",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Liberta Ta-Key",
        "screen_name" : "Ta_Key18",
        "indices" : [ "3", "12" ],
        "id_str" : "1176793471312515072",
        "id" : "1176793471312515072"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Ta_Key18/status/1311621681350287360/photo/1",
        "source_status_id" : "1311621681350287360",
        "indices" : [ "89", "112" ],
        "url" : "https://t.co/yko3XX0kyq",
        "media_url" : "http://pbs.twimg.com/media/EjPQ9tvU0AABbCe.jpg",
        "id_str" : "1311621675163635712",
        "source_user_id" : "1176793471312515072",
        "id" : "1311621675163635712",
        "media_url_https" : "https://pbs.twimg.com/media/EjPQ9tvU0AABbCe.jpg",
        "source_user_id_str" : "1176793471312515072",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1920",
            "h" : "1080",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1311621681350287360",
        "display_url" : "pic.twitter.com/yko3XX0kyq"
      } ],
      "hashtags" : [ {
        "text" : "Fortnitecreative",
        "indices" : [ "54", "71" ]
      }, {
        "text" : "フォートナイトクリエイティブ",
        "indices" : [ "73", "88" ]
      } ]
    },
    "display_text_range" : [ "0", "112" ],
    "favorite_count" : "0",
    "id_str" : "1311627256071024640",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311627256071024640",
    "possibly_sensitive" : false,
    "created_at" : "Thu Oct 01 11:21:21 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Ta_Key18: 80年代アメリカ × 近未来\n今回はフォートナイト要素多めで作ってみました！\n\n#Fortnitecreative \n#フォートナイトクリエイティブ https://t.co/yko3XX0kyq",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Ta_Key18/status/1311621681350287360/photo/1",
        "source_status_id" : "1311621681350287360",
        "indices" : [ "89", "112" ],
        "url" : "https://t.co/yko3XX0kyq",
        "media_url" : "http://pbs.twimg.com/media/EjPQ9tvU0AABbCe.jpg",
        "id_str" : "1311621675163635712",
        "source_user_id" : "1176793471312515072",
        "id" : "1311621675163635712",
        "media_url_https" : "https://pbs.twimg.com/media/EjPQ9tvU0AABbCe.jpg",
        "source_user_id_str" : "1176793471312515072",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1920",
            "h" : "1080",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1311621681350287360",
        "display_url" : "pic.twitter.com/yko3XX0kyq"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ROY【new】",
        "screen_name" : "ROYSTORYq",
        "indices" : [ "3", "13" ],
        "id_str" : "1274275520054571009",
        "id" : "1274275520054571009"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/ROYSTORYq/status/1310609815190736897/photo/1",
        "source_status_id" : "1310609815190736897",
        "indices" : [ "63", "86" ],
        "url" : "https://t.co/5zy0rQKBfy",
        "media_url" : "http://pbs.twimg.com/media/EjA4q6HUYAAHrSz.jpg",
        "id_str" : "1310609801370427392",
        "source_user_id" : "1274275520054571009",
        "id" : "1310609801370427392",
        "media_url_https" : "https://pbs.twimg.com/media/EjA4q6HUYAAHrSz.jpg",
        "source_user_id_str" : "1274275520054571009",
        "sizes" : {
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1920",
            "h" : "1080",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1310609815190736897",
        "display_url" : "pic.twitter.com/5zy0rQKBfy"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "86" ],
    "favorite_count" : "0",
    "id_str" : "1311627064043163650",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311627064043163650",
    "possibly_sensitive" : false,
    "created_at" : "Thu Oct 01 11:20:35 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @ROYSTORYq: 1000♥ありがとうございます！\nいろいろ作ってるのでよかったらフォローよろしくお願いします🙏 https://t.co/5zy0rQKBfy",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/ROYSTORYq/status/1310609815190736897/photo/1",
        "source_status_id" : "1310609815190736897",
        "indices" : [ "63", "86" ],
        "url" : "https://t.co/5zy0rQKBfy",
        "media_url" : "http://pbs.twimg.com/media/EjA4q6HUYAAHrSz.jpg",
        "id_str" : "1310609801370427392",
        "source_user_id" : "1274275520054571009",
        "id" : "1310609801370427392",
        "media_url_https" : "https://pbs.twimg.com/media/EjA4q6HUYAAHrSz.jpg",
        "source_user_id_str" : "1274275520054571009",
        "sizes" : {
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1920",
            "h" : "1080",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1310609815190736897",
        "display_url" : "pic.twitter.com/5zy0rQKBfy"
      }, {
        "expanded_url" : "https://twitter.com/ROYSTORYq/status/1310609815190736897/photo/1",
        "source_status_id" : "1310609815190736897",
        "indices" : [ "63", "86" ],
        "url" : "https://t.co/5zy0rQKBfy",
        "media_url" : "http://pbs.twimg.com/media/EjA4rJMUYAIVLsU.jpg",
        "id_str" : "1310609805417930754",
        "source_user_id" : "1274275520054571009",
        "id" : "1310609805417930754",
        "media_url_https" : "https://pbs.twimg.com/media/EjA4rJMUYAIVLsU.jpg",
        "source_user_id_str" : "1274275520054571009",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1920",
            "h" : "1080",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1310609815190736897",
        "display_url" : "pic.twitter.com/5zy0rQKBfy"
      }, {
        "expanded_url" : "https://twitter.com/ROYSTORYq/status/1310609815190736897/photo/1",
        "source_status_id" : "1310609815190736897",
        "indices" : [ "63", "86" ],
        "url" : "https://t.co/5zy0rQKBfy",
        "media_url" : "http://pbs.twimg.com/media/EjA4rVmU8AAf0ZM.jpg",
        "id_str" : "1310609808748244992",
        "source_user_id" : "1274275520054571009",
        "id" : "1310609808748244992",
        "media_url_https" : "https://pbs.twimg.com/media/EjA4rVmU8AAf0ZM.jpg",
        "source_user_id_str" : "1274275520054571009",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1024",
            "h" : "576",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1024",
            "h" : "576",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1310609815190736897",
        "display_url" : "pic.twitter.com/5zy0rQKBfy"
      }, {
        "expanded_url" : "https://twitter.com/ROYSTORYq/status/1310609815190736897/photo/1",
        "source_status_id" : "1310609815190736897",
        "indices" : [ "63", "86" ],
        "url" : "https://t.co/5zy0rQKBfy",
        "media_url" : "http://pbs.twimg.com/media/EjA4rjnU0AAsP0o.jpg",
        "id_str" : "1310609812510527488",
        "source_user_id" : "1274275520054571009",
        "id" : "1310609812510527488",
        "media_url_https" : "https://pbs.twimg.com/media/EjA4rjnU0AAsP0o.jpg",
        "source_user_id_str" : "1274275520054571009",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1920",
            "h" : "1080",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1310609815190736897",
        "display_url" : "pic.twitter.com/5zy0rQKBfy"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "ROY【new】",
        "screen_name" : "ROYSTORYq",
        "indices" : [ "3", "13" ],
        "id_str" : "1274275520054571009",
        "id" : "1274275520054571009"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "144" ],
    "favorite_count" : "0",
    "id_str" : "1311626768705413120",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311626768705413120",
    "created_at" : "Thu Oct 01 11:19:25 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @ROYSTORYq: FORTNITE × pirates of the caribbean☠\n\nMAP CODE【3543-5702-1813】\n\nブラックパール号を再現しました！（内装も全て）\nフレンドたちと海賊気分を味わおう！\n\nRT &amp; フォローよろしくお願いし…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "10" ],
    "favorite_count" : "1",
    "id_str" : "1311341812561244162",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311341812561244162",
    "created_at" : "Wed Sep 30 16:27:06 +0000 2020",
    "favorited" : false,
    "full_text" : "寝る。おやすみなさい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/rQMImgV77J",
        "expanded_url" : "https://twitter.com/MezzoMikiD/status/1311144690683490304",
        "display_url" : "twitter.com/MezzoMikiD/sta…",
        "indices" : [ "15", "38" ]
      } ]
    },
    "display_text_range" : [ "0", "38" ],
    "favorite_count" : "0",
    "id_str" : "1311171039469035520",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311171039469035520",
    "possibly_sensitive" : false,
    "created_at" : "Wed Sep 30 05:08:30 +0000 2020",
    "favorited" : false,
    "full_text" : "やるのか！行かなきゃ！！！！ https://t.co/rQMImgV77J",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "51" ],
    "favorite_count" : "2",
    "id_str" : "1311170538912411651",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311170538912411651",
    "created_at" : "Wed Sep 30 05:06:31 +0000 2020",
    "favorited" : false,
    "full_text" : "git改築工事\npython系プロジェクト始める\nweb系に興味持つ練習\n\nCで楽しむ機械学習←new",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "29" ],
    "favorite_count" : "0",
    "id_str" : "1311170333894795264",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311170333894795264",
    "created_at" : "Wed Sep 30 05:05:42 +0000 2020",
    "favorited" : false,
    "full_text" : "1ヶ月執行猶予ができた。何をしようか考えなくては行けない。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "KOTO",
        "screen_name" : "koto_science",
        "indices" : [ "0", "13" ],
        "id_str" : "984367814889779200",
        "id" : "984367814889779200"
      }, {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "14", "24" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1311122378286489601",
    "id_str" : "1311128787229106177",
    "in_reply_to_user_id" : "984367814889779200",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311128787229106177",
    "in_reply_to_status_id" : "1311122378286489601",
    "created_at" : "Wed Sep 30 02:20:37 +0000 2020",
    "favorited" : false,
    "full_text" : "@koto_science @luna_yuta",
    "lang" : "und",
    "in_reply_to_screen_name" : "koto_science",
    "in_reply_to_user_id_str" : "984367814889779200"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "KOTO",
        "screen_name" : "koto_science",
        "indices" : [ "3", "16" ],
        "id_str" : "984367814889779200",
        "id" : "984367814889779200"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/koto_science/status/1311122378286489601/photo/1",
        "source_status_id" : "1311122378286489601",
        "indices" : [ "32", "55" ],
        "url" : "https://t.co/mGjc19rNvW",
        "media_url" : "http://pbs.twimg.com/media/EjIK2Z0VkAEaTq0.jpg",
        "id_str" : "1311122371277852673",
        "source_user_id" : "984367814889779200",
        "id" : "1311122371277852673",
        "media_url_https" : "https://pbs.twimg.com/media/EjIK2Z0VkAEaTq0.jpg",
        "source_user_id_str" : "984367814889779200",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "272",
            "h" : "300",
            "resize" : "fit"
          },
          "large" : {
            "w" : "272",
            "h" : "300",
            "resize" : "fit"
          },
          "small" : {
            "w" : "272",
            "h" : "300",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1311122378286489601",
        "display_url" : "pic.twitter.com/mGjc19rNvW"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "55" ],
    "favorite_count" : "0",
    "id_str" : "1311128636284493825",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311128636284493825",
    "possibly_sensitive" : false,
    "created_at" : "Wed Sep 30 02:20:01 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @koto_science: これが強い人が強い(真理) https://t.co/mGjc19rNvW",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/koto_science/status/1311122378286489601/photo/1",
        "source_status_id" : "1311122378286489601",
        "indices" : [ "32", "55" ],
        "url" : "https://t.co/mGjc19rNvW",
        "media_url" : "http://pbs.twimg.com/media/EjIK2Z0VkAEaTq0.jpg",
        "id_str" : "1311122371277852673",
        "source_user_id" : "984367814889779200",
        "id" : "1311122371277852673",
        "media_url_https" : "https://pbs.twimg.com/media/EjIK2Z0VkAEaTq0.jpg",
        "source_user_id_str" : "984367814889779200",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "272",
            "h" : "300",
            "resize" : "fit"
          },
          "large" : {
            "w" : "272",
            "h" : "300",
            "resize" : "fit"
          },
          "small" : {
            "w" : "272",
            "h" : "300",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1311122378286489601",
        "display_url" : "pic.twitter.com/mGjc19rNvW"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "おねすとちゃんねる@42Tokyo.9月Piscine生",
        "screen_name" : "honestchanel",
        "indices" : [ "0", "13" ],
        "id_str" : "855651284006785024",
        "id" : "855651284006785024"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1311126571818737667",
    "id_str" : "1311128547054903296",
    "in_reply_to_user_id" : "855651284006785024",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311128547054903296",
    "in_reply_to_status_id" : "1311126571818737667",
    "created_at" : "Wed Sep 30 02:19:39 +0000 2020",
    "favorited" : false,
    "full_text" : "@honestchanel 42生も追加((((",
    "lang" : "ja",
    "in_reply_to_screen_name" : "honestchanel",
    "in_reply_to_user_id_str" : "855651284006785024"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "おねすとちゃんねる@42Tokyo.9月Piscine生",
        "screen_name" : "honestchanel",
        "indices" : [ "0", "13" ],
        "id_str" : "855651284006785024",
        "id" : "855651284006785024"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "35" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1311121101372628993",
    "id_str" : "1311123984797237248",
    "in_reply_to_user_id" : "855651284006785024",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311123984797237248",
    "in_reply_to_status_id" : "1311121101372628993",
    "created_at" : "Wed Sep 30 02:01:32 +0000 2020",
    "favorited" : false,
    "full_text" : "@honestchanel そうなんだよな…離れてわかるさみしさある…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "honestchanel",
    "in_reply_to_user_id_str" : "855651284006785024"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "22" ],
    "favorite_count" : "0",
    "id_str" : "1311119994604761088",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311119994604761088",
    "created_at" : "Wed Sep 30 01:45:40 +0000 2020",
    "favorited" : false,
    "full_text" : "いやまって、明日から大学じゃんwwwwwww",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "17" ],
    "favorite_count" : "6",
    "id_str" : "1311093100823994369",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311093100823994369",
    "created_at" : "Tue Sep 29 23:58:48 +0000 2020",
    "favorited" : false,
    "full_text" : "間違いなく、今までで一番楽しかった",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "16" ],
    "favorite_count" : "0",
    "id_str" : "1311007554755915777",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311007554755915777",
    "created_at" : "Tue Sep 29 18:18:53 +0000 2020",
    "favorited" : false,
    "full_text" : "おいおい嘘だろ、腹減ってきたぞ…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "ひよ@ 42_tokyo_piscine_9月",
        "screen_name" : "hiyohiyopower",
        "indices" : [ "0", "14" ],
        "id_str" : "1292736568453550083",
        "id" : "1292736568453550083"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "21" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1310947938949103616",
    "id_str" : "1311007195060776960",
    "in_reply_to_user_id" : "1292736568453550083",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311007195060776960",
    "in_reply_to_status_id" : "1310947938949103616",
    "created_at" : "Tue Sep 29 18:17:27 +0000 2020",
    "favorited" : false,
    "full_text" : "@hiyohiyopower ありがとう！",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hiyohiyopower",
    "in_reply_to_user_id_str" : "1292736568453550083"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "えふ@42Tokyo 9月Piscine生",
        "screen_name" : "FPr4242",
        "indices" : [ "0", "8" ],
        "id_str" : "1251179846392143873",
        "id" : "1251179846392143873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1310794471152312320",
    "id_str" : "1310837508045897729",
    "in_reply_to_user_id" : "1251179846392143873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310837508045897729",
    "in_reply_to_status_id" : "1310794471152312320",
    "created_at" : "Tue Sep 29 07:03:10 +0000 2020",
    "favorited" : false,
    "full_text" : "@FPr4242 あざすー！！！！！",
    "lang" : "ja",
    "in_reply_to_screen_name" : "FPr4242",
    "in_reply_to_user_id_str" : "1251179846392143873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "おねすとちゃんねる@42Tokyo.9月Piscine生",
        "screen_name" : "honestchanel",
        "indices" : [ "0", "13" ],
        "id_str" : "855651284006785024",
        "id" : "855651284006785024"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "22" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1310795177678655491",
    "id_str" : "1310837465234591747",
    "in_reply_to_user_id" : "855651284006785024",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310837465234591747",
    "in_reply_to_status_id" : "1310795177678655491",
    "created_at" : "Tue Sep 29 07:03:00 +0000 2020",
    "favorited" : false,
    "full_text" : "@honestchanel あざすー！！！！",
    "lang" : "ja",
    "in_reply_to_screen_name" : "honestchanel",
    "in_reply_to_user_id_str" : "855651284006785024"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "27" ],
    "favorite_count" : "0",
    "id_str" : "1310792479378079744",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310792479378079744",
    "created_at" : "Tue Sep 29 04:04:15 +0000 2020",
    "favorited" : false,
    "full_text" : "あーデバッグ用にまたVisualStudio作るのやだ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "13" ],
    "favorite_count" : "0",
    "id_str" : "1310755338379960322",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310755338379960322",
    "created_at" : "Tue Sep 29 01:36:39 +0000 2020",
    "favorited" : false,
    "full_text" : "楽しいよな、パズルみたいで",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1310751962124570624",
    "id_str" : "1310755221862195203",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310755221862195203",
    "in_reply_to_status_id" : "1310751962124570624",
    "created_at" : "Tue Sep 29 01:36:12 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c ババァった！",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "20" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1310739220533637120",
    "id_str" : "1310755147685834752",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310755147685834752",
    "in_reply_to_status_id" : "1310739220533637120",
    "created_at" : "Tue Sep 29 01:35:54 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish あざ丸水産！！！！",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "6" ],
    "favorite_count" : "6",
    "id_str" : "1310710182335320064",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1310710182335320064",
    "created_at" : "Mon Sep 28 22:37:13 +0000 2020",
    "favorited" : false,
    "full_text" : "誕生日でふ。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "16" ],
    "favorite_count" : "1",
    "id_str" : "1311846359859826688",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311846359859826688",
    "created_at" : "Fri Oct 02 01:51:59 +0000 2020",
    "favorited" : false,
    "full_text" : "さて、電源を切るぜ\n\nあばよ現世",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ぺかそ⌨",
        "screen_name" : "Pekaso",
        "indices" : [ "3", "10" ],
        "id_str" : "20843552",
        "id" : "20843552"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Pekaso/status/1311845118203236353/photo/1",
        "source_status_id" : "1311845118203236353",
        "indices" : [ "43", "66" ],
        "url" : "https://t.co/vNdivFgTgX",
        "media_url" : "http://pbs.twimg.com/media/EjScLUsVgAAiL9s.jpg",
        "id_str" : "1311845109818818560",
        "source_user_id" : "20843552",
        "id" : "1311845109818818560",
        "media_url_https" : "https://pbs.twimg.com/media/EjScLUsVgAAiL9s.jpg",
        "source_user_id_str" : "20843552",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1920",
            "h" : "1080",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1311845118203236353",
        "display_url" : "pic.twitter.com/vNdivFgTgX"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "66" ],
    "favorite_count" : "0",
    "id_str" : "1311845692298592256",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311845692298592256",
    "possibly_sensitive" : false,
    "created_at" : "Fri Oct 02 01:49:20 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Pekaso: 「Looooooooser!!」に対してのこの字幕センス良い https://t.co/vNdivFgTgX",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Pekaso/status/1311845118203236353/photo/1",
        "source_status_id" : "1311845118203236353",
        "indices" : [ "43", "66" ],
        "url" : "https://t.co/vNdivFgTgX",
        "media_url" : "http://pbs.twimg.com/media/EjScLUsVgAAiL9s.jpg",
        "id_str" : "1311845109818818560",
        "source_user_id" : "20843552",
        "id" : "1311845109818818560",
        "media_url_https" : "https://pbs.twimg.com/media/EjScLUsVgAAiL9s.jpg",
        "source_user_id_str" : "20843552",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1920",
            "h" : "1080",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1311845118203236353",
        "display_url" : "pic.twitter.com/vNdivFgTgX"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "じゃみー",
        "screen_name" : "zmallik2",
        "indices" : [ "0", "9" ],
        "id_str" : "1302766029177679873",
        "id" : "1302766029177679873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "17" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1311845145352916992",
    "id_str" : "1311845603698122752",
    "in_reply_to_user_id" : "1302766029177679873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311845603698122752",
    "in_reply_to_status_id" : "1311845145352916992",
    "created_at" : "Fri Oct 02 01:48:59 +0000 2020",
    "favorited" : false,
    "full_text" : "@zmallik2 ばれてたかぁw",
    "lang" : "ja",
    "in_reply_to_screen_name" : "zmallik2",
    "in_reply_to_user_id_str" : "1302766029177679873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1311844595370610688",
    "id_str" : "1311844959817920512",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311844959817920512",
    "in_reply_to_status_id" : "1311844595370610688",
    "created_at" : "Fri Oct 02 01:46:25 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c どこらへん？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "33" ],
    "favorite_count" : "2",
    "id_str" : "1311844477762330624",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311844477762330624",
    "created_at" : "Fri Oct 02 01:44:31 +0000 2020",
    "favorited" : false,
    "full_text" : "今回は誰にも気づかれずにみんなを監視したいところ٩( 'ω' )و",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hayasakaaaaaa",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1311844237000929280",
    "id_str" : "1311844309532962817",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311844309532962817",
    "in_reply_to_status_id" : "1311844237000929280",
    "created_at" : "Fri Oct 02 01:43:50 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c かわよいね。",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "49" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1311843738621108224",
    "id_str" : "1311844101466193920",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311844101466193920",
    "in_reply_to_status_id" : "1311843738621108224",
    "created_at" : "Fri Oct 02 01:43:01 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c ヒョロヒョロした背の高い眼鏡で、教室の中で真ん中あたりに座っているるはずだ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "17" ],
    "favorite_count" : "2",
    "in_reply_to_status_id_str" : "1311839193539072006",
    "id_str" : "1311843361146322944",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311843361146322944",
    "in_reply_to_status_id" : "1311839193539072006",
    "created_at" : "Fri Oct 02 01:40:04 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c みーつけた",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "11" ],
    "favorite_count" : "0",
    "id_str" : "1311843175699341312",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311843175699341312",
    "created_at" : "Fri Oct 02 01:39:20 +0000 2020",
    "favorited" : false,
    "full_text" : "どれが誰かよーわからん",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "4" ],
    "favorite_count" : "0",
    "id_str" : "1311840223974678528",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311840223974678528",
    "created_at" : "Fri Oct 02 01:27:36 +0000 2020",
    "favorited" : false,
    "full_text" : "つーいた",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "喜耶麻アキ　デザフェス【J-227】両日",
        "screen_name" : "kiyama_aki",
        "indices" : [ "3", "14" ],
        "id_str" : "1078791499964342272",
        "id" : "1078791499964342272"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/kiyama_aki/status/1311534262206648326/photo/1",
        "source_status_id" : "1311534262206648326",
        "indices" : [ "38", "61" ],
        "url" : "https://t.co/WZjXBLXm0y",
        "media_url" : "http://pbs.twimg.com/media/EjOBciQVgAAXVKl.jpg",
        "id_str" : "1311534243726589952",
        "source_user_id" : "1078791499964342272",
        "id" : "1311534243726589952",
        "media_url_https" : "https://pbs.twimg.com/media/EjOBciQVgAAXVKl.jpg",
        "source_user_id_str" : "1078791499964342272",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "460",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "676",
            "h" : "1000",
            "resize" : "fit"
          },
          "large" : {
            "w" : "676",
            "h" : "1000",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1311534262206648326",
        "display_url" : "pic.twitter.com/WZjXBLXm0y"
      } ],
      "hashtags" : [ {
        "text" : "コーヒーの日",
        "indices" : [ "23", "30" ]
      }, {
        "text" : "イラスト",
        "indices" : [ "32", "37" ]
      } ]
    },
    "display_text_range" : [ "0", "61" ],
    "favorite_count" : "0",
    "id_str" : "1311838296952074240",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311838296952074240",
    "possibly_sensitive" : false,
    "created_at" : "Fri Oct 02 01:19:57 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @kiyama_aki: 完成ー！！\n\n#コーヒーの日 \n#イラスト https://t.co/WZjXBLXm0y",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/kiyama_aki/status/1311534262206648326/photo/1",
        "source_status_id" : "1311534262206648326",
        "indices" : [ "38", "61" ],
        "url" : "https://t.co/WZjXBLXm0y",
        "media_url" : "http://pbs.twimg.com/media/EjOBciQVgAAXVKl.jpg",
        "id_str" : "1311534243726589952",
        "source_user_id" : "1078791499964342272",
        "id" : "1311534243726589952",
        "media_url_https" : "https://pbs.twimg.com/media/EjOBciQVgAAXVKl.jpg",
        "source_user_id_str" : "1078791499964342272",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "460",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "676",
            "h" : "1000",
            "resize" : "fit"
          },
          "large" : {
            "w" : "676",
            "h" : "1000",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1311534262206648326",
        "display_url" : "pic.twitter.com/WZjXBLXm0y"
      }, {
        "expanded_url" : "https://twitter.com/kiyama_aki/status/1311534262206648326/photo/1",
        "source_status_id" : "1311534262206648326",
        "indices" : [ "38", "61" ],
        "url" : "https://t.co/WZjXBLXm0y",
        "media_url" : "http://pbs.twimg.com/media/EjOBciRUYAEm02_.jpg",
        "id_str" : "1311534243730710529",
        "source_user_id" : "1078791499964342272",
        "id" : "1311534243730710529",
        "media_url_https" : "https://pbs.twimg.com/media/EjOBciRUYAEm02_.jpg",
        "source_user_id_str" : "1078791499964342272",
        "sizes" : {
          "medium" : {
            "w" : "676",
            "h" : "1000",
            "resize" : "fit"
          },
          "large" : {
            "w" : "676",
            "h" : "1000",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "460",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1311534262206648326",
        "display_url" : "pic.twitter.com/WZjXBLXm0y"
      }, {
        "expanded_url" : "https://twitter.com/kiyama_aki/status/1311534262206648326/photo/1",
        "source_status_id" : "1311534262206648326",
        "indices" : [ "38", "61" ],
        "url" : "https://t.co/WZjXBLXm0y",
        "media_url" : "http://pbs.twimg.com/media/EjOBciUUwAAiTf7.jpg",
        "id_str" : "1311534243743318016",
        "source_user_id" : "1078791499964342272",
        "id" : "1311534243743318016",
        "media_url_https" : "https://pbs.twimg.com/media/EjOBciUUwAAiTf7.jpg",
        "source_user_id_str" : "1078791499964342272",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "676",
            "h" : "1000",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "676",
            "h" : "1000",
            "resize" : "fit"
          },
          "small" : {
            "w" : "460",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1311534262206648326",
        "display_url" : "pic.twitter.com/WZjXBLXm0y"
      }, {
        "expanded_url" : "https://twitter.com/kiyama_aki/status/1311534262206648326/photo/1",
        "source_status_id" : "1311534262206648326",
        "indices" : [ "38", "61" ],
        "url" : "https://t.co/WZjXBLXm0y",
        "media_url" : "http://pbs.twimg.com/media/EjOBciTVoAA_Bno.jpg",
        "id_str" : "1311534243739181056",
        "source_user_id" : "1078791499964342272",
        "id" : "1311534243739181056",
        "media_url_https" : "https://pbs.twimg.com/media/EjOBciTVoAA_Bno.jpg",
        "source_user_id_str" : "1078791499964342272",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "676",
            "h" : "1000",
            "resize" : "fit"
          },
          "large" : {
            "w" : "676",
            "h" : "1000",
            "resize" : "fit"
          },
          "small" : {
            "w" : "460",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1311534262206648326",
        "display_url" : "pic.twitter.com/WZjXBLXm0y"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "115" ],
    "favorite_count" : "1",
    "id_str" : "1311836223552409600",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311836223552409600",
    "created_at" : "Fri Oct 02 01:11:43 +0000 2020",
    "favorited" : false,
    "full_text" : "いや、普通付き合ってる人おったら、2人きりで異性の家とか行かんやろ。\nなんやそのルールめんどくさいみたいな雰囲気だすの。\n\nいや付き合ってる相手がその雰囲気なら良いけど、なんで友達だからってなんでも聞かなあかんねん。\n\nしばくぞ。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "12" ],
    "favorite_count" : "1",
    "id_str" : "1311834321389379584",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311834321389379584",
    "created_at" : "Fri Oct 02 01:04:09 +0000 2020",
    "favorited" : false,
    "full_text" : "電車の乗り換えミスったw",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "えふ@42Tokyo 9月Piscine生",
        "screen_name" : "FPr4242",
        "indices" : [ "0", "8" ],
        "id_str" : "1251179846392143873",
        "id" : "1251179846392143873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "14" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1311833080777252864",
    "id_str" : "1311833880681308160",
    "in_reply_to_user_id" : "1251179846392143873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311833880681308160",
    "in_reply_to_status_id" : "1311833080777252864",
    "created_at" : "Fri Oct 02 01:02:24 +0000 2020",
    "favorited" : false,
    "full_text" : "@FPr4242 よろしい。",
    "lang" : "ja",
    "in_reply_to_screen_name" : "FPr4242",
    "in_reply_to_user_id_str" : "1251179846392143873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "2",
    "id_str" : "1311831854681518080",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311831854681518080",
    "created_at" : "Fri Oct 02 00:54:21 +0000 2020",
    "favorited" : false,
    "full_text" : "今日は多分、テストの間明日食べる誕生日ケーキのこと考えてる。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      }, {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "11", "21" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "33" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1311831500053118977",
    "id_str" : "1311831684447256576",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311831684447256576",
    "in_reply_to_status_id" : "1311831500053118977",
    "created_at" : "Fri Oct 02 00:53:40 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish @luna_yuta wwww\n実証済みで草",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "34" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1311830410309955585",
    "id_str" : "1311831200978198530",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311831200978198530",
    "in_reply_to_status_id" : "1311830410309955585",
    "created_at" : "Fri Oct 02 00:51:45 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta 誰かの待ち合わせ場所やん、あながち間違ってない",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "えふ@42Tokyo 9月Piscine生",
        "screen_name" : "FPr4242",
        "indices" : [ "0", "8" ],
        "id_str" : "1251179846392143873",
        "id" : "1251179846392143873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "17" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1311830649645363200",
    "id_str" : "1311831094027669504",
    "in_reply_to_user_id" : "1251179846392143873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311831094027669504",
    "in_reply_to_status_id" : "1311830649645363200",
    "created_at" : "Fri Oct 02 00:51:20 +0000 2020",
    "favorited" : false,
    "full_text" : "@FPr4242 いや、ほんとに？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "FPr4242",
    "in_reply_to_user_id_str" : "1251179846392143873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "26" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1311827123116494848",
    "id_str" : "1311827924035596288",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311827924035596288",
    "in_reply_to_status_id" : "1311827123116494848",
    "created_at" : "Fri Oct 02 00:38:44 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta 目印になるな、影から観察しとこ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "えふ@42Tokyo 9月Piscine生",
        "screen_name" : "FPr4242",
        "indices" : [ "0", "8" ],
        "id_str" : "1251179846392143873",
        "id" : "1251179846392143873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "34" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1311825738731909122",
    "id_str" : "1311827783882997761",
    "in_reply_to_user_id" : "1251179846392143873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311827783882997761",
    "in_reply_to_status_id" : "1311825738731909122",
    "created_at" : "Fri Oct 02 00:38:10 +0000 2020",
    "favorited" : false,
    "full_text" : "@FPr4242 ٩꒰๑･д･꒱۶♡！？\n素敵(☝︎ ՞ਊ ՞)☝︎",
    "lang" : "ja",
    "in_reply_to_screen_name" : "FPr4242",
    "in_reply_to_user_id_str" : "1251179846392143873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "さにー",
        "screen_name" : "sunnylang2019",
        "indices" : [ "3", "17" ],
        "id_str" : "1199683722787713026",
        "id" : "1199683722787713026"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "36" ],
    "favorite_count" : "0",
    "id_str" : "1311823866105266177",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311823866105266177",
    "created_at" : "Fri Oct 02 00:22:36 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @sunnylang2019: 頑張れさにー。最後まで諦めないで。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "KOTO",
        "screen_name" : "koto_science",
        "indices" : [ "3", "16" ],
        "id_str" : "984367814889779200",
        "id" : "984367814889779200"
      }, {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "18", "28" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1311820773997211650",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311820773997211650",
    "created_at" : "Fri Oct 02 00:10:19 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @koto_science: @luna_yuta 体重……\n測ってねえ……\n怖え………",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "えふ@42Tokyo 9月Piscine生",
        "screen_name" : "FPr4242",
        "indices" : [ "0", "8" ],
        "id_str" : "1251179846392143873",
        "id" : "1251179846392143873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "17" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1311817542655045632",
    "id_str" : "1311820522917781504",
    "in_reply_to_user_id" : "1251179846392143873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311820522917781504",
    "in_reply_to_status_id" : "1311817542655045632",
    "created_at" : "Fri Oct 02 00:09:19 +0000 2020",
    "favorited" : false,
    "full_text" : "@FPr4242 え、女の子？？？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "FPr4242",
    "in_reply_to_user_id_str" : "1251179846392143873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "15" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1311817677862658048",
    "id_str" : "1311820453070209024",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311820453070209024",
    "in_reply_to_status_id" : "1311817677862658048",
    "created_at" : "Fri Oct 02 00:09:03 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta 紅生姜？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "14" ],
    "favorite_count" : "1",
    "id_str" : "1311816859562377216",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1311816859562377216",
    "created_at" : "Thu Oct 01 23:54:46 +0000 2020",
    "favorited" : false,
    "full_text" : "テストの日はみんな活発だよね",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "HiroshimaTimeline",
        "indices" : [ "42", "60" ]
      }, {
        "text" : "IfSNSin75YearsAgo",
        "indices" : [ "62", "80" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "0", "15" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "80" ],
    "favorite_count" : "4",
    "in_reply_to_status_id_str" : "1291296689605750784",
    "id_str" : "1291316506421207040",
    "in_reply_to_user_id" : "1227799099287597058",
    "truncated" : false,
    "retweet_count" : "1",
    "id" : "1291316506421207040",
    "in_reply_to_status_id" : "1291296689605750784",
    "created_at" : "Thu Aug 06 10:13:41 +0000 2020",
    "favorited" : false,
    "full_text" : "@nhk_1945ichiro 【1945/8/6】\n\nOh... really\n\n#HiroshimaTimeline \n#IfSNSin75YearsAgo",
    "lang" : "en",
    "in_reply_to_screen_name" : "nhk_1945ichiro",
    "in_reply_to_user_id_str" : "1227799099287597058"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "HiroshimaTimeline",
        "indices" : [ "100", "118" ]
      }, {
        "text" : "IfSNSin75YearsAgo",
        "indices" : [ "120", "138" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "0", "15" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "138" ],
    "favorite_count" : "16",
    "in_reply_to_status_id_str" : "1291296896548581377",
    "id_str" : "1291315818513326080",
    "in_reply_to_user_id" : "1227799099287597058",
    "truncated" : false,
    "retweet_count" : "5",
    "id" : "1291315818513326080",
    "in_reply_to_status_id" : "1291296896548581377",
    "created_at" : "Thu Aug 06 10:10:57 +0000 2020",
    "favorited" : false,
    "full_text" : "@nhk_1945ichiro 【1945/8/6】\n\nあの司令部発表は、もう活字にすることは出来ないのだ…\nI cannot print the HQ announcement anymore.\n\n#HiroshimaTimeline \n#IfSNSin75YearsAgo",
    "lang" : "ja",
    "in_reply_to_screen_name" : "nhk_1945ichiro",
    "in_reply_to_user_id_str" : "1227799099287597058"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "HiroshimaTimeline",
        "indices" : [ "244", "262" ]
      }, {
        "text" : "IfThereAreSNS75YearsAgo",
        "indices" : [ "264", "288" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "0", "15" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "288" ],
    "favorite_count" : "131",
    "in_reply_to_status_id_str" : "1291309720867876864",
    "id_str" : "1291314351400316931",
    "in_reply_to_user_id" : "1227799099287597058",
    "truncated" : false,
    "retweet_count" : "35",
    "id" : "1291314351400316931",
    "in_reply_to_status_id" : "1291309720867876864",
    "created_at" : "Thu Aug 06 10:05:07 +0000 2020",
    "favorited" : false,
    "full_text" : "@nhk_1945ichiro 【1945/8/6】\n\nChecked faces each one. But Mizuhara wasn't in there.\n\nFireman who laid on, move slightly and ask water.\nPuted it in the bottle, he drink it happily.\nThen he run out of black mucus from his nose and mouth and died.\n\n#HiroshimaTimeline \n#IfThereAreSNS75YearsAgo",
    "lang" : "en",
    "in_reply_to_screen_name" : "nhk_1945ichiro",
    "in_reply_to_user_id_str" : "1227799099287597058"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "HiroshimaTimeline",
        "indices" : [ "153", "171" ]
      }, {
        "text" : "IfThereAreSNS75YearsAgo",
        "indices" : [ "173", "197" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "0", "15" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "251" ],
    "favorite_count" : "22",
    "in_reply_to_status_id_str" : "1291297144268369920",
    "id_str" : "1291311858293411840",
    "in_reply_to_user_id" : "1227799099287597058",
    "truncated" : false,
    "retweet_count" : "6",
    "id" : "1291311858293411840",
    "in_reply_to_status_id" : "1291297144268369920",
    "created_at" : "Thu Aug 06 09:55:13 +0000 2020",
    "favorited" : false,
    "full_text" : "@nhk_1945ichiro 【1945/8/6/】\nCan't tell even what we saw today\n\nGet tired on ground around the entrance\nThere're burn marks and body\n\nWhy that happened?\n\n#HiroshimaTimeline \n#IfThereAreSNS75YearsAgo\nこの翻訳は即興です。お直しお願いします。\nPlease translate it more better.",
    "lang" : "ja",
    "in_reply_to_screen_name" : "nhk_1945ichiro",
    "in_reply_to_user_id_str" : "1227799099287597058"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "0", "15" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "38" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1291308499859726338",
    "id_str" : "1291308940207116288",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291308940207116288",
    "in_reply_to_status_id" : "1291308499859726338",
    "created_at" : "Thu Aug 06 09:43:37 +0000 2020",
    "favorited" : false,
    "full_text" : "@nhk_1945ichiro 即興なのであってません。ご指摘お願いします…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "ひろしまタイムライン",
        "indices" : [ "162", "173" ]
      }, {
        "text" : "もし75年前にSNSがあったら",
        "indices" : [ "174", "190" ]
      }, {
        "text" : "HiroshimaTimeline",
        "indices" : [ "191", "209" ]
      }, {
        "text" : "IfThereAreSNS75YearsAgo",
        "indices" : [ "210", "234" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "0", "15" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "234" ],
    "favorite_count" : "37",
    "in_reply_to_status_id_str" : "1291308499859726338",
    "id_str" : "1291308766529429505",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "16",
    "id" : "1291308766529429505",
    "in_reply_to_status_id" : "1291308499859726338",
    "created_at" : "Thu Aug 06 09:42:55 +0000 2020",
    "favorited" : false,
    "full_text" : "@nhk_1945ichiro She was a typist, joined our company few days ago. Her face, rumored for cute, is cutted sharply from under the eyes and back teeth are visible.\n\n#ひろしまタイムライン\n#もし75年前にSNSがあったら\n#HiroshimaTimeline\n#IfThereAreSNS75YearsAgo",
    "lang" : "en",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "ひろしまタイムライン",
        "indices" : [ "157", "168" ]
      }, {
        "text" : "もし75年前にSNSがあったら",
        "indices" : [ "169", "185" ]
      }, {
        "text" : "Hiroshima",
        "indices" : [ "186", "196" ]
      }, {
        "text" : "If",
        "indices" : [ "206", "209" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "0", "15" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "235" ],
    "favorite_count" : "78",
    "in_reply_to_status_id_str" : "1291301128932667392",
    "id_str" : "1291308499859726338",
    "in_reply_to_user_id" : "1227799099287597058",
    "truncated" : false,
    "retweet_count" : "21",
    "id" : "1291308499859726338",
    "in_reply_to_status_id" : "1291301128932667392",
    "created_at" : "Thu Aug 06 09:41:52 +0000 2020",
    "favorited" : false,
    "full_text" : "@nhk_1945ichiro 【1945/8/6】\n\nThere are body not burned in front of the crossing\n\nget closer to find Mizuhara. The body get the name plate \"Isozaki Yoshiko\".\n\n#ひろしまタイムライン\n#もし75年前にSNSがあったら\n#Hiroshima Timeline\n#If there are SNS 75years ago",
    "lang" : "en",
    "in_reply_to_screen_name" : "nhk_1945ichiro",
    "in_reply_to_user_id_str" : "1227799099287597058"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "62" ],
    "favorite_count" : "0",
    "id_str" : "1286575122397069313",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1286575122397069313",
    "created_at" : "Fri Jul 24 08:13:07 +0000 2020",
    "favorited" : false,
    "full_text" : "コラボラトリーのこと考えてないで実験のレポート…\n\nでも自分の開発やりたい…学校の課題…\n\nアーーーーーってなるのなんなのー",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "20" ],
    "favorite_count" : "0",
    "id_str" : "1285892015612243969",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1285892015612243969",
    "created_at" : "Wed Jul 22 10:58:41 +0000 2020",
    "favorited" : false,
    "full_text" : "課題が多すぎてSQLにいけないのなんなの",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/R7AqImWlnI",
        "expanded_url" : "https://qiita.com/Haiao/items/b9a6e517e86b5c7ecb31",
        "display_url" : "qiita.com/Haiao/items/b9…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "64" ],
    "favorite_count" : "2",
    "id_str" : "1285839451478867968",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1285839451478867968",
    "possibly_sensitive" : false,
    "created_at" : "Wed Jul 22 07:29:49 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/R7AqImWlnI\n\nC++に関する記事書きました、初投稿なので文章がど下手ですが\nご査収ください。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "48" ],
    "favorite_count" : "0",
    "id_str" : "1284343830364344321",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1284343830364344321",
    "created_at" : "Sat Jul 18 04:26:45 +0000 2020",
    "favorited" : false,
    "full_text" : "まずはレポートの修正課題を2授業分と、通常課題2つを仕上げて\n\nQittaの投稿を終わらせたい…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "21" ],
    "favorite_count" : "2",
    "id_str" : "1284079900933021696",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1284079900933021696",
    "created_at" : "Fri Jul 17 10:58:00 +0000 2020",
    "favorited" : false,
    "full_text" : "piscine始まるまでSQLやってみよう",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1274054228596543488",
    "id_str" : "1274203587220914177",
    "in_reply_to_user_id" : "1230191189346811904",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1274203587220914177",
    "in_reply_to_status_id" : "1274054228596543488",
    "created_at" : "Sat Jun 20 04:53:03 +0000 2020",
    "favorited" : false,
    "full_text" : "@compute42 型 関数名 (引数)の気がします…引数なしって意味なので()でもokかと",
    "lang" : "ja",
    "in_reply_to_screen_name" : "tegsann",
    "in_reply_to_user_id_str" : "1230191189346811904"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "49" ],
    "favorite_count" : "0",
    "id_str" : "1274194701810233344",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1274194701810233344",
    "created_at" : "Sat Jun 20 04:17:44 +0000 2020",
    "favorited" : false,
    "full_text" : "Qpython面白そう…\n\npythonの機能ってandroid向けアプリに移植できないのかな…？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "50" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1274193897590153222",
    "id_str" : "1274193993627086849",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1274193993627086849",
    "in_reply_to_status_id" : "1274193897590153222",
    "created_at" : "Sat Jun 20 04:14:56 +0000 2020",
    "favorited" : false,
    "full_text" : "クラス+クラスとして演算子しててびびった。あれは計算の前に両辺のオペランドを確認しているんだろうか…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "115" ],
    "favorite_count" : "0",
    "id_str" : "1274193897590153222",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1274193897590153222",
    "created_at" : "Sat Jun 20 04:14:33 +0000 2020",
    "favorited" : false,
    "full_text" : "C++で演算子のオーバーロードを使って独自クラスの文字列同士の結合を作った時\n\n(文字配列を持つ独自クラス)+文字列\n\nは、クラス+文字列で定義した+演算子を使っているのかと思いきや引数コンストラクタで右もクラスにして\n\n↓つづく",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "rumino",
        "screen_name" : "TechnoRYOgy",
        "indices" : [ "3", "15" ],
        "id_str" : "1195993548199350272",
        "id" : "1195993548199350272"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1274165092825743360",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1274165092825743360",
    "created_at" : "Sat Jun 20 02:20:05 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @TechnoRYOgy: Piscineの情報出ましたね！\n2カ月やるようですが、両方MAX300人でやるとしたら200人合格者が出ますが、オーバーしてしまいますよね。\nそこで、\n①42tokyoとしてのキャパを増やす\n②合格率従来比半分\n③受験者数半分(2カ月で300…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "10" ],
    "favorite_count" : "0",
    "id_str" : "1268870711864512516",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1268870711864512516",
    "created_at" : "Fri Jun 05 11:42:06 +0000 2020",
    "favorited" : false,
    "full_text" : "量子物理学むつかしい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "17" ],
    "favorite_count" : "0",
    "id_str" : "1268855655412060160",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1268855655412060160",
    "created_at" : "Fri Jun 05 10:42:17 +0000 2020",
    "favorited" : false,
    "full_text" : "と、空虚に向かって話してみました。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "133" ],
    "favorite_count" : "5",
    "id_str" : "1268855583442001920",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1268855583442001920",
    "created_at" : "Fri Jun 05 10:41:59 +0000 2020",
    "favorited" : false,
    "full_text" : "受ける予定だった3月のpiscineが曖昧で、手元にIDが残っています。\n\nやるかやらないかを検討しているのかだけでも教えてもらえたら嬉しいです。\n\n特にやらない予定ならば手元のIDを戻したいですし、やる予定なら確実なことが言えなくても検討段階の情報が知りたいです。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "BlackLivesMatter",
        "indices" : [ "101", "118" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "LiT｜翻訳キュレーター",
        "screen_name" : "LiT_Japan",
        "indices" : [ "3", "13" ],
        "id_str" : "1123143459026505729",
        "id" : "1123143459026505729"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1267505979672805389",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1267505979672805389",
    "created_at" : "Mon Jun 01 17:19:09 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @LiT_Japan: 現在アメリカで起きている暴動に、黒人は必ずしも賛同しているわけじゃない。むしろ彼らの多くはもっと「マシな方法」を模索しようとしている。\n\n悲劇を止めるのは暴動じゃない。\n\n#BlackLivesMatter https://t.co/ohBURhD…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "ワンタイムイベント",
        "indices" : [ "0", "10" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "45" ],
    "favorite_count" : "0",
    "id_str" : "1258928240573345792",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1258928240573345792",
    "created_at" : "Sat May 09 01:14:16 +0000 2020",
    "favorited" : false,
    "full_text" : "#ワンタイムイベント\n\nってか多分周りも音聞こえてなくて草\n\nエモートとか車の音でがする…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "ワンタイムイベント",
        "indices" : [ "18", "28" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "0",
    "id_str" : "1258928151847038977",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1258928151847038977",
    "created_at" : "Sat May 09 01:13:55 +0000 2020",
    "favorited" : false,
    "full_text" : "やばいワンタイムなのに音聞こえない #ワンタイムイベント",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "19" ],
    "favorite_count" : "1",
    "id_str" : "1255414643775979526",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1255414643775979526",
    "created_at" : "Wed Apr 29 08:32:30 +0000 2020",
    "favorited" : false,
    "full_text" : "あぁ…インターン探さないと…出遅れ感…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "60" ],
    "favorite_count" : "0",
    "id_str" : "1253741074192842752",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1253741074192842752",
    "created_at" : "Fri Apr 24 17:42:20 +0000 2020",
    "favorited" : false,
    "full_text" : "キル厨全員垢バンされたらいい…\n誰も殺してないのに友達と離れ離れになるしゆっくり見れないしあのシステムなんとかしてくれ…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "えふ@42Tokyo 9月Piscine生",
        "screen_name" : "FPr4242",
        "indices" : [ "11", "19" ],
        "id_str" : "1251179846392143873",
        "id" : "1251179846392143873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312068795079426048",
    "id_str" : "1312182188809449473",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312182188809449473",
    "in_reply_to_status_id" : "1312068795079426048",
    "created_at" : "Sat Oct 03 00:06:27 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @FPr4242 むしろ私．",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "えふ@42Tokyo 9月Piscine生",
        "screen_name" : "FPr4242",
        "indices" : [ "0", "8" ],
        "id_str" : "1251179846392143873",
        "id" : "1251179846392143873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312067801025187840",
    "id_str" : "1312068490195398656",
    "in_reply_to_user_id" : "1251179846392143873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312068490195398656",
    "in_reply_to_status_id" : "1312067801025187840",
    "created_at" : "Fri Oct 02 16:34:39 +0000 2020",
    "favorited" : false,
    "full_text" : "@FPr4242 いやえふは十二分過ぎるくらいに貢献してたゾ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "FPr4242",
    "in_reply_to_user_id_str" : "1251179846392143873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/IWJbcJPMFO",
        "expanded_url" : "https://twitter.com/denfaminicogame/status/1311842742465511425",
        "display_url" : "twitter.com/denfaminicogam…",
        "indices" : [ "16", "39" ]
      } ]
    },
    "display_text_range" : [ "0", "39" ],
    "favorite_count" : "1",
    "id_str" : "1312068133809655809",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312068133809655809",
    "possibly_sensitive" : false,
    "created_at" : "Fri Oct 02 16:33:14 +0000 2020",
    "favorited" : false,
    "full_text" : "す、スイッチないの？(震え声) https://t.co/IWJbcJPMFO",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "電ファミニコゲーマー",
        "screen_name" : "denfaminicogame",
        "indices" : [ "3", "19" ],
        "id_str" : "2786677338",
        "id" : "2786677338"
      } ],
      "urls" : [ {
        "url" : "https://t.co/kGONiEOrIN",
        "expanded_url" : "https://news.denfaminicogamer.jp/news/201002c",
        "display_url" : "news.denfaminicogamer.jp/news/201002c",
        "indices" : [ "60", "83" ]
      } ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1312068067623542785",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312068067623542785",
    "possibly_sensitive" : false,
    "created_at" : "Fri Oct 02 16:32:59 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @denfaminicogame: 【ついに】『Apex Legends』クロスプレイ機能のベータ版が提供開始へ\nhttps://t.co/kGONiEOrIN\n\n米国太平洋時間10月6日からPC（Origin）、PS4、Xbox One間でのマルチプレイが可能に。同日か…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "えふ@42Tokyo 9月Piscine生",
        "screen_name" : "FPr4242",
        "indices" : [ "0", "8" ],
        "id_str" : "1251179846392143873",
        "id" : "1251179846392143873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312065241778286597",
    "id_str" : "1312067647823962112",
    "in_reply_to_user_id" : "1251179846392143873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312067647823962112",
    "in_reply_to_status_id" : "1312065241778286597",
    "created_at" : "Fri Oct 02 16:31:18 +0000 2020",
    "favorited" : false,
    "full_text" : "@FPr4242 そしてまたBSQのようなもので徹夜…w",
    "lang" : "ja",
    "in_reply_to_screen_name" : "FPr4242",
    "in_reply_to_user_id_str" : "1251179846392143873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Nuts_Piscine_9月🇪🇪",
        "screen_name" : "nuts_codie",
        "indices" : [ "0", "11" ],
        "id_str" : "1286128540748922881",
        "id" : "1286128540748922881"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "49" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312061277267611648",
    "id_str" : "1312062862584500224",
    "in_reply_to_user_id" : "1286128540748922881",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312062862584500224",
    "in_reply_to_status_id" : "1312061277267611648",
    "created_at" : "Fri Oct 02 16:12:18 +0000 2020",
    "favorited" : false,
    "full_text" : "@nuts_codie お家に帰るとお母さん、お外でお勉強すると生徒さんなんですな…(*´ω`*)",
    "lang" : "ja",
    "in_reply_to_screen_name" : "nuts_codie",
    "in_reply_to_user_id_str" : "1286128540748922881"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Nuts_Piscine_9月🇪🇪",
        "screen_name" : "nuts_codie",
        "indices" : [ "3", "14" ],
        "id_str" : "1286128540748922881",
        "id" : "1286128540748922881"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "51" ],
    "favorite_count" : "0",
    "id_str" : "1312062676936224770",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312062676936224770",
    "created_at" : "Fri Oct 02 16:11:33 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @nuts_codie: 娘に「1ヵ月寂しかった…」って抱きつかれた。\n次女じゃなくて長女の方😆",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "えふ@42Tokyo 9月Piscine生",
        "screen_name" : "FPr4242",
        "indices" : [ "0", "8" ],
        "id_str" : "1251179846392143873",
        "id" : "1251179846392143873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1312058265920958465",
    "id_str" : "1312060519918919687",
    "in_reply_to_user_id" : "1251179846392143873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312060519918919687",
    "in_reply_to_status_id" : "1312058265920958465",
    "created_at" : "Fri Oct 02 16:02:59 +0000 2020",
    "favorited" : false,
    "full_text" : "@FPr4242 本科で会うしかない",
    "lang" : "ja",
    "in_reply_to_screen_name" : "FPr4242",
    "in_reply_to_user_id_str" : "1251179846392143873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "20" ],
    "favorite_count" : "3",
    "id_str" : "1312053011036868609",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312053011036868609",
    "created_at" : "Fri Oct 02 15:33:09 +0000 2020",
    "favorited" : false,
    "full_text" : "明日はデートしてから誕生日ケーキを食べる",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "14" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312048280088395777",
    "id_str" : "1312052674305552384",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312052674305552384",
    "in_reply_to_status_id" : "1312048280088395777",
    "created_at" : "Fri Oct 02 15:31:48 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta 何色？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "11" ],
    "favorite_count" : "0",
    "id_str" : "1312051453570109441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312051453570109441",
    "created_at" : "Fri Oct 02 15:26:57 +0000 2020",
    "favorited" : false,
    "full_text" : "家が遠い\n\n野宿説ある",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "j-carol(whanamot)",
        "screen_name" : "jcarol45241937",
        "indices" : [ "0", "15" ],
        "id_str" : "1284139705273995265",
        "id" : "1284139705273995265"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1312049776335024134",
    "id_str" : "1312050098935721985",
    "in_reply_to_user_id" : "1284139705273995265",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312050098935721985",
    "in_reply_to_status_id" : "1312049776335024134",
    "created_at" : "Fri Oct 02 15:21:34 +0000 2020",
    "favorited" : false,
    "full_text" : "@jcarol45241937 え、めっちゃクソ楽しそうじゃんこれwwww",
    "lang" : "ja",
    "in_reply_to_screen_name" : "jcarol45241937",
    "in_reply_to_user_id_str" : "1284139705273995265"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "j-carol(whanamot)",
        "screen_name" : "jcarol45241937",
        "indices" : [ "0", "15" ],
        "id_str" : "1284139705273995265",
        "id" : "1284139705273995265"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "29" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312049223479693312",
    "id_str" : "1312049339456393218",
    "in_reply_to_user_id" : "1284139705273995265",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312049339456393218",
    "in_reply_to_status_id" : "1312049223479693312",
    "created_at" : "Fri Oct 02 15:18:33 +0000 2020",
    "favorited" : false,
    "full_text" : "@jcarol45241937 それな✌︎('ω'✌︎ )",
    "lang" : "ja",
    "in_reply_to_screen_name" : "jcarol45241937",
    "in_reply_to_user_id_str" : "1284139705273995265"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312048790635864065/photo/1",
        "indices" : [ "15", "38" ],
        "url" : "https://t.co/SVw2m1Zsie",
        "media_url" : "http://pbs.twimg.com/media/EjVVaZ0U8AAxVYO.jpg",
        "id_str" : "1312048778543689728",
        "id" : "1312048778543689728",
        "media_url_https" : "https://pbs.twimg.com/media/EjVVaZ0U8AAxVYO.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/SVw2m1Zsie"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "38" ],
    "favorite_count" : "10",
    "id_str" : "1312048790635864065",
    "truncated" : false,
    "retweet_count" : "1",
    "id" : "1312048790635864065",
    "possibly_sensitive" : false,
    "created_at" : "Fri Oct 02 15:16:23 +0000 2020",
    "favorited" : false,
    "full_text" : "あー、楽観でラーメン食いたい https://t.co/SVw2m1Zsie",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312048790635864065/photo/1",
        "indices" : [ "15", "38" ],
        "url" : "https://t.co/SVw2m1Zsie",
        "media_url" : "http://pbs.twimg.com/media/EjVVaZ0U8AAxVYO.jpg",
        "id_str" : "1312048778543689728",
        "id" : "1312048778543689728",
        "media_url_https" : "https://pbs.twimg.com/media/EjVVaZ0U8AAxVYO.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/SVw2m1Zsie"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "11" ],
    "favorite_count" : "0",
    "id_str" : "1312048378105061376",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312048378105061376",
    "created_at" : "Fri Oct 02 15:14:44 +0000 2020",
    "favorited" : false,
    "full_text" : "早くキーキャップこいよ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "4",
    "id_str" : "1312047942727950336",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312047942727950336",
    "created_at" : "Fri Oct 02 15:13:00 +0000 2020",
    "favorited" : false,
    "full_text" : "明日からは私生活をもう少し大切にしたいと思う。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "j-carol(whanamot)",
        "screen_name" : "jcarol45241937",
        "indices" : [ "0", "15" ],
        "id_str" : "1284139705273995265",
        "id" : "1284139705273995265"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "33" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312047419157213184",
    "id_str" : "1312047659666960384",
    "in_reply_to_user_id" : "1284139705273995265",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312047659666960384",
    "in_reply_to_status_id" : "1312047419157213184",
    "created_at" : "Fri Oct 02 15:11:53 +0000 2020",
    "favorited" : false,
    "full_text" : "@jcarol45241937 何言ってんの！一緒に受かるんだよ！",
    "lang" : "ja",
    "in_reply_to_screen_name" : "jcarol45241937",
    "in_reply_to_user_id_str" : "1284139705273995265"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "j-carol(whanamot)",
        "screen_name" : "jcarol45241937",
        "indices" : [ "0", "15" ],
        "id_str" : "1284139705273995265",
        "id" : "1284139705273995265"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312039173658865666",
    "id_str" : "1312046786488401921",
    "in_reply_to_user_id" : "1284139705273995265",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312046786488401921",
    "in_reply_to_status_id" : "1312039173658865666",
    "created_at" : "Fri Oct 02 15:08:25 +0000 2020",
    "favorited" : false,
    "full_text" : "@jcarol45241937 本科で会うんやで",
    "lang" : "ja",
    "in_reply_to_screen_name" : "jcarol45241937",
    "in_reply_to_user_id_str" : "1284139705273995265"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "えふ@42Tokyo 9月Piscine生",
        "screen_name" : "FPr4242",
        "indices" : [ "0", "8" ],
        "id_str" : "1251179846392143873",
        "id" : "1251179846392143873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "15" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1311970400704765954",
    "id_str" : "1312046711833939968",
    "in_reply_to_user_id" : "1251179846392143873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312046711833939968",
    "in_reply_to_status_id" : "1311970400704765954",
    "created_at" : "Fri Oct 02 15:08:07 +0000 2020",
    "favorited" : false,
    "full_text" : "@FPr4242 会えなかった",
    "lang" : "ja",
    "in_reply_to_screen_name" : "FPr4242",
    "in_reply_to_user_id_str" : "1251179846392143873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Diwamoto",
        "screen_name" : "Diwamoto_",
        "indices" : [ "3", "13" ],
        "id_str" : "1238016966322827264",
        "id" : "1238016966322827264"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "108" ],
    "favorite_count" : "0",
    "id_str" : "1312045617544298496",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312045617544298496",
    "created_at" : "Fri Oct 02 15:03:46 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Diwamoto_: ↑追加で説明なんですけど、「JISのエンターキー付けられないから無理！」って人のために1番右側の中２つのキーを犠牲にしてISOエンターを付けられるようにしています。。\n良かったらどうぞ…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Diwamoto",
        "screen_name" : "Diwamoto_",
        "indices" : [ "3", "13" ],
        "id_str" : "1238016966322827264",
        "id" : "1238016966322827264"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1312045561126612992",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312045561126612992",
    "created_at" : "Fri Oct 02 15:03:33 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Diwamoto_: 新作自作キーボードキット「ownly」の発表です！\n分割キーボードに慣れていない方も使いやすいように一般的なレイアウトを分割し、手を置いたときに自然な位置に来るように調整しています。\nご興味がある方はぜひ以下のフォームにご記入ください。\nhttps…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "26" ],
    "favorite_count" : "2",
    "id_str" : "1312043139494936576",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312043139494936576",
    "created_at" : "Fri Oct 02 14:53:55 +0000 2020",
    "favorited" : false,
    "full_text" : "帰路に着く。\n\n明日からは掃除と筋トレが始まるのだよ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Yukihiro Matsumoto",
        "screen_name" : "yukihiro_matz",
        "indices" : [ "3", "17" ],
        "id_str" : "20104013",
        "id" : "20104013"
      } ],
      "urls" : [ {
        "url" : "https://t.co/xtPExp3jWE",
        "expanded_url" : "https://www.ruby-lang.org/ja/news/2020/10/02/ruby-2-7-2-released/",
        "display_url" : "ruby-lang.org/ja/news/2020/1…",
        "indices" : [ "35", "58" ]
      } ]
    },
    "display_text_range" : [ "0", "58" ],
    "favorite_count" : "0",
    "id_str" : "1312042164415651842",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312042164415651842",
    "possibly_sensitive" : false,
    "created_at" : "Fri Oct 02 14:50:03 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @yukihiro_matz: Ruby 2.7.2 リリース https://t.co/xtPExp3jWE",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/JtAlH4JX7W",
        "expanded_url" : "https://twitter.com/42_tokyo/status/1311976496693616640",
        "display_url" : "twitter.com/42_tokyo/statu…",
        "indices" : [ "43", "66" ]
      } ]
    },
    "display_text_range" : [ "0", "66" ],
    "favorite_count" : "8",
    "id_str" : "1312027601104379905",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312027601104379905",
    "possibly_sensitive" : false,
    "created_at" : "Fri Oct 02 13:52:11 +0000 2020",
    "favorited" : false,
    "full_text" : "42舐め腐ってるお前。\n\nお前が思ってるより世界は広いぞ、舐めてないでかかってこい。 https://t.co/JtAlH4JX7W",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "8" ],
    "favorite_count" : "2",
    "id_str" : "1312027254193442817",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312027254193442817",
    "created_at" : "Fri Oct 02 13:50:48 +0000 2020",
    "favorited" : false,
    "full_text" : "そろそろ眠いな。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "眩しい",
        "screen_name" : "827Chika",
        "indices" : [ "3", "12" ],
        "id_str" : "1166511305907294208",
        "id" : "1166511305907294208"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/827Chika/status/1311993738944684033/photo/1",
        "source_status_id" : "1311993738944684033",
        "indices" : [ "103", "126" ],
        "url" : "https://t.co/V6jGt3fuLy",
        "media_url" : "http://pbs.twimg.com/media/EjUjU0JU0AAdGsP.jpg",
        "id_str" : "1311993706950479872",
        "source_user_id" : "1166511305907294208",
        "id" : "1311993706950479872",
        "media_url_https" : "https://pbs.twimg.com/media/EjUjU0JU0AAdGsP.jpg",
        "source_user_id_str" : "1166511305907294208",
        "sizes" : {
          "medium" : {
            "w" : "1200",
            "h" : "680",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1974",
            "h" : "1119",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "385",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1311993738944684033",
        "display_url" : "pic.twitter.com/V6jGt3fuLy"
      } ],
      "hashtags" : [ {
        "text" : "絵描きさんと繫がりたい",
        "indices" : [ "14", "26" ]
      }, {
        "text" : "秋の創作クラスタフォロー祭り",
        "indices" : [ "28", "43" ]
      } ]
    },
    "display_text_range" : [ "0", "126" ],
    "favorite_count" : "0",
    "id_str" : "1312263233915375616",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312263233915375616",
    "possibly_sensitive" : false,
    "created_at" : "Sat Oct 03 05:28:30 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @827Chika: #絵描きさんと繫がりたい \n#秋の創作クラスタフォロー祭り \n\nタグ失礼します〜\nしゅわしゅわできらきらした世界と可愛い女の子を描くのが好きです💫\n素敵なご縁がありますように！ https://t.co/V6jGt3fuLy",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/827Chika/status/1311993738944684033/photo/1",
        "source_status_id" : "1311993738944684033",
        "indices" : [ "103", "126" ],
        "url" : "https://t.co/V6jGt3fuLy",
        "media_url" : "http://pbs.twimg.com/media/EjUjU0JU0AAdGsP.jpg",
        "id_str" : "1311993706950479872",
        "source_user_id" : "1166511305907294208",
        "id" : "1311993706950479872",
        "media_url_https" : "https://pbs.twimg.com/media/EjUjU0JU0AAdGsP.jpg",
        "source_user_id_str" : "1166511305907294208",
        "sizes" : {
          "medium" : {
            "w" : "1200",
            "h" : "680",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1974",
            "h" : "1119",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "385",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1311993738944684033",
        "display_url" : "pic.twitter.com/V6jGt3fuLy"
      }, {
        "expanded_url" : "https://twitter.com/827Chika/status/1311993738944684033/photo/1",
        "source_status_id" : "1311993738944684033",
        "indices" : [ "103", "126" ],
        "url" : "https://t.co/V6jGt3fuLy",
        "media_url" : "http://pbs.twimg.com/media/EjUjVPrVkAU97Ep.jpg",
        "id_str" : "1311993714340892677",
        "source_user_id" : "1166511305907294208",
        "id" : "1311993714340892677",
        "media_url_https" : "https://pbs.twimg.com/media/EjUjVPrVkAU97Ep.jpg",
        "source_user_id_str" : "1166511305907294208",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "730",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "414",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1974",
            "h" : "1201",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1311993738944684033",
        "display_url" : "pic.twitter.com/V6jGt3fuLy"
      }, {
        "expanded_url" : "https://twitter.com/827Chika/status/1311993738944684033/photo/1",
        "source_status_id" : "1311993738944684033",
        "indices" : [ "103", "126" ],
        "url" : "https://t.co/V6jGt3fuLy",
        "media_url" : "http://pbs.twimg.com/media/EjUjWDuVcAAJnvL.jpg",
        "id_str" : "1311993728312111104",
        "source_user_id" : "1166511305907294208",
        "id" : "1311993728312111104",
        "media_url_https" : "https://pbs.twimg.com/media/EjUjWDuVcAAJnvL.jpg",
        "source_user_id_str" : "1166511305907294208",
        "sizes" : {
          "large" : {
            "w" : "2048",
            "h" : "1245",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "413",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "729",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1311993738944684033",
        "display_url" : "pic.twitter.com/V6jGt3fuLy"
      }, {
        "expanded_url" : "https://twitter.com/827Chika/status/1311993738944684033/photo/1",
        "source_status_id" : "1311993738944684033",
        "indices" : [ "103", "126" ],
        "url" : "https://t.co/V6jGt3fuLy",
        "media_url" : "http://pbs.twimg.com/media/EjUjWfPUwAA4j7A.jpg",
        "id_str" : "1311993735698235392",
        "source_user_id" : "1166511305907294208",
        "id" : "1311993735698235392",
        "media_url_https" : "https://pbs.twimg.com/media/EjUjWfPUwAA4j7A.jpg",
        "source_user_id_str" : "1166511305907294208",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1920",
            "h" : "1080",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1311993738944684033",
        "display_url" : "pic.twitter.com/V6jGt3fuLy"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "3", "13" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      }, {
        "name" : "Hinata",
        "screen_name" : "Hinata72279726",
        "indices" : [ "15", "30" ],
        "id_str" : "1228559135093821441",
        "id" : "1228559135093821441"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "31", "47" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      }, {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "48", "58" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "99" ],
    "favorite_count" : "0",
    "id_str" : "1312250711954997248",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312250711954997248",
    "created_at" : "Sat Oct 03 04:38:44 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @_unlimish: @Hinata72279726 @Kahorin_42Tokyo @luna_yuta あと、何かあったときのためにRAIDを組んでホットスワップもできるようにしたいね",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "11", "27" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      }, {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "28", "38" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "51" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312235148058918912",
    "id_str" : "1312235671487037441",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312235671487037441",
    "in_reply_to_status_id" : "1312235148058918912",
    "created_at" : "Sat Oct 03 03:38:58 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish @Kahorin_42Tokyo @luna_yuta バケットソートでも良いな",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "さかちゃん｜英語ブログ Sakablog 運営中",
        "screen_name" : "SakachanEnglish",
        "indices" : [ "3", "19" ],
        "id_str" : "1191046411657216000",
        "id" : "1191046411657216000"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1312234468095090690",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312234468095090690",
    "created_at" : "Sat Oct 03 03:34:11 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @SakachanEnglish: これまだ知らない人いますかね？ \n \nChromeの拡張機能「Language Learning with Netflix」 \n \n・再生速度を変えられる \n・英語・日本語字幕を同時に表示 \n・単語をクリックすると意味が表示される \n・…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      }, {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "17", "27" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "28", "38" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "60" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1312232041551859712",
    "id_str" : "1312232274172145665",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312232274172145665",
    "in_reply_to_status_id" : "1312232041551859712",
    "created_at" : "Sat Oct 03 03:25:28 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo @luna_yuta @_unlimish そのネタは界隈以外で通じないあたりがよいな",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "11", "27" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312230356863524866",
    "id_str" : "1312230705787621376",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312230705787621376",
    "in_reply_to_status_id" : "1312230356863524866",
    "created_at" : "Sat Oct 03 03:19:14 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @Kahorin_42Tokyo 撮影して2人を脅すことでお金を得るかな",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "11", "27" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312229463938093057",
    "id_str" : "1312230014088167424",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312230014088167424",
    "in_reply_to_status_id" : "1312229463938093057",
    "created_at" : "Sat Oct 03 03:16:30 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @Kahorin_42Tokyo いちゃいちゃすな。",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312228813762224130",
    "id_str" : "1312229238750105601",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312229238750105601",
    "in_reply_to_status_id" : "1312228813762224130",
    "created_at" : "Sat Oct 03 03:13:25 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c w\n私は既に抜かされてるから安心しろ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "34" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312227849122713600",
    "id_str" : "1312228340120522752",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312228340120522752",
    "in_reply_to_status_id" : "1312227849122713600",
    "created_at" : "Sat Oct 03 03:09:50 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c えちょ、怖い怖い仲間やんか…まってくれや…🥺",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "0",
    "id_str" : "1312228006622973953",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312228006622973953",
    "created_at" : "Sat Oct 03 03:08:31 +0000 2020",
    "favorited" : false,
    "full_text" : "どうりで軽いのかフォトナ \n\nUE入門しようかな…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "21" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312227211781369856",
    "id_str" : "1312227548323958784",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312227548323958784",
    "in_reply_to_status_id" : "1312227211781369856",
    "created_at" : "Sat Oct 03 03:06:42 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta 何も出ない。消した。",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312226624188809216",
    "id_str" : "1312226881119219713",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312226881119219713",
    "in_reply_to_status_id" : "1312226624188809216",
    "created_at" : "Sat Oct 03 03:04:03 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta 良いことがあるだけいいじゃん",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "36" ],
    "favorite_count" : "0",
    "id_str" : "1312226780447563777",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312226780447563777",
    "created_at" : "Sat Oct 03 03:03:39 +0000 2020",
    "favorited" : false,
    "full_text" : "実はフォトナ はunrealエンジンなのでC++でできてるはずなんやで。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "フォートナイト",
        "screen_name" : "FortniteJP",
        "indices" : [ "0", "11" ],
        "id_str" : "958264156683091969",
        "id" : "958264156683091969"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "14" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312225862306144256",
    "id_str" : "1312226378469711872",
    "in_reply_to_user_id" : "958264156683091969",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312226378469711872",
    "in_reply_to_status_id" : "1312225862306144256",
    "created_at" : "Sat Oct 03 03:02:03 +0000 2020",
    "favorited" : false,
    "full_text" : "@FortniteJP 釣竿",
    "lang" : "ja",
    "in_reply_to_screen_name" : "FortniteJP",
    "in_reply_to_user_id_str" : "958264156683091969"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "2",
    "id_str" : "1312226115952369665",
    "truncated" : false,
    "retweet_count" : "1",
    "id" : "1312226115952369665",
    "created_at" : "Sat Oct 03 03:01:00 +0000 2020",
    "favorited" : false,
    "full_text" : "秘匿性爆上げで生きていきたい。\n本名で検索しても何もわからない人生が良い。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "3", "13" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ {
        "url" : "https://t.co/QwkVJMtbJl",
        "expanded_url" : "https://www.sigbus.info/compilerbook",
        "display_url" : "sigbus.info/compilerbook",
        "indices" : [ "63", "86" ]
      } ]
    },
    "display_text_range" : [ "0", "86" ],
    "favorite_count" : "0",
    "id_str" : "1312225954006134785",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312225954006134785",
    "possibly_sensitive" : false,
    "created_at" : "Sat Oct 03 03:00:22 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @_unlimish: 1ヶ月間C触ってきたしこれやってみますか。\n\n低レイヤを知りたい人のためのCコンパイラ作成入門 https://t.co/QwkVJMtbJl",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hayasakaaaaaa",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "22" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312225361409667073",
    "id_str" : "1312225835017928704",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312225835017928704",
    "in_reply_to_status_id" : "1312225361409667073",
    "created_at" : "Sat Oct 03 02:59:53 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c あなたは私のライバル",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "31" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1312224079148019713",
    "id_str" : "1312224219791462401",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312224219791462401",
    "in_reply_to_status_id" : "1312224079148019713",
    "created_at" : "Sat Oct 03 02:53:28 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish 理解\nメールボックスの閲覧数爆上げの予感",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "36" ],
    "favorite_count" : "0",
    "id_str" : "1312223782057123842",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312223782057123842",
    "created_at" : "Sat Oct 03 02:51:44 +0000 2020",
    "favorited" : false,
    "full_text" : "あれ？そういえば合格発表ってどうやってするの？どっかに張り出されるの…？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "えふ@42Tokyo 9月Piscine生",
        "screen_name" : "FPr4242",
        "indices" : [ "11", "19" ],
        "id_str" : "1251179846392143873",
        "id" : "1251179846392143873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "2",
    "in_reply_to_status_id_str" : "1312222088652967938",
    "id_str" : "1312222362700378113",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312222362700378113",
    "in_reply_to_status_id" : "1312222088652967938",
    "created_at" : "Sat Oct 03 02:46:05 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @FPr4242 ありがとう",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "107" ],
    "favorite_count" : "4",
    "id_str" : "1312220624257916928",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312220624257916928",
    "created_at" : "Sat Oct 03 02:39:11 +0000 2020",
    "favorited" : false,
    "full_text" : "力が欲しいんじゃ\n\n自分のメンタルは管理できるようになったし、gitは触れるようになったし、学校の曖昧な理解は完全にできたが\n\n1人で何かを成し遂げられる気がしないんじゃ。\n\nこれは何をしたら力がつくかよくわからん",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "えふ@42Tokyo 9月Piscine生",
        "screen_name" : "FPr4242",
        "indices" : [ "11", "19" ],
        "id_str" : "1251179846392143873",
        "id" : "1251179846392143873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "44" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312213830944976896",
    "id_str" : "1312220338344796160",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312220338344796160",
    "in_reply_to_status_id" : "1312213830944976896",
    "created_at" : "Sat Oct 03 02:38:03 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @FPr4242 結局できてないならやってないのと同じなんだよなぁ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "31" ],
    "favorite_count" : "2",
    "id_str" : "1312184126804430849",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312184126804430849",
    "created_at" : "Sat Oct 03 00:14:09 +0000 2020",
    "favorited" : false,
    "full_text" : "隣の家からコロナが風邪って言う話が聞こえてくる\n\n朝からすげぇ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Taka@データサイエンティスト",
        "screen_name" : "freelancer_th",
        "indices" : [ "3", "17" ],
        "id_str" : "1094077940701118464",
        "id" : "1094077940701118464"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "45" ],
    "favorite_count" : "0",
    "id_str" : "1312183600775745536",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312183600775745536",
    "created_at" : "Sat Oct 03 00:12:04 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @freelancer_th: 固有値問題で出てくる話で、統計学で必要な理解の１つ！",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Liberta Ta-Key",
        "screen_name" : "Ta_Key18",
        "indices" : [ "3", "12" ],
        "id_str" : "1176793471312515072",
        "id" : "1176793471312515072"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Ta_Key18/status/1311989839487619073/photo/1",
        "source_status_id" : "1311989839487619073",
        "indices" : [ "62", "85" ],
        "url" : "https://t.co/vmuw1mZcAd",
        "media_url" : "http://pbs.twimg.com/media/EjUfzj7VgAIRBiV.jpg",
        "id_str" : "1311989837126270978",
        "source_user_id" : "1176793471312515072",
        "id" : "1311989837126270978",
        "media_url_https" : "https://pbs.twimg.com/media/EjUfzj7VgAIRBiV.jpg",
        "source_user_id_str" : "1176793471312515072",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1920",
            "h" : "1080",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1311989839487619073",
        "display_url" : "pic.twitter.com/vmuw1mZcAd"
      } ],
      "hashtags" : [ {
        "text" : "FortniteCreative",
        "indices" : [ "27", "44" ]
      }, {
        "text" : "フォートナイトクリエイティブ",
        "indices" : [ "46", "61" ]
      } ]
    },
    "display_text_range" : [ "0", "85" ],
    "favorite_count" : "0",
    "id_str" : "1312182690884448256",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312182690884448256",
    "possibly_sensitive" : false,
    "created_at" : "Sat Oct 03 00:08:27 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Ta_Key18: サイバーオサレパンティ\n\n#FortniteCreative \n#フォートナイトクリエイティブ https://t.co/vmuw1mZcAd",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Ta_Key18/status/1311989839487619073/photo/1",
        "source_status_id" : "1311989839487619073",
        "indices" : [ "62", "85" ],
        "url" : "https://t.co/vmuw1mZcAd",
        "media_url" : "http://pbs.twimg.com/media/EjUfzj7VgAIRBiV.jpg",
        "id_str" : "1311989837126270978",
        "source_user_id" : "1176793471312515072",
        "id" : "1311989837126270978",
        "media_url_https" : "https://pbs.twimg.com/media/EjUfzj7VgAIRBiV.jpg",
        "source_user_id_str" : "1176793471312515072",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1920",
            "h" : "1080",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1311989839487619073",
        "display_url" : "pic.twitter.com/vmuw1mZcAd"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "sinpoko_t",
        "screen_name" : "sinpoko_t",
        "indices" : [ "3", "13" ],
        "id_str" : "1271647278676103170",
        "id" : "1271647278676103170"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1312381825822593025",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312381825822593025",
    "created_at" : "Sat Oct 03 13:19:44 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @sinpoko_t: unityもunrealもエンジン自体の実装はC++だったような",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "26" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312374254222995456",
    "id_str" : "1312380809811165186",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312380809811165186",
    "in_reply_to_status_id" : "1312374254222995456",
    "created_at" : "Sat Oct 03 13:15:42 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo 仲間ジャーンwww",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312340321036951552",
    "id_str" : "1312380646631768065",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312380646631768065",
    "in_reply_to_status_id" : "1312340321036951552",
    "created_at" : "Sat Oct 03 13:15:03 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c ほんとほんとそれわかる",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "たけひと",
        "screen_name" : "takehitopistol",
        "indices" : [ "0", "15" ],
        "id_str" : "1215191126103097344",
        "id" : "1215191126103097344"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312351934108463106",
    "id_str" : "1312380600897085442",
    "in_reply_to_user_id" : "1215191126103097344",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312380600897085442",
    "in_reply_to_status_id" : "1312351934108463106",
    "created_at" : "Sat Oct 03 13:14:52 +0000 2020",
    "favorited" : false,
    "full_text" : "@takehitopistol 優しさ溢れててすこ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "takehitopistol",
    "in_reply_to_user_id_str" : "1215191126103097344"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "29" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312329486910644224",
    "id_str" : "1312332503206694912",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312332503206694912",
    "in_reply_to_status_id" : "1312329486910644224",
    "created_at" : "Sat Oct 03 10:03:45 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta ヘッドエイクで頭痛が痛いの？(混乱)",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312327619585605632",
    "id_str" : "1312328412938162176",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312328412938162176",
    "in_reply_to_status_id" : "1312327619585605632",
    "created_at" : "Sat Oct 03 09:47:30 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta 頭痛が痛くなりそうな構文だな",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "2",
    "id_str" : "1312327141430710273",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312327141430710273",
    "created_at" : "Sat Oct 03 09:42:27 +0000 2020",
    "favorited" : false,
    "full_text" : "みんな微妙に実生活に居場所ないのかTwitterにたまるの面白すぎんか？w",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "43" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312326495726051328",
    "id_str" : "1312326957753753600",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312326957753753600",
    "in_reply_to_status_id" : "1312326495726051328",
    "created_at" : "Sat Oct 03 09:41:43 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta なんとかしなくてはいけない、だからこそなんとかしなくてはならない",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "rex@42Tokyo_Piscine_9月",
        "screen_name" : "trex_dad",
        "indices" : [ "3", "12" ],
        "id_str" : "1280295123725635584",
        "id" : "1280295123725635584"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "63" ],
    "favorite_count" : "0",
    "id_str" : "1312326841059876870",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312326841059876870",
    "created_at" : "Sat Oct 03 09:41:15 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @trex_dad: みんな、感覚マヒってるだけで、相当疲れ溜まってるからね、気が抜けて体調崩さないようにね（特にオレ）",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "20" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312326403417755648",
    "id_str" : "1312326719315955712",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312326719315955712",
    "in_reply_to_status_id" : "1312326403417755648",
    "created_at" : "Sat Oct 03 09:40:46 +0000 2020",
    "favorited" : false,
    "full_text" : "そう言う女友達がいないことにふと気がつく",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "たけひと",
        "screen_name" : "takehitopistol",
        "indices" : [ "0", "15" ],
        "id_str" : "1215191126103097344",
        "id" : "1215191126103097344"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "36" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1312312397521059841",
    "id_str" : "1312326561396260864",
    "in_reply_to_user_id" : "1215191126103097344",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312326561396260864",
    "in_reply_to_status_id" : "1312312397521059841",
    "created_at" : "Sat Oct 03 09:40:08 +0000 2020",
    "favorited" : false,
    "full_text" : "@takehitopistol 賑やかすぎて、たけひとさん引いちゃいそう",
    "lang" : "ja",
    "in_reply_to_screen_name" : "takehitopistol",
    "in_reply_to_user_id_str" : "1215191126103097344"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "12" ],
    "favorite_count" : "2",
    "id_str" : "1312326403417755648",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312326403417755648",
    "created_at" : "Sat Oct 03 09:39:31 +0000 2020",
    "favorited" : false,
    "full_text" : "女友達とペアリングしたい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "26" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312325976781541377",
    "id_str" : "1312326212375572480",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312326212375572480",
    "in_reply_to_status_id" : "1312325976781541377",
    "created_at" : "Sat Oct 03 09:38:45 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta スラリと交わされてしまったか…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "33" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312323051124482049",
    "id_str" : "1312324082981978112",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312324082981978112",
    "in_reply_to_status_id" : "1312323051124482049",
    "created_at" : "Sat Oct 03 09:30:17 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta 一部のマニアに岸本悠太ネタの薄い本がバカウケ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "17" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312322845788135425",
    "id_str" : "1312323132682715136",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312323132682715136",
    "in_reply_to_status_id" : "1312322845788135425",
    "created_at" : "Sat Oct 03 09:26:31 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta むしろ九龍城",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "1",
    "id_str" : "1312322920228687873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312322920228687873",
    "created_at" : "Sat Oct 03 09:25:40 +0000 2020",
    "favorited" : false,
    "full_text" : "たかだか油こってりで胸焼けを感じるからもうババァなんだよなぁ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312322619698409474",
    "id_str" : "1312322780700917760",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312322780700917760",
    "in_reply_to_status_id" : "1312322619698409474",
    "created_at" : "Sat Oct 03 09:25:07 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta 売れたそうな顔",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312321749103460355",
    "id_str" : "1312322526098284545",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312322526098284545",
    "in_reply_to_status_id" : "1312321749103460355",
    "created_at" : "Sat Oct 03 09:24:06 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta そう言う顔してるもんなぁ…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ぐーすかきつね@42tokyo",
        "screen_name" : "sleepyfox_42",
        "indices" : [ "3", "16" ],
        "id_str" : "1284518123954008067",
        "id" : "1284518123954008067"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/sleepyfox_42/status/1312321844788097024/photo/1",
        "source_status_id" : "1312321844788097024",
        "indices" : [ "54", "77" ],
        "url" : "https://t.co/s4mX7m5z4u",
        "media_url" : "http://pbs.twimg.com/media/EjZNwCzVoAEzpRW.jpg",
        "id_str" : "1312321829206335489",
        "source_user_id" : "1284518123954008067",
        "id" : "1312321829206335489",
        "media_url_https" : "https://pbs.twimg.com/media/EjZNwCzVoAEzpRW.jpg",
        "source_user_id_str" : "1284518123954008067",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "2048",
            "h" : "1519",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "504",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "890",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1312321844788097024",
        "display_url" : "pic.twitter.com/s4mX7m5z4u"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "77" ],
    "favorite_count" : "0",
    "id_str" : "1312322253162336257",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312322253162336257",
    "possibly_sensitive" : false,
    "created_at" : "Sat Oct 03 09:23:01 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @sleepyfox_42: 東京来てから何回食ったかわからん、太陽のトマト麺のチーズトマトラーメン https://t.co/s4mX7m5z4u",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/sleepyfox_42/status/1312321844788097024/photo/1",
        "source_status_id" : "1312321844788097024",
        "indices" : [ "54", "77" ],
        "url" : "https://t.co/s4mX7m5z4u",
        "media_url" : "http://pbs.twimg.com/media/EjZNwCzVoAEzpRW.jpg",
        "id_str" : "1312321829206335489",
        "source_user_id" : "1284518123954008067",
        "id" : "1312321829206335489",
        "media_url_https" : "https://pbs.twimg.com/media/EjZNwCzVoAEzpRW.jpg",
        "source_user_id_str" : "1284518123954008067",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "2048",
            "h" : "1519",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "504",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "890",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1312321844788097024",
        "display_url" : "pic.twitter.com/s4mX7m5z4u"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "0",
    "id_str" : "1312322218320228352",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312322218320228352",
    "created_at" : "Sat Oct 03 09:22:53 +0000 2020",
    "favorited" : false,
    "full_text" : "改めて問おう。精神面、肉体面を合わせて私の性別はいかに？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "15" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312320187639623683",
    "id_str" : "1312320822439145472",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312320822439145472",
    "in_reply_to_status_id" : "1312320187639623683",
    "created_at" : "Sat Oct 03 09:17:20 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta いこーぜ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312314788844724224/photo/1",
        "indices" : [ "105", "128" ],
        "url" : "https://t.co/omXSLABb7p",
        "media_url" : "http://pbs.twimg.com/media/EjZHVk3UwAE5R1Y.jpg",
        "id_str" : "1312314777423626241",
        "id" : "1312314777423626241",
        "media_url_https" : "https://pbs.twimg.com/media/EjZHVk3UwAE5R1Y.jpg",
        "sizes" : {
          "large" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/omXSLABb7p"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "128" ],
    "favorite_count" : "7",
    "id_str" : "1312314788844724224",
    "truncated" : false,
    "retweet_count" : "1",
    "id" : "1312314788844724224",
    "possibly_sensitive" : false,
    "created_at" : "Sat Oct 03 08:53:21 +0000 2020",
    "favorited" : false,
    "full_text" : "吉祥寺の野方ホープ軒、今日は濃の脂こってりを注文。\n\n油抜き、あっさり、普通、こってり、こてこてが選べるので、油苦手な人も入れるお店\n\n自分で絞れる悪魔の食べ物生ニンニクもただ…(私はがっつり一粒潰しました) https://t.co/omXSLABb7p",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312314788844724224/photo/1",
        "indices" : [ "105", "128" ],
        "url" : "https://t.co/omXSLABb7p",
        "media_url" : "http://pbs.twimg.com/media/EjZHVk3UwAE5R1Y.jpg",
        "id_str" : "1312314777423626241",
        "id" : "1312314777423626241",
        "media_url_https" : "https://pbs.twimg.com/media/EjZHVk3UwAE5R1Y.jpg",
        "sizes" : {
          "large" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1024",
            "h" : "768",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/omXSLABb7p"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "3", "13" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "79" ],
    "favorite_count" : "0",
    "id_str" : "1312303299542933504",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312303299542933504",
    "created_at" : "Sat Oct 03 08:07:42 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @luna_yuta: 音楽勢と文学勢と頭おかしい勢に加えて頭のおかしいエンジニア志望者たちをTLに追加してしまったのでもうTLがめちゃくちゃだよわかる",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "3", "13" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "42" ],
    "favorite_count" : "0",
    "id_str" : "1312290646619611136",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312290646619611136",
    "created_at" : "Sat Oct 03 07:17:25 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @luna_yuta: 合格ライン分らないけどSNSの汚さでいえば確実に不合格",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "11", "21" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "22", "38" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "51" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312275959937032193",
    "id_str" : "1312290598783647745",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312290598783647745",
    "in_reply_to_status_id" : "1312275959937032193",
    "created_at" : "Sat Oct 03 07:17:14 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @_unlimish @Kahorin_42Tokyo けるべろすおてぃんてぃん",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hayasakaaaaaa",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "34" ],
    "favorite_count" : "2",
    "in_reply_to_status_id_str" : "1312652103303614466",
    "id_str" : "1312655213380038658",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312655213380038658",
    "in_reply_to_status_id" : "1312652103303614466",
    "created_at" : "Sun Oct 04 07:26:05 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c ほんとそれ、入れても入れなくてもまたやりたい",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "61" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1312650959491751937",
    "id_str" : "1312655046778126336",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312655046778126336",
    "in_reply_to_status_id" : "1312650959491751937",
    "created_at" : "Sun Oct 04 07:25:25 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo 美化しすぎなのでは？何にでもなれるものは何にもなることができないのである_(:3」z)_",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "22" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312649137301549057",
    "id_str" : "1312650111650992128",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312650111650992128",
    "in_reply_to_status_id" : "1312649137301549057",
    "created_at" : "Sun Oct 04 07:05:49 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c 溶けてたんだよなぁ…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312649645848313856",
    "id_str" : "1312649973670895616",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312649973670895616",
    "in_reply_to_status_id" : "1312649645848313856",
    "created_at" : "Sun Oct 04 07:05:16 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo えっ、あいつ美容師ではないだろ？？？？w",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "6",
    "id_str" : "1312649057928581120",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312649057928581120",
    "created_at" : "Sun Oct 04 07:01:37 +0000 2020",
    "favorited" : false,
    "full_text" : "夢の中でBSQといてたんだよなぁwwwwwwww",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "42" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312602256194199552",
    "id_str" : "1312646629879554054",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312646629879554054",
    "in_reply_to_status_id" : "1312602256194199552",
    "created_at" : "Sun Oct 04 06:51:59 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo そしてバイトがしたいとなかなか染められないジレンマ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "78" ],
    "favorite_count" : "1",
    "id_str" : "1312646402086850566",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312646402086850566",
    "created_at" : "Sun Oct 04 06:51:04 +0000 2020",
    "favorited" : false,
    "full_text" : "庭の木放置してたら他人の家浸食してたんで、朝から家族総出で選定作業\n\nいい具合にローリエの葉が取れたので、まとめてメルカリ行きかな。\n\nまずは乾かさないとね",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "11", "27" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "56" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312611989366083584",
    "id_str" : "1312646136507719680",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312646136507719680",
    "in_reply_to_status_id" : "1312611989366083584",
    "created_at" : "Sun Oct 04 06:50:01 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @Kahorin_42Tokyo 白ってブリーチ何回したらうまく染まるの…？地肌痛めそう…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "11", "27" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "35" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1312605448357384195",
    "id_str" : "1312646028776992772",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312646028776992772",
    "in_reply_to_status_id" : "1312605448357384195",
    "created_at" : "Sun Oct 04 06:49:35 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @Kahorin_42Tokyo 腐った紅生姜？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "43" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1312602554610577408",
    "id_str" : "1312645984527151105",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312645984527151105",
    "in_reply_to_status_id" : "1312602554610577408",
    "created_at" : "Sun Oct 04 06:49:25 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo おいくら万円になるかによるんだよなぁ(学生あるある)",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hayasakaaaaaa",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "67" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312594963964719105",
    "id_str" : "1312645816058740736",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312645816058740736",
    "in_reply_to_status_id" : "1312594963964719105",
    "created_at" : "Sun Oct 04 06:48:44 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c あっ、ばれた？でもvimでvisualもーど少しは使えたから、いつも使ってなくてもちょっとは対応できる…はずw",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hayasakaaaaaa",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312584786565754881",
    "id_str" : "1312593853568884737",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312593853568884737",
    "in_reply_to_status_id" : "1312584786565754881",
    "created_at" : "Sun Oct 04 03:22:16 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c ✌︎('ω'✌︎ )？",
    "lang" : "und",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312590759330152448/photo/1",
        "indices" : [ "15", "38" ],
        "url" : "https://t.co/XCm9ngyeFG",
        "media_url" : "http://pbs.twimg.com/media/EjdCViYU4AAgWe2.jpg",
        "id_str" : "1312590754175311872",
        "id" : "1312590754175311872",
        "media_url_https" : "https://pbs.twimg.com/media/EjdCViYU4AAgWe2.jpg",
        "sizes" : {
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/XCm9ngyeFG"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "38" ],
    "favorite_count" : "3",
    "id_str" : "1312590759330152448",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312590759330152448",
    "possibly_sensitive" : false,
    "created_at" : "Sun Oct 04 03:09:58 +0000 2020",
    "favorited" : false,
    "full_text" : "こんな風にしたいわ…青色で… https://t.co/XCm9ngyeFG",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312590759330152448/photo/1",
        "indices" : [ "15", "38" ],
        "url" : "https://t.co/XCm9ngyeFG",
        "media_url" : "http://pbs.twimg.com/media/EjdCViYU4AAgWe2.jpg",
        "id_str" : "1312590754175311872",
        "id" : "1312590754175311872",
        "media_url_https" : "https://pbs.twimg.com/media/EjdCViYU4AAgWe2.jpg",
        "sizes" : {
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/XCm9ngyeFG"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "私の女",
        "screen_name" : "genki_heiki",
        "indices" : [ "3", "15" ],
        "id_str" : "1080833444672761856",
        "id" : "1080833444672761856"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/genki_heiki/status/1312370431685402626/photo/1",
        "source_status_id" : "1312370431685402626",
        "indices" : [ "47", "70" ],
        "url" : "https://t.co/vxxylhD87S",
        "media_url" : "http://pbs.twimg.com/media/EjZ51bXUYAAICEH.jpg",
        "id_str" : "1312370300210667520",
        "source_user_id" : "1080833444672761856",
        "id" : "1312370300210667520",
        "media_url_https" : "https://pbs.twimg.com/media/EjZ51bXUYAAICEH.jpg",
        "source_user_id_str" : "1080833444672761856",
        "sizes" : {
          "medium" : {
            "w" : "917",
            "h" : "1000",
            "resize" : "fit"
          },
          "small" : {
            "w" : "624",
            "h" : "680",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "917",
            "h" : "1000",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1312370431685402626",
        "display_url" : "pic.twitter.com/vxxylhD87S"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "70" ],
    "favorite_count" : "0",
    "id_str" : "1312590088275070978",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312590088275070978",
    "possibly_sensitive" : false,
    "created_at" : "Sun Oct 04 03:07:18 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @genki_heiki: サツ意マシマシだった頃に描いたマイアミのイラスト　癒される https://t.co/vxxylhD87S",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/genki_heiki/status/1312370431685402626/photo/1",
        "source_status_id" : "1312370431685402626",
        "indices" : [ "47", "70" ],
        "url" : "https://t.co/vxxylhD87S",
        "media_url" : "http://pbs.twimg.com/media/EjZ51bXUYAAICEH.jpg",
        "id_str" : "1312370300210667520",
        "source_user_id" : "1080833444672761856",
        "id" : "1312370300210667520",
        "media_url_https" : "https://pbs.twimg.com/media/EjZ51bXUYAAICEH.jpg",
        "source_user_id_str" : "1080833444672761856",
        "sizes" : {
          "medium" : {
            "w" : "917",
            "h" : "1000",
            "resize" : "fit"
          },
          "small" : {
            "w" : "624",
            "h" : "680",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "917",
            "h" : "1000",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1312370431685402626",
        "display_url" : "pic.twitter.com/vxxylhD87S"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "mattn",
        "screen_name" : "mattn_jp",
        "indices" : [ "3", "12" ],
        "id_str" : "3180341",
        "id" : "3180341"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1312589789586059264",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312589789586059264",
    "created_at" : "Sun Oct 04 03:06:07 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @mattn_jp: 事前にお知らせがあった通り、GitHub のデフォルトブランチが master から main に変更された。 / “The default branch for newly-created repositories is now main - Gi…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ワーナー ブラザース ジャパン",
        "screen_name" : "warnerjp",
        "indices" : [ "3", "12" ],
        "id_str" : "278549221",
        "id" : "278549221"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/warnerjp/status/1312581365875929089/photo/1",
        "source_status_id" : "1312581365875929089",
        "indices" : [ "67", "90" ],
        "url" : "https://t.co/IFJStsTSLb",
        "media_url" : "http://pbs.twimg.com/media/Ejc5yb8UcAAxvMz.jpg",
        "id_str" : "1312581355058786304",
        "source_user_id" : "278549221",
        "id" : "1312581355058786304",
        "media_url_https" : "https://pbs.twimg.com/media/Ejc5yb8UcAAxvMz.jpg",
        "source_user_id_str" : "278549221",
        "sizes" : {
          "medium" : {
            "w" : "880",
            "h" : "620",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "880",
            "h" : "620",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "479",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1312581365875929089",
        "display_url" : "pic.twitter.com/IFJStsTSLb"
      } ],
      "hashtags" : [ {
        "text" : "天使の日",
        "indices" : [ "24", "29" ]
      }, {
        "text" : "コンスタンティン",
        "indices" : [ "57", "66" ]
      } ]
    },
    "display_text_range" : [ "0", "90" ],
    "favorite_count" : "0",
    "id_str" : "1312588352848228354",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312588352848228354",
    "possibly_sensitive" : false,
    "created_at" : "Sun Oct 04 03:00:24 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @warnerjp: .｡oO（ 本日は #天使の日 ということで…ガブリエル様…置いておきますね…🙏✨\n\n#コンスタンティン https://t.co/IFJStsTSLb",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/warnerjp/status/1312581365875929089/photo/1",
        "source_status_id" : "1312581365875929089",
        "indices" : [ "67", "90" ],
        "url" : "https://t.co/IFJStsTSLb",
        "media_url" : "http://pbs.twimg.com/media/Ejc5yb8UcAAxvMz.jpg",
        "id_str" : "1312581355058786304",
        "source_user_id" : "278549221",
        "id" : "1312581355058786304",
        "media_url_https" : "https://pbs.twimg.com/media/Ejc5yb8UcAAxvMz.jpg",
        "source_user_id_str" : "278549221",
        "sizes" : {
          "medium" : {
            "w" : "880",
            "h" : "620",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "880",
            "h" : "620",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "479",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1312581365875929089",
        "display_url" : "pic.twitter.com/IFJStsTSLb"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "tkyunai",
        "screen_name" : "takashi_971",
        "indices" : [ "0", "12" ],
        "id_str" : "266546862",
        "id" : "266546862"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "20" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312575965608861696",
    "id_str" : "1312583840200708096",
    "in_reply_to_user_id" : "266546862",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312583840200708096",
    "in_reply_to_status_id" : "1312575965608861696",
    "created_at" : "Sun Oct 04 02:42:28 +0000 2020",
    "favorited" : false,
    "full_text" : "@takashi_971 ほんとそれねw",
    "lang" : "ja",
    "in_reply_to_screen_name" : "takashi_971",
    "in_reply_to_user_id_str" : "266546862"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "j-carol(whanamot)",
        "screen_name" : "jcarol45241937",
        "indices" : [ "0", "15" ],
        "id_str" : "1284139705273995265",
        "id" : "1284139705273995265"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "19" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1312390352184123393",
    "id_str" : "1312391014296907781",
    "in_reply_to_user_id" : "1284139705273995265",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312391014296907781",
    "in_reply_to_status_id" : "1312390352184123393",
    "created_at" : "Sat Oct 03 13:56:15 +0000 2020",
    "favorited" : false,
    "full_text" : "@jcarol45241937 わかる",
    "lang" : "ja",
    "in_reply_to_screen_name" : "jcarol45241937",
    "in_reply_to_user_id_str" : "1284139705273995265"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "11", "27" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "43" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312389840952942593",
    "id_str" : "1312390327328632834",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312390327328632834",
    "in_reply_to_status_id" : "1312389840952942593",
    "created_at" : "Sat Oct 03 13:53:31 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish @Kahorin_42Tokyo そうなんだよなぁ、値段次第…w",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      }, {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "17", "27" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312389429177196546",
    "id_str" : "1312390244499554306",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312390244499554306",
    "in_reply_to_status_id" : "1312389429177196546",
    "created_at" : "Sat Oct 03 13:53:11 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo @_unlimish 現代味のあるカラー",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "19" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312385021731172354",
    "id_str" : "1312385528289914882",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312385528289914882",
    "in_reply_to_status_id" : "1312385021731172354",
    "created_at" : "Sat Oct 03 13:34:27 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish それはまずいな…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312384118026461185/photo/1",
        "indices" : [ "21", "44" ],
        "url" : "https://t.co/rkgYwYu1Zm",
        "media_url" : "http://pbs.twimg.com/media/EjaGZUiU8AY8Z-R.jpg",
        "id_str" : "1312384110992617478",
        "id" : "1312384110992617478",
        "media_url_https" : "https://pbs.twimg.com/media/EjaGZUiU8AY8Z-R.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1184",
            "h" : "720",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1184",
            "h" : "720",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "414",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/rkgYwYu1Zm"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "44" ],
    "favorite_count" : "11",
    "id_str" : "1312384118026461185",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312384118026461185",
    "possibly_sensitive" : false,
    "created_at" : "Sat Oct 03 13:28:51 +0000 2020",
    "favorited" : false,
    "full_text" : "Happy Birthday To Me https://t.co/rkgYwYu1Zm",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312384118026461185/photo/1",
        "indices" : [ "21", "44" ],
        "url" : "https://t.co/rkgYwYu1Zm",
        "media_url" : "http://pbs.twimg.com/media/EjaGZUiU8AY8Z-R.jpg",
        "id_str" : "1312384110992617478",
        "id" : "1312384110992617478",
        "media_url_https" : "https://pbs.twimg.com/media/EjaGZUiU8AY8Z-R.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1184",
            "h" : "720",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1184",
            "h" : "720",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "414",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/rkgYwYu1Zm"
      }, {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312384118026461185/photo/1",
        "indices" : [ "21", "44" ],
        "url" : "https://t.co/rkgYwYu1Zm",
        "media_url" : "http://pbs.twimg.com/media/EjaGZVEVkAA6BLe.jpg",
        "id_str" : "1312384111135264768",
        "id" : "1312384111135264768",
        "media_url_https" : "https://pbs.twimg.com/media/EjaGZVEVkAA6BLe.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/rkgYwYu1Zm"
      }, {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312384118026461185/photo/1",
        "indices" : [ "21", "44" ],
        "url" : "https://t.co/rkgYwYu1Zm",
        "media_url" : "http://pbs.twimg.com/media/EjaGZVlU8AAD1J3.jpg",
        "id_str" : "1312384111273635840",
        "id" : "1312384111273635840",
        "media_url_https" : "https://pbs.twimg.com/media/EjaGZVlU8AAD1J3.jpg",
        "sizes" : {
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/rkgYwYu1Zm"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "38" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312383186832224257",
    "id_str" : "1312383559148003330",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312383559148003330",
    "in_reply_to_status_id" : "1312383186832224257",
    "created_at" : "Sat Oct 03 13:26:38 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish あんりみぴんくになるかもしれないから、青にしよーかなー",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312383260480077826/photo/1",
        "indices" : [ "39", "62" ],
        "url" : "https://t.co/MFQEgrSj9K",
        "media_url" : "http://pbs.twimg.com/media/EjaFnizUwAAg1tN.jpg",
        "id_str" : "1312383255828545536",
        "id" : "1312383255828545536",
        "media_url_https" : "https://pbs.twimg.com/media/EjaFnizUwAAg1tN.jpg",
        "sizes" : {
          "medium" : {
            "w" : "1184",
            "h" : "720",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1184",
            "h" : "720",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "414",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/MFQEgrSj9K"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "62" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312382889082847232",
    "id_str" : "1312383260480077826",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312383260480077826",
    "in_reply_to_status_id" : "1312382889082847232",
    "possibly_sensitive" : false,
    "created_at" : "Sat Oct 03 13:25:26 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo 迷うけど、こんなの見つけちゃったのよね…w https://t.co/MFQEgrSj9K",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312383260480077826/photo/1",
        "indices" : [ "39", "62" ],
        "url" : "https://t.co/MFQEgrSj9K",
        "media_url" : "http://pbs.twimg.com/media/EjaFnizUwAAg1tN.jpg",
        "id_str" : "1312383255828545536",
        "id" : "1312383255828545536",
        "media_url_https" : "https://pbs.twimg.com/media/EjaFnizUwAAg1tN.jpg",
        "sizes" : {
          "medium" : {
            "w" : "1184",
            "h" : "720",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1184",
            "h" : "720",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "414",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/MFQEgrSj9K"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "17" ],
    "favorite_count" : "3",
    "id_str" : "1312382772200177664",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312382772200177664",
    "created_at" : "Sat Oct 03 13:23:30 +0000 2020",
    "favorited" : false,
    "full_text" : "人生で初めて髪の毛を染めようと思う",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hayasakaaaaaa",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "32" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312707684123045894",
    "id_str" : "1312708366527913984",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312708366527913984",
    "in_reply_to_status_id" : "1312707684123045894",
    "created_at" : "Sun Oct 04 10:57:18 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c 次はシェイカーが欲しくなる呪いかけといた",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "21" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312629205281075200",
    "id_str" : "1312707681413525511",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312707681413525511",
    "in_reply_to_status_id" : "1312629205281075200",
    "created_at" : "Sun Oct 04 10:54:34 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish そう言うところが好き",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "17" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312697211197685763",
    "id_str" : "1312707397689851905",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312707397689851905",
    "in_reply_to_status_id" : "1312697211197685763",
    "created_at" : "Sun Oct 04 10:53:27 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c めじゃー！",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "sinpoko_t",
        "screen_name" : "sinpoko_t",
        "indices" : [ "3", "13" ],
        "id_str" : "1271647278676103170",
        "id" : "1271647278676103170"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "50" ],
    "favorite_count" : "0",
    "id_str" : "1312707191011377152",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312707191011377152",
    "created_at" : "Sun Oct 04 10:52:37 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @sinpoko_t: origin masterじゃなくてorigin mainになったのか",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312706456244768769/photo/1",
        "indices" : [ "2", "25" ],
        "url" : "https://t.co/cWqwwAjtKq",
        "media_url" : "http://pbs.twimg.com/media/Ejerca-U0AEwQie.jpg",
        "id_str" : "1312706321167208449",
        "id" : "1312706321167208449",
        "media_url_https" : "https://pbs.twimg.com/media/Ejerca-U0AEwQie.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/cWqwwAjtKq"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "8",
    "id_str" : "1312706456244768769",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312706456244768769",
    "possibly_sensitive" : false,
    "created_at" : "Sun Oct 04 10:49:42 +0000 2020",
    "favorited" : false,
    "full_text" : "ん https://t.co/cWqwwAjtKq",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312706456244768769/photo/1",
        "indices" : [ "2", "25" ],
        "url" : "https://t.co/cWqwwAjtKq",
        "media_url" : "http://pbs.twimg.com/media/Ejerca-U0AEwQie.jpg",
        "id_str" : "1312706321167208449",
        "id" : "1312706321167208449",
        "media_url_https" : "https://pbs.twimg.com/media/Ejerca-U0AEwQie.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/cWqwwAjtKq"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "teddie",
        "screen_name" : "Teddie9Piscine1",
        "indices" : [ "3", "19" ],
        "id_str" : "1293010297926479872",
        "id" : "1293010297926479872"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "21", "37" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      }, {
        "name" : "Hinata",
        "screen_name" : "Hinata72279726",
        "indices" : [ "38", "53" ],
        "id_str" : "1228559135093821441",
        "id" : "1228559135093821441"
      }, {
        "name" : "イゴ（cv.リョウヘイ）",
        "screen_name" : "igo1500013",
        "indices" : [ "54", "65" ],
        "id_str" : "1020586855207600129",
        "id" : "1020586855207600129"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "77" ],
    "favorite_count" : "0",
    "id_str" : "1312680536142307328",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312680536142307328",
    "created_at" : "Sun Oct 04 09:06:42 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Teddie9Piscine1: @Kahorin_42Tokyo @Hinata72279726 @igo1500013 イエス、ユア・ハイネス",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1312667590314004480",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312667590314004480",
    "created_at" : "Sun Oct 04 08:15:16 +0000 2020",
    "favorited" : false,
    "full_text" : "明日にはキーキャップが届くそうなので、全裸待機",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Nuts_Piscine_9月🇪🇪",
        "screen_name" : "nuts_codie",
        "indices" : [ "0", "11" ],
        "id_str" : "1286128540748922881",
        "id" : "1286128540748922881"
      }, {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "12", "22" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "23", "39" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "56" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312667003363049472",
    "id_str" : "1312667478040821761",
    "in_reply_to_user_id" : "1286128540748922881",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312667478040821761",
    "in_reply_to_status_id" : "1312667003363049472",
    "created_at" : "Sun Oct 04 08:14:49 +0000 2020",
    "favorited" : false,
    "full_text" : "@nuts_codie @luna_yuta @Kahorin_42Tokyo 助太刀いたす✌︎('ω'✌︎ )",
    "lang" : "ja",
    "in_reply_to_screen_name" : "nuts_codie",
    "in_reply_to_user_id_str" : "1286128540748922881"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Nuts_Piscine_9月🇪🇪",
        "screen_name" : "nuts_codie",
        "indices" : [ "3", "14" ],
        "id_str" : "1286128540748922881",
        "id" : "1286128540748922881"
      }, {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "16", "26" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "27", "43" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "74" ],
    "favorite_count" : "0",
    "id_str" : "1312667383069253633",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312667383069253633",
    "created_at" : "Sun Oct 04 08:14:26 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @nuts_codie: @luna_yuta @Kahorin_42Tokyo なによっ！かっほばっかじゃなくて\nあたしのことも見てよ！！！",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "イゴ（cv.リョウヘイ）",
        "screen_name" : "igo1500013",
        "indices" : [ "17", "28" ],
        "id_str" : "1020586855207600129",
        "id" : "1020586855207600129"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "29", "45" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "57" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312667003191058432",
    "id_str" : "1312667258993307648",
    "in_reply_to_user_id" : "1293010297926479872",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312667258993307648",
    "in_reply_to_status_id" : "1312667003191058432",
    "created_at" : "Sun Oct 04 08:13:57 +0000 2020",
    "favorited" : false,
    "full_text" : "@Teddie9Piscine1 @igo1500013 @Kahorin_42Tokyo つまり全て((((((",
    "lang" : "ja",
    "in_reply_to_screen_name" : "gami3teddie",
    "in_reply_to_user_id_str" : "1293010297926479872"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "イゴ（cv.リョウヘイ）",
        "screen_name" : "igo1500013",
        "indices" : [ "0", "11" ],
        "id_str" : "1020586855207600129",
        "id" : "1020586855207600129"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "12", "28" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "34" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312665797181882368",
    "id_str" : "1312666029475069952",
    "in_reply_to_user_id" : "1020586855207600129",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312666029475069952",
    "in_reply_to_status_id" : "1312665797181882368",
    "created_at" : "Sun Oct 04 08:09:04 +0000 2020",
    "favorited" : false,
    "full_text" : "@igo1500013 @Kahorin_42Tokyo 上に同じく",
    "lang" : "ja",
    "in_reply_to_screen_name" : "igo1500013",
    "in_reply_to_user_id_str" : "1020586855207600129"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "11", "27" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "28", "44" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "48" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312663964593975296",
    "id_str" : "1312664816692064258",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312664816692064258",
    "in_reply_to_status_id" : "1312663964593975296",
    "created_at" : "Sun Oct 04 08:04:15 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @Kahorin_42Tokyo @Kahorin_42Tokyo だって",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "11", "27" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "34" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312664132739424256",
    "id_str" : "1312664754079428610",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312664754079428610",
    "in_reply_to_status_id" : "1312664132739424256",
    "created_at" : "Sun Oct 04 08:04:00 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @Kahorin_42Tokyo どっちなのw",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "39" ],
    "favorite_count" : "1",
    "id_str" : "1312663053784109058",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312663053784109058",
    "created_at" : "Sun Oct 04 07:57:14 +0000 2020",
    "favorited" : false,
    "full_text" : "彼ピッピに抵抗8.2Ω渡しても何それと言われそうだから、これから指輪作りに行く",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "3", "19" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "44" ],
    "favorite_count" : "0",
    "id_str" : "1312662381986607108",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312662381986607108",
    "created_at" : "Sun Oct 04 07:54:34 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Kahorin_42Tokyo: 首から下の毛、何のためにあるの？って思ってる人",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312661294038671360",
    "id_str" : "1312662329889157122",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312662329889157122",
    "in_reply_to_status_id" : "1312661294038671360",
    "created_at" : "Sun Oct 04 07:54:22 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo セグフォるの？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "ひよ@ 42_tokyo_piscine_9月",
        "screen_name" : "hiyohiyopower",
        "indices" : [ "3", "17" ],
        "id_str" : "1292736568453550083",
        "id" : "1292736568453550083"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "54" ],
    "favorite_count" : "0",
    "id_str" : "1312661106351988736",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312661106351988736",
    "created_at" : "Sun Oct 04 07:49:30 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @hiyohiyopower: エスカレーター歩く人が左側\npwd\n/kansai\n\n!= TOKYO",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "3", "19" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "45" ],
    "favorite_count" : "0",
    "id_str" : "1312660348315467778",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312660348315467778",
    "created_at" : "Sun Oct 04 07:46:29 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Kahorin_42Tokyo: 一緒に呑んでみたい人\nひなた、イゴさん、がみさん",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "29" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312659814489616386",
    "id_str" : "1312660120271159296",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312660120271159296",
    "in_reply_to_status_id" : "1312659814489616386",
    "created_at" : "Sun Oct 04 07:45:35 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo えちはぷにんぐを希望する",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "27" ],
    "favorite_count" : "0",
    "id_str" : "1312659785108529152",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312659785108529152",
    "created_at" : "Sun Oct 04 07:44:15 +0000 2020",
    "favorited" : false,
    "full_text" : "au光、Nuro、Softbank光、どれが良いのだ？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "32" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312658283551834114",
    "id_str" : "1312659224522940417",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312659224522940417",
    "in_reply_to_status_id" : "1312658283551834114",
    "created_at" : "Sun Oct 04 07:42:01 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo ✌︎('ω'✌︎ )ひなたと？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "たけひと",
        "screen_name" : "takehitopistol",
        "indices" : [ "0", "15" ],
        "id_str" : "1215191126103097344",
        "id" : "1215191126103097344"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "44" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312657541378183168",
    "id_str" : "1312659148476018690",
    "in_reply_to_user_id" : "1215191126103097344",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312659148476018690",
    "in_reply_to_status_id" : "1312657541378183168",
    "created_at" : "Sun Oct 04 07:41:43 +0000 2020",
    "favorited" : false,
    "full_text" : "@takehitopistol とはいえ、合格基準が公開されてない以上断言は不可能なのだ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "takehitopistol",
    "in_reply_to_user_id_str" : "1215191126103097344"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      }, {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "17", "27" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "44" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1312656078933389312",
    "id_str" : "1312658916526841856",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312658916526841856",
    "in_reply_to_status_id" : "1312656078933389312",
    "created_at" : "Sun Oct 04 07:40:48 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo @luna_yuta \nほら、ゆーたくんあいさつして？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ゆうきpiscine",
        "screen_name" : "yukiprogramming",
        "indices" : [ "3", "19" ],
        "id_str" : "1257274478989459456",
        "id" : "1257274478989459456"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/yukiprogramming/status/1312641053128683521/photo/1",
        "source_status_id" : "1312641053128683521",
        "indices" : [ "41", "64" ],
        "url" : "https://t.co/3A5PWdT0UN",
        "media_url" : "http://pbs.twimg.com/media/EjdwFDgU4AAxqOY.jpg",
        "id_str" : "1312641048544337920",
        "source_user_id" : "1257274478989459456",
        "id" : "1312641048544337920",
        "media_url_https" : "https://pbs.twimg.com/media/EjdwFDgU4AAxqOY.jpg",
        "source_user_id_str" : "1257274478989459456",
        "sizes" : {
          "large" : {
            "w" : "1440",
            "h" : "900",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "750",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "425",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1312641053128683521",
        "display_url" : "pic.twitter.com/3A5PWdT0UN"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "64" ],
    "favorite_count" : "0",
    "id_str" : "1312656172944551936",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312656172944551936",
    "possibly_sensitive" : false,
    "created_at" : "Sun Oct 04 07:29:54 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @yukiprogramming: Piscineロスを紛らわすために採用 https://t.co/3A5PWdT0UN",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/yukiprogramming/status/1312641053128683521/photo/1",
        "source_status_id" : "1312641053128683521",
        "indices" : [ "41", "64" ],
        "url" : "https://t.co/3A5PWdT0UN",
        "media_url" : "http://pbs.twimg.com/media/EjdwFDgU4AAxqOY.jpg",
        "id_str" : "1312641048544337920",
        "source_user_id" : "1257274478989459456",
        "id" : "1312641048544337920",
        "media_url_https" : "https://pbs.twimg.com/media/EjdwFDgU4AAxqOY.jpg",
        "source_user_id_str" : "1257274478989459456",
        "sizes" : {
          "large" : {
            "w" : "1440",
            "h" : "900",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "750",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "425",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1312641053128683521",
        "display_url" : "pic.twitter.com/3A5PWdT0UN"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312656111841935360/photo/1",
        "indices" : [ "124", "147" ],
        "url" : "https://t.co/Ha3XTc7b04",
        "media_url" : "http://pbs.twimg.com/media/Ejd9u_aVoAAwPkc.jpg",
        "id_str" : "1312656062651146240",
        "id" : "1312656062651146240",
        "media_url_https" : "https://pbs.twimg.com/media/Ejd9u_aVoAAwPkc.jpg",
        "sizes" : {
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/Ha3XTc7b04"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "147" ],
    "favorite_count" : "8",
    "id_str" : "1312656111841935360",
    "truncated" : false,
    "retweet_count" : "1",
    "id" : "1312656111841935360",
    "possibly_sensitive" : false,
    "created_at" : "Sun Oct 04 07:29:39 +0000 2020",
    "favorited" : false,
    "full_text" : "最近食べ過ぎだけど、またやってしまった\n\n小平うどん400g肉増し。結構太めのうどんで、食べ応え満点。生姜、うどん汁が無料なので、お肉ましても胃もたれしない。最小重量300gから。味玉天もつけてしまった…w\n是非一度食べていただきたい優しい味わい https://t.co/Ha3XTc7b04",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312656111841935360/photo/1",
        "indices" : [ "124", "147" ],
        "url" : "https://t.co/Ha3XTc7b04",
        "media_url" : "http://pbs.twimg.com/media/Ejd9u_aVoAAwPkc.jpg",
        "id_str" : "1312656062651146240",
        "id" : "1312656062651146240",
        "media_url_https" : "https://pbs.twimg.com/media/Ejd9u_aVoAAwPkc.jpg",
        "sizes" : {
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/Ha3XTc7b04"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312936197887410176/photo/1",
        "indices" : [ "51", "74" ],
        "url" : "https://t.co/iVP7bXeuD9",
        "media_url" : "http://pbs.twimg.com/media/Ejh8gSNVcAI452n.jpg",
        "id_str" : "1312936185463926786",
        "id" : "1312936185463926786",
        "media_url_https" : "https://pbs.twimg.com/media/Ejh8gSNVcAI452n.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1915",
            "h" : "1436",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/iVP7bXeuD9"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "74" ],
    "favorite_count" : "6",
    "id_str" : "1312936197887410176",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312936197887410176",
    "possibly_sensitive" : false,
    "created_at" : "Mon Oct 05 02:02:37 +0000 2020",
    "favorited" : false,
    "full_text" : "ああああああああああああああああああああああああきたああああああああああああああああああああああああ https://t.co/iVP7bXeuD9",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312936197887410176/photo/1",
        "indices" : [ "51", "74" ],
        "url" : "https://t.co/iVP7bXeuD9",
        "media_url" : "http://pbs.twimg.com/media/Ejh8gSNVcAI452n.jpg",
        "id_str" : "1312936185463926786",
        "id" : "1312936185463926786",
        "media_url_https" : "https://pbs.twimg.com/media/Ejh8gSNVcAI452n.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1915",
            "h" : "1436",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/iVP7bXeuD9"
      }, {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312936197887410176/photo/1",
        "indices" : [ "51", "74" ],
        "url" : "https://t.co/iVP7bXeuD9",
        "media_url" : "http://pbs.twimg.com/media/Ejh8gYYU8AA2HyV.jpg",
        "id_str" : "1312936187120644096",
        "id" : "1312936187120644096",
        "media_url_https" : "https://pbs.twimg.com/media/Ejh8gYYU8AA2HyV.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/iVP7bXeuD9"
      }, {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312936197887410176/photo/1",
        "indices" : [ "51", "74" ],
        "url" : "https://t.co/iVP7bXeuD9",
        "media_url" : "http://pbs.twimg.com/media/Ejh8gYYVkAAWyIo.jpg",
        "id_str" : "1312936187120685056",
        "id" : "1312936187120685056",
        "media_url_https" : "https://pbs.twimg.com/media/Ejh8gYYVkAAWyIo.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/iVP7bXeuD9"
      }, {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312936197887410176/photo/1",
        "indices" : [ "51", "74" ],
        "url" : "https://t.co/iVP7bXeuD9",
        "media_url" : "http://pbs.twimg.com/media/Ejh8gZSU4AAOScx.jpg",
        "id_str" : "1312936187363909632",
        "id" : "1312936187363909632",
        "media_url_https" : "https://pbs.twimg.com/media/Ejh8gZSU4AAOScx.jpg",
        "sizes" : {
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/iVP7bXeuD9"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "0",
    "id_str" : "1312930346443239424",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312930346443239424",
    "created_at" : "Mon Oct 05 01:39:22 +0000 2020",
    "favorited" : false,
    "full_text" : "体重が驚愕の増加率なので、本日から減量再開ですね",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "27" ],
    "favorite_count" : "4",
    "id_str" : "1312922695382695936",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312922695382695936",
    "created_at" : "Mon Oct 05 01:08:58 +0000 2020",
    "favorited" : false,
    "full_text" : "朝起きたらdisco開く癖ついてんぞどーにかならんのか",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "20" ],
    "favorite_count" : "0",
    "id_str" : "1312922162802511872",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312922162802511872",
    "created_at" : "Mon Oct 05 01:06:51 +0000 2020",
    "favorited" : false,
    "full_text" : "Oh研究室説明会16時からなのかOhhh",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "29" ],
    "favorite_count" : "1",
    "id_str" : "1312919203536498688",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312919203536498688",
    "created_at" : "Mon Oct 05 00:55:05 +0000 2020",
    "favorited" : false,
    "full_text" : "すげぇ、この時間に起きることに罪悪感感じてるじゃん恐ろしい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "えるエル",
        "screen_name" : "ImAI_Eruel",
        "indices" : [ "3", "14" ],
        "id_str" : "1007504472916951041",
        "id" : "1007504472916951041"
      } ],
      "urls" : [ {
        "url" : "https://t.co/1AmIhkExoB",
        "expanded_url" : "https://github.com/NVlabs/imaginaire",
        "display_url" : "github.com/NVlabs/imagina…",
        "indices" : [ "80", "103" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/liu_mingyu/status/1310690272355823617/photo/1",
        "source_status_id" : "1310690272355823617",
        "indices" : [ "105", "128" ],
        "url" : "https://t.co/X0B1ev7gKQ",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EjB_wYIUcAAAsQZ.jpg",
        "id_str" : "1310687960652607488",
        "source_user_id" : "4475055297",
        "id" : "1310687960652607488",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EjB_wYIUcAAAsQZ.jpg",
        "source_user_id_str" : "4475055297",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1280",
            "h" : "720",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1310690272355823617",
        "display_url" : "pic.twitter.com/X0B1ev7gKQ"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "128" ],
    "favorite_count" : "0",
    "id_str" : "1312768438960447489",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312768438960447489",
    "possibly_sensitive" : false,
    "created_at" : "Sun Oct 04 14:56:00 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @ImAI_Eruel: NVIDIAが、開発してきた様々なGAN系の手法をまとめたPyTorch実装のライブラリ\"Imaginaire\"を公開した模様\nhttps://t.co/1AmIhkExoB\n https://t.co/X0B1ev7gKQ",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/liu_mingyu/status/1310690272355823617/photo/1",
        "source_status_id" : "1310690272355823617",
        "indices" : [ "105", "128" ],
        "url" : "https://t.co/X0B1ev7gKQ",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/EjB_wYIUcAAAsQZ.jpg",
        "id_str" : "1310687960652607488",
        "video_info" : {
          "aspect_ratio" : [ "16", "9" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/EjB_wYIUcAAAsQZ.mp4"
          } ]
        },
        "source_user_id" : "4475055297",
        "id" : "1310687960652607488",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/EjB_wYIUcAAAsQZ.jpg",
        "source_user_id_str" : "4475055297",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1280",
            "h" : "720",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "source_status_id_str" : "1310690272355823617",
        "display_url" : "pic.twitter.com/X0B1ev7gKQ"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Erik",
        "screen_name" : "Sp00pyisthegoat",
        "indices" : [ "3", "19" ],
        "id_str" : "1152751753198280704",
        "id" : "1152751753198280704"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Sp00pyisthegoat/status/1310677429204258817/photo/1",
        "source_status_id" : "1310677429204258817",
        "indices" : [ "35", "58" ],
        "url" : "https://t.co/Vpbvhx7lH7",
        "media_url" : "http://pbs.twimg.com/media/EjB2LFqWoAI4rpJ.jpg",
        "id_str" : "1310677424435273730",
        "source_user_id" : "1152751753198280704",
        "id" : "1310677424435273730",
        "media_url_https" : "https://pbs.twimg.com/media/EjB2LFqWoAI4rpJ.jpg",
        "source_user_id_str" : "1152751753198280704",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "268",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "806",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "472",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1310677429204258817",
        "display_url" : "pic.twitter.com/Vpbvhx7lH7"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "58" ],
    "favorite_count" : "0",
    "id_str" : "1312760644140036098",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312760644140036098",
    "possibly_sensitive" : false,
    "created_at" : "Sun Oct 04 14:25:02 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Sp00pyisthegoat: New Keycaps!😈 https://t.co/Vpbvhx7lH7",
    "lang" : "en",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Sp00pyisthegoat/status/1310677429204258817/photo/1",
        "source_status_id" : "1310677429204258817",
        "indices" : [ "35", "58" ],
        "url" : "https://t.co/Vpbvhx7lH7",
        "media_url" : "http://pbs.twimg.com/media/EjB2LFqWoAI4rpJ.jpg",
        "id_str" : "1310677424435273730",
        "source_user_id" : "1152751753198280704",
        "id" : "1310677424435273730",
        "media_url_https" : "https://pbs.twimg.com/media/EjB2LFqWoAI4rpJ.jpg",
        "source_user_id_str" : "1152751753198280704",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "268",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "806",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "472",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1310677429204258817",
        "display_url" : "pic.twitter.com/Vpbvhx7lH7"
      }, {
        "expanded_url" : "https://twitter.com/Sp00pyisthegoat/status/1310677429204258817/photo/1",
        "source_status_id" : "1310677429204258817",
        "indices" : [ "35", "58" ],
        "url" : "https://t.co/Vpbvhx7lH7",
        "media_url" : "http://pbs.twimg.com/media/EjB2LFpXYAYZUHM.jpg",
        "id_str" : "1310677424431128582",
        "source_user_id" : "1152751753198280704",
        "id" : "1310677424431128582",
        "media_url_https" : "https://pbs.twimg.com/media/EjB2LFpXYAYZUHM.jpg",
        "source_user_id_str" : "1152751753198280704",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "2048",
            "h" : "718",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "421",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "238",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1310677429204258817",
        "display_url" : "pic.twitter.com/Vpbvhx7lH7"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/Ezi5M7dHt0",
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312322218320228352",
        "display_url" : "twitter.com/Hinata72279726…",
        "indices" : [ "30", "53" ]
      } ]
    },
    "display_text_range" : [ "0", "53" ],
    "favorite_count" : "3",
    "id_str" : "1312754536872697858",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312754536872697858",
    "possibly_sensitive" : false,
    "created_at" : "Sun Oct 04 14:00:46 +0000 2020",
    "favorited" : false,
    "full_text" : "と、いうことでひなたは男になりました。よろしくお願いします https://t.co/Ezi5M7dHt0",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "11", "21" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "54" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312727438846164994",
    "id_str" : "1312727657344233474",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312727657344233474",
    "in_reply_to_status_id" : "1312727438846164994",
    "created_at" : "Sun Oct 04 12:13:57 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @_unlimish 涙でそうなるシーンだけたくさん再生して、いろんな角度から堪能する",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "22" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312706456244768769",
    "id_str" : "1312727377533829120",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312727377533829120",
    "in_reply_to_status_id" : "1312706456244768769",
    "created_at" : "Sun Oct 04 12:12:50 +0000 2020",
    "favorited" : false,
    "full_text" : "右が私、左が彼女(?)左が私、右が彼氏(?)",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      }, {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "11", "21" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "43" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312725872953028608",
    "id_str" : "1312726801228021760",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312726801228021760",
    "in_reply_to_status_id" : "1312725872953028608",
    "created_at" : "Sun Oct 04 12:10:33 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish @luna_yuta ディスクに焼いてください私何度でも見れます",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "36" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1312725707231903745",
    "id_str" : "1312726655366959106",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312726655366959106",
    "in_reply_to_status_id" : "1312725707231903745",
    "created_at" : "Sun Oct 04 12:09:58 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish 俺の胸で泣けてきな雰囲気を醸し出したいと努力してる",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1312725665351790592",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312725665351790592",
    "created_at" : "Sun Oct 04 12:06:02 +0000 2020",
    "favorited" : false,
    "full_text" : "いやーauは早いけど、値段的にも速度的にもNuro圧倒的な気がしてきたな…\n\nちゃんと調べよ…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "11", "21" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312717682974711814",
    "id_str" : "1312725329627156480",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312725329627156480",
    "in_reply_to_status_id" : "1312717682974711814",
    "created_at" : "Sun Oct 04 12:04:42 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @_unlimish なんだこいつ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "34" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312716853211402240",
    "id_str" : "1312725301684658177",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312725301684658177",
    "in_reply_to_status_id" : "1312716853211402240",
    "created_at" : "Sun Oct 04 12:04:35 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish 泣かさないように頑張るけど多分無理なんだよなぁ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Nuts_Piscine_9月🇪🇪",
        "screen_name" : "nuts_codie",
        "indices" : [ "0", "11" ],
        "id_str" : "1286128540748922881",
        "id" : "1286128540748922881"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312722598669611010",
    "id_str" : "1312725216842313729",
    "in_reply_to_user_id" : "1286128540748922881",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312725216842313729",
    "in_reply_to_status_id" : "1312722598669611010",
    "created_at" : "Sun Oct 04 12:04:15 +0000 2020",
    "favorited" : false,
    "full_text" : "@nuts_codie うふ✌︎('ω'✌︎ )",
    "lang" : "ja",
    "in_reply_to_screen_name" : "nuts_codie",
    "in_reply_to_user_id_str" : "1286128540748922881"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hayasakaaaaaa",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "27" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1312715759169093632",
    "id_str" : "1312716612743516160",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312716612743516160",
    "in_reply_to_status_id" : "1312715759169093632",
    "created_at" : "Sun Oct 04 11:30:04 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c 下戸かぁ。代わりに飲んでやるぜ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "46" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312715674620432386",
    "id_str" : "1312716564324442112",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312716564324442112",
    "in_reply_to_status_id" : "1312715674620432386",
    "created_at" : "Sun Oct 04 11:29:52 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish 泣いてる女の子は百合要素が強くてえっちぃってえちぜんりょうまがゆってた",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312716192587554817/photo/1",
        "indices" : [ "143", "166" ],
        "url" : "https://t.co/trL59j5Yrn",
        "media_url" : "http://pbs.twimg.com/media/Eje0ZYNVkAAD7BR.jpg",
        "id_str" : "1312716164489908224",
        "id" : "1312716164489908224",
        "media_url_https" : "https://pbs.twimg.com/media/Eje0ZYNVkAAD7BR.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1024",
            "h" : "776",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1024",
            "h" : "776",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "515",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/trL59j5Yrn"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "166" ],
    "favorite_count" : "6",
    "id_str" : "1312716192587554817",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312716192587554817",
    "possibly_sensitive" : false,
    "created_at" : "Sun Oct 04 11:28:24 +0000 2020",
    "favorited" : false,
    "full_text" : "吉祥寺、大野亭と言う定食屋さんのポークカレー。定食のご飯とお味噌汁はお代わりし放題、カレーもこのサイズで¥888。\nアーケード街の地下のお店で隠れ家的な内装なのに、店内は大人気。頻繁にメニューが変わったり、日替わりで安くなるメニューがあるので是非一度食べてみて欲しい。ちなみに、あ字数 https://t.co/trL59j5Yrn",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1312716192587554817/photo/1",
        "indices" : [ "143", "166" ],
        "url" : "https://t.co/trL59j5Yrn",
        "media_url" : "http://pbs.twimg.com/media/Eje0ZYNVkAAD7BR.jpg",
        "id_str" : "1312716164489908224",
        "id" : "1312716164489908224",
        "media_url_https" : "https://pbs.twimg.com/media/Eje0ZYNVkAAD7BR.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1024",
            "h" : "776",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1024",
            "h" : "776",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "515",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/trL59j5Yrn"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "21" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312714873831260161",
    "id_str" : "1312715412597956608",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312715412597956608",
    "in_reply_to_status_id" : "1312714873831260161",
    "created_at" : "Sun Oct 04 11:25:18 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c バーテンダーでは？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hayasakaaaaaa",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312714217540050944",
    "id_str" : "1312714479944126464",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312714479944126464",
    "in_reply_to_status_id" : "1312714217540050944",
    "created_at" : "Sun Oct 04 11:21:35 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c グラスホッパー用に生クリームを頼むぜ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1312713740668731394",
    "id_str" : "1312714078746411008",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312714078746411008",
    "in_reply_to_status_id" : "1312713740668731394",
    "created_at" : "Sun Oct 04 11:20:00 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish 自分のことよくわかってんジャーン\nエェチィジャァァン",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "87" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312708007105495040",
    "id_str" : "1312710247467741189",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312710247467741189",
    "in_reply_to_status_id" : "1312708007105495040",
    "created_at" : "Sun Oct 04 11:04:46 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish 泣き顔のあんりみすごく俺得なんだよなぁ\n\nあんりみ、見えないとこですごくがんばっちゃうタイプだと思うから、無理しないでゆっくり休んだ方が良いと思うのだよ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "キツネ写真館＠キツネ飼養中",
        "screen_name" : "fox_info_net",
        "indices" : [ "3", "16" ],
        "id_str" : "2914738909",
        "id" : "2914738909"
      } ],
      "urls" : [ {
        "url" : "https://t.co/VwDQHimbMI",
        "expanded_url" : "http://fox-info.net/fox-photo/archives/22167",
        "display_url" : "fox-info.net/fox-photo/arch…",
        "indices" : [ "34", "57" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/fox_info_net/status/1312694797820334080/photo/1",
        "source_status_id" : "1312694797820334080",
        "indices" : [ "58", "81" ],
        "url" : "https://t.co/jrBNdtqV6H",
        "media_url" : "http://pbs.twimg.com/media/Ejeg9hoVcAYwAzO.jpg",
        "id_str" : "1312694795261800454",
        "source_user_id" : "2914738909",
        "id" : "1312694795261800454",
        "media_url_https" : "https://pbs.twimg.com/media/Ejeg9hoVcAYwAzO.jpg",
        "source_user_id_str" : "2914738909",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "900",
            "h" : "601",
            "resize" : "fit"
          },
          "large" : {
            "w" : "900",
            "h" : "601",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "454",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1312694797820334080",
        "display_url" : "pic.twitter.com/jrBNdtqV6H"
      } ],
      "hashtags" : [ {
        "text" : "蔵王キツネ村",
        "indices" : [ "26", "33" ]
      } ]
    },
    "display_text_range" : [ "0", "81" ],
    "favorite_count" : "0",
    "id_str" : "1312709217300566017",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312709217300566017",
    "possibly_sensitive" : false,
    "created_at" : "Sun Oct 04 11:00:41 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @fox_info_net: 落ち葉味🦊🦊\n #蔵王キツネ村 https://t.co/VwDQHimbMI https://t.co/jrBNdtqV6H",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/fox_info_net/status/1312694797820334080/photo/1",
        "source_status_id" : "1312694797820334080",
        "indices" : [ "58", "81" ],
        "url" : "https://t.co/jrBNdtqV6H",
        "media_url" : "http://pbs.twimg.com/media/Ejeg9hoVcAYwAzO.jpg",
        "id_str" : "1312694795261800454",
        "source_user_id" : "2914738909",
        "id" : "1312694795261800454",
        "media_url_https" : "https://pbs.twimg.com/media/Ejeg9hoVcAYwAzO.jpg",
        "source_user_id_str" : "2914738909",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "900",
            "h" : "601",
            "resize" : "fit"
          },
          "large" : {
            "w" : "900",
            "h" : "601",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "454",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1312694797820334080",
        "display_url" : "pic.twitter.com/jrBNdtqV6H"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "88" ],
    "favorite_count" : "1",
    "id_str" : "1312709050111467521",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312709050111467521",
    "created_at" : "Sun Oct 04 11:00:01 +0000 2020",
    "favorited" : false,
    "full_text" : "人より秀でることが全くないタイプなので、せめて精神と衣食住だけは確保すると人生に誓っている。\n\n今この瞬間太平洋のど真ん中にイカダひとつで落とされても生きて帰ると強く決めている",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313134678275051530",
    "id_str" : "1313135783411236865",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313135783411236865",
    "in_reply_to_status_id" : "1313134678275051530",
    "created_at" : "Mon Oct 05 15:15:42 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta マジモンのクソやろうじゃんwwww",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hayasakaaaaaa",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313131991882113024",
    "id_str" : "1313133485297528838",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313133485297528838",
    "in_reply_to_status_id" : "1313131991882113024",
    "created_at" : "Mon Oct 05 15:06:34 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c ネタにも真面目に返してくれる君が好き",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "80" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313129961406959617",
    "id_str" : "1313133384256770048",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313133384256770048",
    "in_reply_to_status_id" : "1313129961406959617",
    "created_at" : "Mon Oct 05 15:06:10 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta 私を置いて見に行ったことが罪(((\n\n下ネタのラインは規約違反して垢バンされるまでセーフ。現行では下ネタ垢バンはあんまないから永久不滅だね",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313129925201723392",
    "id_str" : "1313131262249328641",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313131262249328641",
    "in_reply_to_status_id" : "1313129925201723392",
    "created_at" : "Mon Oct 05 14:57:44 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c 文法間違えてるかしら？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "2",
    "id_str" : "1313130059545288704",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313130059545288704",
    "created_at" : "Mon Oct 05 14:52:57 +0000 2020",
    "favorited" : false,
    "full_text" : "もうjupyterがvscodeで動くなら勝ったも同然なのでイカさんやるか",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hayasakaaaaaa",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "88" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1313128307362164736",
    "id_str" : "1313129636226711557",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313129636226711557",
    "in_reply_to_status_id" : "1313128307362164736",
    "created_at" : "Mon Oct 05 14:51:16 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c garvage= []\nfor you in experience:\n       garvage.append(not C language you)",
    "lang" : "en",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Ponta @ piscine 9月参加予定",
        "screen_name" : "pontazm",
        "indices" : [ "3", "11" ],
        "id_str" : "2920199443",
        "id" : "2920199443"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "0",
    "id_str" : "1313129248773697538",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313129248773697538",
    "created_at" : "Mon Oct 05 14:49:44 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @pontazm: ピシン前ってなに考えて過ごしてたんやっけか、、、",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1312937879933345793",
    "id_str" : "1313129215902937090",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313129215902937090",
    "in_reply_to_status_id" : "1312937879933345793",
    "created_at" : "Mon Oct 05 14:49:36 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish されました_(:3」z)_",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "48" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313121157894209536",
    "id_str" : "1313129066640236544",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313129066640236544",
    "in_reply_to_status_id" : "1313121157894209536",
    "created_at" : "Mon Oct 05 14:49:00 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta まかしとけ、と言いたいがゆうたのツイに散々ネタバレ感出されたからゆるさない",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "33" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313113897398804480",
    "id_str" : "1313114643913564168",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313114643913564168",
    "in_reply_to_status_id" : "1313113897398804480",
    "created_at" : "Mon Oct 05 13:51:42 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta これを参考に私がIMAXで見れば無駄ではない",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "0",
    "id_str" : "1313105496912523266",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313105496912523266",
    "created_at" : "Mon Oct 05 13:15:21 +0000 2020",
    "favorited" : false,
    "full_text" : "カスタマイズって楽しいんだけど、すぐに時間すぎるから駄目よね",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "49" ],
    "favorite_count" : "0",
    "id_str" : "1313098102769737729",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313098102769737729",
    "created_at" : "Mon Oct 05 12:45:58 +0000 2020",
    "favorited" : false,
    "full_text" : "まじjupyterじゃ触る気にならないけどvscodeだと触る気10000万倍起きる(モンキー脳)",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "72" ],
    "favorite_count" : "1",
    "id_str" : "1313063207410429953",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313063207410429953",
    "created_at" : "Mon Oct 05 10:27:18 +0000 2020",
    "favorited" : false,
    "full_text" : "自分でブリーチすることになった…が、カラーとカットは2000円で済むらしいので楽しみ…\n\n人生初のブリーチで大失敗とかなかなかネタ性強そうで好き",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "52" ],
    "favorite_count" : "0",
    "id_str" : "1313057490527952896",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313057490527952896",
    "created_at" : "Mon Oct 05 10:04:35 +0000 2020",
    "favorited" : false,
    "full_text" : "jupyterがvscodeで動くの知らなかったよ…ずっとcolaboratoryか本家で動かしてたよ…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "2",
    "id_str" : "1313045432407257088",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313045432407257088",
    "created_at" : "Mon Oct 05 09:16:40 +0000 2020",
    "favorited" : false,
    "full_text" : "やっぱ何か作るより何か競う方がやる気になるのな…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "12" ],
    "favorite_count" : "2",
    "id_str" : "1313018461652574208",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313018461652574208",
    "created_at" : "Mon Oct 05 07:29:30 +0000 2020",
    "favorited" : false,
    "full_text" : "ポトフォリでもつくるかえ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "3",
    "id_str" : "1313017349444788225",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313017349444788225",
    "created_at" : "Mon Oct 05 07:25:05 +0000 2020",
    "favorited" : false,
    "full_text" : "何か作りたいけど何作りたいかわからん",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "60" ],
    "favorite_count" : "2",
    "id_str" : "1313015935347773442",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313015935347773442",
    "created_at" : "Mon Oct 05 07:19:28 +0000 2020",
    "favorited" : false,
    "full_text" : "研究室説明会が完全リモートなのでゆっくりしながら聞ける\n\n情報系研究室が多いかと思いきや、意外と物理、数学系研究室が多い",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313007520772882433",
    "id_str" : "1313015666933342208",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313015666933342208",
    "in_reply_to_status_id" : "1313007520772882433",
    "created_at" : "Mon Oct 05 07:18:24 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish それは確かに通るけどもwww",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "38" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313004497094860800",
    "id_str" : "1313006002464124928",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313006002464124928",
    "in_reply_to_status_id" : "1313004497094860800",
    "created_at" : "Mon Oct 05 06:40:00 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish はいってるんだよなぁ…なんでできないかよくわかんない…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "77" ],
    "favorite_count" : "1",
    "id_str" : "1313004290332450816",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313004290332450816",
    "created_at" : "Mon Oct 05 06:33:11 +0000 2020",
    "favorited" : false,
    "full_text" : "ターミナルがcmdならなんとかデバッグできるようになった。逆に言うとcmdじゃないとvscode でデバッグできない問題。shell使いたいんだけれども？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/kq1jOX4B3g",
        "expanded_url" : "https://twitter.com/TDR_PR/status/1312941012923211776",
        "display_url" : "twitter.com/TDR_PR/status/…",
        "indices" : [ "57", "80" ]
      } ]
    },
    "display_text_range" : [ "0", "80" ],
    "favorite_count" : "1",
    "id_str" : "1312959699952701440",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312959699952701440",
    "possibly_sensitive" : false,
    "created_at" : "Mon Oct 05 03:36:00 +0000 2020",
    "favorited" : false,
    "full_text" : "ランドの初期の作品に比べて、今回は映像からもアニマトロニクスの技術が向上したことが窺えるので皆さん是非動画をば… https://t.co/kq1jOX4B3g",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "東京ディズニーリゾートPR【公式】",
        "screen_name" : "TDR_PR",
        "indices" : [ "3", "10" ],
        "id_str" : "346393965",
        "id" : "346393965"
      } ],
      "urls" : [ {
        "url" : "https://t.co/97PJAgcNhU",
        "expanded_url" : "http://tdr.eng.mg/58e51",
        "display_url" : "tdr.eng.mg/58e51",
        "indices" : [ "114", "137" ]
      } ]
    },
    "display_text_range" : [ "0", "138" ],
    "favorite_count" : "0",
    "id_str" : "1312959465017102337",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312959465017102337",
    "possibly_sensitive" : false,
    "created_at" : "Mon Oct 05 03:35:04 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @TDR_PR: 【今日の東京ディズニーランド2020 ～「美女と野獣“魔法のものがたり”」編②～】\n今日は、「美女と野獣“魔法のものがたり”」の見どころをイマジニアたちが語る動画の続編をお届けします。\nこちらから♪＞＞ https://t.co/97PJAgcNhU…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "21" ],
    "favorite_count" : "0",
    "id_str" : "1312958951051329536",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312958951051329536",
    "created_at" : "Mon Oct 05 03:33:02 +0000 2020",
    "favorited" : false,
    "full_text" : "工房空いてたら今日にでも駆け出してるのに…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "おねすとちゃんねる@42Tokyo.9月Piscine生",
        "screen_name" : "honestchanel",
        "indices" : [ "3", "16" ],
        "id_str" : "855651284006785024",
        "id" : "855651284006785024"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1312957882975965184",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1312957882975965184",
    "created_at" : "Mon Oct 05 03:28:47 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @honestchanel: 夢の中でC言語書いてた。\nもう病気だ。\nΣ(ﾟдﾟlll)",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "34" ],
    "favorite_count" : "0",
    "id_str" : "1313461132573642752",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313461132573642752",
    "created_at" : "Tue Oct 06 12:48:31 +0000 2020",
    "favorited" : false,
    "full_text" : "母親にヨガマット取られたのでデブは大人しく涅槃像のフリすることにした",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "38" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1313445315416997888",
    "id_str" : "1313460738988466176",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313460738988466176",
    "in_reply_to_status_id" : "1313445315416997888",
    "created_at" : "Tue Oct 06 12:46:57 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c 白くて細い指\n私指げ生えてるんでそういうの羨ましいわ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "たくわん",
        "screen_name" : "__takuwan__",
        "indices" : [ "3", "15" ],
        "id_str" : "1186404679",
        "id" : "1186404679"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1313441825152135174",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313441825152135174",
    "created_at" : "Tue Oct 06 11:31:48 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @__takuwan__: エンジニアとして3年以上働いて次にステップアップしたいと思ったときに学ぶコスパいいモノに\n\n- SQL\n- CSS\n- vim\n\nがある。特にSQLとCSSはマジおすすめ。できないエンジニア多数なので市場価値が間違いなく上がる。\nあと、女の子か…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "22" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313421319426330624",
    "id_str" : "1313441709586481153",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313441709586481153",
    "in_reply_to_status_id" : "1313421319426330624",
    "created_at" : "Tue Oct 06 11:31:20 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c エッチな手をしている",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "82" ],
    "favorite_count" : "0",
    "id_str" : "1313428347993509888",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313428347993509888",
    "created_at" : "Tue Oct 06 10:38:15 +0000 2020",
    "favorited" : false,
    "full_text" : "ここらへんのTwitter界隈はうるささで言えば落ちるんだけど\n\n42の基準にありそうな「コミュ力的なさむしんぐ」は合格基準のメーターぶっと壊して受かってんだよなぁ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313426064165617671",
    "id_str" : "1313426504475238401",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313426504475238401",
    "in_reply_to_status_id" : "1313426064165617671",
    "created_at" : "Tue Oct 06 10:30:55 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish 8月までの期間店@原宿でした",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313424410867449857",
    "id_str" : "1313425536710967296",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313425536710967296",
    "in_reply_to_status_id" : "1313424410867449857",
    "created_at" : "Tue Oct 06 10:27:04 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish しゅっき✌︎('ω'✌︎ )",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1313419470409400320/photo/1",
        "indices" : [ "11", "34" ],
        "url" : "https://t.co/BzotT7DR47",
        "media_url" : "http://pbs.twimg.com/media/Ejo0BCMU0AEu0Cx.jpg",
        "id_str" : "1313419433705000961",
        "id" : "1313419433705000961",
        "media_url_https" : "https://pbs.twimg.com/media/Ejo0BCMU0AEu0Cx.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/BzotT7DR47"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "34" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313351219201470464",
    "id_str" : "1313419470409400320",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313419470409400320",
    "in_reply_to_status_id" : "1313351219201470464",
    "possibly_sensitive" : false,
    "created_at" : "Tue Oct 06 10:02:58 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish https://t.co/BzotT7DR47",
    "lang" : "und",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1313419470409400320/photo/1",
        "indices" : [ "11", "34" ],
        "url" : "https://t.co/BzotT7DR47",
        "media_url" : "http://pbs.twimg.com/media/Ejo0BCMU0AEu0Cx.jpg",
        "id_str" : "1313419433705000961",
        "id" : "1313419433705000961",
        "media_url_https" : "https://pbs.twimg.com/media/Ejo0BCMU0AEu0Cx.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/BzotT7DR47"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1313415193255272448/photo/1",
        "indices" : [ "3", "26" ],
        "url" : "https://t.co/DsUdWrIo1y",
        "media_url" : "http://pbs.twimg.com/media/EjowJsUU0AAHOKM.jpg",
        "id_str" : "1313415184405286912",
        "id" : "1313415184405286912",
        "media_url_https" : "https://pbs.twimg.com/media/EjowJsUU0AAHOKM.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "576",
            "h" : "1024",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "576",
            "h" : "1024",
            "resize" : "fit"
          },
          "small" : {
            "w" : "383",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/DsUdWrIo1y"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "26" ],
    "favorite_count" : "2",
    "id_str" : "1313415193255272448",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313415193255272448",
    "possibly_sensitive" : false,
    "created_at" : "Tue Oct 06 09:45:58 +0000 2020",
    "favorited" : false,
    "full_text" : "おー https://t.co/DsUdWrIo1y",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1313415193255272448/photo/1",
        "indices" : [ "3", "26" ],
        "url" : "https://t.co/DsUdWrIo1y",
        "media_url" : "http://pbs.twimg.com/media/EjowJsUU0AAHOKM.jpg",
        "id_str" : "1313415184405286912",
        "id" : "1313415184405286912",
        "media_url_https" : "https://pbs.twimg.com/media/EjowJsUU0AAHOKM.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "576",
            "h" : "1024",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "576",
            "h" : "1024",
            "resize" : "fit"
          },
          "small" : {
            "w" : "383",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/DsUdWrIo1y"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "75" ],
    "favorite_count" : "3",
    "id_str" : "1313408701433167872",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313408701433167872",
    "created_at" : "Tue Oct 06 09:20:11 +0000 2020",
    "favorited" : false,
    "full_text" : "この思想やばいとは思うんだけど、人と関わるのが面倒になってきた…\n\nいや、もちろん頭の中では嬉しい。嬉しいんだけど、どっかで時間を気にする自分がいる…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Nuts_Piscine_9月🇪🇪",
        "screen_name" : "nuts_codie",
        "indices" : [ "0", "11" ],
        "id_str" : "1286128540748922881",
        "id" : "1286128540748922881"
      }, {
        "name" : "maitake55",
        "screen_name" : "maitake55",
        "indices" : [ "12", "22" ],
        "id_str" : "83568223",
        "id" : "83568223"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "32" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1313349723961487360",
    "id_str" : "1313408363196108801",
    "in_reply_to_user_id" : "1286128540748922881",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313408363196108801",
    "in_reply_to_status_id" : "1313349723961487360",
    "created_at" : "Tue Oct 06 09:18:50 +0000 2020",
    "favorited" : false,
    "full_text" : "@nuts_codie @maitake55 そういうとこ好きw",
    "lang" : "ja",
    "in_reply_to_screen_name" : "nuts_codie",
    "in_reply_to_user_id_str" : "1286128540748922881"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1313312849255563264",
    "id_str" : "1313313021804965889",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313313021804965889",
    "in_reply_to_status_id" : "1313312849255563264",
    "created_at" : "Tue Oct 06 02:59:59 +0000 2020",
    "favorited" : false,
    "full_text" : "え、簡体字と平仮名併用するとフォント変なるの？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "26" ],
    "favorite_count" : "0",
    "id_str" : "1313312849255563264",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313312849255563264",
    "created_at" : "Tue Oct 06 02:59:18 +0000 2020",
    "favorited" : false,
    "full_text" : "汉语は本科の工学系授業と被るら今期取れねぇんだよなぁ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "14" ],
    "favorite_count" : "0",
    "id_str" : "1313312680103436288",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313312680103436288",
    "created_at" : "Tue Oct 06 02:58:37 +0000 2020",
    "favorited" : false,
    "full_text" : "仏語だけは授業あるんだよなぁ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "21" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313139845494050816",
    "id_str" : "1313312246269841411",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313312246269841411",
    "in_reply_to_status_id" : "1313139845494050816",
    "created_at" : "Tue Oct 06 02:56:54 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta ✌︎('ω'✌︎ )",
    "lang" : "und",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "maitake55",
        "screen_name" : "maitake55",
        "indices" : [ "3", "13" ],
        "id_str" : "83568223",
        "id" : "83568223"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "84" ],
    "favorite_count" : "0",
    "id_str" : "1313311253306122241",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313311253306122241",
    "created_at" : "Tue Oct 06 02:52:57 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @maitake55: この時期になると、「日本のキンモクセイはオスしかいないので実がつかないんだよ」というウンチクを120回くらい言ってたの、さすがにもうやめた",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "stfnm",
        "screen_name" : "stfnm_",
        "indices" : [ "3", "10" ],
        "id_str" : "1086511055470190593",
        "id" : "1086511055470190593"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/stfnm_/status/1312261342728912896/photo/1",
        "source_status_id" : "1312261342728912896",
        "indices" : [ "46", "69" ],
        "url" : "https://t.co/jJAfDVOYl7",
        "media_url" : "http://pbs.twimg.com/media/EjYWvE4VkAAZhYB.jpg",
        "id_str" : "1312261339444776960",
        "source_user_id" : "1086511055470190593",
        "id" : "1312261339444776960",
        "media_url_https" : "https://pbs.twimg.com/media/EjYWvE4VkAAZhYB.jpg",
        "source_user_id_str" : "1086511055470190593",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "750",
            "h" : "475",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "750",
            "h" : "475",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "431",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1312261342728912896",
        "display_url" : "pic.twitter.com/jJAfDVOYl7"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "69" ],
    "favorite_count" : "0",
    "id_str" : "1313296309470732288",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313296309470732288",
    "possibly_sensitive" : false,
    "created_at" : "Tue Oct 06 01:53:34 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @stfnm_: ディープフェイク事件関連のサイト見てたら急に俺の事disってきた… https://t.co/jJAfDVOYl7",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/stfnm_/status/1312261342728912896/photo/1",
        "source_status_id" : "1312261342728912896",
        "indices" : [ "46", "69" ],
        "url" : "https://t.co/jJAfDVOYl7",
        "media_url" : "http://pbs.twimg.com/media/EjYWvE4VkAAZhYB.jpg",
        "id_str" : "1312261339444776960",
        "source_user_id" : "1086511055470190593",
        "id" : "1312261339444776960",
        "media_url_https" : "https://pbs.twimg.com/media/EjYWvE4VkAAZhYB.jpg",
        "source_user_id_str" : "1086511055470190593",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "750",
            "h" : "475",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "750",
            "h" : "475",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "431",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1312261342728912896",
        "display_url" : "pic.twitter.com/jJAfDVOYl7"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "unistd",
        "indices" : [ "14", "21" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "KOTO",
        "screen_name" : "koto_science",
        "indices" : [ "0", "13" ],
        "id_str" : "984367814889779200",
        "id" : "984367814889779200"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313258229602807808",
    "id_str" : "1313295732552552448",
    "in_reply_to_user_id" : "984367814889779200",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313295732552552448",
    "in_reply_to_status_id" : "1313258229602807808",
    "created_at" : "Tue Oct 06 01:51:17 +0000 2020",
    "favorited" : false,
    "full_text" : "@koto_science #unistd.h",
    "lang" : "und",
    "in_reply_to_screen_name" : "koto_science",
    "in_reply_to_user_id_str" : "984367814889779200"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "41" ],
    "favorite_count" : "1",
    "id_str" : "1313281822906671104",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313281822906671104",
    "created_at" : "Tue Oct 06 00:56:00 +0000 2020",
    "favorited" : false,
    "full_text" : "pythonでwhile文を回す方法を知らないことに今気がついた\n\nまずいなこれは",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "2",
    "id_str" : "1313280979197292545",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313280979197292545",
    "created_at" : "Tue Oct 06 00:52:39 +0000 2020",
    "favorited" : false,
    "full_text" : "vueとjsonやっておけば何か役に立つかな？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "27" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313274065474342913",
    "id_str" : "1313280678927114240",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313280678927114240",
    "in_reply_to_status_id" : "1313274065474342913",
    "created_at" : "Tue Oct 06 00:51:28 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish iostreamにする？←C++",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313138842061344768",
    "id_str" : "1313139270555586560",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313139270555586560",
    "in_reply_to_status_id" : "1313138842061344768",
    "created_at" : "Mon Oct 05 15:29:33 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta oh\nエッチな女子校生…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "27" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313136391241388034",
    "id_str" : "1313137103786500097",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313137103786500097",
    "in_reply_to_status_id" : "1313136391241388034",
    "created_at" : "Mon Oct 05 15:20:57 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta エッチな女子高生だったと推測する",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "49" ],
    "favorite_count" : "0",
    "id_str" : "1313136978452307968",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313136978452307968",
    "created_at" : "Mon Oct 05 15:20:27 +0000 2020",
    "favorited" : false,
    "full_text" : "研究室見学会に遊舎工房の営業日の休みを飲み込まれてしまったので\n\n金曜までキーボードの自作はお預け",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "11" ],
    "favorite_count" : "1",
    "id_str" : "1313739034674380800",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313739034674380800",
    "created_at" : "Wed Oct 07 07:12:48 +0000 2020",
    "favorited" : false,
    "full_text" : "AR/VR系研究室な…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://www.nintendo.com/countryselector\" rel=\"nofollow\">Nintendo Switch Share</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1313718118565376000/photo/1",
        "indices" : [ "26", "49" ],
        "url" : "https://t.co/W0wJhMEufg",
        "media_url" : "http://pbs.twimg.com/media/EjtDqreUcAAHxyv.jpg",
        "id_str" : "1313718116812091392",
        "id" : "1313718116812091392",
        "media_url_https" : "https://pbs.twimg.com/media/EjtDqreUcAAHxyv.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1280",
            "h" : "720",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/W0wJhMEufg"
      } ],
      "hashtags" : [ {
        "text" : "NintendoSwitch",
        "indices" : [ "0", "15" ]
      } ]
    },
    "display_text_range" : [ "0", "49" ],
    "favorite_count" : "1",
    "id_str" : "1313718118565376000",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313718118565376000",
    "possibly_sensitive" : false,
    "created_at" : "Wed Oct 07 05:49:41 +0000 2020",
    "favorited" : false,
    "full_text" : "#NintendoSwitch\nあのころのおもひで https://t.co/W0wJhMEufg",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1313718118565376000/photo/1",
        "indices" : [ "26", "49" ],
        "url" : "https://t.co/W0wJhMEufg",
        "media_url" : "http://pbs.twimg.com/media/EjtDqreUcAAHxyv.jpg",
        "id_str" : "1313718116812091392",
        "id" : "1313718116812091392",
        "media_url_https" : "https://pbs.twimg.com/media/EjtDqreUcAAHxyv.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1280",
            "h" : "720",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/W0wJhMEufg"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "三崎律日＠「奇書の世界史」発売中",
        "screen_name" : "i_kaseki",
        "indices" : [ "3", "12" ],
        "id_str" : "203533545",
        "id" : "203533545"
      } ],
      "urls" : [ {
        "url" : "https://t.co/imV0P1PSeC",
        "expanded_url" : "https://twitter.com/space_dandy/status/409665041680433153",
        "display_url" : "twitter.com/space_dandy/st…",
        "indices" : [ "70", "93" ]
      } ]
    },
    "display_text_range" : [ "0", "93" ],
    "favorite_count" : "0",
    "id_str" : "1313715294834057217",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313715294834057217",
    "possibly_sensitive" : false,
    "created_at" : "Wed Oct 07 05:38:28 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @i_kaseki: 新作アニゴジの脚本を円城塔氏が担当されるとの事で、ここで氏による「スペース☆ダンディ」の脚本を見てみましょう。 https://t.co/imV0P1PSeC",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/tdzaItEXOC",
        "expanded_url" : "https://qiita.com/hinata/items/08861bd1f319f5c37991",
        "display_url" : "qiita.com/hinata/items/0…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "67" ],
    "favorite_count" : "6",
    "id_str" : "1313708137333968896",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313708137333968896",
    "possibly_sensitive" : false,
    "created_at" : "Wed Oct 07 05:10:02 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/tdzaItEXOC\n微妙な記事書いた。そもそもqiita見てるやつって初学者すくねぇよなとか言うな((((",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "えふ@42Tokyo 9月Piscine生",
        "screen_name" : "FPr4242",
        "indices" : [ "0", "8" ],
        "id_str" : "1251179846392143873",
        "id" : "1251179846392143873"
      }, {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "9", "19" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313679426970771457",
    "id_str" : "1313680481548791809",
    "in_reply_to_user_id" : "1251179846392143873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313680481548791809",
    "in_reply_to_status_id" : "1313679426970771457",
    "created_at" : "Wed Oct 07 03:20:08 +0000 2020",
    "favorited" : false,
    "full_text" : "@FPr4242 @luna_yuta あれを見てtweetやめたのかと…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "FPr4242",
    "in_reply_to_user_id_str" : "1251179846392143873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "えふ@42Tokyo 9月Piscine生",
        "screen_name" : "FPr4242",
        "indices" : [ "0", "8" ],
        "id_str" : "1251179846392143873",
        "id" : "1251179846392143873"
      }, {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "9", "19" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "35" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313677611424337920",
    "id_str" : "1313678040585572354",
    "in_reply_to_user_id" : "1251179846392143873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313678040585572354",
    "in_reply_to_status_id" : "1313677611424337920",
    "created_at" : "Wed Oct 07 03:10:26 +0000 2020",
    "favorited" : false,
    "full_text" : "@FPr4242 @luna_yuta 生きてるなら大丈夫だわwwww",
    "lang" : "ja",
    "in_reply_to_screen_name" : "FPr4242",
    "in_reply_to_user_id_str" : "1251179846392143873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1313677884414857216/photo/1",
        "indices" : [ "34", "57" ],
        "url" : "https://t.co/oz8hfdj4X2",
        "media_url" : "http://pbs.twimg.com/media/Ejse-smVcAA2q7H.jpg",
        "id_str" : "1313677778781302784",
        "id" : "1313677778781302784",
        "media_url_https" : "https://pbs.twimg.com/media/Ejse-smVcAA2q7H.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1064",
            "h" : "1040",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "665",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1064",
            "h" : "1040",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/oz8hfdj4X2"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "57" ],
    "favorite_count" : "0",
    "id_str" : "1313677884414857216",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313677884414857216",
    "possibly_sensitive" : false,
    "created_at" : "Wed Oct 07 03:09:49 +0000 2020",
    "favorited" : false,
    "full_text" : "notebookめんどいな。セルごとのデバッグのくせに重すぎないか https://t.co/oz8hfdj4X2",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1313677884414857216/photo/1",
        "indices" : [ "34", "57" ],
        "url" : "https://t.co/oz8hfdj4X2",
        "media_url" : "http://pbs.twimg.com/media/Ejse-smVcAA2q7H.jpg",
        "id_str" : "1313677778781302784",
        "id" : "1313677778781302784",
        "media_url_https" : "https://pbs.twimg.com/media/Ejse-smVcAA2q7H.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1064",
            "h" : "1040",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "665",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1064",
            "h" : "1040",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/oz8hfdj4X2"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      }, {
        "name" : "えふ@42Tokyo 9月Piscine生",
        "screen_name" : "FPr4242",
        "indices" : [ "11", "19" ],
        "id_str" : "1251179846392143873",
        "id" : "1251179846392143873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "21" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313670530357063680",
    "id_str" : "1313671299495985152",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313671299495985152",
    "in_reply_to_status_id" : "1313670530357063680",
    "created_at" : "Wed Oct 07 02:43:39 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta @FPr4242 ↑",
    "lang" : "und",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "14" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313670530357063680",
    "id_str" : "1313671181917061120",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313671181917061120",
    "in_reply_to_status_id" : "1313670530357063680",
    "created_at" : "Wed Oct 07 02:43:11 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta 大草原",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "みいたん☆グラビアモデル【乃愛】の母",
        "screen_name" : "cutemiia0414",
        "indices" : [ "3", "16" ],
        "id_str" : "3323922308",
        "id" : "3323922308"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1313655358049509376",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313655358049509376",
    "created_at" : "Wed Oct 07 01:40:18 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @cutemiia0414: 11月1日には\n主催イベントがあることと\n刺青メインな♥\nグラビアの単体DVD撮影を控えておりますので…\n\nそりゃあもう…はい🤓\nハイペースに刺青進めております。\n\nmy鳳凰ちゃん♥も早く開眼させてあげたいですし♥\n\n娘（乃愛）に負けじと\nマ…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "PG_MANA＠帰省中",
        "screen_name" : "PG_MANA_",
        "indices" : [ "3", "12" ],
        "id_str" : "2875059632",
        "id" : "2875059632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "117" ],
    "favorite_count" : "0",
    "id_str" : "1313655114566168576",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313655114566168576",
    "created_at" : "Wed Oct 07 01:39:20 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @PG_MANA_: GitHubのメインブランチがmainになったことで、「masterブランチにほとんどマージされずdevelopで永遠に開発されてる状態」を「idle master、略してアイマス」と呼べなくなるのか...",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "11" ],
    "favorite_count" : "1",
    "id_str" : "1313652277949853696",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313652277949853696",
    "created_at" : "Wed Oct 07 01:28:04 +0000 2020",
    "favorited" : false,
    "full_text" : "あれ？えふどこいった？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "きくらげ",
        "screen_name" : "Suolan_",
        "indices" : [ "3", "11" ],
        "id_str" : "262996409",
        "id" : "262996409"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Suolan_/status/1313638009548410880/photo/1",
        "source_status_id" : "1313638009548410880",
        "indices" : [ "22", "45" ],
        "url" : "https://t.co/B1Io9kUIM1",
        "media_url" : "http://pbs.twimg.com/media/Ejr6I3GUwAACt85.png",
        "id_str" : "1313637271468294144",
        "source_user_id" : "262996409",
        "id" : "1313637271468294144",
        "media_url_https" : "https://pbs.twimg.com/media/Ejr6I3GUwAACt85.png",
        "source_user_id_str" : "262996409",
        "sizes" : {
          "small" : {
            "w" : "600",
            "h" : "480",
            "resize" : "fit"
          },
          "large" : {
            "w" : "600",
            "h" : "480",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "600",
            "h" : "480",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1313638009548410880",
        "display_url" : "pic.twitter.com/B1Io9kUIM1"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "45" ],
    "favorite_count" : "0",
    "id_str" : "1313651764214657025",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313651764214657025",
    "possibly_sensitive" : false,
    "created_at" : "Wed Oct 07 01:26:01 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Suolan_: 個人的お気に入り https://t.co/B1Io9kUIM1",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Suolan_/status/1313638009548410880/photo/1",
        "source_status_id" : "1313638009548410880",
        "indices" : [ "22", "45" ],
        "url" : "https://t.co/B1Io9kUIM1",
        "media_url" : "http://pbs.twimg.com/media/Ejr6I3GUwAACt85.png",
        "id_str" : "1313637271468294144",
        "source_user_id" : "262996409",
        "id" : "1313637271468294144",
        "media_url_https" : "https://pbs.twimg.com/media/Ejr6I3GUwAACt85.png",
        "source_user_id_str" : "262996409",
        "sizes" : {
          "small" : {
            "w" : "600",
            "h" : "480",
            "resize" : "fit"
          },
          "large" : {
            "w" : "600",
            "h" : "480",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "600",
            "h" : "480",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1313638009548410880",
        "display_url" : "pic.twitter.com/B1Io9kUIM1"
      }, {
        "expanded_url" : "https://twitter.com/Suolan_/status/1313638009548410880/photo/1",
        "source_status_id" : "1313638009548410880",
        "indices" : [ "22", "45" ],
        "url" : "https://t.co/B1Io9kUIM1",
        "media_url" : "http://pbs.twimg.com/media/Ejr6Ja8VkAAUqTK.png",
        "id_str" : "1313637281090080768",
        "source_user_id" : "262996409",
        "id" : "1313637281090080768",
        "media_url_https" : "https://pbs.twimg.com/media/Ejr6Ja8VkAAUqTK.png",
        "source_user_id_str" : "262996409",
        "sizes" : {
          "large" : {
            "w" : "600",
            "h" : "540",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "600",
            "h" : "540",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "600",
            "h" : "540",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1313638009548410880",
        "display_url" : "pic.twitter.com/B1Io9kUIM1"
      }, {
        "expanded_url" : "https://twitter.com/Suolan_/status/1313638009548410880/photo/1",
        "source_status_id" : "1313638009548410880",
        "indices" : [ "22", "45" ],
        "url" : "https://t.co/B1Io9kUIM1",
        "media_url" : "http://pbs.twimg.com/media/Ejr6LhzU4AAfCGR.png",
        "id_str" : "1313637317291073536",
        "source_user_id" : "262996409",
        "id" : "1313637317291073536",
        "media_url_https" : "https://pbs.twimg.com/media/Ejr6LhzU4AAfCGR.png",
        "source_user_id_str" : "262996409",
        "sizes" : {
          "large" : {
            "w" : "600",
            "h" : "480",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "600",
            "h" : "480",
            "resize" : "fit"
          },
          "small" : {
            "w" : "600",
            "h" : "480",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1313638009548410880",
        "display_url" : "pic.twitter.com/B1Io9kUIM1"
      }, {
        "expanded_url" : "https://twitter.com/Suolan_/status/1313638009548410880/photo/1",
        "source_status_id" : "1313638009548410880",
        "indices" : [ "22", "45" ],
        "url" : "https://t.co/B1Io9kUIM1",
        "media_url" : "http://pbs.twimg.com/media/Ejr6UqRUcAc0r7f.png",
        "id_str" : "1313637474183180295",
        "source_user_id" : "262996409",
        "id" : "1313637474183180295",
        "media_url_https" : "https://pbs.twimg.com/media/Ejr6UqRUcAc0r7f.png",
        "source_user_id_str" : "262996409",
        "sizes" : {
          "medium" : {
            "w" : "600",
            "h" : "510",
            "resize" : "fit"
          },
          "large" : {
            "w" : "600",
            "h" : "510",
            "resize" : "fit"
          },
          "small" : {
            "w" : "600",
            "h" : "510",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1313638009548410880",
        "display_url" : "pic.twitter.com/B1Io9kUIM1"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/xcGfrFuuN7",
        "expanded_url" : "https://twitter.com/famitsu/status/1313607505432383488",
        "display_url" : "twitter.com/famitsu/status…",
        "indices" : [ "18", "41" ]
      } ]
    },
    "display_text_range" : [ "0", "41" ],
    "favorite_count" : "0",
    "id_str" : "1313650702128803840",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313650702128803840",
    "possibly_sensitive" : false,
    "created_at" : "Wed Oct 07 01:21:48 +0000 2020",
    "favorited" : false,
    "full_text" : "これでSEの第二世代やすくなるな？ https://t.co/xcGfrFuuN7",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "3", "13" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "36" ],
    "favorite_count" : "0",
    "id_str" : "1313649980230430720",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313649980230430720",
    "created_at" : "Wed Oct 07 01:18:56 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @_unlimish: しかも、\\0ってテープのためにできたの？！",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "松井 諒祐",
        "screen_name" : "MatsuiRyosuke",
        "indices" : [ "3", "17" ],
        "id_str" : "440102503",
        "id" : "440102503"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/MatsuiRyosuke/status/1313104979893252096/video/1",
        "source_status_id" : "1313104979893252096",
        "indices" : [ "30", "53" ],
        "url" : "https://t.co/jXuegS00ns",
        "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1313104938747142149/pu/img/TWvUK9TTSDn-q_pH.jpg",
        "id_str" : "1313104938747142149",
        "source_user_id" : "440102503",
        "id" : "1313104938747142149",
        "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1313104938747142149/pu/img/TWvUK9TTSDn-q_pH.jpg",
        "source_user_id_str" : "440102503",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "383",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "720",
            "h" : "1280",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "675",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1313104979893252096",
        "display_url" : "pic.twitter.com/jXuegS00ns"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "53" ],
    "favorite_count" : "0",
    "id_str" : "1313643224859176960",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313643224859176960",
    "possibly_sensitive" : false,
    "created_at" : "Wed Oct 07 00:52:05 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @MatsuiRyosuke: 言葉が全く必要ない。 https://t.co/jXuegS00ns",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/MatsuiRyosuke/status/1313104979893252096/video/1",
        "source_status_id" : "1313104979893252096",
        "indices" : [ "30", "53" ],
        "url" : "https://t.co/jXuegS00ns",
        "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1313104938747142149/pu/img/TWvUK9TTSDn-q_pH.jpg",
        "id_str" : "1313104938747142149",
        "video_info" : {
          "aspect_ratio" : [ "9", "16" ],
          "duration_millis" : "2238",
          "variants" : [ {
            "content_type" : "application/x-mpegURL",
            "url" : "https://video.twimg.com/ext_tw_video/1313104938747142149/pu/pl/yNlZGMZWpA4BJH8D.m3u8?tag=10"
          }, {
            "bitrate" : "2176000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/ext_tw_video/1313104938747142149/pu/vid/720x1280/MOW2LUrumkUuXORn.mp4?tag=10"
          }, {
            "bitrate" : "832000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/ext_tw_video/1313104938747142149/pu/vid/360x640/s9cIHBE74I4Qaw_1.mp4?tag=10"
          }, {
            "bitrate" : "632000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/ext_tw_video/1313104938747142149/pu/vid/320x568/gMEIwE743q8o17B5.mp4?tag=10"
          } ]
        },
        "source_user_id" : "440102503",
        "additional_media_info" : {
          "monetizable" : false
        },
        "id" : "1313104938747142149",
        "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1313104938747142149/pu/img/TWvUK9TTSDn-q_pH.jpg",
        "source_user_id_str" : "440102503",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "383",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "720",
            "h" : "1280",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "675",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "video",
        "source_status_id_str" : "1313104979893252096",
        "display_url" : "pic.twitter.com/jXuegS00ns"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "すてらのどん",
        "screen_name" : "stella02903",
        "indices" : [ "3", "15" ],
        "id_str" : "978547247842406401",
        "id" : "978547247842406401"
      } ],
      "urls" : [ {
        "url" : "https://t.co/JBcto7wmB6",
        "expanded_url" : "https://store.playstation.com/#!/ja-jp/tid=CUSA07022_00",
        "display_url" : "store.playstation.com/#!/ja-jp/tid=C…",
        "indices" : [ "21", "44" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/stella02903/status/1313496966672900097/video/1",
        "source_status_id" : "1313496966672900097",
        "indices" : [ "45", "68" ],
        "url" : "https://t.co/crbcHFA1Di",
        "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1313496852420009990/pu/img/hk2eQUqmpJ8OF6Ms.jpg",
        "id_str" : "1313496852420009990",
        "source_user_id" : "978547247842406401",
        "id" : "1313496852420009990",
        "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1313496852420009990/pu/img/hk2eQUqmpJ8OF6Ms.jpg",
        "source_user_id_str" : "978547247842406401",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1280",
            "h" : "720",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1313496966672900097",
        "display_url" : "pic.twitter.com/crbcHFA1Di"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "68" ],
    "favorite_count" : "0",
    "id_str" : "1313642555892883456",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313642555892883456",
    "possibly_sensitive" : false,
    "created_at" : "Wed Oct 07 00:49:26 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @stella02903: 亀か\n\nhttps://t.co/JBcto7wmB6 https://t.co/crbcHFA1Di",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/stella02903/status/1313496966672900097/video/1",
        "source_status_id" : "1313496966672900097",
        "indices" : [ "45", "68" ],
        "url" : "https://t.co/crbcHFA1Di",
        "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1313496852420009990/pu/img/hk2eQUqmpJ8OF6Ms.jpg",
        "id_str" : "1313496852420009990",
        "video_info" : {
          "aspect_ratio" : [ "16", "9" ],
          "duration_millis" : "24791",
          "variants" : [ {
            "bitrate" : "2176000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/ext_tw_video/1313496852420009990/pu/vid/1280x720/k5SJxOhmLJMZ7naX.mp4?tag=10"
          }, {
            "bitrate" : "832000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/ext_tw_video/1313496852420009990/pu/vid/640x360/lY6EU6KK5uOoW7Dc.mp4?tag=10"
          }, {
            "content_type" : "application/x-mpegURL",
            "url" : "https://video.twimg.com/ext_tw_video/1313496852420009990/pu/pl/-Wtqp_Gf2yfqiCjH.m3u8?tag=10"
          }, {
            "bitrate" : "256000",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/ext_tw_video/1313496852420009990/pu/vid/480x270/vYGe0GYml5oSRKYB.mp4?tag=10"
          } ]
        },
        "source_user_id" : "978547247842406401",
        "additional_media_info" : {
          "monetizable" : false
        },
        "id" : "1313496852420009990",
        "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1313496852420009990/pu/img/hk2eQUqmpJ8OF6Ms.jpg",
        "source_user_id_str" : "978547247842406401",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1280",
            "h" : "720",
            "resize" : "fit"
          }
        },
        "type" : "video",
        "source_status_id_str" : "1313496966672900097",
        "display_url" : "pic.twitter.com/crbcHFA1Di"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "にょんギツネ",
        "screen_name" : "nyol2novel",
        "indices" : [ "3", "14" ],
        "id_str" : "904758878558076933",
        "id" : "904758878558076933"
      } ],
      "urls" : [ {
        "url" : "https://t.co/5Y33x7kizU",
        "expanded_url" : "https://store.steampowered.com/checkout/ssapopup",
        "display_url" : "store.steampowered.com/checkout/ssapo…",
        "indices" : [ "39", "62" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nyol2novel/status/1313638393545281536/photo/1",
        "source_status_id" : "1313638393545281536",
        "indices" : [ "63", "86" ],
        "url" : "https://t.co/nxdu9TyvCA",
        "media_url" : "http://pbs.twimg.com/media/Ejr7CUMVgAAAEAN.png",
        "id_str" : "1313638258530680832",
        "source_user_id" : "904758878558076933",
        "id" : "1313638258530680832",
        "media_url_https" : "https://pbs.twimg.com/media/Ejr7CUMVgAAAEAN.png",
        "source_user_id_str" : "904758878558076933",
        "sizes" : {
          "medium" : {
            "w" : "669",
            "h" : "710",
            "resize" : "fit"
          },
          "small" : {
            "w" : "641",
            "h" : "680",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "669",
            "h" : "710",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1313638393545281536",
        "display_url" : "pic.twitter.com/nxdu9TyvCA"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "86" ],
    "favorite_count" : "0",
    "id_str" : "1313642448371867648",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313642448371867648",
    "possibly_sensitive" : false,
    "created_at" : "Wed Oct 07 00:49:00 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @nyol2novel: むむっ、これは……契約書の誤字脱字なのじゃ？\nhttps://t.co/5Y33x7kizU https://t.co/nxdu9TyvCA",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nyol2novel/status/1313638393545281536/photo/1",
        "source_status_id" : "1313638393545281536",
        "indices" : [ "63", "86" ],
        "url" : "https://t.co/nxdu9TyvCA",
        "media_url" : "http://pbs.twimg.com/media/Ejr7CUMVgAAAEAN.png",
        "id_str" : "1313638258530680832",
        "source_user_id" : "904758878558076933",
        "id" : "1313638258530680832",
        "media_url_https" : "https://pbs.twimg.com/media/Ejr7CUMVgAAAEAN.png",
        "source_user_id_str" : "904758878558076933",
        "sizes" : {
          "medium" : {
            "w" : "669",
            "h" : "710",
            "resize" : "fit"
          },
          "small" : {
            "w" : "641",
            "h" : "680",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "669",
            "h" : "710",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1313638393545281536",
        "display_url" : "pic.twitter.com/nxdu9TyvCA"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "4" ],
    "favorite_count" : "1",
    "id_str" : "1313624141472231424",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313624141472231424",
    "created_at" : "Tue Oct 06 23:36:15 +0000 2020",
    "favorited" : false,
    "full_text" : "おはよう",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "14" ],
    "favorite_count" : "0",
    "id_str" : "1313503842433003520",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313503842433003520",
    "created_at" : "Tue Oct 06 15:38:14 +0000 2020",
    "favorited" : false,
    "full_text" : "寝るぜ\n\nアディオスアミーゴ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "88" ],
    "favorite_count" : "0",
    "id_str" : "1313502196810407936",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313502196810407936",
    "created_at" : "Tue Oct 06 15:31:42 +0000 2020",
    "favorited" : false,
    "full_text" : "生成した分かち書きのトークンが勝手にイテレータになる問題。\nstrのlistにしてくれたらそれでいいってだけなのにどうして…\n\nちな、list(iter)はダメと怒られてしもた",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313452676714164224",
    "id_str" : "1313500998535585792",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313500998535585792",
    "in_reply_to_status_id" : "1313452676714164224",
    "created_at" : "Tue Oct 06 15:26:56 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo ん？呼んだ？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "12" ],
    "favorite_count" : "1",
    "id_str" : "1313492716362313729",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313492716362313729",
    "created_at" : "Tue Oct 06 14:54:01 +0000 2020",
    "favorited" : false,
    "full_text" : "なしてこげに染まらぬだ？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ニナ",
        "screen_name" : "nina_ekaku",
        "indices" : [ "3", "14" ],
        "id_str" : "1235528771442073601",
        "id" : "1235528771442073601"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/nina_ekaku/status/1313432405651329025/photo/1",
        "source_status_id" : "1313432405651329025",
        "indices" : [ "111", "134" ],
        "url" : "https://t.co/51WrT7G7uq",
        "media_url" : "http://pbs.twimg.com/media/Ejo_zRcVoAIuPj4.jpg",
        "id_str" : "1313432391420059650",
        "source_user_id" : "1235528771442073601",
        "id" : "1313432391420059650",
        "media_url_https" : "https://pbs.twimg.com/media/Ejo_zRcVoAIuPj4.jpg",
        "source_user_id_str" : "1235528771442073601",
        "sizes" : {
          "medium" : {
            "w" : "1200",
            "h" : "858",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "486",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1801",
            "h" : "1287",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1313432405651329025",
        "display_url" : "pic.twitter.com/51WrT7G7uq"
      } ],
      "hashtags" : [ {
        "text" : "絵描きさんと繫がりたい",
        "indices" : [ "64", "76" ]
      }, {
        "text" : "相互さんの相互さんと繋がりたい",
        "indices" : [ "78", "94" ]
      }, {
        "text" : "秋の創作クラスタフォロー祭",
        "indices" : [ "96", "110" ]
      } ]
    },
    "display_text_range" : [ "0", "134" ],
    "favorite_count" : "0",
    "id_str" : "1313467936837791746",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313467936837791746",
    "possibly_sensitive" : false,
    "created_at" : "Tue Oct 06 13:15:33 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @nina_ekaku: 使いまわしでタグ失礼します🙏\n\n♡♻巡回します。挨拶は不要です。無言でまわらせてもらいます🙌\n\n#絵描きさんと繫がりたい \n#相互さんの相互さんと繋がりたい \n#秋の創作クラスタフォロー祭 https://t.co/51WrT7G7uq",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/nina_ekaku/status/1313432405651329025/photo/1",
        "source_status_id" : "1313432405651329025",
        "indices" : [ "111", "134" ],
        "url" : "https://t.co/51WrT7G7uq",
        "media_url" : "http://pbs.twimg.com/media/Ejo_zRcVoAIuPj4.jpg",
        "id_str" : "1313432391420059650",
        "source_user_id" : "1235528771442073601",
        "id" : "1313432391420059650",
        "media_url_https" : "https://pbs.twimg.com/media/Ejo_zRcVoAIuPj4.jpg",
        "source_user_id_str" : "1235528771442073601",
        "sizes" : {
          "medium" : {
            "w" : "1200",
            "h" : "858",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "486",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1801",
            "h" : "1287",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1313432405651329025",
        "display_url" : "pic.twitter.com/51WrT7G7uq"
      }, {
        "expanded_url" : "https://twitter.com/nina_ekaku/status/1313432405651329025/photo/1",
        "source_status_id" : "1313432405651329025",
        "indices" : [ "111", "134" ],
        "url" : "https://t.co/51WrT7G7uq",
        "media_url" : "http://pbs.twimg.com/media/Ejo_zdVVcAAzAQS.jpg",
        "id_str" : "1313432394611912704",
        "source_user_id" : "1235528771442073601",
        "id" : "1313432394611912704",
        "media_url_https" : "https://pbs.twimg.com/media/Ejo_zdVVcAAzAQS.jpg",
        "source_user_id_str" : "1235528771442073601",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1024",
            "h" : "855",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1024",
            "h" : "855",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "568",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1313432405651329025",
        "display_url" : "pic.twitter.com/51WrT7G7uq"
      }, {
        "expanded_url" : "https://twitter.com/nina_ekaku/status/1313432405651329025/photo/1",
        "source_status_id" : "1313432405651329025",
        "indices" : [ "111", "134" ],
        "url" : "https://t.co/51WrT7G7uq",
        "media_url" : "http://pbs.twimg.com/media/Ejo_zr0UwAcWCAw.jpg",
        "id_str" : "1313432398499987463",
        "source_user_id" : "1235528771442073601",
        "id" : "1313432398499987463",
        "media_url_https" : "https://pbs.twimg.com/media/Ejo_zr0UwAcWCAw.jpg",
        "source_user_id_str" : "1235528771442073601",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "458",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1378",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "807",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1313432405651329025",
        "display_url" : "pic.twitter.com/51WrT7G7uq"
      }, {
        "expanded_url" : "https://twitter.com/nina_ekaku/status/1313432405651329025/photo/1",
        "source_status_id" : "1313432405651329025",
        "indices" : [ "111", "134" ],
        "url" : "https://t.co/51WrT7G7uq",
        "media_url" : "http://pbs.twimg.com/media/Ejo_z-HUYAIs6Dv.jpg",
        "id_str" : "1313432403411492866",
        "source_user_id" : "1235528771442073601",
        "id" : "1313432403411492866",
        "media_url_https" : "https://pbs.twimg.com/media/Ejo_z-HUYAIs6Dv.jpg",
        "source_user_id_str" : "1235528771442073601",
        "sizes" : {
          "small" : {
            "w" : "502",
            "h" : "680",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "771",
            "h" : "1044",
            "resize" : "fit"
          },
          "large" : {
            "w" : "771",
            "h" : "1044",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1313432405651329025",
        "display_url" : "pic.twitter.com/51WrT7G7uq"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "0",
    "id_str" : "1313467722500431872",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313467722500431872",
    "created_at" : "Tue Oct 06 13:14:42 +0000 2020",
    "favorited" : false,
    "full_text" : "イテレーターとジェネレーターのあたりで詰まっている",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "15" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1314055288366878722",
    "id_str" : "1314055739938238464",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314055739938238464",
    "in_reply_to_status_id" : "1314055288366878722",
    "created_at" : "Thu Oct 08 04:11:17 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c oh…",
    "lang" : "und",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/AqIcL159YX",
        "expanded_url" : "https://techracho.bpsinc.jp/ohno/2019_08_29/79893",
        "display_url" : "techracho.bpsinc.jp/ohno/2019_08_2…",
        "indices" : [ "29", "52" ]
      } ]
    },
    "display_text_range" : [ "0", "52" ],
    "favorite_count" : "0",
    "id_str" : "1314055040370319360",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314055040370319360",
    "possibly_sensitive" : false,
    "created_at" : "Thu Oct 08 04:08:30 +0000 2020",
    "favorited" : false,
    "full_text" : "vimiumとかいう非常に面白そうなもの紹介されたんだが\nhttps://t.co/AqIcL159YX",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "16" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1314047019627892737",
    "id_str" : "1314054849252581377",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314054849252581377",
    "in_reply_to_status_id" : "1314047019627892737",
    "created_at" : "Thu Oct 08 04:07:44 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c how?",
    "lang" : "und",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/0QAmf1qadz",
        "expanded_url" : "https://qiita.com/hinata/items/810dea02008e96d00721",
        "display_url" : "qiita.com/hinata/items/8…",
        "indices" : [ "0", "23" ]
      } ]
    },
    "display_text_range" : [ "0", "46" ],
    "favorite_count" : "1",
    "id_str" : "1314053999084015617",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314053999084015617",
    "possibly_sensitive" : false,
    "created_at" : "Thu Oct 08 04:04:21 +0000 2020",
    "favorited" : false,
    "full_text" : "https://t.co/0QAmf1qadz\n昨日の続きに当たる記事です。ご査収ください。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://qiita.com\" rel=\"nofollow\">Qiita</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Qiita (キータ) 公式",
        "screen_name" : "Qiita",
        "indices" : [ "24", "30" ],
        "id_str" : "341374118",
        "id" : "341374118"
      } ],
      "urls" : [ {
        "url" : "https://t.co/0QAmf1qadz",
        "expanded_url" : "https://qiita.com/hinata/items/810dea02008e96d00721",
        "display_url" : "qiita.com/hinata/items/8…",
        "indices" : [ "31", "54" ]
      } ]
    },
    "display_text_range" : [ "0", "54" ],
    "favorite_count" : "3",
    "id_str" : "1314053713221177344",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314053713221177344",
    "possibly_sensitive" : false,
    "created_at" : "Thu Oct 08 04:03:13 +0000 2020",
    "favorited" : false,
    "full_text" : "配列のアドレスとポインタの関係性 [C] on @Qiita https://t.co/0QAmf1qadz",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "19" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1314041981283131398",
    "id_str" : "1314042543122776065",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314042543122776065",
    "in_reply_to_status_id" : "1314041981283131398",
    "created_at" : "Thu Oct 08 03:18:50 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish ばれたぁ👯‍♀️",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1314040776481939456/photo/1",
        "indices" : [ "25", "48" ],
        "url" : "https://t.co/QnJ5dlFOHT",
        "media_url" : "http://pbs.twimg.com/media/EjxpHl2U0AECrmQ.jpg",
        "id_str" : "1314040770425311233",
        "id" : "1314040770425311233",
        "media_url_https" : "https://pbs.twimg.com/media/EjxpHl2U0AECrmQ.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/QnJ5dlFOHT"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "48" ],
    "favorite_count" : "1",
    "id_str" : "1314040776481939456",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314040776481939456",
    "possibly_sensitive" : false,
    "created_at" : "Thu Oct 08 03:11:49 +0000 2020",
    "favorited" : false,
    "full_text" : "キータップいじる前に店行けよって話よね\n明日行く https://t.co/QnJ5dlFOHT",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1314040776481939456/photo/1",
        "indices" : [ "25", "48" ],
        "url" : "https://t.co/QnJ5dlFOHT",
        "media_url" : "http://pbs.twimg.com/media/EjxpHl2U0AECrmQ.jpg",
        "id_str" : "1314040770425311233",
        "id" : "1314040770425311233",
        "media_url_https" : "https://pbs.twimg.com/media/EjxpHl2U0AECrmQ.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/QnJ5dlFOHT"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "29" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1314029282138615808",
    "id_str" : "1314039578638966784",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314039578638966784",
    "in_reply_to_status_id" : "1314029282138615808",
    "created_at" : "Thu Oct 08 03:07:03 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo 黒服って手もあってだなぁ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1314027305082122241",
    "id_str" : "1314028687050719232",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314028687050719232",
    "in_reply_to_status_id" : "1314027305082122241",
    "created_at" : "Thu Oct 08 02:23:47 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo 体型要項に引っかかりアウト",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "29" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1314026070031527936",
    "id_str" : "1314027168028999682",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314027168028999682",
    "in_reply_to_status_id" : "1314026070031527936",
    "created_at" : "Thu Oct 08 02:17:44 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo 雇ってー_(:3」z)_",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "泡",
        "screen_name" : "bubble_oOoO",
        "indices" : [ "3", "15" ],
        "id_str" : "855252893103865856",
        "id" : "855252893103865856"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "56" ],
    "favorite_count" : "0",
    "id_str" : "1314024943907041281",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314024943907041281",
    "created_at" : "Thu Oct 08 02:08:54 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @bubble_oOoO: みんなエッチなくせにエッチじゃありませんみたいな顔して仕事してるのほんとすごい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1314024108942790658",
    "id_str" : "1314024842333569024",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314024842333569024",
    "in_reply_to_status_id" : "1314024108942790658",
    "created_at" : "Thu Oct 08 02:08:30 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo www\n店で電子工作始めるんでしょ\n名刺がgitのurl的な",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1314023887852584960",
    "id_str" : "1314023949110394882",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314023949110394882",
    "in_reply_to_status_id" : "1314023887852584960",
    "created_at" : "Thu Oct 08 02:04:57 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo 逆じゃないよ、客",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "32" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1314023667890675713",
    "id_str" : "1314023887852584960",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314023887852584960",
    "in_reply_to_status_id" : "1314023667890675713",
    "created_at" : "Thu Oct 08 02:04:42 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo 逆になります(☝ ՞ਊ ՞)☝",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "3", "19" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "44" ],
    "favorite_count" : "0",
    "id_str" : "1314023836044541952",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314023836044541952",
    "created_at" : "Thu Oct 08 02:04:30 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Kahorin_42Tokyo: テック系女子を集めたキャバクラ\n\n経済周りそう",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "68" ],
    "favorite_count" : "0",
    "id_str" : "1314018347411894272",
    "truncated" : false,
    "retweet_count" : "1",
    "id" : "1314018347411894272",
    "created_at" : "Thu Oct 08 01:42:41 +0000 2020",
    "favorited" : false,
    "full_text" : "新規契約と継続で比べるとやっぱり継続なんだよなぁ…\n\n回線周りは工事費、カムバックしても明らかにJcomのセット割りの方が安いんだよな…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "らーめん わかつ",
        "screen_name" : "WAKATU106",
        "indices" : [ "3", "13" ],
        "id_str" : "1100697650418962432",
        "id" : "1100697650418962432"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/WAKATU106/status/1313639366330183680/photo/1",
        "source_status_id" : "1313639366330183680",
        "indices" : [ "85", "108" ],
        "url" : "https://t.co/dLn2jALx7M",
        "media_url" : "http://pbs.twimg.com/media/Ejr8CMIU4AE7pRe.jpg",
        "id_str" : "1313639355878006785",
        "source_user_id" : "1100697650418962432",
        "id" : "1313639355878006785",
        "media_url_https" : "https://pbs.twimg.com/media/Ejr8CMIU4AE7pRe.jpg",
        "source_user_id_str" : "1100697650418962432",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "413",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1245",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "729",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1313639366330183680",
        "display_url" : "pic.twitter.com/dLn2jALx7M"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "108" ],
    "favorite_count" : "0",
    "id_str" : "1313857944484634624",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313857944484634624",
    "possibly_sensitive" : false,
    "created_at" : "Wed Oct 07 15:05:18 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @WAKATU106: 10月11月限定の「すだちつけ麺」です。つけ汁は正油ベースで大根おろしが入っていて、みぞれ風になっております。すだちは今が旬なので是非❗️ https://t.co/dLn2jALx7M",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/WAKATU106/status/1313639366330183680/photo/1",
        "source_status_id" : "1313639366330183680",
        "indices" : [ "85", "108" ],
        "url" : "https://t.co/dLn2jALx7M",
        "media_url" : "http://pbs.twimg.com/media/Ejr8CMIU4AE7pRe.jpg",
        "id_str" : "1313639355878006785",
        "source_user_id" : "1100697650418962432",
        "id" : "1313639355878006785",
        "media_url_https" : "https://pbs.twimg.com/media/Ejr8CMIU4AE7pRe.jpg",
        "source_user_id_str" : "1100697650418962432",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "413",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1245",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "729",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1313639366330183680",
        "display_url" : "pic.twitter.com/dLn2jALx7M"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "きっかわ@エンジニアネタ",
        "screen_name" : "kikkawapapa",
        "indices" : [ "3", "15" ],
        "id_str" : "1045099274541793280",
        "id" : "1045099274541793280"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "86" ],
    "favorite_count" : "0",
    "id_str" : "1313853656341475328",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313853656341475328",
    "created_at" : "Wed Oct 07 14:48:16 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @kikkawapapa: スクレイピング開発案件を初めてやってるんですが、これってブラックではないにしてもグレーぐらいのハッキング技術になってしまうんでしょうかね？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "34" ],
    "favorite_count" : "1",
    "id_str" : "1313847289199259648",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313847289199259648",
    "created_at" : "Wed Oct 07 14:22:58 +0000 2020",
    "favorited" : false,
    "full_text" : "いやもうps5おかしいだろ。なんであの値段でできるんだよwwwwww",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "39" ],
    "favorite_count" : "0",
    "id_str" : "1313844688286216196",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313844688286216196",
    "created_at" : "Wed Oct 07 14:12:38 +0000 2020",
    "favorited" : false,
    "full_text" : "tf-idf使って何かしたい。対象語をtwitter以外で引っ張ってきたい()",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "34" ],
    "favorite_count" : "0",
    "id_str" : "1313835888900620288",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313835888900620288",
    "created_at" : "Wed Oct 07 13:37:40 +0000 2020",
    "favorited" : false,
    "full_text" : "ころっけを右手に、左手に自作キーボード、傘をささずに台風を潜り抜ける",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "22" ],
    "favorite_count" : "1",
    "id_str" : "1313835196005851138",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313835196005851138",
    "created_at" : "Wed Oct 07 13:34:55 +0000 2020",
    "favorited" : false,
    "full_text" : "台風くる日にキーボードをつくりに行くと決めた",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "33" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313785063377575936",
    "id_str" : "1313792731920003073",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313792731920003073",
    "in_reply_to_status_id" : "1313785063377575936",
    "created_at" : "Wed Oct 07 10:46:11 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish 了解した、死にそうになってなくても押し掛ける",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "17" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1313771499120021504",
    "id_str" : "1313779494860144641",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313779494860144641",
    "in_reply_to_status_id" : "1313771499120021504",
    "created_at" : "Wed Oct 07 09:53:35 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish 立候補する😎",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "36" ],
    "favorite_count" : "2",
    "id_str" : "1313779337892487168",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1313779337892487168",
    "created_at" : "Wed Oct 07 09:52:57 +0000 2020",
    "favorited" : false,
    "full_text" : "+で文結合できた瞬間strcatが頭をよぎってしまったのでもう私はだめだ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "78" ],
    "favorite_count" : "1",
    "id_str" : "1296795696436146176",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1296795696436146176",
    "created_at" : "Fri Aug 21 13:06:01 +0000 2020",
    "favorited" : false,
    "full_text" : "piscineアカウントさんたちにフォローしていただけて大変嬉しい\n\nでも自分から話に行けてないから、誰とも繋がれていないつらさ\n\nぜひここで話しかけて…w",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "31" ],
    "favorite_count" : "0",
    "id_str" : "1295639080689000454",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1295639080689000454",
    "created_at" : "Tue Aug 18 08:30:03 +0000 2020",
    "favorited" : false,
    "full_text" : "一郎さんの翻訳、ごめんなさい追いつかないので断念します\n許して",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "HiroshimaTimeline",
        "indices" : [ "237", "255" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "0", "15" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "255" ],
    "favorite_count" : "22",
    "in_reply_to_status_id_str" : "1291504759258722304",
    "id_str" : "1291545171050369024",
    "in_reply_to_user_id" : "1227799099287597058",
    "truncated" : false,
    "retweet_count" : "7",
    "id" : "1291545171050369024",
    "in_reply_to_status_id" : "1291504759258722304",
    "created_at" : "Fri Aug 07 01:22:19 +0000 2020",
    "favorited" : false,
    "full_text" : "@nhk_1945ichiro 【1945/8/7】\nThe body on the street are collected by track or rear car.\nBut still bodies on here and there.\nBeing a reporter, but I can't write this misery into articles.\nI never want to forget this scenery . For someday.\n\n#HiroshimaTimeline",
    "lang" : "en",
    "in_reply_to_screen_name" : "nhk_1945ichiro",
    "in_reply_to_user_id_str" : "1227799099287597058"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "3",
    "id_str" : "1291541671956475905",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291541671956475905",
    "created_at" : "Fri Aug 07 01:08:24 +0000 2020",
    "favorited" : false,
    "full_text" : "彼らのほうがつらいのにここで止まるのはダメだね",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "HiroshimaTimeline",
        "indices" : [ "234", "252" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "0", "15" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "252" ],
    "favorite_count" : "18",
    "in_reply_to_status_id_str" : "1291501780141039617",
    "id_str" : "1291541434042970112",
    "in_reply_to_user_id" : "1227799099287597058",
    "truncated" : false,
    "retweet_count" : "3",
    "id" : "1291541434042970112",
    "in_reply_to_status_id" : "1291501780141039617",
    "created_at" : "Fri Aug 07 01:07:28 +0000 2020",
    "favorited" : false,
    "full_text" : "@nhk_1945ichiro 【1945/8/7】\n\nHell panorama still continues today.\nBurned body like dried fish on the streets.\nflock of naked body on sea  level come up toward the High tide.Moans of seriously injured who can't distinguish the gender.\n\n#HiroshimaTimeline",
    "lang" : "en",
    "in_reply_to_screen_name" : "nhk_1945ichiro",
    "in_reply_to_user_id_str" : "1227799099287597058"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "HiroshimaTimeline",
        "indices" : [ "268", "286" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "0", "15" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "286" ],
    "favorite_count" : "13",
    "in_reply_to_status_id_str" : "1291498031716675587",
    "id_str" : "1291538963845398528",
    "in_reply_to_user_id" : "1227799099287597058",
    "truncated" : false,
    "retweet_count" : "1",
    "id" : "1291538963845398528",
    "in_reply_to_status_id" : "1291498031716675587",
    "created_at" : "Fri Aug 07 00:57:39 +0000 2020",
    "favorited" : false,
    "full_text" : "@nhk_1945ichiro 【1945/8/7】 \n\n\"Well, let me find my hasband too.\"\nThe wife of the president's son told me when I try to left with my colleague. She hold the health box cherishly in front of her chest. Looks frantically. we decided to enter the city with three people.\n\n#HiroshimaTimeline",
    "lang" : "en",
    "in_reply_to_screen_name" : "nhk_1945ichiro",
    "in_reply_to_user_id_str" : "1227799099287597058"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "HiroshimaTimeline",
        "indices" : [ "265", "283" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "0", "15" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "283" ],
    "favorite_count" : "24",
    "in_reply_to_status_id_str" : "1291494180716503044",
    "id_str" : "1291535426449100800",
    "in_reply_to_user_id" : "1227799099287597058",
    "truncated" : false,
    "retweet_count" : "5",
    "id" : "1291535426449100800",
    "in_reply_to_status_id" : "1291494180716503044",
    "created_at" : "Fri Aug 07 00:43:35 +0000 2020",
    "favorited" : false,
    "full_text" : "@nhk_1945ichiro 【1945/8/7】\n\nWe gathered at the president's house.\nStraw hat and long-sleeved shirt. Brought a lunch and water bottle. The sight of yesterday crosses my head. Iron helmet or disaster prevention hood never works against that bomb. Now find survivors.\n#HiroshimaTimeline",
    "lang" : "en",
    "in_reply_to_screen_name" : "nhk_1945ichiro",
    "in_reply_to_user_id_str" : "1227799099287597058"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "万里小路（までのこうじ）わいぐ",
        "screen_name" : "tomato3124",
        "indices" : [ "0", "11" ],
        "id_str" : "948655377054294017",
        "id" : "948655377054294017"
      }, {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "12", "27" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "199" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1291531156119154690",
    "id_str" : "1291532040228069376",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291532040228069376",
    "in_reply_to_status_id" : "1291531156119154690",
    "created_at" : "Fri Aug 07 00:30:08 +0000 2020",
    "favorited" : false,
    "full_text" : "@tomato3124 @nhk_1945ichiro I'm in faculty of engineering. English is not my major.I took english classes  one years ago. I didn't use it for a year, so My English is Terrible....so I need your help.",
    "lang" : "en",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "万里小路（までのこうじ）わいぐ",
        "screen_name" : "tomato3124",
        "indices" : [ "0", "11" ],
        "id_str" : "948655377054294017",
        "id" : "948655377054294017"
      }, {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "12", "27" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "233" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1291404877696872448",
    "id_str" : "1291531156119154690",
    "in_reply_to_user_id" : "948655377054294017",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291531156119154690",
    "in_reply_to_status_id" : "1291404877696872448",
    "created_at" : "Fri Aug 07 00:26:37 +0000 2020",
    "favorited" : false,
    "full_text" : "@tomato3124 @nhk_1945ichiro Thank you Mrs Madeno. I saw your translations in this morning. These are so nice to let it known for others. I'll do my best, so please check it whenever convenient for you. Translations are always needed.",
    "lang" : "en",
    "in_reply_to_screen_name" : "tomato3124",
    "in_reply_to_user_id_str" : "948655377054294017"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "HiroshimaTimeline",
        "indices" : [ "201", "219" ]
      }, {
        "text" : "Hiroshima",
        "indices" : [ "221", "231" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "0", "15" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "231" ],
    "favorite_count" : "2",
    "in_reply_to_status_id_str" : "1291526027454197760",
    "id_str" : "1291529542935252993",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "1",
    "id" : "1291529542935252993",
    "in_reply_to_status_id" : "1291526027454197760",
    "created_at" : "Fri Aug 07 00:20:13 +0000 2020",
    "favorited" : false,
    "full_text" : "@nhk_1945ichiro 【1945/8/6】\nI'm alive like this, because he had taken over for me.\n\nI'll go back to Hiroshima again and I'll confirm the life or death of my friends.\nThat is an obligation of survivors.\n#HiroshimaTimeline \n#Hiroshima",
    "lang" : "en",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "0", "15" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "285" ],
    "favorite_count" : "2",
    "in_reply_to_status_id_str" : "1291354309200838658",
    "id_str" : "1291526027454197760",
    "in_reply_to_user_id" : "1227799099287597058",
    "truncated" : false,
    "retweet_count" : "1",
    "id" : "1291526027454197760",
    "in_reply_to_status_id" : "1291354309200838658",
    "created_at" : "Fri Aug 07 00:06:14 +0000 2020",
    "favorited" : false,
    "full_text" : "@nhk_1945ichiro 【1945/8/6】\n\"Convocation order came to you. I'll go instead of you\"\nIf true this morning, I had to go to break the building to save these from fire after night shift as militia. (建物疎開\"tatemono sokai\"== break buildings to make spaces to save these from fire or explosion)",
    "lang" : "en",
    "in_reply_to_screen_name" : "nhk_1945ichiro",
    "in_reply_to_user_id_str" : "1227799099287597058"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "ひろしまタイムライン",
        "indices" : [ "58", "69" ]
      }, {
        "text" : "Hiroshima75",
        "indices" : [ "70", "82" ]
      }, {
        "text" : "Hiroshima",
        "indices" : [ "83", "93" ]
      }, {
        "text" : "世界平和",
        "indices" : [ "94", "99" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "tacos",
        "screen_name" : "Kwk_uta",
        "indices" : [ "3", "11" ],
        "id_str" : "2991694895",
        "id" : "2991694895"
      }, {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "13", "28" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1291522626125361152",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291522626125361152",
    "created_at" : "Thu Aug 06 23:52:44 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Kwk_uta: @nhk_1945ichiro [from Ichiro (a journalist)] #ひろしまタイムライン #Hiroshima75 #Hiroshima #世界平和 \n1945, August 6th 19:17\nThe explosion t…",
    "lang" : "en"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "43" ],
    "favorite_count" : "3",
    "id_str" : "1291404275084451840",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291404275084451840",
    "created_at" : "Thu Aug 06 16:02:26 +0000 2020",
    "favorited" : false,
    "full_text" : "明日あと二つ課題仕上げたらもっと頑張ります、今日もう無理そうですおやすみなさい🤦‍♀️",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "139" ],
    "favorite_count" : "8",
    "in_reply_to_status_id_str" : "1291403736632266753",
    "id_str" : "1291404119895191552",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "2",
    "id" : "1291404119895191552",
    "in_reply_to_status_id" : "1291403736632266753",
    "created_at" : "Thu Aug 06 16:01:49 +0000 2020",
    "favorited" : false,
    "full_text" : "ツイートにはもちろん翻訳機能もありますが、あまり機能しない場合や、忙しかったり、他の言語だと見る時間が取れない人もいると思うんです…\n\nタイムラインで見かけてパッと読んで心の片隅にでも止めてもらえるように\n\nぜひ皆さんもご一緒に…\n\n一郎さん以外にもあとお二方おられますので…😭",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "104" ],
    "favorite_count" : "18",
    "id_str" : "1291403736632266753",
    "truncated" : false,
    "retweet_count" : "6",
    "id" : "1291403736632266753",
    "created_at" : "Thu Aug 06 16:00:18 +0000 2020",
    "favorited" : false,
    "full_text" : "もう私はただの通りすがりの人間なので翻訳誰にも頼まれたわけではなくて\n\nこんなに8月6日が辛かったとわかったのが初めてだっただけなので\n\nぜひ皆さん日本語の彼らのツイート見つけたら翻訳をつけてあげてください…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "万里小路（までのこうじ）わいぐ",
        "screen_name" : "tomato3124",
        "indices" : [ "0", "11" ],
        "id_str" : "948655377054294017",
        "id" : "948655377054294017"
      }, {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "12", "27" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "59" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1291375686926471168",
    "id_str" : "1291403321849176064",
    "in_reply_to_user_id" : "948655377054294017",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291403321849176064",
    "in_reply_to_status_id" : "1291375686926471168",
    "created_at" : "Thu Aug 06 15:58:39 +0000 2020",
    "favorited" : false,
    "full_text" : "@tomato3124 @nhk_1945ichiro I really appreciate your reply😭",
    "lang" : "en",
    "in_reply_to_screen_name" : "tomato3124",
    "in_reply_to_user_id_str" : "948655377054294017"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "ツヅリ@スパイスカレー沼の浅瀬",
        "screen_name" : "tsuzuri75",
        "indices" : [ "0", "10" ],
        "id_str" : "2328878924",
        "id" : "2328878924"
      }, {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "11", "26" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1291348517865177088",
    "id_str" : "1291402963219386369",
    "in_reply_to_user_id" : "2328878924",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291402963219386369",
    "in_reply_to_status_id" : "1291348517865177088",
    "created_at" : "Thu Aug 06 15:57:14 +0000 2020",
    "favorited" : false,
    "full_text" : "@tsuzuri75 @nhk_1945ichiro ああああありがとうございます、そう言っていただけると助かります…つづりさんのお気持ちが嬉しいです🙇‍♀️\n\n彼らもきっとここからたくさんの道のりを歩んでいくと思うと、ぜひ多くの人に知ってもらえたらと思います\n\n課題頑張ります😭",
    "lang" : "ja",
    "in_reply_to_screen_name" : "tsuzuri75",
    "in_reply_to_user_id_str" : "2328878924"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "blue",
        "screen_name" : "blue69375775",
        "indices" : [ "0", "13" ],
        "id_str" : "1209467710930767873",
        "id" : "1209467710930767873"
      }, {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "14", "29" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "53" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1291376291514445824",
    "id_str" : "1291386590619512832",
    "in_reply_to_user_id" : "1209467710930767873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291386590619512832",
    "in_reply_to_status_id" : "1291376291514445824",
    "created_at" : "Thu Aug 06 14:52:10 +0000 2020",
    "favorited" : false,
    "full_text" : "@blue69375775 @nhk_1945ichiro 本当にありがとうございます、今日は徹夜かも…w",
    "lang" : "ja",
    "in_reply_to_screen_name" : "blue69375775",
    "in_reply_to_user_id_str" : "1209467710930767873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "nailee",
        "screen_name" : "nailee02588901",
        "indices" : [ "0", "15" ],
        "id_str" : "1206236186345267200",
        "id" : "1206236186345267200"
      }, {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "16", "31" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "178" ],
    "favorite_count" : "6",
    "in_reply_to_status_id_str" : "1291381725281452032",
    "id_str" : "1291386430103592960",
    "in_reply_to_user_id" : "1206236186345267200",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291386430103592960",
    "in_reply_to_status_id" : "1291381725281452032",
    "created_at" : "Thu Aug 06 14:51:32 +0000 2020",
    "favorited" : false,
    "full_text" : "@nailee02588901 @nhk_1945ichiro いえ、クソリプだなんてとんでもない、ご指摘ありがとうございます。そうですよね…もう英語から離れてかなりになりますので勉強不足をお許しください…。\nレポートに追われて校正時間も取れない有様です…ぜひnailee様の手もお借りできれば幸いです…\nたくさんの方に読んでいただきたいのでぜひ…((((",
    "lang" : "ja",
    "in_reply_to_screen_name" : "nailee02588901",
    "in_reply_to_user_id_str" : "1206236186345267200"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "blue",
        "screen_name" : "blue69375775",
        "indices" : [ "0", "13" ],
        "id_str" : "1209467710930767873",
        "id" : "1209467710930767873"
      }, {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "14", "29" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "157" ],
    "favorite_count" : "3",
    "in_reply_to_status_id_str" : "1291368755092578311",
    "id_str" : "1291370301364740096",
    "in_reply_to_user_id" : "1209467710930767873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291370301364740096",
    "in_reply_to_status_id" : "1291368755092578311",
    "created_at" : "Thu Aug 06 13:47:27 +0000 2020",
    "favorited" : false,
    "full_text" : "@blue69375775 @nhk_1945ichiro 本当に本当にありがとうございます…、私もlineのオープンチャットの英語グループに送ったんですが見事にスルーみたいになってしまいました…。\n明日また、翻訳されていないところを探します。中国語や韓国語の翻訳もちょっと頑張ります…本当にありがとうございます…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "blue69375775",
    "in_reply_to_user_id_str" : "1209467710930767873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "43" ],
    "favorite_count" : "13",
    "id_str" : "1291320884309839872",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1291320884309839872",
    "created_at" : "Thu Aug 06 10:31:05 +0000 2020",
    "favorited" : false,
    "full_text" : "あぁああ課題終わらないので離脱しますうううう戻ったら急いで翻訳戻るからまっててぇぇぇえ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "HiroshimaTimeline",
        "indices" : [ "211", "229" ]
      }, {
        "text" : "IfSNSin75YearsAgo",
        "indices" : [ "230", "248" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "0", "15" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "248" ],
    "favorite_count" : "26",
    "in_reply_to_status_id_str" : "1291316555050037248",
    "id_str" : "1291320736980692992",
    "in_reply_to_user_id" : "1227799099287597058",
    "truncated" : false,
    "retweet_count" : "8",
    "id" : "1291320736980692992",
    "in_reply_to_status_id" : "1291316555050037248",
    "created_at" : "Thu Aug 06 10:30:29 +0000 2020",
    "favorited" : false,
    "full_text" : "@nhk_1945ichiro 【1945/8/6】\n\nI should go to President's residence, but my body don't obey me.\nSun to set before I kenw it, then the sky turned rosy flush.\nStill sparks on here and there and the frame is burning\n\n#HiroshimaTimeline\n#IfSNSin75YearsAgo",
    "lang" : "en",
    "in_reply_to_screen_name" : "nhk_1945ichiro",
    "in_reply_to_user_id_str" : "1227799099287597058"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "blue",
        "screen_name" : "blue69375775",
        "indices" : [ "0", "13" ],
        "id_str" : "1209467710930767873",
        "id" : "1209467710930767873"
      }, {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "14", "29" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "110" ],
    "favorite_count" : "8",
    "in_reply_to_status_id_str" : "1291317199714414592",
    "id_str" : "1291317897994756103",
    "in_reply_to_user_id" : "1209467710930767873",
    "truncated" : false,
    "retweet_count" : "1",
    "id" : "1291317897994756103",
    "in_reply_to_status_id" : "1291317199714414592",
    "created_at" : "Thu Aug 06 10:19:13 +0000 2020",
    "favorited" : false,
    "full_text" : "@blue69375775 @nhk_1945ichiro 自分は広島放送局の方々の試みで今までの8月6日と違う体験ができたので貢献したいと思ったのですが…\n学校の課題がまずいので誰かにバトンを渡さないとかもしれません…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "blue69375775",
    "in_reply_to_user_id_str" : "1209467710930767873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "HiroshimaTimeline",
        "indices" : [ "133", "151" ]
      }, {
        "text" : "IfSNS75YearsAgo",
        "indices" : [ "153", "169" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "一郎@ひろしまタイムライン",
        "screen_name" : "nhk_1945ichiro",
        "indices" : [ "0", "15" ],
        "id_str" : "1227799099287597058",
        "id" : "1227799099287597058"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "169" ],
    "favorite_count" : "13",
    "in_reply_to_status_id_str" : "1291296339628892163",
    "id_str" : "1291317510277496832",
    "in_reply_to_user_id" : "1227799099287597058",
    "truncated" : false,
    "retweet_count" : "2",
    "id" : "1291317510277496832",
    "in_reply_to_status_id" : "1291296339628892163",
    "created_at" : "Thu Aug 06 10:17:40 +0000 2020",
    "favorited" : false,
    "full_text" : "@nhk_1945ichiro 【1945/8/6】\n\n\"Hot！Can't digging it now!\", said reporter Kamakura.\nI felt the heat from the rubble, standing next to.\n\n#HiroshimaTimeline \n#IfSNS75YearsAgo",
    "lang" : "en",
    "in_reply_to_screen_name" : "nhk_1945ichiro",
    "in_reply_to_user_id_str" : "1227799099287597058"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "11" ],
    "favorite_count" : "2",
    "id_str" : "1314395998018367488",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314395998018367488",
    "created_at" : "Fri Oct 09 02:43:20 +0000 2020",
    "favorited" : false,
    "full_text" : "よし、遊舎工房に行くゾ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "47" ],
    "favorite_count" : "0",
    "id_str" : "1314395464557494272",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314395464557494272",
    "created_at" : "Fri Oct 09 02:41:13 +0000 2020",
    "favorited" : false,
    "full_text" : "インターン先のテストがCだったら、printfの代わりにwrite使って怒られてみたい気もする",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ {
        "text" : "include",
        "indices" : [ "31", "39" ]
      } ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "KOTO",
        "screen_name" : "koto_science",
        "indices" : [ "0", "13" ],
        "id_str" : "984367814889779200",
        "id" : "984367814889779200"
      }, {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "14", "30" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "246" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1314388985309921280",
    "id_str" : "1314395161548341249",
    "in_reply_to_user_id" : "984367814889779200",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314395161548341249",
    "in_reply_to_status_id" : "1314388985309921280",
    "created_at" : "Fri Oct 09 02:40:01 +0000 2020",
    "favorited" : false,
    "full_text" : "@koto_science @Kahorin_42Tokyo #include&lt;unistd.h&gt;\nint main(void)\n{\n    int i;\n    char *a;\n\n    i = 0;\n    a = \"Hello World\";\n    while (*(a + i) != '\\0')\n    {\n        write(1, (a + i), 1);\n        i++;\n    }\n    return (0);\n}\n\n確かにめんどくせぇなw",
    "lang" : "ja",
    "in_reply_to_screen_name" : "koto_science",
    "in_reply_to_user_id_str" : "984367814889779200"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "118" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1314382110136782849",
    "id_str" : "1314386614622146560",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314386614622146560",
    "in_reply_to_status_id" : "1314382110136782849",
    "created_at" : "Fri Oct 09 02:06:03 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo char *a=\"Hello World\":\n\nwhile ( *(a+i) != '¥0' )\n{\n　　　　write(1, (a+i), 1);\n              i++;\n}\n\nかなぁ？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "14" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1314357750911004673",
    "id_str" : "1314364377806503937",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314364377806503937",
    "in_reply_to_status_id" : "1314357750911004673",
    "created_at" : "Fri Oct 09 00:37:42 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish ぉあょ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "46" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1314338700210270209",
    "id_str" : "1314364309623898112",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314364309623898112",
    "in_reply_to_status_id" : "1314338700210270209",
    "created_at" : "Fri Oct 09 00:37:25 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo write(1, \"Hellow World\", 12);",
    "lang" : "en",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "3" ],
    "favorite_count" : "0",
    "id_str" : "1314337849223725056",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314337849223725056",
    "created_at" : "Thu Oct 08 22:52:17 +0000 2020",
    "favorited" : false,
    "full_text" : "おはよ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "97" ],
    "favorite_count" : "1",
    "id_str" : "1314203718636597254",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314203718636597254",
    "created_at" : "Thu Oct 08 13:59:17 +0000 2020",
    "favorited" : false,
    "full_text" : "いやしかし、qiitaを書くのは楽しいし、人に指摘してもらうことは嫌じゃないから。楽しいからと言って独りよがりになってはまずいので\n\n明日はちゃんと返信して、編集作業もちゃんとやりますわ\n\n寝よ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "32" ],
    "favorite_count" : "1",
    "id_str" : "1314197741786951683",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314197741786951683",
    "created_at" : "Thu Oct 08 13:35:32 +0000 2020",
    "favorited" : false,
    "full_text" : "だからCやりたくない若者増えるのではないかと一瞬勘ぐった((((",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/5OqneCfpII",
        "expanded_url" : "https://twitter.com/_unlimish/status/1314195779523813376",
        "display_url" : "twitter.com/_unlimish/stat…",
        "indices" : [ "5", "28" ]
      } ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "2",
    "id_str" : "1314197622329024512",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314197622329024512",
    "possibly_sensitive" : false,
    "created_at" : "Thu Oct 08 13:35:04 +0000 2020",
    "favorited" : false,
    "full_text" : "ほんこれ https://t.co/5OqneCfpII",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "27" ],
    "favorite_count" : "0",
    "id_str" : "1314194565662822400",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314194565662822400",
    "created_at" : "Thu Oct 08 13:22:55 +0000 2020",
    "favorited" : false,
    "full_text" : "コメントだけ伸びている…答える気力がなくて申し訳ない…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "21" ],
    "favorite_count" : "2",
    "id_str" : "1314188120145895425",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314188120145895425",
    "created_at" : "Thu Oct 08 12:57:18 +0000 2020",
    "favorited" : false,
    "full_text" : "えちょ、日テレ落ちた？\n\nえ、テレビが…？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "tkasasagi🐻@バリキャリ熊",
        "screen_name" : "tkasasagi",
        "indices" : [ "3", "13" ],
        "id_str" : "892732157294030848",
        "id" : "892732157294030848"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1314187471412813824",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314187471412813824",
    "created_at" : "Thu Oct 08 12:54:44 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @tkasasagi: プログラミングは難しいことではない。やろうと思えば文系学生、大学院生でもできる。でも、「みんな、プログラマーになって就職しよう！」とか、今までの自分を捨てるのではなく、自分の知識をそのまま活かして、プログラミングをツールの一つとして自分の研究を効率…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "イゴ（cv.リョウヘイ）",
        "screen_name" : "igo1500013",
        "indices" : [ "0", "11" ],
        "id_str" : "1020586855207600129",
        "id" : "1020586855207600129"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "35" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1314156159759118337",
    "id_str" : "1314187128851423232",
    "in_reply_to_user_id" : "1020586855207600129",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314187128851423232",
    "in_reply_to_status_id" : "1314156159759118337",
    "created_at" : "Thu Oct 08 12:53:22 +0000 2020",
    "favorited" : false,
    "full_text" : "@igo1500013 あー、かんしたおさけも、冷のお酒も合うやつだ。",
    "lang" : "ja",
    "in_reply_to_screen_name" : "igo1500013",
    "in_reply_to_user_id_str" : "1020586855207600129"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "イゴ（cv.リョウヘイ）",
        "screen_name" : "igo1500013",
        "indices" : [ "3", "14" ],
        "id_str" : "1020586855207600129",
        "id" : "1020586855207600129"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/igo1500013/status/1314156159759118337/photo/1",
        "source_status_id" : "1314156159759118337",
        "indices" : [ "44", "67" ],
        "url" : "https://t.co/gDwQvd3zpN",
        "media_url" : "http://pbs.twimg.com/media/EjzSD1RU0AAnzkw.jpg",
        "id_str" : "1314156154566529024",
        "source_user_id" : "1020586855207600129",
        "id" : "1314156154566529024",
        "media_url_https" : "https://pbs.twimg.com/media/EjzSD1RU0AAnzkw.jpg",
        "source_user_id_str" : "1020586855207600129",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "382",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1150",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "674",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1314156159759118337",
        "display_url" : "pic.twitter.com/gDwQvd3zpN"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "67" ],
    "favorite_count" : "0",
    "id_str" : "1314186985163026432",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314186985163026432",
    "possibly_sensitive" : false,
    "created_at" : "Thu Oct 08 12:52:48 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @igo1500013: そして、ひとりで白子ポン酢。そんな季節になりましたね。 https://t.co/gDwQvd3zpN",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/igo1500013/status/1314156159759118337/photo/1",
        "source_status_id" : "1314156159759118337",
        "indices" : [ "44", "67" ],
        "url" : "https://t.co/gDwQvd3zpN",
        "media_url" : "http://pbs.twimg.com/media/EjzSD1RU0AAnzkw.jpg",
        "id_str" : "1314156154566529024",
        "source_user_id" : "1020586855207600129",
        "id" : "1314156154566529024",
        "media_url_https" : "https://pbs.twimg.com/media/EjzSD1RU0AAnzkw.jpg",
        "source_user_id_str" : "1020586855207600129",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "382",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1150",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "674",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1314156159759118337",
        "display_url" : "pic.twitter.com/gDwQvd3zpN"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "76" ],
    "favorite_count" : "1",
    "id_str" : "1314186927873040384",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314186927873040384",
    "created_at" : "Thu Oct 08 12:52:34 +0000 2020",
    "favorited" : false,
    "full_text" : "Qiitaで記事書くと、教えてくれる人がたくさんいて嬉しいんだけど\n\nその文自分のキャパも考えないといけないことに気がついた。今日はもう記事触りたくない",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "99" ],
    "favorite_count" : "4",
    "id_str" : "1314145011248689153",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314145011248689153",
    "created_at" : "Thu Oct 08 10:06:00 +0000 2020",
    "favorited" : false,
    "full_text" : "qiitaに記事書くと、プログラミングつよつよ兄貴たちが公正してくれるので気づかされることがおおい\n\n自分で気が付けないのやばいんだけど、今度から気を付けられたらいいなって思う((((((甘えかな)",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      }, {
        "name" : "hayasak",
        "screen_name" : "ydytast",
        "indices" : [ "12", "20" ],
        "id_str" : "845624153424113665",
        "id" : "845624153424113665"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1314131547105054720",
    "id_str" : "1314132247599964160",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314132247599964160",
    "in_reply_to_status_id" : "1314131547105054720",
    "created_at" : "Thu Oct 08 09:15:17 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c @ydytast かわよ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "17" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1314129993308332034",
    "id_str" : "1314131330234425345",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314131330234425345",
    "in_reply_to_status_id" : "1314129993308332034",
    "created_at" : "Thu Oct 08 09:11:39 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c みして❤️",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "21" ],
    "favorite_count" : "2",
    "id_str" : "1314065378117472258",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314065378117472258",
    "created_at" : "Thu Oct 08 04:49:34 +0000 2020",
    "favorited" : false,
    "full_text" : "寒すぎてイライラしたから布団でスプラ始めた",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "10" ],
    "favorite_count" : "3",
    "id_str" : "1314062344582955009",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314062344582955009",
    "created_at" : "Thu Oct 08 04:37:31 +0000 2020",
    "favorited" : false,
    "full_text" : "今日普通に寒すぎね？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Ken@Piscine_Sep.",
        "screen_name" : "42KeN47",
        "indices" : [ "3", "11" ],
        "id_str" : "1302579062695579650",
        "id" : "1302579062695579650"
      } ],
      "urls" : [ {
        "url" : "https://t.co/R1EsAthRfr",
        "expanded_url" : "https://twitter.com/nvidiaaidev/status/1313532560916373504",
        "display_url" : "twitter.com/nvidiaaidev/st…",
        "indices" : [ "111", "134" ]
      } ]
    },
    "display_text_range" : [ "0", "134" ],
    "favorite_count" : "0",
    "id_str" : "1314062113468370945",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314062113468370945",
    "possibly_sensitive" : false,
    "created_at" : "Thu Oct 08 04:36:36 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @42KeN47: 特徴量抽出して情報量ばり下げた上でGANでリアルタイム生成の流れえぐいな\n電話も「声に似たパターンの信号送ってる」って事で発想の根本は昔からあるけど、それ映像で実現するのやばすぎでしょ(語彙力) https://t.co/R1EsAthRfr",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      }, {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "12", "22" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "31" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1314057266413277188",
    "id_str" : "1314058629432000512",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314058629432000512",
    "in_reply_to_status_id" : "1314057266413277188",
    "created_at" : "Thu Oct 08 04:22:45 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c @_unlimish 君たち怖いなぁw",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "48" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1314055288366878722",
    "id_str" : "1314056059770683393",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314056059770683393",
    "in_reply_to_status_id" : "1314055288366878722",
    "created_at" : "Thu Oct 08 04:12:33 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c あれ？fizzbuzzって3と5の倍数問題？ゆーだいとけてそうだけど…？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "𝚃𝚊𝚛𝚘𝚕𝚘𝚝𝚝𝚊🇬🇧",
        "screen_name" : "lottalottat",
        "indices" : [ "3", "15" ],
        "id_str" : "921930041126039553",
        "id" : "921930041126039553"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "132" ],
    "favorite_count" : "0",
    "id_str" : "1314423191532564480",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314423191532564480",
    "created_at" : "Fri Oct 09 04:31:24 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @lottalottat: 引用で失礼するのですがこのドア！！！ラプンツェルの塔のドア意識してる？！？！？\n私は！！！一度描いたことがある(戦ったことがある)ので！！！！見た瞬間！！！！！ぶったまげた！！！！！ https://t.co/m785TNW6NU",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "16" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1314422113911021568",
    "id_str" : "1314422980231852032",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314422980231852032",
    "in_reply_to_status_id" : "1314422113911021568",
    "created_at" : "Fri Oct 09 04:30:33 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish あざーす！",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "u++",
        "screen_name" : "upura0",
        "indices" : [ "3", "10" ],
        "id_str" : "2149170847",
        "id" : "2149170847"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "109" ],
    "favorite_count" : "0",
    "id_str" : "1314422556934369280",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314422556934369280",
    "created_at" : "Fri Oct 09 04:28:53 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @upura0: Yann LeCun教授によるディープラーニングの授業（NY大、2020年春）の資料一式が公開された👏 スライドだけでなく、講義動画やJupyter Notebooks（PyTorch実装）も！",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "12" ],
    "favorite_count" : "0",
    "id_str" : "1314421901419114496",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314421901419114496",
    "created_at" : "Fri Oct 09 04:26:16 +0000 2020",
    "favorited" : false,
    "full_text" : "あれ？合格発表っていつ？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "タカツマ🍊",
        "screen_name" : "takatmaorange",
        "indices" : [ "3", "17" ],
        "id_str" : "915420834931523585",
        "id" : "915420834931523585"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1314419771694178304",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314419771694178304",
    "created_at" : "Fri Oct 09 04:17:48 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @takatmaorange: 〜ミッキーとミニーのディズニーシー巡り〜\nミッキーとミニーのディズニーシーに密着！\n\n明日から1日1枚載せていきます〜\n(コロナ関係なく通常運営のディズニーシーに設定しています！平日のアトラクション混雑を参考にしています✨) https:/…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "輝樹社長@社会を予防する理学療法士",
        "screen_name" : "tellkey301pt",
        "indices" : [ "3", "16" ],
        "id_str" : "295100280",
        "id" : "295100280"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1314418813534781442",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314418813534781442",
    "created_at" : "Fri Oct 09 04:14:00 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @tellkey301pt: 【怖い。。。】\nzoomが勝手に国際電話登録されていて、24万円の請求かかった人がいたみたい。電話設定がなぜかアイルランドに。。\n\nそんなまさかー。と自分も確認したら。。。\n\nなんと僕のzoomもアイルランドになっちゃってました。。。\n\nあわ…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "19" ],
    "favorite_count" : "1",
    "id_str" : "1314418491538075648",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314418491538075648",
    "created_at" : "Fri Oct 09 04:12:43 +0000 2020",
    "favorited" : false,
    "full_text" : "性別がバレるツイートしたくない派閥代表",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "31" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1314417446091014145",
    "id_str" : "1314417638097911808",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314417638097911808",
    "in_reply_to_status_id" : "1314417446091014145",
    "created_at" : "Fri Oct 09 04:09:20 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish 茶軸…あるけど、よってかない？(キメ顔)",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "0",
    "id_str" : "1314417307188260864",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314417307188260864",
    "created_at" : "Fri Oct 09 04:08:01 +0000 2020",
    "favorited" : false,
    "full_text" : "さみぃな、帰り電車とまらんとよいが…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "3", "14" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "31" ],
    "favorite_count" : "0",
    "id_str" : "1314417186383884292",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314417186383884292",
    "created_at" : "Fri Oct 09 04:07:32 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @hayasaka_c: TLに32歳児おるな....?",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "26" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1314415814083178496",
    "id_str" : "1314417108122398721",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314417108122398721",
    "in_reply_to_status_id" : "1314415814083178496",
    "created_at" : "Fri Oct 09 04:07:13 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta おっ、そうだな(諦め)🤦‍♀️",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "ni_gata",
        "screen_name" : "ni_gata",
        "indices" : [ "3", "11" ],
        "id_str" : "14110940",
        "id" : "14110940"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1314416758615207936",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314416758615207936",
    "created_at" : "Fri Oct 09 04:05:50 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @ni_gata: 先手「わたしディズニー超好きなんですよ〜〜〜〜🤗」\n\n後手「(キャラクターか？　アニメーションか？　実写映画か？　テーマパークか？　範囲が広すぎるぞ😓)……JR京葉線はお好きですか？」\n\n解説1「おっと初手からミスですか？」\n解説2「熟考しすぎて混乱し…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かがみん（加賀美 隆一:カガミ リュウイチ）",
        "screen_name" : "KagaminPower001",
        "indices" : [ "3", "19" ],
        "id_str" : "1116751929969766400",
        "id" : "1116751929969766400"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1314415952394514432",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314415952394514432",
    "created_at" : "Fri Oct 09 04:02:38 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @KagaminPower001: そしてなぜJavaが素晴らしいのかは、JavaならWebアプリが作れるから！ではなくて、オブジェクト指向開発ができるからなのだと思います。\n\nC言語の後継でありながら、ポインタやめたりガーベージコレクタ導入したりしたのも、すべてはオブジ…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "岸本悠太（きしもと・ゆうた）",
        "screen_name" : "luna_yuta",
        "indices" : [ "0", "10" ],
        "id_str" : "129578179",
        "id" : "129578179"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1314413610039271424",
    "id_str" : "1314415198002790403",
    "in_reply_to_user_id" : "129578179",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1314415198002790403",
    "in_reply_to_status_id" : "1314413610039271424",
    "created_at" : "Fri Oct 09 03:59:38 +0000 2020",
    "favorited" : false,
    "full_text" : "@luna_yuta しれっとした顔の変態バンドマン岸本悠太",
    "lang" : "ja",
    "in_reply_to_screen_name" : "luna_yuta",
    "in_reply_to_user_id_str" : "129578179"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/QQdQVYyMwF",
        "expanded_url" : "https://twitter.com/g76012889/status/1300382110205661184",
        "display_url" : "twitter.com/g76012889/stat…",
        "indices" : [ "43", "66" ]
      } ]
    },
    "display_text_range" : [ "0", "66" ],
    "favorite_count" : "1",
    "id_str" : "1300429739396530178",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300429739396530178",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 31 13:46:25 +0000 2020",
    "favorited" : false,
    "full_text" : "とはいえ、インターン先との繋がりもてたり、周りの人と会話できる環境が魅力的に見える… https://t.co/QQdQVYyMwF",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "kusaba.tomoaKING",
        "screen_name" : "stabarization",
        "indices" : [ "0", "14" ],
        "id_str" : "236868779",
        "id" : "236868779"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "48" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1300428153605599232",
    "id_str" : "1300429381987233793",
    "in_reply_to_user_id" : "236868779",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300429381987233793",
    "in_reply_to_status_id" : "1300428153605599232",
    "created_at" : "Mon Aug 31 13:45:00 +0000 2020",
    "favorited" : false,
    "full_text" : "@stabarization ご回答ありがとうございます！\nそれらはオンラインで行うのしょうか？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "stabarization",
    "in_reply_to_user_id_str" : "236868779"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "0",
    "id_str" : "1300427314426122241",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300427314426122241",
    "created_at" : "Mon Aug 31 13:36:47 +0000 2020",
    "favorited" : false,
    "full_text" : "バイト探してるって言ったらインターンを進められる闇",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "kusaba.tomoaKING",
        "screen_name" : "stabarization",
        "indices" : [ "0", "14" ],
        "id_str" : "236868779",
        "id" : "236868779"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "32" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1300401848545755136",
    "id_str" : "1300426837290483713",
    "in_reply_to_user_id" : "236868779",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300426837290483713",
    "in_reply_to_status_id" : "1300401848545755136",
    "created_at" : "Mon Aug 31 13:34:53 +0000 2020",
    "favorited" : false,
    "full_text" : "@stabarization ピアラーニングってどうやってます？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "stabarization",
    "in_reply_to_user_id_str" : "236868779"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "5" ],
    "favorite_count" : "0",
    "id_str" : "1300366822676426752",
    "truncated" : false,
    "retweet_count" : "1",
    "id" : "1300366822676426752",
    "created_at" : "Mon Aug 31 09:36:24 +0000 2020",
    "favorited" : false,
    "full_text" : "私の性別を",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "ぬちまるこ",
        "screen_name" : "nutimaruko",
        "indices" : [ "0", "11" ],
        "id_str" : "1216724186023919616",
        "id" : "1216724186023919616"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "29" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1300035442612420609",
    "id_str" : "1300049892044283905",
    "in_reply_to_user_id" : "1216724186023919616",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300049892044283905",
    "in_reply_to_status_id" : "1300035442612420609",
    "created_at" : "Sun Aug 30 12:37:02 +0000 2020",
    "favorited" : false,
    "full_text" : "@nutimaruko 歯ブラシで便所掃除してやりましょ🧹",
    "lang" : "ja",
    "in_reply_to_screen_name" : "nutimaruko",
    "in_reply_to_user_id_str" : "1216724186023919616"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "うら",
        "screen_name" : "mcguff1n",
        "indices" : [ "3", "12" ],
        "id_str" : "1033030946478419973",
        "id" : "1033030946478419973"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "43" ],
    "favorite_count" : "0",
    "id_str" : "1300049523234844672",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300049523234844672",
    "created_at" : "Sun Aug 30 12:35:34 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @mcguff1n: 3月に延期になってから半年もあったのに一体何してたんだ僕は",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "たけひと",
        "screen_name" : "takehitopistol",
        "indices" : [ "0", "15" ],
        "id_str" : "1215191126103097344",
        "id" : "1215191126103097344"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "35" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1299748251650813953",
    "id_str" : "1300049449465470979",
    "in_reply_to_user_id" : "1215191126103097344",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300049449465470979",
    "in_reply_to_status_id" : "1299748251650813953",
    "created_at" : "Sun Aug 30 12:35:17 +0000 2020",
    "favorited" : false,
    "full_text" : "@takehitopistol おなじく、ぜひに_:(´ཀ`」 ∠):",
    "lang" : "ja",
    "in_reply_to_screen_name" : "takehitopistol",
    "in_reply_to_user_id_str" : "1215191126103097344"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "13" ],
    "favorite_count" : "0",
    "id_str" : "1300049211019292672",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300049211019292672",
    "created_at" : "Sun Aug 30 12:34:20 +0000 2020",
    "favorited" : false,
    "full_text" : "piscine受けるなら？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "0",
    "id_str" : "1299928178232713216",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1299928178232713216",
    "created_at" : "Sun Aug 30 04:33:23 +0000 2020",
    "favorited" : false,
    "full_text" : "あれ？42って、VS使えるの？？？？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "50" ],
    "favorite_count" : "0",
    "id_str" : "1299927934275256321",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1299927934275256321",
    "created_at" : "Sun Aug 30 04:32:25 +0000 2020",
    "favorited" : false,
    "full_text" : "piscine前には自作が出来上がっていることを願いたい。\n\nいまだケースを発注していないが((((",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "32" ],
    "favorite_count" : "1",
    "id_str" : "1298921283514556417",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1298921283514556417",
    "created_at" : "Thu Aug 27 09:52:21 +0000 2020",
    "favorited" : false,
    "full_text" : "FIFO、LIFOはわかるんだけど、関連する語句が出てこない事件",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "86" ],
    "favorite_count" : "0",
    "id_str" : "1298440013022019585",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1298440013022019585",
    "created_at" : "Wed Aug 26 01:59:57 +0000 2020",
    "favorited" : false,
    "full_text" : "verilogって結局どうやってリアルな方の論理回路と対応させるのかわからずじまいであった。\n\n組み立て→シミュは分かったのに\n\nコロナのせいで実験がないからだよほんともう",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "53" ],
    "favorite_count" : "1",
    "id_str" : "1298192287298510848",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1298192287298510848",
    "created_at" : "Tue Aug 25 09:35:35 +0000 2020",
    "favorited" : false,
    "full_text" : "char *aまではなんとかなるのにどうしてchar **aは意味がわからなくなるんだろう\n\n理解しにくい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "16" ],
    "favorite_count" : "0",
    "id_str" : "1297940597500592128",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1297940597500592128",
    "created_at" : "Mon Aug 24 16:55:27 +0000 2020",
    "favorited" : false,
    "full_text" : "newとmallocの違いエモい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "17" ],
    "favorite_count" : "1",
    "id_str" : "1297940180884533252",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1297940180884533252",
    "created_at" : "Mon Aug 24 16:53:48 +0000 2020",
    "favorited" : false,
    "full_text" : "誰だよ動的メモリ確保とか作ったやつ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "豚婦村@42Tokyo9月piscine",
        "screen_name" : "ladyvierna",
        "indices" : [ "0", "11" ],
        "id_str" : "1196027845836824578",
        "id" : "1196027845836824578"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "64" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1297880546119258113",
    "id_str" : "1297886863143780356",
    "in_reply_to_user_id" : "1196027845836824578",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1297886863143780356",
    "in_reply_to_status_id" : "1297880546119258113",
    "created_at" : "Mon Aug 24 13:21:56 +0000 2020",
    "favorited" : false,
    "full_text" : "@ladyvierna それは本当に辛い…2週間もzoom…\nぜひ一緒に乗り切りましょう…\nよかったらDMでもいかがでしょう…😭",
    "lang" : "ja",
    "in_reply_to_screen_name" : "ladyvierna",
    "in_reply_to_user_id_str" : "1196027845836824578"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "129" ],
    "favorite_count" : "6",
    "id_str" : "1297738001980641282",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1297738001980641282",
    "created_at" : "Mon Aug 24 03:30:25 +0000 2020",
    "favorited" : false,
    "full_text" : "不躾だけども\n9月piscine生と敬語なしで、なんでも聞きあえる仲になりたい…😭\n\n学校ではそうやって友達と繋がってたら、友達と教え合うことで成績が向上したってことがあったので…😣\n\nLINEも大丈夫、敬語使わなくてもいいよって人リプかDMください🙇‍♀️",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "32" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1297670617118908416",
    "id_str" : "1297737491684814849",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1297737491684814849",
    "in_reply_to_status_id" : "1297670617118908416",
    "created_at" : "Mon Aug 24 03:28:23 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo ご対応ありがとうございます！！",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "3",
    "id_str" : "1297566453961388033",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1297566453961388033",
    "created_at" : "Sun Aug 23 16:08:44 +0000 2020",
    "favorited" : false,
    "full_text" : "9月piscine生と全く繋がれていない…\n\n焦りを感じる…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "40" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1296373687923273729",
    "id_str" : "1297565309067390976",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1297565309067390976",
    "in_reply_to_status_id" : "1296373687923273729",
    "created_at" : "Sun Aug 23 16:04:11 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo 初見失礼します、私です…_:(´ཀ`」 ∠):",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "3", "19" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "87" ],
    "favorite_count" : "0",
    "id_str" : "1297565181996761088",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1297565181996761088",
    "created_at" : "Sun Aug 23 16:03:41 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Kahorin_42Tokyo: slack招待も来てないし、9月piscineのリストにも入ってないんですけど💢って方がいましたらごめんなさい、教えてくださたいmm",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "豚婦村@42Tokyo9月piscine",
        "screen_name" : "ladyvierna",
        "indices" : [ "0", "11" ],
        "id_str" : "1196027845836824578",
        "id" : "1196027845836824578"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "90" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1297548037011542018",
    "id_str" : "1297548619420114944",
    "in_reply_to_user_id" : "1196027845836824578",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1297548619420114944",
    "in_reply_to_status_id" : "1297548037011542018",
    "created_at" : "Sun Aug 23 14:57:52 +0000 2020",
    "favorited" : false,
    "full_text" : "@ladyvierna ありがとうございます！フルコミットの予定です！9月は夏休みなのですが、最後の2日間、もしかしたら授業があるかもしれないです…。なんとかして乗り切りたいです…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "ladyvierna",
    "in_reply_to_user_id_str" : "1196027845836824578"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "豚婦村@42Tokyo9月piscine",
        "screen_name" : "ladyvierna",
        "indices" : [ "0", "11" ],
        "id_str" : "1196027845836824578",
        "id" : "1196027845836824578"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "134" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1296830102819319810",
    "id_str" : "1297365768762306560",
    "in_reply_to_user_id" : "1196027845836824578",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1297365768762306560",
    "in_reply_to_status_id" : "1296830102819319810",
    "created_at" : "Sun Aug 23 02:51:17 +0000 2020",
    "favorited" : false,
    "full_text" : "@ladyvierna ありがとうございます！私は情報工学専門です！\nそうですね…構造体も少し複雑ですよね…どんな問題が出るかはわからないですが、言われた時にできるように私も復習しようと思います😭\nわからないことや、疑問に思った時にDMとんでも大丈夫ですか…？🙇‍♀️",
    "lang" : "ja",
    "in_reply_to_screen_name" : "ladyvierna",
    "in_reply_to_user_id_str" : "1196027845836824578"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "豚婦村@42Tokyo9月piscine",
        "screen_name" : "ladyvierna",
        "indices" : [ "0", "11" ],
        "id_str" : "1196027845836824578",
        "id" : "1196027845836824578"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "112" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1296806637554958337",
    "id_str" : "1296812397760372736",
    "in_reply_to_user_id" : "1196027845836824578",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1296812397760372736",
    "in_reply_to_status_id" : "1296806637554958337",
    "created_at" : "Fri Aug 21 14:12:23 +0000 2020",
    "favorited" : false,
    "full_text" : "@ladyvierna おおおぉ、お声がけありがとうございます😊\n最近はもっぱら大学のレポートに追われてます…\nなんとか、昔やっていたCの内容を探しては復習していますが、正直ポインタがきついです…\n豚婦村さんはいかがですか？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "ladyvierna",
    "in_reply_to_user_id_str" : "1196027845836824578"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "35" ],
    "favorite_count" : "0",
    "id_str" : "1300846293082750979",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300846293082750979",
    "created_at" : "Tue Sep 01 17:21:39 +0000 2020",
    "favorited" : false,
    "full_text" : "FFでありたいので\n\n寂しさからフォローされてない人はフォローしない派",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "39" ],
    "favorite_count" : "1",
    "id_str" : "1300845320809492480",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300845320809492480",
    "created_at" : "Tue Sep 01 17:17:47 +0000 2020",
    "favorited" : false,
    "full_text" : "RTX3080とエアコン、ケトルでブレーカー落ちると思うの\n\nそれはこまるの。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "33" ],
    "favorite_count" : "0",
    "id_str" : "1300834147087167489",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300834147087167489",
    "created_at" : "Tue Sep 01 16:33:23 +0000 2020",
    "favorited" : false,
    "full_text" : "え、メールって登録のメールが来たらいいんだよね？\n違うの？？？？？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "60" ],
    "favorite_count" : "0",
    "id_str" : "1300803796398780416",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300803796398780416",
    "created_at" : "Tue Sep 01 14:32:47 +0000 2020",
    "favorited" : false,
    "full_text" : "Cの勉強ちょいちょいやりつつ\n\n明日からPyで何か作ろうと思う\n\n作った物ポートフォリオで直接体験できないか考えてみよう",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "大田区議会議員 おぎの稔（荻野稔）議員系Vtuber🏭✈️",
        "screen_name" : "ogino_otaku",
        "indices" : [ "3", "15" ],
        "id_str" : "186814852",
        "id" : "186814852"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/ogino_otaku/status/1300662404473184260/photo/1",
        "source_status_id" : "1300662404473184260",
        "indices" : [ "38", "61" ],
        "url" : "https://t.co/vsT2fhtHv0",
        "media_url" : "http://pbs.twimg.com/media/Egzhi7WVoAUKeyX.jpg",
        "id_str" : "1300662382566416389",
        "source_user_id" : "186814852",
        "id" : "1300662382566416389",
        "media_url_https" : "https://pbs.twimg.com/media/Egzhi7WVoAUKeyX.jpg",
        "source_user_id_str" : "186814852",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "2048",
            "h" : "1116",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "654",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "371",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1300662404473184260",
        "display_url" : "pic.twitter.com/vsT2fhtHv0"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "61" ],
    "favorite_count" : "0",
    "id_str" : "1300736789842284545",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300736789842284545",
    "possibly_sensitive" : false,
    "created_at" : "Tue Sep 01 10:06:31 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @ogino_otaku: 一般区議会議員事務所のキーボードですわ〜 https://t.co/vsT2fhtHv0",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/ogino_otaku/status/1300662404473184260/photo/1",
        "source_status_id" : "1300662404473184260",
        "indices" : [ "38", "61" ],
        "url" : "https://t.co/vsT2fhtHv0",
        "media_url" : "http://pbs.twimg.com/media/Egzhi7WVoAUKeyX.jpg",
        "id_str" : "1300662382566416389",
        "source_user_id" : "186814852",
        "id" : "1300662382566416389",
        "media_url_https" : "https://pbs.twimg.com/media/Egzhi7WVoAUKeyX.jpg",
        "source_user_id_str" : "186814852",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "2048",
            "h" : "1116",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "654",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "371",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1300662404473184260",
        "display_url" : "pic.twitter.com/vsT2fhtHv0"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "0",
    "id_str" : "1300736406143164418",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300736406143164418",
    "created_at" : "Tue Sep 01 10:05:00 +0000 2020",
    "favorited" : false,
    "full_text" : "やばい、キーボードを失念していた。\n\nその分の金がないまずい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "13" ],
    "favorite_count" : "0",
    "id_str" : "1300734253886439425",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300734253886439425",
    "created_at" : "Tue Sep 01 09:56:27 +0000 2020",
    "favorited" : false,
    "full_text" : "SATAケーブル買わなきゃ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "14" ],
    "favorite_count" : "0",
    "id_str" : "1300733886960336896",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300733886960336896",
    "created_at" : "Tue Sep 01 09:54:59 +0000 2020",
    "favorited" : false,
    "full_text" : "まぁ金曜合えば性別わかるだろ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/mv1NVpKJwY",
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1300366822676426752",
        "display_url" : "twitter.com/Hinata72279726…",
        "indices" : [ "34", "57" ]
      } ]
    },
    "display_text_range" : [ "0", "57" ],
    "favorite_count" : "1",
    "id_str" : "1300733651433390080",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300733651433390080",
    "possibly_sensitive" : false,
    "created_at" : "Tue Sep 01 09:54:03 +0000 2020",
    "favorited" : false,
    "full_text" : "大多数の皆様から頂いた意見により、私の性別は無くなりました。解散。 https://t.co/mv1NVpKJwY",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "40" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1300719882439335937",
    "id_str" : "1300721398315245568",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300721398315245568",
    "in_reply_to_status_id" : "1300719882439335937",
    "created_at" : "Tue Sep 01 09:05:22 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo うっ、私にも身に覚えが…_:(´ཀ`」 ∠):",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "34" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1300712621608374273",
    "id_str" : "1300719462157492224",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300719462157492224",
    "in_reply_to_status_id" : "1300712621608374273",
    "created_at" : "Tue Sep 01 08:57:40 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo (　ﾟдﾟ)！\n٩꒰๑･д･꒱۶♡",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "aokamoto＠9月piscine",
        "screen_name" : "atsu8823",
        "indices" : [ "0", "9" ],
        "id_str" : "1289220638117257217",
        "id" : "1289220638117257217"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "48" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1300702908103581696",
    "id_str" : "1300717063099408384",
    "in_reply_to_user_id" : "1289220638117257217",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300717063099408384",
    "in_reply_to_status_id" : "1300702908103581696",
    "created_at" : "Tue Sep 01 08:48:08 +0000 2020",
    "favorited" : false,
    "full_text" : "@atsu8823 あっちゃー😨\nここは、もう被ってる人たちのやる気を吸い取って頑張るしかない💪",
    "lang" : "ja",
    "in_reply_to_screen_name" : "atsu8823",
    "in_reply_to_user_id_str" : "1289220638117257217"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Hinata",
        "screen_name" : "Hinata72279726",
        "indices" : [ "3", "18" ],
        "id_str" : "1228559135093821441",
        "id" : "1228559135093821441"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "0",
    "id_str" : "1300681285715648517",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300681285715648517",
    "created_at" : "Tue Sep 01 06:25:58 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Hinata72279726: 私の性別を",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "54" ],
    "favorite_count" : "0",
    "id_str" : "1300680857347211264",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300680857347211264",
    "created_at" : "Tue Sep 01 06:24:16 +0000 2020",
    "favorited" : false,
    "full_text" : "PCケースとグラボとSSDかった\n\nあとはSATAケーブルだけなんだがチャージするタイプのカードだからだるい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Ma@9月piscine",
        "screen_name" : "1Dpi56jZCglsnnc",
        "indices" : [ "0", "16" ],
        "id_str" : "1275038994913390594",
        "id" : "1275038994913390594"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "29" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1300642187630137344",
    "id_str" : "1300664214625742848",
    "in_reply_to_user_id" : "1275038994913390594",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300664214625742848",
    "in_reply_to_status_id" : "1300642187630137344",
    "created_at" : "Tue Sep 01 05:18:08 +0000 2020",
    "favorited" : false,
    "full_text" : "@1Dpi56jZCglsnnc ここは気合で乗り切るしか",
    "lang" : "ja",
    "in_reply_to_screen_name" : "1Dpi56jZCglsnnc",
    "in_reply_to_user_id_str" : "1275038994913390594"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Ma@9月piscine",
        "screen_name" : "1Dpi56jZCglsnnc",
        "indices" : [ "0", "16" ],
        "id_str" : "1275038994913390594",
        "id" : "1275038994913390594"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "48" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1300521946585509893",
    "id_str" : "1300625293585969152",
    "in_reply_to_user_id" : "1275038994913390594",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300625293585969152",
    "in_reply_to_status_id" : "1300521946585509893",
    "created_at" : "Tue Sep 01 02:43:29 +0000 2020",
    "favorited" : false,
    "full_text" : "@1Dpi56jZCglsnnc そうきたか…\nでも人によっては仕事と両立とかの人もいるもんね…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "1Dpi56jZCglsnnc",
    "in_reply_to_user_id_str" : "1275038994913390594"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "もきょ【8月Piscine】",
        "screen_name" : "mokyo_97s",
        "indices" : [ "0", "10" ],
        "id_str" : "1288924432321273856",
        "id" : "1288924432321273856"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "48" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1300483205934411777",
    "id_str" : "1300625171036864513",
    "in_reply_to_user_id" : "1288924432321273856",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300625171036864513",
    "in_reply_to_status_id" : "1300483205934411777",
    "created_at" : "Tue Sep 01 02:42:59 +0000 2020",
    "favorited" : false,
    "full_text" : "@mokyo_97s ありがとうございます！！！！😭\n運を味方につけるところからスタートかな？🤔",
    "lang" : "ja",
    "in_reply_to_screen_name" : "mokyo_97s",
    "in_reply_to_user_id_str" : "1288924432321273856"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/EaI2yunZoS",
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1300049211019292672",
        "display_url" : "twitter.com/Hinata72279726…",
        "indices" : [ "59", "82" ]
      } ]
    },
    "display_text_range" : [ "0", "82" ],
    "favorite_count" : "0",
    "id_str" : "1300461892129890305",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300461892129890305",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 31 15:54:11 +0000 2020",
    "favorited" : false,
    "full_text" : "思ったより校舎で受ける人いたなぁ\n\nリモートの人と半々くらい\n\n金曜にはみんなと会えるから、その時はほんとたのむぜ🤤 https://t.co/EaI2yunZoS",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/LxWGUdBM9l",
        "expanded_url" : "https://twitter.com/mokyo_97s/status/1300123895064743937",
        "display_url" : "twitter.com/mokyo_97s/stat…",
        "indices" : [ "13", "36" ]
      } ]
    },
    "display_text_range" : [ "0", "36" ],
    "favorite_count" : "1",
    "id_str" : "1300461418274152448",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300461418274152448",
    "possibly_sensitive" : false,
    "created_at" : "Mon Aug 31 15:52:18 +0000 2020",
    "favorited" : false,
    "full_text" : "そういう仲間に出会いたい https://t.co/LxWGUdBM9l",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "KEI@邪エナガ@シミュレーションの世界に引きこもる",
        "screen_name" : "KeiKei47585517",
        "indices" : [ "3", "18" ],
        "id_str" : "1248867717634899971",
        "id" : "1248867717634899971"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "132" ],
    "favorite_count" : "0",
    "id_str" : "1300459946912264194",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300459946912264194",
    "created_at" : "Mon Aug 31 15:46:27 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @KeiKei47585517: ルータの実装は知らなかったけど、\nやっぱ、単純コピーは性能面から極力さけるっぽい。\n(コピー処理削減＆メモリ使用量削減)\n\nイーサネットフレームは結構長いからそこら辺の工夫がかなり効きそうです。\n(品質保証は大変そうだけど)",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "やましー@データ活用クラウドエンジニア＆筋トレ",
        "screen_name" : "yamashi18041",
        "indices" : [ "3", "16" ],
        "id_str" : "379232830",
        "id" : "379232830"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "44" ],
    "favorite_count" : "0",
    "id_str" : "1300459821762707456",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300459821762707456",
    "created_at" : "Mon Aug 31 15:45:57 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @yamashi18041: C言語でポインタの利用価値はこういうところにあります",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "11" ],
    "favorite_count" : "0",
    "id_str" : "1300458671504154624",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300458671504154624",
    "created_at" : "Mon Aug 31 15:41:23 +0000 2020",
    "favorited" : false,
    "full_text" : "テスト受けてから考えよ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "1",
    "id_str" : "1300457916193894400",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300457916193894400",
    "created_at" : "Mon Aug 31 15:38:23 +0000 2020",
    "favorited" : false,
    "full_text" : "最後の金曜日、大学の授業とかぶるという驚愕の事実",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "fuku",
        "screen_name" : "g76012889",
        "indices" : [ "0", "10" ],
        "id_str" : "1120305715908755456",
        "id" : "1120305715908755456"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "50" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1300445712379817984",
    "id_str" : "1300456226308808705",
    "in_reply_to_user_id" : "1120305715908755456",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300456226308808705",
    "in_reply_to_status_id" : "1300445712379817984",
    "created_at" : "Mon Aug 31 15:31:40 +0000 2020",
    "favorited" : false,
    "full_text" : "@g76012889 そうですよね…42と並行して自分でも勉強します…😭\n情報ありがとうございます！",
    "lang" : "ja",
    "in_reply_to_screen_name" : "g76012889",
    "in_reply_to_user_id_str" : "1120305715908755456"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "kusaba.tomoaKING",
        "screen_name" : "stabarization",
        "indices" : [ "0", "14" ],
        "id_str" : "236868779",
        "id" : "236868779"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "33" ],
    "favorite_count" : "2",
    "in_reply_to_status_id_str" : "1300432874705829889",
    "id_str" : "1300438995030044672",
    "in_reply_to_user_id" : "236868779",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300438995030044672",
    "in_reply_to_status_id" : "1300432874705829889",
    "created_at" : "Mon Aug 31 14:23:12 +0000 2020",
    "favorited" : false,
    "full_text" : "@stabarization すごく素敵…\n校舎開くといいですね…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "stabarization",
    "in_reply_to_user_id_str" : "236868779"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1302041403531251712",
    "id_str" : "1302213241599193088",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302213241599193088",
    "in_reply_to_status_id" : "1302041403531251712",
    "created_at" : "Sat Sep 05 11:53:25 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish 私、キーボード沼初心者の人です(☝︎ ՞ਊ ՞)☝︎",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "36" ],
    "favorite_count" : "0",
    "id_str" : "1302213080500248577",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302213080500248577",
    "created_at" : "Sat Sep 05 11:52:46 +0000 2020",
    "favorited" : false,
    "full_text" : "janome初めて使ったけど、無理してmecabにすることもないと悟った",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "26" ],
    "favorite_count" : "0",
    "id_str" : "1301946468874371072",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1301946468874371072",
    "created_at" : "Fri Sep 04 18:13:21 +0000 2020",
    "favorited" : false,
    "full_text" : "jdkないとandroid studioはいらんの草",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "やましー@データ活用クラウドエンジニア＆筋トレ",
        "screen_name" : "yamashi18041",
        "indices" : [ "3", "16" ],
        "id_str" : "379232830",
        "id" : "379232830"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "68" ],
    "favorite_count" : "0",
    "id_str" : "1301930744709705729",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1301930744709705729",
    "created_at" : "Fri Sep 04 17:10:52 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @yamashi18041: プログラマー、エンジニアの方にご質問\n\nズバリ去年の年収はいくら⁉️\n\n拡散して貰えると嬉しいです😌",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "59" ],
    "favorite_count" : "0",
    "id_str" : "1301930626384236544",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1301930626384236544",
    "created_at" : "Fri Sep 04 17:10:24 +0000 2020",
    "favorited" : false,
    "full_text" : "pyの環境構築ちょいだるだる\n\nサイドパッケージのインストール1からスタートなの草\n\npip打つだけの廃人になりかける",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "13" ],
    "favorite_count" : "0",
    "id_str" : "1301930416513806336",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1301930416513806336",
    "created_at" : "Fri Sep 04 17:09:34 +0000 2020",
    "favorited" : false,
    "full_text" : "ん？図らずも秋入学？？？？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "39" ],
    "favorite_count" : "0",
    "id_str" : "1301780790863253504",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1301780790863253504",
    "created_at" : "Fri Sep 04 07:15:01 +0000 2020",
    "favorited" : false,
    "full_text" : "はんだごて、そのほかもろもろないし…\n遊舎工房さんの工作室でやってみようかな…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1301756272291622912",
    "id_str" : "1301760755000205312",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1301760755000205312",
    "in_reply_to_status_id" : "1301756272291622912",
    "created_at" : "Fri Sep 04 05:55:24 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish これは普通のに戻れませんわ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "45" ],
    "favorite_count" : "0",
    "id_str" : "1301756629533122560",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1301756629533122560",
    "created_at" : "Fri Sep 04 05:39:00 +0000 2020",
    "favorited" : false,
    "full_text" : "今回の台風から雷が出て\n\n私の指がはんだごてになれば、買わなくて済むんじゃない？(謎推理)",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "40" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1301755584396406784",
    "id_str" : "1301756064199659520",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1301756064199659520",
    "in_reply_to_status_id" : "1301755584396406784",
    "created_at" : "Fri Sep 04 05:36:45 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish ああああですよなぁあああああ\nあの感じは癖になりそうな…w",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "10" ],
    "favorite_count" : "2",
    "in_reply_to_status_id_str" : "1301746236802740224",
    "id_str" : "1301752604490264579",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1301752604490264579",
    "in_reply_to_status_id" : "1301746236802740224",
    "created_at" : "Fri Sep 04 05:23:00 +0000 2020",
    "favorited" : false,
    "full_text" : "欲を言えば左右分離で",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "14" ],
    "favorite_count" : "0",
    "id_str" : "1301746236802740224",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1301746236802740224",
    "created_at" : "Fri Sep 04 04:57:42 +0000 2020",
    "favorited" : false,
    "full_text" : "自作キーボードが欲しい(欲)",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1301730797896888320/photo/1",
        "indices" : [ "4", "27" ],
        "url" : "https://t.co/vrYZUuJ8dO",
        "media_url" : "http://pbs.twimg.com/media/EhCtQhqU0AAVEBI.jpg",
        "id_str" : "1301730791735480320",
        "id" : "1301730791735480320",
        "media_url_https" : "https://pbs.twimg.com/media/EhCtQhqU0AAVEBI.jpg",
        "sizes" : {
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/vrYZUuJ8dO"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "27" ],
    "favorite_count" : "3",
    "id_str" : "1301730797896888320",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1301730797896888320",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 04 03:56:21 +0000 2020",
    "favorited" : false,
    "full_text" : "できた https://t.co/vrYZUuJ8dO",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1301730797896888320/photo/1",
        "indices" : [ "4", "27" ],
        "url" : "https://t.co/vrYZUuJ8dO",
        "media_url" : "http://pbs.twimg.com/media/EhCtQhqU0AAVEBI.jpg",
        "id_str" : "1301730791735480320",
        "id" : "1301730791735480320",
        "media_url_https" : "https://pbs.twimg.com/media/EhCtQhqU0AAVEBI.jpg",
        "sizes" : {
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/vrYZUuJ8dO"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "111" ],
    "favorite_count" : "0",
    "id_str" : "1301329007145705472",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1301329007145705472",
    "created_at" : "Thu Sep 03 01:19:47 +0000 2020",
    "favorited" : false,
    "full_text" : "戸建てを建てるのが当たり前だったのは私たちの祖父母の世代まで\n\n子供を産むのが当たり前だったのは私の親の世代まで\n\n私たちはきっと子供を産むのにもお金がかかって厳しいし、家を建てるのはよっぽどのことがないと無理なんだろうな",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "0",
    "id_str" : "1301195646808907776",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1301195646808907776",
    "created_at" : "Wed Sep 02 16:29:51 +0000 2020",
    "favorited" : false,
    "full_text" : "初めての株、軍資金はなけなしの10万\n\n何買う？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "56" ],
    "favorite_count" : "0",
    "id_str" : "1301195528030412800",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1301195528030412800",
    "created_at" : "Wed Sep 02 16:29:23 +0000 2020",
    "favorited" : false,
    "full_text" : "地方大学生\nNISA株の審査で、コロナ渦のリモート授業により住所が違うことを指摘される。\n\n未文書再提出たるたる",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "id_str" : "1301053094671740928",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1301053094671740928",
    "created_at" : "Wed Sep 02 07:03:24 +0000 2020",
    "favorited" : false,
    "full_text" : "して、イーサケーブルないことに気がついた。最悪",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "豚婦村@42Tokyo9月piscine",
        "screen_name" : "ladyvierna",
        "indices" : [ "0", "11" ],
        "id_str" : "1196027845836824578",
        "id" : "1196027845836824578"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "21" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1301030362164768768",
    "id_str" : "1301052271648677888",
    "in_reply_to_user_id" : "1196027845836824578",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1301052271648677888",
    "in_reply_to_status_id" : "1301030362164768768",
    "created_at" : "Wed Sep 02 07:00:08 +0000 2020",
    "favorited" : false,
    "full_text" : "@ladyvierna 😭❤️❤️❤️❤️",
    "lang" : "und",
    "in_reply_to_screen_name" : "ladyvierna",
    "in_reply_to_user_id_str" : "1196027845836824578"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "豚婦村@42Tokyo9月piscine",
        "screen_name" : "ladyvierna",
        "indices" : [ "0", "11" ],
        "id_str" : "1196027845836824578",
        "id" : "1196027845836824578"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "27" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1301021235078262785",
    "id_str" : "1301051503864475648",
    "in_reply_to_user_id" : "1196027845836824578",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1301051503864475648",
    "in_reply_to_status_id" : "1301021235078262785",
    "created_at" : "Wed Sep 02 06:57:05 +0000 2020",
    "favorited" : false,
    "full_text" : "@ladyvierna 😂❤️❤️❤️❤️❤️❤️❤️",
    "lang" : "und",
    "in_reply_to_screen_name" : "ladyvierna",
    "in_reply_to_user_id_str" : "1196027845836824578"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "IRONfe@42_9月Piscine",
        "screen_name" : "42_sept_join",
        "indices" : [ "0", "13" ],
        "id_str" : "1299903838409768962",
        "id" : "1299903838409768962"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "43" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1301000715427434496",
    "id_str" : "1301002339101192193",
    "in_reply_to_user_id" : "1299903838409768962",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1301002339101192193",
    "in_reply_to_status_id" : "1301000715427434496",
    "created_at" : "Wed Sep 02 03:41:43 +0000 2020",
    "favorited" : false,
    "full_text" : "@42_sept_join 登録できました！！！\nリンク貼り忘れたのかもしれませんね…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "42_sept_join",
    "in_reply_to_user_id_str" : "1299903838409768962"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IRONfe@42_9月Piscine",
        "screen_name" : "42_sept_join",
        "indices" : [ "0", "13" ],
        "id_str" : "1299903838409768962",
        "id" : "1299903838409768962"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1300998047623602176/photo/1",
        "indices" : [ "99", "122" ],
        "url" : "https://t.co/OCcR9ndPZn",
        "media_url" : "http://pbs.twimg.com/media/Eg4S0-CVoAAklTf.jpg",
        "id_str" : "1300998043571953664",
        "id" : "1300998043571953664",
        "media_url_https" : "https://pbs.twimg.com/media/Eg4S0-CVoAAklTf.jpg",
        "sizes" : {
          "medium" : {
            "w" : "640",
            "h" : "973",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "640",
            "h" : "973",
            "resize" : "fit"
          },
          "small" : {
            "w" : "447",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/OCcR9ndPZn"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "122" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1300994370758344705",
    "id_str" : "1300998047623602176",
    "in_reply_to_user_id" : "1299903838409768962",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300998047623602176",
    "in_reply_to_status_id" : "1300994370758344705",
    "possibly_sensitive" : false,
    "created_at" : "Wed Sep 02 03:24:40 +0000 2020",
    "favorited" : false,
    "full_text" : "@42_sept_join お返事ありがとうございます！\n私は3月に参加予定だったので、そのメールは2月に届いていたんですが\n\nURLがついていませんでした…\n誰かに聞いた方が良いのでしょうかね… https://t.co/OCcR9ndPZn",
    "lang" : "ja",
    "in_reply_to_screen_name" : "42_sept_join",
    "in_reply_to_user_id_str" : "1299903838409768962",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1300998047623602176/photo/1",
        "indices" : [ "99", "122" ],
        "url" : "https://t.co/OCcR9ndPZn",
        "media_url" : "http://pbs.twimg.com/media/Eg4S0-CVoAAklTf.jpg",
        "id_str" : "1300998043571953664",
        "id" : "1300998043571953664",
        "media_url_https" : "https://pbs.twimg.com/media/Eg4S0-CVoAAklTf.jpg",
        "sizes" : {
          "medium" : {
            "w" : "640",
            "h" : "973",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "640",
            "h" : "973",
            "resize" : "fit"
          },
          "small" : {
            "w" : "447",
            "h" : "680",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/OCcR9ndPZn"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1300981245459836928/photo/1",
        "indices" : [ "5", "28" ],
        "url" : "https://t.co/3Czwmoi1wK",
        "media_url" : "http://pbs.twimg.com/media/Eg4DiyMVgAAgA9q.jpg",
        "id_str" : "1300981238480601088",
        "id" : "1300981238480601088",
        "media_url_https" : "https://pbs.twimg.com/media/Eg4DiyMVgAAgA9q.jpg",
        "sizes" : {
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/3Czwmoi1wK"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "4",
    "id_str" : "1300981245459836928",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300981245459836928",
    "possibly_sensitive" : false,
    "created_at" : "Wed Sep 02 02:17:54 +0000 2020",
    "favorited" : false,
    "full_text" : "よしきた https://t.co/3Czwmoi1wK",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1300981245459836928/photo/1",
        "indices" : [ "5", "28" ],
        "url" : "https://t.co/3Czwmoi1wK",
        "media_url" : "http://pbs.twimg.com/media/Eg4DiyMVgAAgA9q.jpg",
        "id_str" : "1300981238480601088",
        "id" : "1300981238480601088",
        "media_url_https" : "https://pbs.twimg.com/media/Eg4DiyMVgAAgA9q.jpg",
        "sizes" : {
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/3Czwmoi1wK"
      }, {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1300981245459836928/photo/1",
        "indices" : [ "5", "28" ],
        "url" : "https://t.co/3Czwmoi1wK",
        "media_url" : "http://pbs.twimg.com/media/Eg4DiyTUMAEuRwL.jpg",
        "id_str" : "1300981238509875201",
        "id" : "1300981238509875201",
        "media_url_https" : "https://pbs.twimg.com/media/Eg4DiyTUMAEuRwL.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/3Czwmoi1wK"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/AdrQhNx7XQ",
        "expanded_url" : "https://twitter.com/42_sept_join/status/1300721411011391488",
        "display_url" : "twitter.com/42_sept_join/s…",
        "indices" : [ "27", "50" ]
      } ]
    },
    "display_text_range" : [ "0", "50" ],
    "favorite_count" : "1",
    "id_str" : "1300976640890085378",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300976640890085378",
    "possibly_sensitive" : false,
    "created_at" : "Wed Sep 02 01:59:36 +0000 2020",
    "favorited" : false,
    "full_text" : "これが来ていないので不安なんですが\n\n同じ人いますか https://t.co/AdrQhNx7XQ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "19" ],
    "favorite_count" : "1",
    "id_str" : "1300975521224781825",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1300975521224781825",
    "created_at" : "Wed Sep 02 01:55:09 +0000 2020",
    "favorited" : false,
    "full_text" : "勉強どころか今日の洗濯が終わっていない",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "43" ],
    "favorite_count" : "3",
    "id_str" : "1303848070988271616",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1303848070988271616",
    "created_at" : "Thu Sep 10 00:09:39 +0000 2020",
    "favorited" : false,
    "full_text" : "42始まってから、脳が興奮して無理やり寝ないと寝れない\n\nが、ちゃんと寝ないと夜に病む",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "なつのこ🍅",
        "screen_name" : "natsunoko24",
        "indices" : [ "3", "15" ],
        "id_str" : "915527141738950656",
        "id" : "915527141738950656"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1303221015661617153",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1303221015661617153",
    "created_at" : "Tue Sep 08 06:37:57 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @natsunoko24: アンジャッシュ児島さんのメイクシリーズ、男性が女性のメイクする動画にありがちな「こんなことやってんの！？」みたいな否定的な発言が一切なくて、\n「すごい、この一手間で変わるね」「違和感ないね」「可愛くなるね」「盛れました🤗」と全肯定してくれるから…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "hyudai",
        "screen_name" : "hayasaka_c",
        "indices" : [ "0", "11" ],
        "id_str" : "1294077412368556034",
        "id" : "1294077412368556034"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "42" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1303151114213142532",
    "id_str" : "1303186078023655425",
    "in_reply_to_user_id" : "1294077412368556034",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1303186078023655425",
    "in_reply_to_status_id" : "1303151114213142532",
    "created_at" : "Tue Sep 08 04:19:07 +0000 2020",
    "favorited" : false,
    "full_text" : "@hayasaka_c そうですよね…\nなかなか周りと歩調を合わせようとしてしまう…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "hayasaka_c",
    "in_reply_to_user_id_str" : "1294077412368556034"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "みう【9月Piscine】",
        "screen_name" : "imcosy33",
        "indices" : [ "0", "9" ],
        "id_str" : "1246852016657195009",
        "id" : "1246852016657195009"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1303160710885638144",
    "id_str" : "1303185849220124673",
    "in_reply_to_user_id" : "1246852016657195009",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1303185849220124673",
    "in_reply_to_status_id" : "1303160710885638144",
    "created_at" : "Tue Sep 08 04:18:13 +0000 2020",
    "favorited" : false,
    "full_text" : "@imcosy33 ああああああつらいいいい\n朝起きて陽が高いと罪悪感…w",
    "lang" : "ja",
    "in_reply_to_screen_name" : "imcosy33",
    "in_reply_to_user_id_str" : "1246852016657195009"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "59" ],
    "favorite_count" : "2",
    "id_str" : "1303143958642483206",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1303143958642483206",
    "created_at" : "Tue Sep 08 01:31:45 +0000 2020",
    "favorited" : false,
    "full_text" : "進めないのは自分だけじゃないと信じて\n今を楽しむことにした。\n\n進めないことより、誰とも協力できなくなった時が一番怖い",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "2",
    "id_str" : "1303143136965795840",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1303143136965795840",
    "created_at" : "Tue Sep 08 01:28:29 +0000 2020",
    "favorited" : false,
    "full_text" : "ロングスリーパーって短所すぎる\n\n目が覚めるの遅すぎて草",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "19" ],
    "favorite_count" : "0",
    "id_str" : "1302919252941221889",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302919252941221889",
    "created_at" : "Mon Sep 07 10:38:51 +0000 2020",
    "favorited" : false,
    "full_text" : "あれ？もしかして？解決が近い？？？？？",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "さにー",
        "screen_name" : "sunnylang2019",
        "indices" : [ "3", "17" ],
        "id_str" : "1199683722787713026",
        "id" : "1199683722787713026"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "43" ],
    "favorite_count" : "0",
    "id_str" : "1302919199136780288",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302919199136780288",
    "created_at" : "Mon Sep 07 10:38:38 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @sunnylang2019: 僕も全然わかりません！！泥臭くても頑張ります！！",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "さにー",
        "screen_name" : "sunnylang2019",
        "indices" : [ "0", "14" ],
        "id_str" : "1199683722787713026",
        "id" : "1199683722787713026"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1302912318301327361",
    "id_str" : "1302915862609891328",
    "in_reply_to_user_id" : "1199683722787713026",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302915862609891328",
    "in_reply_to_status_id" : "1302912318301327361",
    "created_at" : "Mon Sep 07 10:25:23 +0000 2020",
    "favorited" : false,
    "full_text" : "@sunnylang2019 おなじくー！！！！",
    "lang" : "ja",
    "in_reply_to_screen_name" : "sunnylang2019",
    "in_reply_to_user_id_str" : "1199683722787713026"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "1",
    "id_str" : "1302776396742144000",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302776396742144000",
    "created_at" : "Mon Sep 07 01:11:12 +0000 2020",
    "favorited" : false,
    "full_text" : "今起きたすごく不真面目なpiscine生は私です",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "にとろん( ᐛ ) ＜片サレ脳死極練組めたぁ",
        "screen_name" : "Nitrobenzene_ss",
        "indices" : [ "3", "19" ],
        "id_str" : "1042033217560182784",
        "id" : "1042033217560182784"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Nitrobenzene_ss/status/1302130924969054208/photo/1",
        "source_status_id" : "1302130924969054208",
        "indices" : [ "40", "63" ],
        "url" : "https://t.co/KDJsXZgNUF",
        "media_url" : "http://pbs.twimg.com/media/EhIZK_FVkAE-4L1.jpg",
        "id_str" : "1302130918786699265",
        "source_user_id" : "1042033217560182784",
        "id" : "1302130918786699265",
        "media_url_https" : "https://pbs.twimg.com/media/EhIZK_FVkAE-4L1.jpg",
        "source_user_id_str" : "1042033217560182784",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "720",
            "h" : "617",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "583",
            "resize" : "fit"
          },
          "large" : {
            "w" : "720",
            "h" : "617",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1302130924969054208",
        "display_url" : "pic.twitter.com/KDJsXZgNUF"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "63" ],
    "favorite_count" : "0",
    "id_str" : "1302606009853194240",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302606009853194240",
    "possibly_sensitive" : false,
    "created_at" : "Sun Sep 06 13:54:08 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Nitrobenzene_ss: なんだよこれwwwwwwwwwwww https://t.co/KDJsXZgNUF",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Nitrobenzene_ss/status/1302130924969054208/photo/1",
        "source_status_id" : "1302130924969054208",
        "indices" : [ "40", "63" ],
        "url" : "https://t.co/KDJsXZgNUF",
        "media_url" : "http://pbs.twimg.com/media/EhIZK_FVkAE-4L1.jpg",
        "id_str" : "1302130918786699265",
        "source_user_id" : "1042033217560182784",
        "id" : "1302130918786699265",
        "media_url_https" : "https://pbs.twimg.com/media/EhIZK_FVkAE-4L1.jpg",
        "source_user_id_str" : "1042033217560182784",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "720",
            "h" : "617",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "583",
            "resize" : "fit"
          },
          "large" : {
            "w" : "720",
            "h" : "617",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1302130924969054208",
        "display_url" : "pic.twitter.com/KDJsXZgNUF"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "144" ],
    "favorite_count" : "16",
    "id_str" : "1302605898385293320",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302605898385293320",
    "created_at" : "Sun Sep 06 13:53:42 +0000 2020",
    "favorited" : false,
    "full_text" : "恥を捨て、聴きまくる覚悟を明日から持つ予定なので\n\n飛び込みで質問きていーよー！って方、答えられるかわからないけど一緒に考えたい！と思ってくださる方\nいいねか、りぷか、DMいただければと思います。\n\n私の方は、答えられるか不明ですが一緒に考えたいのでぜひ皆様からのDMお待ちしております！",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Toshihiko Nakai",
        "screen_name" : "tophysics",
        "indices" : [ "3", "13" ],
        "id_str" : "1118967160951304192",
        "id" : "1118967160951304192"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "110" ],
    "favorite_count" : "0",
    "id_str" : "1302604042116292609",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302604042116292609",
    "created_at" : "Sun Sep 06 13:46:19 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @tophysics: これからPiscineを受ける人へのアドバイスとして、\n”人との縁はマジで大事にする”\n“どうしても分からないことは恥捨ててガンガン人に聞きまくる”\nこの2つがとても大事なことだと思います！",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "IT初級マン@9月piscine参加",
        "screen_name" : "IT45630742",
        "indices" : [ "3", "14" ],
        "id_str" : "1301507810392334337",
        "id" : "1301507810392334337"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "74" ],
    "favorite_count" : "0",
    "id_str" : "1302568858364985345",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302568858364985345",
    "created_at" : "Sun Sep 06 11:26:31 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @IT45630742: piscineオンライン参加だけど、たまに平日六本木に行くことは可能なのかな？金曜日以外にふらっと行けたらいいな..",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "45" ],
    "favorite_count" : "0",
    "id_str" : "1302567499813199873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302567499813199873",
    "created_at" : "Sun Sep 06 11:21:07 +0000 2020",
    "favorited" : false,
    "full_text" : "一日8時間で終わるなら学校と同じなんだが…\n\nタスク量が不明なので全くスケジュール立たんな",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1302566985465606146/photo/1",
        "indices" : [ "52", "75" ],
        "url" : "https://t.co/kzUqirmpNJ",
        "media_url" : "http://pbs.twimg.com/media/EhOlq4zVkAA0D3k.jpg",
        "id_str" : "1302566873461002240",
        "id" : "1302566873461002240",
        "media_url_https" : "https://pbs.twimg.com/media/EhOlq4zVkAA0D3k.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/kzUqirmpNJ"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "75" ],
    "favorite_count" : "3",
    "id_str" : "1302566985465606146",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302566985465606146",
    "possibly_sensitive" : false,
    "created_at" : "Sun Sep 06 11:19:04 +0000 2020",
    "favorited" : false,
    "full_text" : "昨日の1人のみ。\n今日は牛角で1人焼肉の予定。\n\npiscineが始まる前にうまいもんたくさんたべとく https://t.co/kzUqirmpNJ",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1302566985465606146/photo/1",
        "indices" : [ "52", "75" ],
        "url" : "https://t.co/kzUqirmpNJ",
        "media_url" : "http://pbs.twimg.com/media/EhOlq4zVkAA0D3k.jpg",
        "id_str" : "1302566873461002240",
        "id" : "1302566873461002240",
        "media_url_https" : "https://pbs.twimg.com/media/EhOlq4zVkAA0D3k.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/kzUqirmpNJ"
      }, {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1302566985465606146/photo/1",
        "indices" : [ "52", "75" ],
        "url" : "https://t.co/kzUqirmpNJ",
        "media_url" : "http://pbs.twimg.com/media/EhOlq40U8AMxiX_.jpg",
        "id_str" : "1302566873465155587",
        "id" : "1302566873465155587",
        "media_url_https" : "https://pbs.twimg.com/media/EhOlq40U8AMxiX_.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "1536",
            "h" : "2048",
            "resize" : "fit"
          },
          "small" : {
            "w" : "510",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "900",
            "h" : "1200",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/kzUqirmpNJ"
      }, {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1302566985465606146/photo/1",
        "indices" : [ "52", "75" ],
        "url" : "https://t.co/kzUqirmpNJ",
        "media_url" : "http://pbs.twimg.com/media/EhOlq41U4AILEeA.jpg",
        "id_str" : "1302566873469345794",
        "id" : "1302566873469345794",
        "media_url_https" : "https://pbs.twimg.com/media/EhOlq41U4AILEeA.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          },
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/kzUqirmpNJ"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ビタワン🐕脱サラちゃん&社畜ちゃん連載中☃️",
        "screen_name" : "vitaone_",
        "indices" : [ "3", "12" ],
        "id_str" : "602904575",
        "id" : "602904575"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/vitaone_/status/1302441389850898432/photo/1",
        "source_status_id" : "1302441389850898432",
        "indices" : [ "20", "43" ],
        "url" : "https://t.co/KYjQ6Lv4hF",
        "media_url" : "http://pbs.twimg.com/media/EhKjkDYVgAAx4KY.png",
        "id_str" : "1302283082041491456",
        "source_user_id" : "602904575",
        "id" : "1302283082041491456",
        "media_url_https" : "https://pbs.twimg.com/media/EhKjkDYVgAAx4KY.png",
        "source_user_id_str" : "602904575",
        "sizes" : {
          "large" : {
            "w" : "1400",
            "h" : "715",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "347",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "613",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1302441389850898432",
        "display_url" : "pic.twitter.com/KYjQ6Lv4hF"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "43" ],
    "favorite_count" : "0",
    "id_str" : "1302482084859002880",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302482084859002880",
    "possibly_sensitive" : false,
    "created_at" : "Sun Sep 06 05:41:42 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @vitaone_: 今日も１日 https://t.co/KYjQ6Lv4hF",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/vitaone_/status/1302441389850898432/photo/1",
        "source_status_id" : "1302441389850898432",
        "indices" : [ "20", "43" ],
        "url" : "https://t.co/KYjQ6Lv4hF",
        "media_url" : "http://pbs.twimg.com/media/EhKjkDYVgAAx4KY.png",
        "id_str" : "1302283082041491456",
        "source_user_id" : "602904575",
        "id" : "1302283082041491456",
        "media_url_https" : "https://pbs.twimg.com/media/EhKjkDYVgAAx4KY.png",
        "source_user_id_str" : "602904575",
        "sizes" : {
          "large" : {
            "w" : "1400",
            "h" : "715",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "347",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "613",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1302441389850898432",
        "display_url" : "pic.twitter.com/KYjQ6Lv4hF"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Machiko",
        "screen_name" : "machiko1012",
        "indices" : [ "0", "12" ],
        "id_str" : "1259464500631109632",
        "id" : "1259464500631109632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "48" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1302479288529158145",
    "id_str" : "1302480986748280833",
    "in_reply_to_user_id" : "1259464500631109632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302480986748280833",
    "in_reply_to_status_id" : "1302479288529158145",
    "created_at" : "Sun Sep 06 05:37:20 +0000 2020",
    "favorited" : false,
    "full_text" : "@machiko1012 ありがとうございます！(｀・∀・´)全力で校舎内探し回りますw🏃‍♀️",
    "lang" : "ja",
    "in_reply_to_screen_name" : "machiko1012",
    "in_reply_to_user_id_str" : "1259464500631109632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "22" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1302128163229560832",
    "id_str" : "1302260646558404610",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302260646558404610",
    "in_reply_to_status_id" : "1302128163229560832",
    "created_at" : "Sat Sep 05 15:01:47 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo 上に同じく",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "29" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1302255707136294914",
    "id_str" : "1302256324550377472",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302256324550377472",
    "in_reply_to_status_id" : "1302255707136294914",
    "created_at" : "Sat Sep 05 14:44:37 +0000 2020",
    "favorited" : false,
    "full_text" : "補足2\n今ならもれなく私の性別が判明する(誰も得はしない)",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1302256074574106625/photo/1",
        "indices" : [ "36", "59" ],
        "url" : "https://t.co/ISSTDsrriA",
        "media_url" : "http://pbs.twimg.com/media/EhKK_k2UcAksPAY.jpg",
        "id_str" : "1302256067091394569",
        "id" : "1302256067091394569",
        "media_url_https" : "https://pbs.twimg.com/media/EhKK_k2UcAksPAY.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1024",
            "h" : "576",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1024",
            "h" : "576",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/ISSTDsrriA"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "59" ],
    "favorite_count" : "0",
    "id_str" : "1302256074574106625",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302256074574106625",
    "possibly_sensitive" : false,
    "created_at" : "Sat Sep 05 14:43:37 +0000 2020",
    "favorited" : false,
    "full_text" : "机の反対側はベッドなので、寝転びながらamazon primeが見放題 https://t.co/ISSTDsrriA",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1302256074574106625/photo/1",
        "indices" : [ "36", "59" ],
        "url" : "https://t.co/ISSTDsrriA",
        "media_url" : "http://pbs.twimg.com/media/EhKK_k2UcAksPAY.jpg",
        "id_str" : "1302256067091394569",
        "id" : "1302256067091394569",
        "media_url_https" : "https://pbs.twimg.com/media/EhKK_k2UcAksPAY.jpg",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1024",
            "h" : "576",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1024",
            "h" : "576",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/ISSTDsrriA"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1302253373102542850",
    "id_str" : "1302255707136294914",
    "in_reply_to_user_id" : "1228559135093821441",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302255707136294914",
    "in_reply_to_status_id" : "1302253373102542850",
    "created_at" : "Sat Sep 05 14:42:09 +0000 2020",
    "favorited" : false,
    "full_text" : "補足\nいいねをおすと、ひなたは後者でその人を探して彷徨う…w",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Hinata72279726",
    "in_reply_to_user_id_str" : "1228559135093821441"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "48" ],
    "favorite_count" : "10",
    "id_str" : "1302253373102542850",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302253373102542850",
    "created_at" : "Sat Sep 05 14:32:53 +0000 2020",
    "favorited" : false,
    "full_text" : "金曜のpiscineで話しかけてくれる人をさりげなく募集してみるので\n\nぜひリプかdmかいいねで",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "25" ],
    "favorite_count" : "0",
    "id_str" : "1302252030547771392",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302252030547771392",
    "created_at" : "Sat Sep 05 14:27:33 +0000 2020",
    "favorited" : false,
    "full_text" : "Twitterは鋼のメンタルを持って続けるべきか…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "54" ],
    "favorite_count" : "2",
    "id_str" : "1302251669044867072",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1302251669044867072",
    "created_at" : "Sat Sep 05 14:26:07 +0000 2020",
    "favorited" : false,
    "full_text" : "piscineが始まったらどのくらいの時間コミットできるか測ってみないとまずいな。\n\n家事を考えるとなかなか",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "72" ],
    "favorite_count" : "1",
    "id_str" : "1304449435343052800",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304449435343052800",
    "created_at" : "Fri Sep 11 15:59:15 +0000 2020",
    "favorited" : false,
    "full_text" : "気になって寝れない症候群だから、気になった内容付箋に書いて張ってから寝ることにした\n\n明日同じ熱量は引き継げる自信はないが、忘れる心配はなくなる",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "じゃみー",
        "screen_name" : "zmallik2",
        "indices" : [ "0", "9" ],
        "id_str" : "1302766029177679873",
        "id" : "1302766029177679873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "13" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1304349770178207744",
    "id_str" : "1304350987474280448",
    "in_reply_to_user_id" : "1302766029177679873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304350987474280448",
    "in_reply_to_status_id" : "1304349770178207744",
    "created_at" : "Fri Sep 11 09:28:03 +0000 2020",
    "favorited" : false,
    "full_text" : "@zmallik2 です！",
    "lang" : "ja",
    "in_reply_to_screen_name" : "zmallik2",
    "in_reply_to_user_id_str" : "1302766029177679873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "じゃみー",
        "screen_name" : "zmallik2",
        "indices" : [ "0", "9" ],
        "id_str" : "1302766029177679873",
        "id" : "1302766029177679873"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "20" ],
    "favorite_count" : "2",
    "id_str" : "1304344600534892546",
    "in_reply_to_user_id" : "1302766029177679873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304344600534892546",
    "created_at" : "Fri Sep 11 09:02:40 +0000 2020",
    "favorited" : false,
    "full_text" : "@zmallik2 Hi mister!",
    "lang" : "en",
    "in_reply_to_screen_name" : "zmallik2",
    "in_reply_to_user_id_str" : "1302766029177679873"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "CGS @Surviving in Tokyo",
        "screen_name" : "CShimokura",
        "indices" : [ "0", "11" ],
        "id_str" : "1088079834704564225",
        "id" : "1088079834704564225"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "20" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1304301116046233602",
    "id_str" : "1304316934465314818",
    "in_reply_to_user_id" : "1088079834704564225",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304316934465314818",
    "in_reply_to_status_id" : "1304301116046233602",
    "created_at" : "Fri Sep 11 07:12:44 +0000 2020",
    "favorited" : false,
    "full_text" : "@CShimokura ！！！！\n猛者！",
    "lang" : "ja",
    "in_reply_to_screen_name" : "CShimokura",
    "in_reply_to_user_id_str" : "1088079834704564225"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "46" ],
    "favorite_count" : "6",
    "id_str" : "1304316805935063041",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304316805935063041",
    "created_at" : "Fri Sep 11 07:12:14 +0000 2020",
    "favorited" : false,
    "full_text" : "そう、実はpiscineで会いたいと思ってた人ほとんど会えんかったのよ\n\n悲しさあるよほんと",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "30" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1304316089044672513",
    "id_str" : "1304316641941938176",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304316641941938176",
    "in_reply_to_status_id" : "1304316089044672513",
    "created_at" : "Fri Sep 11 07:11:35 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo かほりんさんあってみたい🤭",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "0", "16" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1304310562113769473",
    "id_str" : "1304315011305668608",
    "in_reply_to_user_id" : "1280326248523169793",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304315011305668608",
    "in_reply_to_status_id" : "1304310562113769473",
    "created_at" : "Fri Sep 11 07:05:06 +0000 2020",
    "favorited" : false,
    "full_text" : "@Kahorin_42Tokyo ほんとすこw",
    "lang" : "ja",
    "in_reply_to_screen_name" : "Kahorin_42Tokyo",
    "in_reply_to_user_id_str" : "1280326248523169793"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "42" ],
    "favorite_count" : "9",
    "id_str" : "1304310304692559873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304310304692559873",
    "created_at" : "Fri Sep 11 06:46:24 +0000 2020",
    "favorited" : false,
    "full_text" : "やらなきゃいけないことが見えた。\n理解した。\n\n英会話教室に通えってんだろ？(違う)",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "かほりん",
        "screen_name" : "Kahorin_42Tokyo",
        "indices" : [ "3", "19" ],
        "id_str" : "1280326248523169793",
        "id" : "1280326248523169793"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "74" ],
    "favorite_count" : "0",
    "id_str" : "1304309129096298497",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304309129096298497",
    "created_at" : "Fri Sep 11 06:41:43 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Kahorin_42Tokyo: 仕事じゃないのにpc持ち歩いてる自分に草\n意識高い系ですか？いいえ、何が起きるか分からなくて不安なだけです",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "15" ],
    "favorite_count" : "2",
    "id_str" : "1304299261010485250",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304299261010485250",
    "created_at" : "Fri Sep 11 06:02:31 +0000 2020",
    "favorited" : false,
    "full_text" : "ご褒美に丸亀製麺の最新商品なう",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "みう【9月Piscine】",
        "screen_name" : "imcosy33",
        "indices" : [ "0", "9" ],
        "id_str" : "1246852016657195009",
        "id" : "1246852016657195009"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "16" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1304251014778888193",
    "id_str" : "1304298326418845696",
    "in_reply_to_user_id" : "1246852016657195009",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304298326418845696",
    "in_reply_to_status_id" : "1304251014778888193",
    "created_at" : "Fri Sep 11 05:58:48 +0000 2020",
    "favorited" : false,
    "full_text" : "@imcosy33 私がいたら…",
    "lang" : "ja",
    "in_reply_to_screen_name" : "imcosy33",
    "in_reply_to_user_id_str" : "1246852016657195009"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "16" ],
    "favorite_count" : "4",
    "id_str" : "1304298266582904832",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304298266582904832",
    "created_at" : "Fri Sep 11 05:58:34 +0000 2020",
    "favorited" : false,
    "full_text" : "私にしては頑張ったよ。面白かった",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "みう【9月Piscine】",
        "screen_name" : "imcosy33",
        "indices" : [ "0", "9" ],
        "id_str" : "1246852016657195009",
        "id" : "1246852016657195009"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1304232995805487104",
    "id_str" : "1304234603968753668",
    "in_reply_to_user_id" : "1246852016657195009",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304234603968753668",
    "in_reply_to_status_id" : "1304232995805487104",
    "created_at" : "Fri Sep 11 01:45:35 +0000 2020",
    "favorited" : false,
    "full_text" : "@imcosy33 グランドタワーみつからん？",
    "lang" : "ja",
    "in_reply_to_screen_name" : "imcosy33",
    "in_reply_to_user_id_str" : "1246852016657195009"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Ken@Piscine_Sep.",
        "screen_name" : "42KeN47",
        "indices" : [ "0", "8" ],
        "id_str" : "1302579062695579650",
        "id" : "1302579062695579650"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "13" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1304229552202289153",
    "id_str" : "1304231667930771456",
    "in_reply_to_user_id" : "1302579062695579650",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304231667930771456",
    "in_reply_to_status_id" : "1304229552202289153",
    "created_at" : "Fri Sep 11 01:33:55 +0000 2020",
    "favorited" : false,
    "full_text" : "@42KeN47 ほんそれ",
    "lang" : "ja",
    "in_reply_to_screen_name" : "42KeN47",
    "in_reply_to_user_id_str" : "1302579062695579650"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "22" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1304225297051471872",
    "id_str" : "1304231557008297984",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304231557008297984",
    "in_reply_to_status_id" : "1304225297051471872",
    "created_at" : "Fri Sep 11 01:33:29 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish すきぴ_(┐「ε:)_",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "3", "13" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      }, {
        "name" : "Hinata",
        "screen_name" : "Hinata72279726",
        "indices" : [ "15", "30" ],
        "id_str" : "1228559135093821441",
        "id" : "1228559135093821441"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "35" ],
    "favorite_count" : "0",
    "id_str" : "1304231338426335232",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304231338426335232",
    "created_at" : "Fri Sep 11 01:32:37 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @_unlimish: @Hinata72279726 うれぴ！",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "3",
    "id_str" : "1304221955579506689",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304221955579506689",
    "created_at" : "Fri Sep 11 00:55:20 +0000 2020",
    "favorited" : false,
    "full_text" : "わしじつはあんりみさんけっこうすこ🤤",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "3", "13" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "0",
    "id_str" : "1304221955579469824",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304221955579469824",
    "created_at" : "Fri Sep 11 00:55:20 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @_unlimish: + 内側に尿カテいれるとよさそう（マジレス）",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "3",
    "id_str" : "1304219644010487808",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304219644010487808",
    "created_at" : "Fri Sep 11 00:46:09 +0000 2020",
    "favorited" : false,
    "full_text" : "心臓潰れちゃうくらいドキドキなのは私",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "おばあちゃんでもできるプログラミング教室（ばあプロ）",
        "screen_name" : "Pythonist19",
        "indices" : [ "3", "15" ],
        "id_str" : "1268751606893260807",
        "id" : "1268751606893260807"
      } ],
      "urls" : [ {
        "url" : "https://t.co/y7EYH2jhfs",
        "expanded_url" : "http://draw.io",
        "display_url" : "draw.io",
        "indices" : [ "25", "48" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Pythonist19/status/1303894344307408896/photo/1",
        "source_status_id" : "1303894344307408896",
        "indices" : [ "55", "78" ],
        "url" : "https://t.co/O2e2jBE6gN",
        "media_url" : "http://pbs.twimg.com/media/Ehhc_YaU0AYBFfW.png",
        "id_str" : "1303894336078139398",
        "source_user_id" : "1268751606893260807",
        "id" : "1303894336078139398",
        "media_url_https" : "https://pbs.twimg.com/media/Ehhc_YaU0AYBFfW.png",
        "source_user_id_str" : "1268751606893260807",
        "sizes" : {
          "medium" : {
            "w" : "1200",
            "h" : "710",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1628",
            "h" : "963",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "402",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1303894344307408896",
        "display_url" : "pic.twitter.com/O2e2jBE6gN"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "78" ],
    "favorite_count" : "0",
    "id_str" : "1304208794004594688",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304208794004594688",
    "possibly_sensitive" : false,
    "created_at" : "Fri Sep 11 00:03:02 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Pythonist19: VS codeでhttps://t.co/y7EYH2jhfs使えたのね😁 https://t.co/O2e2jBE6gN",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Pythonist19/status/1303894344307408896/photo/1",
        "source_status_id" : "1303894344307408896",
        "indices" : [ "55", "78" ],
        "url" : "https://t.co/O2e2jBE6gN",
        "media_url" : "http://pbs.twimg.com/media/Ehhc_YaU0AYBFfW.png",
        "id_str" : "1303894336078139398",
        "source_user_id" : "1268751606893260807",
        "id" : "1303894336078139398",
        "media_url_https" : "https://pbs.twimg.com/media/Ehhc_YaU0AYBFfW.png",
        "source_user_id_str" : "1268751606893260807",
        "sizes" : {
          "medium" : {
            "w" : "1200",
            "h" : "710",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1628",
            "h" : "963",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "402",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1303894344307408896",
        "display_url" : "pic.twitter.com/O2e2jBE6gN"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "39" ],
    "favorite_count" : "4",
    "id_str" : "1304208736790040576",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304208736790040576",
    "created_at" : "Fri Sep 11 00:02:48 +0000 2020",
    "favorited" : false,
    "full_text" : "ちょ、怖い\n\nみんな強すぎてムキムキマッチョしかいなかったらどうしよう(物理)",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "☃",
        "screen_name" : "jpnykw",
        "indices" : [ "3", "10" ],
        "id_str" : "4802617320",
        "id" : "4802617320"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/jpnykw/status/1304027489300217857/photo/1",
        "source_status_id" : "1304027489300217857",
        "indices" : [ "17", "40" ],
        "url" : "https://t.co/MlgJDWFnVk",
        "media_url" : "http://pbs.twimg.com/media/EhjWFn8U0AANaSa.jpg",
        "id_str" : "1304027484233453568",
        "source_user_id" : "4802617320",
        "id" : "1304027484233453568",
        "media_url_https" : "https://pbs.twimg.com/media/EhjWFn8U0AANaSa.jpg",
        "source_user_id_str" : "4802617320",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "914",
            "h" : "915",
            "resize" : "fit"
          },
          "small" : {
            "w" : "679",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "914",
            "h" : "915",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1304027489300217857",
        "display_url" : "pic.twitter.com/MlgJDWFnVk"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "40" ],
    "favorite_count" : "0",
    "id_str" : "1304088770237480961",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304088770237480961",
    "possibly_sensitive" : false,
    "created_at" : "Thu Sep 10 16:06:06 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @jpnykw: これ好き https://t.co/MlgJDWFnVk",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/jpnykw/status/1304027489300217857/photo/1",
        "source_status_id" : "1304027489300217857",
        "indices" : [ "17", "40" ],
        "url" : "https://t.co/MlgJDWFnVk",
        "media_url" : "http://pbs.twimg.com/media/EhjWFn8U0AANaSa.jpg",
        "id_str" : "1304027484233453568",
        "source_user_id" : "4802617320",
        "id" : "1304027484233453568",
        "media_url_https" : "https://pbs.twimg.com/media/EhjWFn8U0AANaSa.jpg",
        "source_user_id_str" : "4802617320",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "914",
            "h" : "915",
            "resize" : "fit"
          },
          "small" : {
            "w" : "679",
            "h" : "680",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "914",
            "h" : "915",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1304027489300217857",
        "display_url" : "pic.twitter.com/MlgJDWFnVk"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "21" ],
    "favorite_count" : "4",
    "id_str" : "1304015001397506048",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304015001397506048",
    "created_at" : "Thu Sep 10 11:12:58 +0000 2020",
    "favorited" : false,
    "full_text" : "1日ずつ、できることが増えていくのが嬉しい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "21" ],
    "favorite_count" : "2",
    "id_str" : "1303864712493367296",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1303864712493367296",
    "created_at" : "Thu Sep 10 01:15:46 +0000 2020",
    "favorited" : false,
    "full_text" : "敬語が使えない病にかかった\n\n許せサスケ。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Machiko",
        "screen_name" : "machiko1012",
        "indices" : [ "0", "12" ],
        "id_str" : "1259464500631109632",
        "id" : "1259464500631109632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "18" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1303862565189988353",
    "id_str" : "1303864641886384128",
    "in_reply_to_user_id" : "1259464500631109632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1303864641886384128",
    "in_reply_to_status_id" : "1303862565189988353",
    "created_at" : "Thu Sep 10 01:15:29 +0000 2020",
    "favorited" : false,
    "full_text" : "@machiko1012 一緒だ…😨",
    "lang" : "ja",
    "in_reply_to_screen_name" : "machiko1012",
    "in_reply_to_user_id_str" : "1259464500631109632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "あんりみさん 💜 a.k.a Unlimish",
        "screen_name" : "_unlimish",
        "indices" : [ "0", "10" ],
        "id_str" : "1206502514897477632",
        "id" : "1206502514897477632"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "23" ],
    "favorite_count" : "0",
    "in_reply_to_status_id_str" : "1305621751951364096",
    "id_str" : "1305791963535269889",
    "in_reply_to_user_id" : "1206502514897477632",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305791963535269889",
    "in_reply_to_status_id" : "1305621751951364096",
    "created_at" : "Tue Sep 15 08:53:59 +0000 2020",
    "favorited" : false,
    "full_text" : "@_unlimish 耳が痛い_(┐「ε:)_",
    "lang" : "ja",
    "in_reply_to_screen_name" : "_unlimish",
    "in_reply_to_user_id_str" : "1206502514897477632"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "21" ],
    "favorite_count" : "0",
    "id_str" : "1305642437705039873",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305642437705039873",
    "created_at" : "Mon Sep 14 22:59:49 +0000 2020",
    "favorited" : false,
    "full_text" : "きょーは晴れてるし、ちょっとだけ気分がいい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "16" ],
    "favorite_count" : "0",
    "id_str" : "1305634867078520832",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305634867078520832",
    "created_at" : "Mon Sep 14 22:29:44 +0000 2020",
    "favorited" : false,
    "full_text" : "筋トレしたいけど、時間が取れない",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "10" ],
    "favorite_count" : "1",
    "id_str" : "1305634160434769920",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305634160434769920",
    "created_at" : "Mon Sep 14 22:26:56 +0000 2020",
    "favorited" : false,
    "full_text" : "おぉ、早く起きれる。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "0",
    "id_str" : "1305518159470837760",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305518159470837760",
    "created_at" : "Mon Sep 14 14:45:59 +0000 2020",
    "favorited" : false,
    "full_text" : "それは、りんごとそうでないものを比べるようなものですね。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "42" ],
    "favorite_count" : "0",
    "id_str" : "1305518073999364098",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305518073999364098",
    "created_at" : "Mon Sep 14 14:45:38 +0000 2020",
    "favorited" : false,
    "full_text" : "Ok Google\n\n早く寝るには？\n\n???「すみません、よくわかりませんでした」",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "48" ],
    "favorite_count" : "0",
    "id_str" : "1305448223570452480",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305448223570452480",
    "created_at" : "Mon Sep 14 10:08:05 +0000 2020",
    "favorited" : false,
    "full_text" : "フォトなとイカがやりたい。別にピシンに飽きたとかではないが、ちょっと違うベクトルの楽しさもほしい",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neverty7",
        "screen_name" : "Neverty7",
        "indices" : [ "3", "12" ],
        "id_str" : "1036738822808121345",
        "id" : "1036738822808121345"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Neverty7/status/1305348629549338626/photo/1",
        "source_status_id" : "1305348629549338626",
        "indices" : [ "39", "62" ],
        "url" : "https://t.co/phY5wfjXJW",
        "media_url" : "http://pbs.twimg.com/media/Eh2HqQrVkAAGppO.jpg",
        "id_str" : "1305348627108302848",
        "source_user_id" : "1036738822808121345",
        "id" : "1305348627108302848",
        "media_url_https" : "https://pbs.twimg.com/media/Eh2HqQrVkAAGppO.jpg",
        "source_user_id_str" : "1036738822808121345",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1920",
            "h" : "1080",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1305348629549338626",
        "display_url" : "pic.twitter.com/phY5wfjXJW"
      } ],
      "hashtags" : [ {
        "text" : "温泉ゴンテスト",
        "indices" : [ "30", "38" ]
      } ]
    },
    "display_text_range" : [ "0", "62" ],
    "favorite_count" : "0",
    "id_str" : "1305418037458161665",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305418037458161665",
    "possibly_sensitive" : false,
    "created_at" : "Mon Sep 14 08:08:08 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @Neverty7: フォートナイトで温泉作ったよ！\n#温泉ゴンテスト https://t.co/phY5wfjXJW",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Neverty7/status/1305348629549338626/photo/1",
        "source_status_id" : "1305348629549338626",
        "indices" : [ "39", "62" ],
        "url" : "https://t.co/phY5wfjXJW",
        "media_url" : "http://pbs.twimg.com/media/Eh2HqQrVkAAGppO.jpg",
        "id_str" : "1305348627108302848",
        "source_user_id" : "1036738822808121345",
        "id" : "1305348627108302848",
        "media_url_https" : "https://pbs.twimg.com/media/Eh2HqQrVkAAGppO.jpg",
        "source_user_id_str" : "1036738822808121345",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "675",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          },
          "large" : {
            "w" : "1920",
            "h" : "1080",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1305348629549338626",
        "display_url" : "pic.twitter.com/phY5wfjXJW"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ {
        "url" : "https://t.co/CZGT74fptF",
        "expanded_url" : "https://twitter.com/eucalyn_kb/status/1290643740864974848",
        "display_url" : "twitter.com/eucalyn_kb/sta…",
        "indices" : [ "92", "115" ]
      } ]
    },
    "display_text_range" : [ "0", "115" ],
    "favorite_count" : "0",
    "id_str" : "1305381361155338240",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305381361155338240",
    "possibly_sensitive" : false,
    "created_at" : "Mon Sep 14 05:42:23 +0000 2020",
    "favorited" : false,
    "full_text" : "これが欲しくてたまらないのだけれど、こてもなければニッパーもないので\n\nゆうしゃさんの作業場を借りに行こうかと思っている…\n\nたしか工房で組み立てるものは他社さんもokだったのよね… https://t.co/CZGT74fptF",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ゆかりキーボードファクトリー",
        "screen_name" : "eucalyn_kb",
        "indices" : [ "3", "14" ],
        "id_str" : "1248112788246900739",
        "id" : "1248112788246900739"
      } ],
      "urls" : [ {
        "url" : "https://t.co/tt6RUrj05Y",
        "expanded_url" : "https://eucalyn.shop/shop/kits/mint60-starter",
        "display_url" : "eucalyn.shop/shop/kits/mint…",
        "indices" : [ "87", "110" ]
      } ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/eucalyn_kb/status/1292051341733318656/photo/1",
        "source_status_id" : "1292051341733318656",
        "indices" : [ "111", "134" ],
        "url" : "https://t.co/2xTAAEMqVz",
        "media_url" : "http://pbs.twimg.com/media/Ee5J1v9VAAI2ZXc.jpg",
        "id_str" : "1292051330857500674",
        "source_user_id" : "1248112788246900739",
        "id" : "1292051330857500674",
        "media_url_https" : "https://pbs.twimg.com/media/Ee5J1v9VAAI2ZXc.jpg",
        "source_user_id_str" : "1248112788246900739",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "2048",
            "h" : "1155",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "677",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1292051341733318656",
        "display_url" : "pic.twitter.com/2xTAAEMqVz"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "134" ],
    "favorite_count" : "0",
    "id_str" : "1305381080627732480",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305381080627732480",
    "possibly_sensitive" : false,
    "created_at" : "Mon Sep 14 05:41:17 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @eucalyn_kb: 今年のお盆は引きこもって自作キーボード！！\n初心者向け「Mint60」のスターターセットはこちらです！\n新しいキーキャップも大好評発売中！\n\nhttps://t.co/tt6RUrj05Y https://t.co/2xTAAEMqVz",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/eucalyn_kb/status/1292051341733318656/photo/1",
        "source_status_id" : "1292051341733318656",
        "indices" : [ "111", "134" ],
        "url" : "https://t.co/2xTAAEMqVz",
        "media_url" : "http://pbs.twimg.com/media/Ee5J1v9VAAI2ZXc.jpg",
        "id_str" : "1292051330857500674",
        "source_user_id" : "1248112788246900739",
        "id" : "1292051330857500674",
        "media_url_https" : "https://pbs.twimg.com/media/Ee5J1v9VAAI2ZXc.jpg",
        "source_user_id_str" : "1248112788246900739",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "large" : {
            "w" : "2048",
            "h" : "1155",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "677",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "383",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1292051341733318656",
        "display_url" : "pic.twitter.com/2xTAAEMqVz"
      }, {
        "expanded_url" : "https://twitter.com/eucalyn_kb/status/1292051341733318656/photo/1",
        "source_status_id" : "1292051341733318656",
        "indices" : [ "111", "134" ],
        "url" : "https://t.co/2xTAAEMqVz",
        "media_url" : "http://pbs.twimg.com/media/Ee5J2CQU0AI7Uqs.jpg",
        "id_str" : "1292051335769018370",
        "source_user_id" : "1248112788246900739",
        "id" : "1292051335769018370",
        "media_url_https" : "https://pbs.twimg.com/media/Ee5J2CQU0AI7Uqs.jpg",
        "source_user_id_str" : "1248112788246900739",
        "sizes" : {
          "large" : {
            "w" : "2048",
            "h" : "1052",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "349",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "1200",
            "h" : "616",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1292051341733318656",
        "display_url" : "pic.twitter.com/2xTAAEMqVz"
      }, {
        "expanded_url" : "https://twitter.com/eucalyn_kb/status/1292051341733318656/photo/1",
        "source_status_id" : "1292051341733318656",
        "indices" : [ "111", "134" ],
        "url" : "https://t.co/2xTAAEMqVz",
        "media_url" : "http://pbs.twimg.com/media/Ee5J2OgUEAAh9xq.jpg",
        "id_str" : "1292051339057303552",
        "source_user_id" : "1248112788246900739",
        "id" : "1292051339057303552",
        "media_url_https" : "https://pbs.twimg.com/media/Ee5J2OgUEAAh9xq.jpg",
        "source_user_id_str" : "1248112788246900739",
        "sizes" : {
          "large" : {
            "w" : "2048",
            "h" : "1536",
            "resize" : "fit"
          },
          "small" : {
            "w" : "680",
            "h" : "510",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "medium" : {
            "w" : "1200",
            "h" : "900",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1292051341733318656",
        "display_url" : "pic.twitter.com/2xTAAEMqVz"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "ゆかりキーボードファクトリー",
        "screen_name" : "eucalyn_kb",
        "indices" : [ "3", "14" ],
        "id_str" : "1248112788246900739",
        "id" : "1248112788246900739"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "140" ],
    "favorite_count" : "0",
    "id_str" : "1305381037136986113",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305381037136986113",
    "created_at" : "Mon Sep 14 05:41:06 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @eucalyn_kb: 自作キーボード「Mint60」はこちらで購入可能です！ キースイッチ、キーキャップとプレート色をそれぞれ選択することで好きな見た目と打ち心地を選ぶことができます。\n現代人にとっての必須ツールといえばキーボード！ こだわればキリのない自作キーボード…",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "claw さかなくん ０",
        "screen_name" : "clawsakanakungg",
        "indices" : [ "3", "19" ],
        "id_str" : "1214230488975466496",
        "id" : "1214230488975466496"
      } ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/clawsakanakungg/status/1305105155201724416/photo/1",
        "source_status_id" : "1305105155201724416",
        "indices" : [ "39", "62" ],
        "url" : "https://t.co/3BEaQdtfC8",
        "media_url" : "http://pbs.twimg.com/media/EhyqOISU0AEsMTV.jpg",
        "id_str" : "1305105151749836801",
        "source_user_id" : "1214230488975466496",
        "id" : "1305105151749836801",
        "media_url_https" : "https://pbs.twimg.com/media/EhyqOISU0AEsMTV.jpg",
        "source_user_id_str" : "1214230488975466496",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "389",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "700",
            "h" : "400",
            "resize" : "fit"
          },
          "large" : {
            "w" : "700",
            "h" : "400",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1305105155201724416",
        "display_url" : "pic.twitter.com/3BEaQdtfC8"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "62" ],
    "favorite_count" : "0",
    "id_str" : "1305380918358503424",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305380918358503424",
    "possibly_sensitive" : false,
    "created_at" : "Mon Sep 14 05:40:38 +0000 2020",
    "favorited" : false,
    "full_text" : "RT @clawsakanakungg: これ覚えてるフォートナイト民いる？ https://t.co/3BEaQdtfC8",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/clawsakanakungg/status/1305105155201724416/photo/1",
        "source_status_id" : "1305105155201724416",
        "indices" : [ "39", "62" ],
        "url" : "https://t.co/3BEaQdtfC8",
        "media_url" : "http://pbs.twimg.com/media/EhyqOISU0AEsMTV.jpg",
        "id_str" : "1305105151749836801",
        "source_user_id" : "1214230488975466496",
        "id" : "1305105151749836801",
        "media_url_https" : "https://pbs.twimg.com/media/EhyqOISU0AEsMTV.jpg",
        "source_user_id_str" : "1214230488975466496",
        "sizes" : {
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "680",
            "h" : "389",
            "resize" : "fit"
          },
          "medium" : {
            "w" : "700",
            "h" : "400",
            "resize" : "fit"
          },
          "large" : {
            "w" : "700",
            "h" : "400",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "source_status_id_str" : "1305105155201724416",
        "display_url" : "pic.twitter.com/3BEaQdtfC8"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "13" ],
    "favorite_count" : "1",
    "id_str" : "1305374215789453313",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305374215789453313",
    "created_at" : "Mon Sep 14 05:14:00 +0000 2020",
    "favorited" : false,
    "full_text" : "怒涛の午前を経て飯を食う。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "urls" : [ ],
      "symbols" : [ ],
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1305273213564252160/photo/1",
        "indices" : [ "14", "37" ],
        "url" : "https://t.co/rxJecOrQQ4",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Eh1DELrU8AAB_iF.jpg",
        "id_str" : "1305273206140366848",
        "id" : "1305273206140366848",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Eh1DELrU8AAB_iF.jpg",
        "sizes" : {
          "medium" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "large" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          }
        },
        "type" : "photo",
        "display_url" : "pic.twitter.com/rxJecOrQQ4"
      } ],
      "hashtags" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "2",
    "id_str" : "1305273213564252160",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305273213564252160",
    "possibly_sensitive" : false,
    "created_at" : "Sun Sep 13 22:32:39 +0000 2020",
    "favorited" : false,
    "full_text" : "おぉ、早くに起きた気がする https://t.co/rxJecOrQQ4",
    "lang" : "ja",
    "extended_entities" : {
      "media" : [ {
        "expanded_url" : "https://twitter.com/Hinata72279726/status/1305273213564252160/photo/1",
        "indices" : [ "14", "37" ],
        "url" : "https://t.co/rxJecOrQQ4",
        "media_url" : "http://pbs.twimg.com/tweet_video_thumb/Eh1DELrU8AAB_iF.jpg",
        "id_str" : "1305273206140366848",
        "video_info" : {
          "aspect_ratio" : [ "16", "9" ],
          "variants" : [ {
            "bitrate" : "0",
            "content_type" : "video/mp4",
            "url" : "https://video.twimg.com/tweet_video/Eh1DELrU8AAB_iF.mp4"
          } ]
        },
        "id" : "1305273206140366848",
        "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/Eh1DELrU8AAB_iF.jpg",
        "sizes" : {
          "medium" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "thumb" : {
            "w" : "150",
            "h" : "150",
            "resize" : "crop"
          },
          "small" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          },
          "large" : {
            "w" : "480",
            "h" : "270",
            "resize" : "fit"
          }
        },
        "type" : "animated_gif",
        "display_url" : "pic.twitter.com/rxJecOrQQ4"
      } ]
    }
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "13" ],
    "favorite_count" : "0",
    "id_str" : "1305171018755895297",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305171018755895297",
    "created_at" : "Sun Sep 13 15:46:34 +0000 2020",
    "favorited" : false,
    "full_text" : "早く起きる生活実践したい。",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ {
        "name" : "Tatts",
        "screen_name" : "tats_odasii",
        "indices" : [ "0", "12" ],
        "id_str" : "1190869429854199808",
        "id" : "1190869429854199808"
      } ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "27" ],
    "favorite_count" : "1",
    "in_reply_to_status_id_str" : "1305053062495522822",
    "id_str" : "1305055752956985344",
    "in_reply_to_user_id" : "1190869429854199808",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305055752956985344",
    "in_reply_to_status_id" : "1305053062495522822",
    "created_at" : "Sun Sep 13 08:08:32 +0000 2020",
    "favorited" : false,
    "full_text" : "@tats_odasii 確かに、そげなものはないでな",
    "lang" : "ja",
    "in_reply_to_screen_name" : "tats_odasii",
    "in_reply_to_user_id_str" : "1190869429854199808"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "28" ],
    "favorite_count" : "8",
    "id_str" : "1305053159367168000",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305053159367168000",
    "created_at" : "Sun Sep 13 07:58:14 +0000 2020",
    "favorited" : false,
    "full_text" : "42入れたら、4年でいったん休学して本気でやってみようと",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "10" ],
    "favorite_count" : "3",
    "id_str" : "1305052693631705088",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305052693631705088",
    "created_at" : "Sun Sep 13 07:56:23 +0000 2020",
    "favorited" : false,
    "full_text" : "piscine≒院試",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "3" ],
    "favorite_count" : "0",
    "id_str" : "1305052281478373377",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305052281478373377",
    "created_at" : "Sun Sep 13 07:54:45 +0000 2020",
    "favorited" : false,
    "full_text" : "きゅけ",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "37" ],
    "favorite_count" : "1",
    "id_str" : "1305002253154050051",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1305002253154050051",
    "created_at" : "Sun Sep 13 04:35:57 +0000 2020",
    "favorited" : false,
    "full_text" : "自分が役に立ってると言う実感は、チームワークで非常に大切だと思った\n\nまる",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "50" ],
    "favorite_count" : "1",
    "id_str" : "1304827317856821249",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304827317856821249",
    "created_at" : "Sat Sep 12 17:00:49 +0000 2020",
    "favorited" : false,
    "full_text" : "早く寝ようと思った日は大抵早く寝れないのだ。\n\n疲れてハイになってて、まだおきていたい日はよく眠れる",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "24" ],
    "favorite_count" : "0",
    "id_str" : "1304743530120638464",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304743530120638464",
    "created_at" : "Sat Sep 12 11:27:53 +0000 2020",
    "favorited" : false,
    "full_text" : "8時間座ると流石に病むから、お酒で流すことにした",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "15" ],
    "favorite_count" : "1",
    "id_str" : "1304654220017070080",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304654220017070080",
    "created_at" : "Sat Sep 12 05:33:00 +0000 2020",
    "favorited" : false,
    "full_text" : "休まなくても楽しいの社畜みある",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "31" ],
    "favorite_count" : "3",
    "id_str" : "1304591980740009984",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304591980740009984",
    "created_at" : "Sat Sep 12 01:25:41 +0000 2020",
    "favorited" : false,
    "full_text" : "目が覚めて、時計を見た時の失望感をここ2〜3日毎回味わっている",
    "lang" : "ja"
  }
}, {
  "tweet" : {
    "retweeted" : false,
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "hashtags" : [ ],
      "symbols" : [ ],
      "user_mentions" : [ ],
      "urls" : [ ]
    },
    "display_text_range" : [ "0", "16" ],
    "favorite_count" : "1",
    "id_str" : "1304452508681527297",
    "truncated" : false,
    "retweet_count" : "0",
    "id" : "1304452508681527297",
    "created_at" : "Fri Sep 11 16:11:28 +0000 2020",
    "favorited" : false,
    "full_text" : "ダクソっぽい\n\n人間性捧げてる。",
    "lang" : "ja"
  }
} ]