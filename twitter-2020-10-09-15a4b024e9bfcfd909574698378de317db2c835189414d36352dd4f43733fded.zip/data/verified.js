window.YTD.verified.part0 = [ {
  "verified" : {
    "accountId" : "1228559135093821441",
    "verified" : false
  }
} ]