window.YTD.like.part0 = [ {
  "like" : {
    "tweetId" : "1314418819264258053",
    "fullText" : "悪い大人とか変態バンドマンとか言われたような気がするけどマリリンマンソン流しながら洗濯物干してる一般男性です",
    "expandedUrl" : "https://twitter.com/i/web/status/1314418819264258053"
  }
}, {
  "like" : {
    "tweetId" : "1314148235951259648",
    "fullText" : "【怖い。。。】\nzoomが勝手に国際電話登録されていて、24万円の請求かかった人がいたみたい。電話設定がなぜかアイルランドに。。\n\nそんなまさかー。と自分も確認したら。。。\n\nなんと僕のzoomもアイルランドになっちゃってました。。。\n\nあわわ。恐ろしい！\n皆さん、これは絶対にチェック！ https://t.co/XoRDb4u9uB",
    "expandedUrl" : "https://twitter.com/i/web/status/1314148235951259648"
  }
}, {
  "like" : {
    "tweetId" : "1314413610039271424",
    "fullText" : "変態バンドマンとかいるんだ、Piscine こわいな〜",
    "expandedUrl" : "https://twitter.com/i/web/status/1314413610039271424"
  }
}, {
  "like" : {
    "tweetId" : "1314176284419780608",
    "fullText" : "先手「わたしディズニー超好きなんですよ〜〜〜〜🤗」\n\n後手「(キャラクターか？　アニメーションか？　実写映画か？　テーマパークか？　範囲が広すぎるぞ😓)……JR京葉線はお好きですか？」\n\n解説1「おっと初手からミスですか？」\n解説2「熟考しすぎて混乱したようです」",
    "expandedUrl" : "https://twitter.com/i/web/status/1314176284419780608"
  }
}, {
  "like" : {
    "tweetId" : "1314230350336331776",
    "fullText" : "引用で失礼するのですがこのドア！！！ラプンツェルの塔のドア意識してる？！？！？\n私は！！！一度描いたことがある(戦ったことがある)ので！！！！見た瞬間！！！！！ぶったまげた！！！！！ https://t.co/8uGsva3zN1 https://t.co/m785TNW6NU",
    "expandedUrl" : "https://twitter.com/i/web/status/1314230350336331776"
  }
}, {
  "like" : {
    "tweetId" : "1314211637419667468",
    "fullText" : "あんりみさんに影響されて、ラムネ買って、ボリボリなう。\n(´・ω・｀)",
    "expandedUrl" : "https://twitter.com/i/web/status/1314211637419667468"
  }
}, {
  "like" : {
    "tweetId" : "1314388985309921280",
    "fullText" : "@Hinata72279726 @Kahorin_42Tokyo Undefined variable “i”",
    "expandedUrl" : "https://twitter.com/i/web/status/1314388985309921280"
  }
}, {
  "like" : {
    "tweetId" : "1314257148524683264",
    "fullText" : "これをインスタのリア垢に投稿したら高校の同級生の医学部に進学した男の子からこんなDMが…\n私は彼の知識のなさにショックを受けてこんなメモを送りました\n(以下ツリーに続く)\n#緊急避妊薬を薬局で #ピル\n#緊急避妊薬 #性教育 https://t.co/64atEa9AUF",
    "expandedUrl" : "https://twitter.com/i/web/status/1314257148524683264"
  }
}, {
  "like" : {
    "tweetId" : "1313713009269895170",
    "fullText" : "使用編はこちら：\n\n月経カップを使ってみた。【使用編】｜あんな @annaPHd9pj #note https://t.co/Uq8ajZcpTl",
    "expandedUrl" : "https://twitter.com/i/web/status/1313713009269895170"
  }
}, {
  "like" : {
    "tweetId" : "1314186776378966019",
    "fullText" : "令嬢になりたいよなー",
    "expandedUrl" : "https://twitter.com/i/web/status/1314186776378966019"
  }
}, {
  "like" : {
    "tweetId" : "1314177592254054400",
    "fullText" : "そしてなぜJavaが素晴らしいのかは、JavaならWebアプリが作れるから！ではなくて、オブジェクト指向開発ができるからなのだと思います。\n\nC言語の後継でありながら、ポインタやめたりガーベージコレクタ導入したりしたのも、すべてはオブジェクト指向開発に特化する為だけなのではと勘ぐってしまいます",
    "expandedUrl" : "https://twitter.com/i/web/status/1314177592254054400"
  }
}, {
  "like" : {
    "tweetId" : "1314195779523813376",
    "fullText" : "Qiita投稿したらいろいろコメントしてくれていいサービスだけれど、投稿したあとに病みそう",
    "expandedUrl" : "https://twitter.com/i/web/status/1314195779523813376"
  }
}, {
  "like" : {
    "tweetId" : "1314156019329581056",
    "fullText" : "@nuts_codie @Kahorin_42Tokyo こんな人間のプロフィール画像変えたごときに気づいてくれて絵なんかを褒めてくれて泣いた",
    "expandedUrl" : "https://twitter.com/i/web/status/1314156019329581056"
  }
}, {
  "like" : {
    "tweetId" : "1314158616170000384",
    "fullText" : "白子ポン酢が美味しいから、ついつい日本酒に手を出すよね。\n秋に収穫した米で作ってるらしーっすよ。コンビニであるのと違うやーつらしーっす。 https://t.co/nb1MxTgCjA",
    "expandedUrl" : "https://twitter.com/i/web/status/1314158616170000384"
  }
}, {
  "like" : {
    "tweetId" : "1314397246171930624",
    "fullText" : "Yann LeCun教授によるディープラーニングの授業（NY大、2020年春）の資料一式が公開された👏 スライドだけでなく、講義動画やJupyter Notebooks（PyTorch実装）も！ https://t.co/QkETDc8fEg",
    "expandedUrl" : "https://twitter.com/i/web/status/1314397246171930624"
  }
}, {
  "like" : {
    "tweetId" : "1314411623340077061",
    "fullText" : "クリエイター系メンヘラがPiscineを受けたら教祖になったはなし｜Unlimish @unlimish #note https://t.co/Lqy12H1KnR",
    "expandedUrl" : "https://twitter.com/i/web/status/1314411623340077061"
  }
}, {
  "like" : {
    "tweetId" : "1314382110136782849",
    "fullText" : "@Hinata72279726 whileで書こうとしたけど面倒だった",
    "expandedUrl" : "https://twitter.com/i/web/status/1314382110136782849"
  }
}, {
  "like" : {
    "tweetId" : "1314416579371659266",
    "fullText" : "TLに32歳児おるな....?",
    "expandedUrl" : "https://twitter.com/i/web/status/1314416579371659266"
  }
}, {
  "like" : {
    "tweetId" : "1314221970842509313",
    "fullText" : "Piscine受ける前AtCoderのビギナーズセレクションでひーひー言ってた人間がPiscineから帰ってきたらE問題解いてるの恐怖でしょ",
    "expandedUrl" : "https://twitter.com/i/web/status/1314221970842509313"
  }
}, {
  "like" : {
    "tweetId" : "1314338700210270209",
    "fullText" : "@Hinata72279726 はろーわーるど",
    "expandedUrl" : "https://twitter.com/i/web/status/1314338700210270209"
  }
}, {
  "like" : {
    "tweetId" : "1314093865826091008",
    "fullText" : "プログラミングは難しいことではない。やろうと思えば文系学生、大学院生でもできる。でも、「みんな、プログラマーになって就職しよう！」とか、今までの自分を捨てるのではなく、自分の知識をそのまま活かして、プログラミングをツールの一つとして自分の研究を効率化すればいいと思う。",
    "expandedUrl" : "https://twitter.com/i/web/status/1314093865826091008"
  }
}, {
  "like" : {
    "tweetId" : "1314417446091014145",
    "fullText" : "@Hinata72279726 この、キースイッチ気持ちよスギィ！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1314417446091014145"
  }
}, {
  "like" : {
    "tweetId" : "1314159029845848064",
    "fullText" : "〜ミッキーとミニーのディズニーシー巡り〜\nミッキーとミニーのディズニーシーに密着！\n\n明日から1日1枚載せていきます〜\n(コロナ関係なく通常運営のディズニーシーに設定しています！平日のアトラクション混雑を参考にしています✨) https://t.co/Jz7kJQPcbS",
    "expandedUrl" : "https://twitter.com/i/web/status/1314159029845848064"
  }
}, {
  "like" : {
    "tweetId" : "1314422113911021568",
    "fullText" : "@Hinata72279726 https://t.co/SBynWQMPbZ",
    "expandedUrl" : "https://twitter.com/i/web/status/1314422113911021568"
  }
}, {
  "like" : {
    "tweetId" : "1314357750911004673",
    "fullText" : "@Hinata72279726 ぁーよ",
    "expandedUrl" : "https://twitter.com/i/web/status/1314357750911004673"
  }
}, {
  "like" : {
    "tweetId" : "1314122239629914112",
    "fullText" : "あんりみのアイコンが変わってるー",
    "expandedUrl" : "https://twitter.com/i/web/status/1314122239629914112"
  }
}, {
  "like" : {
    "tweetId" : "1314058024860839936",
    "fullText" : "特徴量抽出して情報量ばり下げた上でGANでリアルタイム生成の流れえぐいな\n電話も「声に似たパターンの信号送ってる」って事で発想の根本は昔からあるけど、それ映像で実現するのやばすぎでしょ(語彙力) https://t.co/R1EsAthRfr",
    "expandedUrl" : "https://twitter.com/i/web/status/1314058024860839936"
  }
}, {
  "like" : {
    "tweetId" : "1314029067792912385",
    "fullText" : "@Hinata72279726 それがねー、そーゆうのあんまり関係なかったりするもんなんだな",
    "expandedUrl" : "https://twitter.com/i/web/status/1314029067792912385"
  }
}, {
  "like" : {
    "tweetId" : "1314047019627892737",
    "fullText" : "fizzbuzzを一瞬で組める...ほう？？",
    "expandedUrl" : "https://twitter.com/i/web/status/1314047019627892737"
  }
}, {
  "like" : {
    "tweetId" : "1314129752928653312",
    "fullText" : "担当していた動画配信ウェブサイトがりりーすされていた、わーい。",
    "expandedUrl" : "https://twitter.com/i/web/status/1314129752928653312"
  }
}, {
  "like" : {
    "tweetId" : "1314029282138615808",
    "fullText" : "@Hinata72279726 それにひなた気にするレベルじゃないから",
    "expandedUrl" : "https://twitter.com/i/web/status/1314029282138615808"
  }
}, {
  "like" : {
    "tweetId" : "1314170199965229062",
    "fullText" : "寒くなってきて走りに行く気持ちがどんどん小さくなっていく",
    "expandedUrl" : "https://twitter.com/i/web/status/1314170199965229062"
  }
}, {
  "like" : {
    "tweetId" : "1313350168649981952",
    "fullText" : "ゼニガメ #ポケモンと生活 https://t.co/OHvXiAu2S6",
    "expandedUrl" : "https://twitter.com/i/web/status/1313350168649981952"
  }
}, {
  "like" : {
    "tweetId" : "1314025570125017088",
    "fullText" : "@Hinata72279726 gitのURL良いね笑\nAR/MR的な感じで自分の隣にプロフ表示させておくってのもありだね。",
    "expandedUrl" : "https://twitter.com/i/web/status/1314025570125017088"
  }
}, {
  "like" : {
    "tweetId" : "1314131547105054720",
    "fullText" : "@Hinata72279726 Placing Marbles 解けてません！！！！！（解けました！！！加筆済み）｜hyudai @ydytast #note https://t.co/i7JKOjdRkf",
    "expandedUrl" : "https://twitter.com/i/web/status/1314131547105054720"
  }
}, {
  "like" : {
    "tweetId" : "1314056393511456769",
    "fullText" : "じゃあうち茶色かもしれない（） https://t.co/He5YHKeFLI",
    "expandedUrl" : "https://twitter.com/i/web/status/1314056393511456769"
  }
}, {
  "like" : {
    "tweetId" : "1314129993308332034",
    "fullText" : "Note書いたはいいけど駄文すぎて公表したくねえ....したんですけどね",
    "expandedUrl" : "https://twitter.com/i/web/status/1314129993308332034"
  }
}, {
  "like" : {
    "tweetId" : "1314027557621174273",
    "fullText" : "キャバクラって響き好みじゃないからラウンジにしよう。",
    "expandedUrl" : "https://twitter.com/i/web/status/1314027557621174273"
  }
}, {
  "like" : {
    "tweetId" : "1314069830157234177",
    "fullText" : "@Kahorin_42Tokyo お客として行く！\nお金落とす！",
    "expandedUrl" : "https://twitter.com/i/web/status/1314069830157234177"
  }
}, {
  "like" : {
    "tweetId" : "1314055504159625217",
    "fullText" : "@Hinata72279726 ふぉふぉい！",
    "expandedUrl" : "https://twitter.com/i/web/status/1314055504159625217"
  }
}, {
  "like" : {
    "tweetId" : "1314056972048584707",
    "fullText" : "@Hinata72279726 ブックオフで買った参考書にあるレベルだと割と瞬殺できるので私は茶色。解けなくても全部書くので茶色。",
    "expandedUrl" : "https://twitter.com/i/web/status/1314056972048584707"
  }
}, {
  "like" : {
    "tweetId" : "1314057266413277188",
    "fullText" : "@_unlimish @Hinata72279726 今日15時からこの問題やろうね＾＾\nhttps://t.co/vnfZlM7hIB",
    "expandedUrl" : "https://twitter.com/i/web/status/1314057266413277188"
  }
}, {
  "like" : {
    "tweetId" : "1314156159759118337",
    "fullText" : "そして、ひとりで白子ポン酢。そんな季節になりましたね。 https://t.co/gDwQvd3zpN",
    "expandedUrl" : "https://twitter.com/i/web/status/1314156159759118337"
  }
}, {
  "like" : {
    "tweetId" : "1314056947167948802",
    "fullText" : "@Hinata72279726 @hayasaka_c ゆーだい人力で解いたでしょ👀",
    "expandedUrl" : "https://twitter.com/i/web/status/1314056947167948802"
  }
}, {
  "like" : {
    "tweetId" : "1314056407818280961",
    "fullText" : "珍しく主婦みたいな時間過ごしたw\nさ、仕事行こ",
    "expandedUrl" : "https://twitter.com/i/web/status/1314056407818280961"
  }
}, {
  "like" : {
    "tweetId" : "1313740181858525184",
    "fullText" : "家帰って上見上げたらこれ https://t.co/O8x4SXuH3p",
    "expandedUrl" : "https://twitter.com/i/web/status/1313740181858525184"
  }
}, {
  "like" : {
    "tweetId" : "1313484695334793217",
    "fullText" : "@Kahorin_42Tokyo アドバイスありがとうございます😭\n良い仲間を作り上げられるよう頑張ります！",
    "expandedUrl" : "https://twitter.com/i/web/status/1313484695334793217"
  }
}, {
  "like" : {
    "tweetId" : "1314060457032912896",
    "fullText" : "こんな面白いサムネ、かつてあった？ https://t.co/ebbKnTGUNU",
    "expandedUrl" : "https://twitter.com/i/web/status/1314060457032912896"
  }
}, {
  "like" : {
    "tweetId" : "1313483170042589184",
    "fullText" : "@Angelin34118789 1次試験に関しては頑張れとしか言えないのですが、2次試験に関しては仲間集め先手必勝です。",
    "expandedUrl" : "https://twitter.com/i/web/status/1313483170042589184"
  }
}, {
  "like" : {
    "tweetId" : "1314030997780873216",
    "fullText" : "お金持ちのおじさんたち、女の子育てるの好きだから才能ありそうな子集めたら沢山お金使ってくれる説",
    "expandedUrl" : "https://twitter.com/i/web/status/1314030997780873216"
  }
}, {
  "like" : {
    "tweetId" : "1312224079148019713",
    "fullText" : "@Hinata72279726 Webテスト見たいな感じでメールが来る",
    "expandedUrl" : "https://twitter.com/i/web/status/1312224079148019713"
  }
}, {
  "like" : {
    "tweetId" : "1312071340157882369",
    "fullText" : "@luna_yuta @Hinata72279726 ひなた先輩がせっかく庇ってくれてるのに掘り返すのやめろ",
    "expandedUrl" : "https://twitter.com/i/web/status/1312071340157882369"
  }
}, {
  "like" : {
    "tweetId" : "1312170726334492672",
    "fullText" : "@nuts_codie 長女っていうのは大変なんですよ（当社比）",
    "expandedUrl" : "https://twitter.com/i/web/status/1312170726334492672"
  }
}, {
  "like" : {
    "tweetId" : "1312213772136714242",
    "fullText" : "@FPr4242 @Hinata72279726 フォーマットは頑張った、おつ",
    "expandedUrl" : "https://twitter.com/i/web/status/1312213772136714242"
  }
}, {
  "like" : {
    "tweetId" : "1312227849122713600",
    "fullText" : "@Hinata72279726 ひなたどころかりみっしゅもえふくんも入ってるしなんなら私のレベル+-1は全員ライバル視してる。",
    "expandedUrl" : "https://twitter.com/i/web/status/1312227849122713600"
  }
}, {
  "like" : {
    "tweetId" : "1311989839487619073",
    "fullText" : "サイバーオサレパンティ\n\n#FortniteCreative \n#フォートナイトクリエイティブ https://t.co/vmuw1mZcAd",
    "expandedUrl" : "https://twitter.com/i/web/status/1311989839487619073"
  }
}, {
  "like" : {
    "tweetId" : "1312231653171843072",
    "fullText" : "@_unlimish @Kahorin_42Tokyo @Hinata72279726 あ、交換するの？変数用意しとかなきゃ",
    "expandedUrl" : "https://twitter.com/i/web/status/1312231653171843072"
  }
}, {
  "like" : {
    "tweetId" : "1312223170208788482",
    "fullText" : "マジかお前",
    "expandedUrl" : "https://twitter.com/i/web/status/1312223170208788482"
  }
}, {
  "like" : {
    "tweetId" : "1312173813002432512",
    "fullText" : "piscineお疲れ様でした。\n皆さんに支えられて頑張れました。\nみんな大好きです！\n次は本科でまた共に勉強できるのを楽しみにしてます。",
    "expandedUrl" : "https://twitter.com/i/web/status/1312173813002432512"
  }
}, {
  "like" : {
    "tweetId" : "1312191384263118849",
    "fullText" : "@Hinata72279726 そうなのよぉ。\npiscineではピンクの恐竜でした🦕w",
    "expandedUrl" : "https://twitter.com/i/web/status/1312191384263118849"
  }
}, {
  "like" : {
    "tweetId" : "1312230901061836800",
    "fullText" : "@Hinata72279726 @luna_yuta 大丈夫だよー、女の子も扱えるよー",
    "expandedUrl" : "https://twitter.com/i/web/status/1312230901061836800"
  }
}, {
  "like" : {
    "tweetId" : "1312222088652967938",
    "fullText" : "@Hinata72279726 @FPr4242 過程も大事",
    "expandedUrl" : "https://twitter.com/i/web/status/1312222088652967938"
  }
}, {
  "like" : {
    "tweetId" : "1312213830944976896",
    "fullText" : "@Hinata72279726 @FPr4242 お前は一番頑張ったぞ",
    "expandedUrl" : "https://twitter.com/i/web/status/1312213830944976896"
  }
}, {
  "like" : {
    "tweetId" : "1312232041551859712",
    "fullText" : "@luna_yuta @_unlimish @Hinata72279726 とりあえずソートしてそのあとスワップしますか",
    "expandedUrl" : "https://twitter.com/i/web/status/1312232041551859712"
  }
}, {
  "like" : {
    "tweetId" : "1312145109819879424",
    "fullText" : "9月Piscine関係者の皆さん、一旦ありがとうございました〜！おつかれさまでした〜",
    "expandedUrl" : "https://twitter.com/i/web/status/1312145109819879424"
  }
}, {
  "like" : {
    "tweetId" : "1312227211781369856",
    "fullText" : "@Hinata72279726 悪いことでてくんの、なにそれ面白そう、ヘイ、グーグル！",
    "expandedUrl" : "https://twitter.com/i/web/status/1312227211781369856"
  }
}, {
  "like" : {
    "tweetId" : "1312228813762224130",
    "fullText" : "@Hinata72279726 後ろから刺してやろうとかではないよ！！仲間ではあるけど負けたくないとかはあるじゃん...？",
    "expandedUrl" : "https://twitter.com/i/web/status/1312228813762224130"
  }
}, {
  "like" : {
    "tweetId" : "1312231245422583810",
    "fullText" : "@Kahorin_42Tokyo @Hinata72279726 @luna_yuta お？スワッピングー？",
    "expandedUrl" : "https://twitter.com/i/web/status/1312231245422583810"
  }
}, {
  "like" : {
    "tweetId" : "1312192820644466688",
    "fullText" : "1ヶ月間C触ってきたしこれやってみますか。\n\n低レイヤを知りたい人のためのCコンパイラ作成入門 https://t.co/QwkVJMtbJl",
    "expandedUrl" : "https://twitter.com/i/web/status/1312192820644466688"
  }
}, {
  "like" : {
    "tweetId" : "1312225361409667073",
    "fullText" : "ライバル視してる人を昨日数えたら10人をゆうに超えていた。狂犬か何かな？",
    "expandedUrl" : "https://twitter.com/i/web/status/1312225361409667073"
  }
}, {
  "like" : {
    "tweetId" : "1312172658230915072",
    "fullText" : "@nuts_codie ママおつかれさま！今月からは沢山遊んであげよう〜！！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1312172658230915072"
  }
}, {
  "like" : {
    "tweetId" : "1312067801025187840",
    "fullText" : "@Hinata72279726 次は貢献するので！！！！！！！！！！！！！！！！！！！！！！！！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1312067801025187840"
  }
}, {
  "like" : {
    "tweetId" : "1312228491702624256",
    "fullText" : "今日も六本木！ これでネタバレから逃げる日々も終わる。\n……ってほどネタバレに合わなかったのは、僕が泳いでたからか売れてないからか？ https://t.co/nXq6F8NXDh",
    "expandedUrl" : "https://twitter.com/i/web/status/1312228491702624256"
  }
}, {
  "like" : {
    "tweetId" : "1312166989331263488",
    "fullText" : "固有値問題で出てくる話で、統計学で必要な理解の１つ！ https://t.co/6c5aW8hB93",
    "expandedUrl" : "https://twitter.com/i/web/status/1312166989331263488"
  }
}, {
  "like" : {
    "tweetId" : "1312226624188809216",
    "fullText" : "@Hinata72279726 子供の頃の過去の栄光残っちゃってるからもう遅いんだよなぁ、、、",
    "expandedUrl" : "https://twitter.com/i/web/status/1312226624188809216"
  }
}, {
  "like" : {
    "tweetId" : "1311970400704765954",
    "fullText" : "Piscine、終了\n皆様お疲れ様でした。そしてありがとう。",
    "expandedUrl" : "https://twitter.com/i/web/status/1311970400704765954"
  }
}, {
  "like" : {
    "tweetId" : "1312047963888259072",
    "fullText" : "9月ピシナーお疲れ様でしたー！！！🥳\n#42Tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1312047963888259072"
  }
}, {
  "like" : {
    "tweetId" : "1312032188678823938",
    "fullText" : "プールというより太平洋、環境は整いきっていない現実的な世界で、台風なんかも訪れますが、充実した世界が広がっています。\n本気で自分を変えたい人は、どこまででも変われると思いますよ。 https://t.co/cJp5QFcU38",
    "expandedUrl" : "https://twitter.com/i/web/status/1312032188678823938"
  }
}, {
  "like" : {
    "tweetId" : "1311970478215503872",
    "fullText" : "@FPr4242 おつかれ！！！！ありがとう！！！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1311970478215503872"
  }
}, {
  "like" : {
    "tweetId" : "1312021510488387585",
    "fullText" : "終わったーー！\nそして勉強したいことが増えたー。\nとにかく、素敵な方々と出会えて終始楽しく１ヶ月過ごせました。感謝。",
    "expandedUrl" : "https://twitter.com/i/web/status/1312021510488387585"
  }
}, {
  "like" : {
    "tweetId" : "1312036137121112065",
    "fullText" : "piscine、仕事、子育てと限界に挑戦してみようと思ったけど見事にメンタル3回崩壊しました。それでも続ける価値がある程、魅力的な環境と面白い人たちに出会えます。\n受けるか受けないか迷う人がいるなら、今なら「とりあえず挑戦してみなよ」って迷わず言うかな。 https://t.co/1Jl8iJAfEe",
    "expandedUrl" : "https://twitter.com/i/web/status/1312036137121112065"
  }
}, {
  "like" : {
    "tweetId" : "1312061277267611648",
    "fullText" : "娘に「1ヵ月寂しかった…」って抱きつかれた。\n次女じゃなくて長女の方😆",
    "expandedUrl" : "https://twitter.com/i/web/status/1312061277267611648"
  }
}, {
  "like" : {
    "tweetId" : "1312055893307998209",
    "fullText" : "@takehitopistol さっき帰宅してうんこした",
    "expandedUrl" : "https://twitter.com/i/web/status/1312055893307998209"
  }
}, {
  "like" : {
    "tweetId" : "1312031714684727297",
    "fullText" : "そうか、今宵は満月やったんやね。",
    "expandedUrl" : "https://twitter.com/i/web/status/1312031714684727297"
  }
}, {
  "like" : {
    "tweetId" : "1311973350499966977",
    "fullText" : "@hayasaka_c ここまで来れたのはひゅーさんのおかげみたいなところある🤝こちらこそありがとうだよ！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1311973350499966977"
  }
}, {
  "like" : {
    "tweetId" : "1311795033968766977",
    "fullText" : "aliExpress、無料配送なのマジバグだろ\nすごすぎる",
    "expandedUrl" : "https://twitter.com/i/web/status/1311795033968766977"
  }
}, {
  "like" : {
    "tweetId" : "1312050886810632194",
    "fullText" : "娘が将来プログラミングに触れる時に、ママも一緒に取り組めるように学習を続けたいとは思う。うん。",
    "expandedUrl" : "https://twitter.com/i/web/status/1312050886810632194"
  }
}, {
  "like" : {
    "tweetId" : "1312065241778286597",
    "fullText" : "@Hinata72279726 そうだよ！！一緒に合格するんだよ！！！👊",
    "expandedUrl" : "https://twitter.com/i/web/status/1312065241778286597"
  }
}, {
  "like" : {
    "tweetId" : "1312049776335024134",
    "fullText" : "@Hinata72279726 今日も試験中に萎えちゃったし...\nってかロケットリーグやろww",
    "expandedUrl" : "https://twitter.com/i/web/status/1312049776335024134"
  }
}, {
  "like" : {
    "tweetId" : "1312047419157213184",
    "fullText" : "@Hinata72279726 本科では僕の分も頼んだよ！^_^",
    "expandedUrl" : "https://twitter.com/i/web/status/1312047419157213184"
  }
}, {
  "like" : {
    "tweetId" : "1312046088715595777",
    "fullText" : "@Kahorin_42Tokyo ですよね。。。\nかほりんさんもゆっくり休んでください((｡´･ω･)｡´_ _))ﾍﾟｺﾘ",
    "expandedUrl" : "https://twitter.com/i/web/status/1312046088715595777"
  }
}, {
  "like" : {
    "tweetId" : "1312058265920958465",
    "fullText" : "@Hinata72279726 受かることを祈ろう！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1312058265920958465"
  }
}, {
  "like" : {
    "tweetId" : "1312041729680240640",
    "fullText" : "爆飲み必至。ゆーたさん何しとん。",
    "expandedUrl" : "https://twitter.com/i/web/status/1312041729680240640"
  }
}, {
  "like" : {
    "tweetId" : "1312039173658865666",
    "fullText" : "おつかれさまでした",
    "expandedUrl" : "https://twitter.com/i/web/status/1312039173658865666"
  }
}, {
  "like" : {
    "tweetId" : "1312049223479693312",
    "fullText" : "チームワークとかは楽しかった。いやほんと！\nレビューし合うっていうのはいいなって思ったし、ピシン生はいい人が多かった。仲間づくりにはいいなって",
    "expandedUrl" : "https://twitter.com/i/web/status/1312049223479693312"
  }
}, {
  "like" : {
    "tweetId" : "1312054740809728000",
    "fullText" : "@Hinata72279726 限りなくうんこ色に近いうんこ",
    "expandedUrl" : "https://twitter.com/i/web/status/1312054740809728000"
  }
}, {
  "like" : {
    "tweetId" : "1311886797194981379",
    "fullText" : "ニューヨークのフォトグラファー、Daniel Murtaghの作品。ヴェールを纏った神秘的な女性のポートレート。その静謐な空間は写真を越えて絵画と見紛うほど。\n©︎DanielMurtagh\nimages via : https://t.co/1N3eqwpy9f https://t.co/V2qm6uFs1p",
    "expandedUrl" : "https://twitter.com/i/web/status/1311886797194981379"
  }
}, {
  "like" : {
    "tweetId" : "1312048837020708864",
    "fullText" : "家に着いたからPiscineが終わった",
    "expandedUrl" : "https://twitter.com/i/web/status/1312048837020708864"
  }
}, {
  "like" : {
    "tweetId" : "1312026188626362369",
    "fullText" : "楽しかったからよし！！1か月で形成された交友関係じゃない",
    "expandedUrl" : "https://twitter.com/i/web/status/1312026188626362369"
  }
}, {
  "like" : {
    "tweetId" : "1312048603855089666",
    "fullText" : "風呂に入る元気がない...",
    "expandedUrl" : "https://twitter.com/i/web/status/1312048603855089666"
  }
}, {
  "like" : {
    "tweetId" : "1311534262206648326",
    "fullText" : "完成ー！！\n\n#コーヒーの日 \n#イラスト https://t.co/WZjXBLXm0y",
    "expandedUrl" : "https://twitter.com/i/web/status/1311534262206648326"
  }
}, {
  "like" : {
    "tweetId" : "1311845145352916992",
    "fullText" : "@Hinata72279726 気ずいてしまいました😁",
    "expandedUrl" : "https://twitter.com/i/web/status/1311845145352916992"
  }
}, {
  "like" : {
    "tweetId" : "1311984576927948800",
    "fullText" : "@42_tokyo 密度が濃い試験でとても苦しかったですが、同時に同じぐらいの楽しさもありました！　諦めずに続けることが大切だと強く感じました！　9月Piscine生の皆さんお疲れ様&amp;ありがとうございました❗️❗️",
    "expandedUrl" : "https://twitter.com/i/web/status/1311984576927948800"
  }
}, {
  "like" : {
    "tweetId" : "1312022994022100992",
    "fullText" : "Ruby 2.7.2 リリース https://t.co/xtPExp3jWE",
    "expandedUrl" : "https://twitter.com/i/web/status/1312022994022100992"
  }
}, {
  "like" : {
    "tweetId" : "1311926906095202305",
    "fullText" : "↑追加で説明なんですけど、「JISのエンターキー付けられないから無理！」って人のために1番右側の中２つのキーを犠牲にしてISOエンターを付けられるようにしています。。\n良かったらどうぞ…",
    "expandedUrl" : "https://twitter.com/i/web/status/1311926906095202305"
  }
}, {
  "like" : {
    "tweetId" : "1308015971722878976",
    "fullText" : "たまにはカフェイン取らないで早く寝よう",
    "expandedUrl" : "https://twitter.com/i/web/status/1308015971722878976"
  }
}, {
  "like" : {
    "tweetId" : "1306934916626571264",
    "fullText" : "死ぬほど悔しい",
    "expandedUrl" : "https://twitter.com/i/web/status/1306934916626571264"
  }
}, {
  "like" : {
    "tweetId" : "1312006875697700864",
    "fullText" : "私が最後まで頑張れたのはpiscine仲間のおかげ！\n何度も何度もめげそうになったけど、本当に楽しかったー！！！\nそしてこんな私を隣で支えてくれた従業員と家族にも、本当に本当に本当に感謝してる！！！\nありがとう！！！！！！ https://t.co/gwbG2Busk0",
    "expandedUrl" : "https://twitter.com/i/web/status/1312006875697700864"
  }
}, {
  "like" : {
    "tweetId" : "1311844803919835136",
    "fullText" : "今日の飲み代です https://t.co/Png2dcrbvn",
    "expandedUrl" : "https://twitter.com/i/web/status/1311844803919835136"
  }
}, {
  "like" : {
    "tweetId" : "1311976496693616640",
    "fullText" : "【Piscine受験者のみなさんへ】\n本日をもって9月のPiscineが終了しました。\n\n泳ぎ切った皆さんおつかれさまでした🔥\nネタバレは厳禁ですが、Piscineの感想は大歓迎です！\n\n次にPiscineを受験するひとへ一言お願いします👀\n#42tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1311976496693616640"
  }
}, {
  "like" : {
    "tweetId" : "1311845118203236353",
    "fullText" : "「Looooooooser!!」に対してのこの字幕センス良い https://t.co/vNdivFgTgX",
    "expandedUrl" : "https://twitter.com/i/web/status/1311845118203236353"
  }
}, {
  "like" : {
    "tweetId" : "1312028205889413120",
    "fullText" : "はい！\nついにワイに人権が！！！！付与されました！！！！！！！！\n健康で文化的な！！！最低限度の生活も！！送れるようになりました！！！！\nPiscineが終わりました！！！！！！！！！！！！！！！！！！！！！！！！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1312028205889413120"
  }
}, {
  "like" : {
    "tweetId" : "1311700857860190210",
    "fullText" : "０２天秤座。とても壮大な恩送りの日。短期スパンではなく、とても長期の遠い未来の自分へ贈る恩送り。優しさと思いやりをダレカに。",
    "expandedUrl" : "https://twitter.com/i/web/status/1311700857860190210"
  }
}, {
  "like" : {
    "tweetId" : "1312028473322467328",
    "fullText" : "この1ヶ月間シャワーしか浴びてなかったからめっちゃ久々に湯船につかった(ﾉ∀`)ﾀﾊｰ",
    "expandedUrl" : "https://twitter.com/i/web/status/1312028473322467328"
  }
}, {
  "like" : {
    "tweetId" : "1311639898303070209",
    "fullText" : "京コスメの舞妓夢コロン 金木犀がまんま金木犀でヤバイ！！金木犀の香り大好きで試しに買ってみたら、そのまんま金木犀！！\n変に甘ったるい匂いがなくて最高！\nしかも1000円台で手に入って、最高！ https://t.co/MXo4PVMQXr",
    "expandedUrl" : "https://twitter.com/i/web/status/1311639898303070209"
  }
}, {
  "like" : {
    "tweetId" : "1311845058853756928",
    "fullText" : "@Hinata72279726 2、3分前に入場してた",
    "expandedUrl" : "https://twitter.com/i/web/status/1311845058853756928"
  }
}, {
  "like" : {
    "tweetId" : "1312038252396773376",
    "fullText" : "@sleepyfox_42 まさにさっき似たようなこと話してた笑\n多くの人権奪われたよね。",
    "expandedUrl" : "https://twitter.com/i/web/status/1312038252396773376"
  }
}, {
  "like" : {
    "tweetId" : "1312029747317096449",
    "fullText" : "さて、いつも通り呑みに行きますか。",
    "expandedUrl" : "https://twitter.com/i/web/status/1312029747317096449"
  }
}, {
  "like" : {
    "tweetId" : "1308196344171868161",
    "fullText" : "朝の方が断然頭冴えることに今更気づいた",
    "expandedUrl" : "https://twitter.com/i/web/status/1308196344171868161"
  }
}, {
  "like" : {
    "tweetId" : "1311844595370610688",
    "fullText" : "あ、りみっしゅいた",
    "expandedUrl" : "https://twitter.com/i/web/status/1311844595370610688"
  }
}, {
  "like" : {
    "tweetId" : "1311835044994928641",
    "fullText" : "誰かFixしてプルリク作って https://t.co/vI1iZx5Rq7",
    "expandedUrl" : "https://twitter.com/i/web/status/1311835044994928641"
  }
}, {
  "like" : {
    "tweetId" : "1296685163359789056",
    "fullText" : "参加者のコミュニティのようなものがあったら是非招待お願いいたします🙇🏽‍♂️",
    "expandedUrl" : "https://twitter.com/i/web/status/1296685163359789056"
  }
}, {
  "like" : {
    "tweetId" : "1311666911524974595",
    "fullText" : "新作自作キーボードキット「ownly」の発表です！\n分割キーボードに慣れていない方も使いやすいように一般的なレイアウトを分割し、手を置いたときに自然な位置に来るように調整しています。\nご興味がある方はぜひ以下のフォームにご記入ください。\nhttps://t.co/Oy1OBmVp2i https://t.co/CVlgthkmdW",
    "expandedUrl" : "https://twitter.com/i/web/status/1311666911524974595"
  }
}, {
  "like" : {
    "tweetId" : "1311979793160695808",
    "fullText" : "次のPiscine生へ\n\n流れの強いプール、Piscineをお楽しみください。 https://t.co/Gm1ADvRw9m",
    "expandedUrl" : "https://twitter.com/i/web/status/1311979793160695808"
  }
}, {
  "like" : {
    "tweetId" : "1312027243875500032",
    "fullText" : "へそから栄養を摂れるデバイスを用意するといいよ https://t.co/TynSUoiveq",
    "expandedUrl" : "https://twitter.com/i/web/status/1312027243875500032"
  }
}, {
  "like" : {
    "tweetId" : "1311631286935515136",
    "fullText" : "いや、ね、大学の授業で求めてるのは、これじゃないんだよね？分かってる.... https://t.co/eJlNVFcygY",
    "expandedUrl" : "https://twitter.com/i/web/status/1311631286935515136"
  }
}, {
  "like" : {
    "tweetId" : "1311665627732484101",
    "fullText" : "42の合否が出るまでアカウント非公開にしておきます。こわこわ",
    "expandedUrl" : "https://twitter.com/i/web/status/1311665627732484101"
  }
}, {
  "like" : {
    "tweetId" : "1311621681350287360",
    "fullText" : "80年代アメリカ × 近未来\n今回はフォートナイト要素多めで作ってみました！\n\n#Fortnitecreative \n#フォートナイトクリエイティブ https://t.co/yko3XX0kyq",
    "expandedUrl" : "https://twitter.com/i/web/status/1311621681350287360"
  }
}, {
  "like" : {
    "tweetId" : "1311823058840084480",
    "fullText" : "頑張れさにー。最後まで諦めないで。",
    "expandedUrl" : "https://twitter.com/i/web/status/1311823058840084480"
  }
}, {
  "like" : {
    "tweetId" : "1311637781039386624",
    "fullText" : "本格的にしんどいので、仮眠する。\n……したくないー！ 課題を通したいー！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1311637781039386624"
  }
}, {
  "like" : {
    "tweetId" : "1311831428498362369",
    "fullText" : "@Hinata72279726 「変な髪色のやついるからそいつ目印な！」やめろやめろ",
    "expandedUrl" : "https://twitter.com/i/web/status/1311831428498362369"
  }
}, {
  "like" : {
    "tweetId" : "1311801449119051776",
    "fullText" : "全然寝てないから試験中寝そう",
    "expandedUrl" : "https://twitter.com/i/web/status/1311801449119051776"
  }
}, {
  "like" : {
    "tweetId" : "1311831500053118977",
    "fullText" : "@Hinata72279726 @luna_yuta 前回もその髪色のおかげで見つけられた",
    "expandedUrl" : "https://twitter.com/i/web/status/1311831500053118977"
  }
}, {
  "like" : {
    "tweetId" : "1311783401683255296",
    "fullText" : "「この1世紀余で犬を飼ってない大統領はトランプだけ」\nバイデン陣営、斜め上から攻めて来たな\nhttps://t.co/JwS6slWM4N",
    "expandedUrl" : "https://twitter.com/i/web/status/1311783401683255296"
  }
}, {
  "like" : {
    "tweetId" : "1311825738731909122",
    "fullText" : "@Hinata72279726 え？そうですが？？？？？？？？？",
    "expandedUrl" : "https://twitter.com/i/web/status/1311825738731909122"
  }
}, {
  "like" : {
    "tweetId" : "1311817542655045632",
    "fullText" : "今日はさすがに軽装にした\nノーメイクだし髪ボッサボサだしカラコン疲れるのでメガネだし疲れるので軽いスニーカー",
    "expandedUrl" : "https://twitter.com/i/web/status/1311817542655045632"
  }
}, {
  "like" : {
    "tweetId" : "1310609815190736897",
    "fullText" : "1000♥ありがとうございます！\nいろいろ作ってるのでよかったらフォローよろしくお願いします🙏 https://t.co/5zy0rQKBfy",
    "expandedUrl" : "https://twitter.com/i/web/status/1310609815190736897"
  }
}, {
  "like" : {
    "tweetId" : "1311697599628341250",
    "fullText" : "たくさんの人に教えさせてもらって、教えてもらったおかげで文系脳理解力雑魚の自分でもなんとかここまで来れたんだ\nやっぱり点数にしたいな",
    "expandedUrl" : "https://twitter.com/i/web/status/1311697599628341250"
  }
}, {
  "like" : {
    "tweetId" : "1311678017270243328",
    "fullText" : "コード弾くな、コード書け、はい。",
    "expandedUrl" : "https://twitter.com/i/web/status/1311678017270243328"
  }
}, {
  "like" : {
    "tweetId" : "1311627046280331265",
    "fullText" : "FINAL EXAMおわったー！\nこの4週間弱で大学4年間の10倍くらいコード書いたな、、、とにかく疲れた。\n明日試験の方頑張ってください！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1311627046280331265"
  }
}, {
  "like" : {
    "tweetId" : "1311580949918830593",
    "fullText" : "FORTNITE × pirates of the caribbean☠\n\nMAP CODE【3543-5702-1813】\n\nブラックパール号を再現しました！（内装も全て）\nフレンドたちと海賊気分を味わおう！\n\nRT &amp; フォローよろしくお願いします\n\n#FortniteCreativeArt\n#フォートナイトクリエイティブ \n#PiratesoftheCaribbean https://t.co/99QCW9sBgg",
    "expandedUrl" : "https://twitter.com/i/web/status/1311580949918830593"
  }
}, {
  "like" : {
    "tweetId" : "1311818801822883841",
    "fullText" : "@luna_yuta 体重……\n測ってねえ……\n怖え………",
    "expandedUrl" : "https://twitter.com/i/web/status/1311818801822883841"
  }
}, {
  "like" : {
    "tweetId" : "1311821479558877185",
    "fullText" : "とりあえず前髪だけクソだったのでアイロンデバッガーでfixした",
    "expandedUrl" : "https://twitter.com/i/web/status/1311821479558877185"
  }
}, {
  "like" : {
    "tweetId" : "1311830410309955585",
    "fullText" : "@Hinata72279726 渋谷のモアイ像とちゃうんやぞ",
    "expandedUrl" : "https://twitter.com/i/web/status/1311830410309955585"
  }
}, {
  "like" : {
    "tweetId" : "1311824997640364035",
    "fullText" : "四天王倒してくる",
    "expandedUrl" : "https://twitter.com/i/web/status/1311824997640364035"
  }
}, {
  "like" : {
    "tweetId" : "1311807699114315776",
    "fullText" : "@nuts_codie 飛行機の長時間フライトとかでも使ええる技だけど、貧乏ゆすりみたいに、かかとをアップダウンすると予防になるよー",
    "expandedUrl" : "https://twitter.com/i/web/status/1311807699114315776"
  }
}, {
  "like" : {
    "tweetId" : "1311821326676492288",
    "fullText" : "いざ、最終試験へ\n\n第一関門の息子の登園と電車乗るとこまでクリア",
    "expandedUrl" : "https://twitter.com/i/web/status/1311821326676492288"
  }
}, {
  "like" : {
    "tweetId" : "1311808056989085697",
    "fullText" : "朝、この時間に電車に乗るということだけでも、新鮮な気持ち。\n今日、終わるはずなのに、今日から何かが始まる気持ち。",
    "expandedUrl" : "https://twitter.com/i/web/status/1311808056989085697"
  }
}, {
  "like" : {
    "tweetId" : "1311830649645363200",
    "fullText" : "@Hinata72279726 やったぁ✌️✌️✌️✌️✌️✌️✌️✌️",
    "expandedUrl" : "https://twitter.com/i/web/status/1311830649645363200"
  }
}, {
  "like" : {
    "tweetId" : "1311824632807186432",
    "fullText" : "行ってきまー。\n|*ﾟДﾟ)ﾉｲｯﾃｸﾙｧ!!!!\n\n今日で最後です。\nPiscuneの皆さんお世話になりました。\n(´・ω・｀)\n\n朝方の4:00までやってたので、\n起きれてよかった。",
    "expandedUrl" : "https://twitter.com/i/web/status/1311824632807186432"
  }
}, {
  "like" : {
    "tweetId" : "1311125108057014273",
    "fullText" : "情緒不安定もええところ",
    "expandedUrl" : "https://twitter.com/i/web/status/1311125108057014273"
  }
}, {
  "like" : {
    "tweetId" : "1311479814906236928",
    "fullText" : "@FPr4242 まだ！！！終わってない！！！！！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1311479814906236928"
  }
}, {
  "like" : {
    "tweetId" : "1311101705774194688",
    "fullText" : "やりたいことが多すぎてやりたいこと忘れる",
    "expandedUrl" : "https://twitter.com/i/web/status/1311101705774194688"
  }
}, {
  "like" : {
    "tweetId" : "1310794471152312320",
    "fullText" : "@Hinata72279726 おめでとうございます🖐🖐🖐🖐🖐",
    "expandedUrl" : "https://twitter.com/i/web/status/1310794471152312320"
  }
}, {
  "like" : {
    "tweetId" : "1310751962124570624",
    "fullText" : "@Hinata72279726 めめめめー",
    "expandedUrl" : "https://twitter.com/i/web/status/1310751962124570624"
  }
}, {
  "like" : {
    "tweetId" : "1310708806721003520",
    "fullText" : "現在のところ、EpicとAppleの間での戦いすべてが、最大で2021年末まで続く継続的な訴訟です。 \n#Fortnite https://t.co/byvfLwDDWw",
    "expandedUrl" : "https://twitter.com/i/web/status/1310708806721003520"
  }
}, {
  "like" : {
    "tweetId" : "1310911872422486016",
    "fullText" : "過去1で楽しいです。",
    "expandedUrl" : "https://twitter.com/i/web/status/1310911872422486016"
  }
}, {
  "like" : {
    "tweetId" : "1311238970399846400",
    "fullText" : "Fortniteのジョンジーをディグダに\n転生させました❗　️🙇‍♂️RT🙇‍♂️ https://t.co/9umRmiVD5j",
    "expandedUrl" : "https://twitter.com/i/web/status/1311238970399846400"
  }
}, {
  "like" : {
    "tweetId" : "1310777456194801666",
    "fullText" : "凄い学習サービスあった・・\n\n・今のところ無料\n\n・Udemy講師による動画教材\n\n・現時点でPHP/SQL/Git/Dockerまで学べる。今後はLaravel/Awsが追加予定\n\n動画を一通り見ましたが、完成度がかなり高いです。\n\nPHPを勉強したい人は高額スクールよりここで勉強しましょう\n\nhttps://t.co/aHjpAEzWF6",
    "expandedUrl" : "https://twitter.com/i/web/status/1310777456194801666"
  }
}, {
  "like" : {
    "tweetId" : "1311122378286489601",
    "fullText" : "これが強い人が強い(真理) https://t.co/mGjc19rNvW",
    "expandedUrl" : "https://twitter.com/i/web/status/1311122378286489601"
  }
}, {
  "like" : {
    "tweetId" : "1311121116476223488",
    "fullText" : "1時間くらい仮眠す",
    "expandedUrl" : "https://twitter.com/i/web/status/1311121116476223488"
  }
}, {
  "like" : {
    "tweetId" : "1310493042697105408",
    "fullText" : "@luna_yuta ほんまに狂ってる",
    "expandedUrl" : "https://twitter.com/i/web/status/1310493042697105408"
  }
}, {
  "like" : {
    "tweetId" : "1310996438801764352",
    "fullText" : "マジでこのタイミングで壊れるワイの身体〜〜〜〜〜〜〜〜〜〜〜〜〜〜許せない",
    "expandedUrl" : "https://twitter.com/i/web/status/1310996438801764352"
  }
}, {
  "like" : {
    "tweetId" : "1310716919431929856",
    "fullText" : "ワイが健康で文化的な最低限度の生活を送れるようになるまで、あと4日 https://t.co/VZ1jrxFh0P",
    "expandedUrl" : "https://twitter.com/i/web/status/1310716919431929856"
  }
}, {
  "like" : {
    "tweetId" : "1311337367660232705",
    "fullText" : "くっそ楽しかったな〜Piscine",
    "expandedUrl" : "https://twitter.com/i/web/status/1311337367660232705"
  }
}, {
  "like" : {
    "tweetId" : "1311137636153610240",
    "fullText" : "←現実のエンジニア\n　\n　　　　　→Twitter上のエンジニア https://t.co/xUmySeZ4jb",
    "expandedUrl" : "https://twitter.com/i/web/status/1311137636153610240"
  }
}, {
  "like" : {
    "tweetId" : "1311124865169063936",
    "fullText" : "ラーメン食べたい。\n駅前のラーメン屋に行きまっす。\n(´・ω・｀)",
    "expandedUrl" : "https://twitter.com/i/web/status/1311124865169063936"
  }
}, {
  "like" : {
    "tweetId" : "1311545611586478080",
    "fullText" : "明日は１ヶ月続いた入学テストの最終テスト。\n健康には自信があるのに風邪っぽい！\n\n念の為に風邪薬ルルを呑むも、賞味期限（？）が2019年12月だった。\n\nまー、大丈夫でしょう。\n\nどーしよう、教室入る検温でひっかかってテスト受けれなかったら！",
    "expandedUrl" : "https://twitter.com/i/web/status/1311545611586478080"
  }
}, {
  "like" : {
    "tweetId" : "1310539308235849728",
    "fullText" : "みんなヘラってるからおじさん構文使おうと思ったけど探す気力がない",
    "expandedUrl" : "https://twitter.com/i/web/status/1310539308235849728"
  }
}, {
  "like" : {
    "tweetId" : "1311485255396716544",
    "fullText" : "テスト終わったら何がしたいかと言うとマッサージ",
    "expandedUrl" : "https://twitter.com/i/web/status/1311485255396716544"
  }
}, {
  "like" : {
    "tweetId" : "1310947938949103616",
    "fullText" : "@Hinata72279726 おめでとう！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1310947938949103616"
  }
}, {
  "like" : {
    "tweetId" : "1311126571818737667",
    "fullText" : "@Hinata72279726 大学生は、無敵だよ。(オイラの持論)",
    "expandedUrl" : "https://twitter.com/i/web/status/1311126571818737667"
  }
}, {
  "like" : {
    "tweetId" : "1310795177678655491",
    "fullText" : "@Hinata72279726 おめでとうございます。\nピシン後に、誕生日会ですね！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1310795177678655491"
  }
}, {
  "like" : {
    "tweetId" : "1311053612835954688",
    "fullText" : "今日？は22時間コードを書いた。\n最長記録を更新した。",
    "expandedUrl" : "https://twitter.com/i/web/status/1311053612835954688"
  }
}, {
  "like" : {
    "tweetId" : "1311121101372628993",
    "fullText" : "@Hinata72279726 オイラは、大学生にもどりたぃーー！！！\n( ´ •̥  ̫ •̥ ` )",
    "expandedUrl" : "https://twitter.com/i/web/status/1311121101372628993"
  }
}, {
  "like" : {
    "tweetId" : "1310293732156039168",
    "fullText" : "あかんほんまに悔しい涙でる",
    "expandedUrl" : "https://twitter.com/i/web/status/1310293732156039168"
  }
}, {
  "like" : {
    "tweetId" : "1309829793966301184",
    "fullText" : "@Hinata72279726 全てを忘れて今を楽しむ生き方はかっこいいので続けましょう",
    "expandedUrl" : "https://twitter.com/i/web/status/1309829793966301184"
  }
}, {
  "like" : {
    "tweetId" : "1310157233380970498",
    "fullText" : "フォートナイトで\n【ワタル＆レッド戦】\nをガチで作ってみました！！\nPls RT＆LIKE!!\n#フォートナイト\n#フォートナイトクリエイティブ　\nちょっとした立体音響みたいなのもあるのでイヤフォン推奨！ https://t.co/OEmNTdEO7Q",
    "expandedUrl" : "https://twitter.com/i/web/status/1310157233380970498"
  }
}, {
  "like" : {
    "tweetId" : "1310221157379928065",
    "fullText" : "夫も『小さな子残してよく死ねるよなぁ…』『旦那何してるんだよ』派なので『やるかやらないかの差だけだよ。産後は寝れないから色んな判断が狂うんだよ、死産流産含めて4度目の妊娠、辛くてしんどいっていくら伝えても洗濯物1つ畳まないじゃない、旦那がいれば助かる訳では無い』とお伝えしております",
    "expandedUrl" : "https://twitter.com/i/web/status/1310221157379928065"
  }
}, {
  "like" : {
    "tweetId" : "1309824867630366721",
    "fullText" : "最近時間感覚おかしいから昨日の夜がEXAMだっけ？？あれ？ってなってる",
    "expandedUrl" : "https://twitter.com/i/web/status/1309824867630366721"
  }
}, {
  "like" : {
    "tweetId" : "1310351672082751488",
    "fullText" : "寝た起きた",
    "expandedUrl" : "https://twitter.com/i/web/status/1310351672082751488"
  }
}, {
  "like" : {
    "tweetId" : "1310046609137303554",
    "fullText" : "@luna_yuta シャウエッセン",
    "expandedUrl" : "https://twitter.com/i/web/status/1310046609137303554"
  }
}, {
  "like" : {
    "tweetId" : "1310142269895225346",
    "fullText" : "要介護IT老人",
    "expandedUrl" : "https://twitter.com/i/web/status/1310142269895225346"
  }
}, {
  "like" : {
    "tweetId" : "1310042143004618753",
    "fullText" : "@luna_yuta @Hinata72279726 @Kahorin_42Tokyo 理 論 的 ポ テ 腹",
    "expandedUrl" : "https://twitter.com/i/web/status/1310042143004618753"
  }
}, {
  "like" : {
    "tweetId" : "1309933207521878016",
    "fullText" : "@Hinata72279726 @Kahorin_42Tokyo オーバーライドしないで",
    "expandedUrl" : "https://twitter.com/i/web/status/1309933207521878016"
  }
}, {
  "like" : {
    "tweetId" : "1310223344231276544",
    "fullText" : "そういうことなの、\n他人の話だと『旦那酷いな』と思うのに自分は何もしなくて当たり前でいられる。お前の方が酷い。\n(あの件に関しては真相は不明だから仮の話)",
    "expandedUrl" : "https://twitter.com/i/web/status/1310223344231276544"
  }
}, {
  "like" : {
    "tweetId" : "1309806944895475712",
    "fullText" : "ハングル時計 https://t.co/QNlSJHx2cw",
    "expandedUrl" : "https://twitter.com/i/web/status/1309806944895475712"
  }
}, {
  "like" : {
    "tweetId" : "1309828149354442752",
    "fullText" : "@Hinata72279726 飲ん兵衛こわ、〆ラーメンは....ふt",
    "expandedUrl" : "https://twitter.com/i/web/status/1309828149354442752"
  }
}, {
  "like" : {
    "tweetId" : "1310253692256358402",
    "fullText" : "悔しい\nしんど",
    "expandedUrl" : "https://twitter.com/i/web/status/1310253692256358402"
  }
}, {
  "like" : {
    "tweetId" : "1310444761308827649",
    "fullText" : "情緒不安定すぎてないてるけど正常な動作かも",
    "expandedUrl" : "https://twitter.com/i/web/status/1310444761308827649"
  }
}, {
  "like" : {
    "tweetId" : "1310139805586526209",
    "fullText" : "これやばみ\n妄想スケッチ | TextAlive https://t.co/jlzzQIRo4t #TextAlive",
    "expandedUrl" : "https://twitter.com/i/web/status/1310139805586526209"
  }
}, {
  "like" : {
    "tweetId" : "1310222394728935425",
    "fullText" : "ねんトレ研究始めて 暗くて静かにできる部屋１階だけなので、赤ちゃんベッドは１階に置きたい、息子は様子見で3階(玩具部屋)じゃないと寝ないんじゃ…等と話してたら 1番協力すべき唯一の大人・夫が『無理じゃねぇ？』\n…それは私ひとりで2人の子を寝かせて夜中中起きてお前は何もしないと言ってるのか",
    "expandedUrl" : "https://twitter.com/i/web/status/1310222394728935425"
  }
}, {
  "like" : {
    "tweetId" : "1309862646070427648",
    "fullText" : "フォートナイト3周年おめでとうです！",
    "expandedUrl" : "https://twitter.com/i/web/status/1309862646070427648"
  }
}, {
  "like" : {
    "tweetId" : "1310142091910029312",
    "fullText" : "picaineは、コロナがなければ、\n校舎で、みんなでワイワイしてたのになぁー。\nリモートは、やっぱりツラい。\n(´・ω・｀)",
    "expandedUrl" : "https://twitter.com/i/web/status/1310142091910029312"
  }
}, {
  "like" : {
    "tweetId" : "1309832463481319425",
    "fullText" : "プロンプトを顔文字にするの、めちゃめちゃ可愛いな https://t.co/bG5tAdasHC",
    "expandedUrl" : "https://twitter.com/i/web/status/1309832463481319425"
  }
}, {
  "like" : {
    "tweetId" : "1310078689434980360",
    "fullText" : "元気注入、七宝！ https://t.co/w7wMnpp5xB",
    "expandedUrl" : "https://twitter.com/i/web/status/1310078689434980360"
  }
}, {
  "like" : {
    "tweetId" : "1310453898545512448",
    "fullText" : "ものごとには期限があるので頑張らなきゃいけないんですけど",
    "expandedUrl" : "https://twitter.com/i/web/status/1310453898545512448"
  }
}, {
  "like" : {
    "tweetId" : "1310170280472375296",
    "fullText" : "東京ディズニーシー\nTokyo Disneysea\n\nお気に入り夜景スポットの4選 https://t.co/JBm8B3VDuT",
    "expandedUrl" : "https://twitter.com/i/web/status/1310170280472375296"
  }
}, {
  "like" : {
    "tweetId" : "1309850382139404288",
    "fullText" : "@Hinata72279726 なにやってんだ！！んもう、けしからん！実にけしからんっ！(いいぞ、もっとやれ",
    "expandedUrl" : "https://twitter.com/i/web/status/1309850382139404288"
  }
}, {
  "like" : {
    "tweetId" : "1310048463694880773",
    "fullText" : "@luna_yuta @Hinata72279726 こんなの、たふぇれないろぉ///♡♡",
    "expandedUrl" : "https://twitter.com/i/web/status/1310048463694880773"
  }
}, {
  "like" : {
    "tweetId" : "1309438160393220096",
    "fullText" : "おしまーい",
    "expandedUrl" : "https://twitter.com/i/web/status/1309438160393220096"
  }
}, {
  "like" : {
    "tweetId" : "1309533480124993543",
    "fullText" : "https://t.co/Oq0OWkfY9N",
    "expandedUrl" : "https://twitter.com/i/web/status/1309533480124993543"
  }
}, {
  "like" : {
    "tweetId" : "1309680556691521536",
    "fullText" : "危険な思想を持った哲学者は多くいるが、やはりプラトンが断トツだな。くじ引きで結婚を決める制度を作るが、実際は裏で操作するという発想がヤバイ。（ラッセル『西洋哲学史』） https://t.co/vVavrsXnE7",
    "expandedUrl" : "https://twitter.com/i/web/status/1309680556691521536"
  }
}, {
  "like" : {
    "tweetId" : "1309817399156174849",
    "fullText" : "「野獣」グッズをまとめて！\n東京ディズニーランド『美女と野獣』グッズ・お土産\n9月28日発売☆\n詳細→https://t.co/8BVUFNG0eY https://t.co/4cVjv30RKu",
    "expandedUrl" : "https://twitter.com/i/web/status/1309817399156174849"
  }
}, {
  "like" : {
    "tweetId" : "1309794823440723969",
    "fullText" : "[新商品]ソウルジェムキーキャップが入荷しました\n(;´･ω･).。o○（誰か足りない気がするけどまぁいいか…） https://t.co/VJ8hMdtzG2",
    "expandedUrl" : "https://twitter.com/i/web/status/1309794823440723969"
  }
}, {
  "like" : {
    "tweetId" : "1309490406267056128",
    "fullText" : "@Hinata72279726 いいねオブいいね",
    "expandedUrl" : "https://twitter.com/i/web/status/1309490406267056128"
  }
}, {
  "like" : {
    "tweetId" : "1309456496212623360",
    "fullText" : "早すぎじゃないかい？",
    "expandedUrl" : "https://twitter.com/i/web/status/1309456496212623360"
  }
}, {
  "like" : {
    "tweetId" : "1309374080726958080",
    "fullText" : "さて、もう一回行ってきますよ",
    "expandedUrl" : "https://twitter.com/i/web/status/1309374080726958080"
  }
}, {
  "like" : {
    "tweetId" : "1309305339523727360",
    "fullText" : "@Hinata72279726 10分前すぎそうでやばい",
    "expandedUrl" : "https://twitter.com/i/web/status/1309305339523727360"
  }
}, {
  "like" : {
    "tweetId" : "1309446590818521088",
    "fullText" : "AfterEffectsの不安定さに慣れすぎて\nVimの安定さが逆に不安になる",
    "expandedUrl" : "https://twitter.com/i/web/status/1309446590818521088"
  }
}, {
  "like" : {
    "tweetId" : "1309343997177942016",
    "fullText" : "合宿免許にGoTo使えるのバグってて好き。MT15万で取れる。 https://t.co/C0ogVrrHG8",
    "expandedUrl" : "https://twitter.com/i/web/status/1309343997177942016"
  }
}, {
  "like" : {
    "tweetId" : "1309823448319844352",
    "fullText" : "@Hinata72279726 ここ美味しいよ、歌舞伎町だけど\n\nhttps://t.co/ZcjPrJOQ1j",
    "expandedUrl" : "https://twitter.com/i/web/status/1309823448319844352"
  }
}, {
  "like" : {
    "tweetId" : "1309490299270434816",
    "fullText" : "@Hinata72279726 あーーーーーーーーたべたいたべたすぎる",
    "expandedUrl" : "https://twitter.com/i/web/status/1309490299270434816"
  }
}, {
  "like" : {
    "tweetId" : "1309266369234391041",
    "fullText" : "【販売開始】\n不思議なパワーと妖艶さを持つ、怪しくも美しいディズニーヴィランズのスペシャルコレクションが販売開始❗\nTシャツやスウェット、グッズなどハロウィンにぴったりなアイテムが登場🎃😈\n#ジーユー #GU ＃Disney #ディズニー #Halloween\nhttps://t.co/Jty2cyouLb",
    "expandedUrl" : "https://twitter.com/i/web/status/1309266369234391041"
  }
}, {
  "like" : {
    "tweetId" : "1309647359077502976",
    "fullText" : "why fortnite did us wrong... it couldve looked like this with giant animated bts doing choreography yall 😕https://t.co/tNywfxw0TV",
    "expandedUrl" : "https://twitter.com/i/web/status/1309647359077502976"
  }
}, {
  "like" : {
    "tweetId" : "1309495599511683072",
    "fullText" : "@FPr4242 なんか口に入れた方がいいよ。。。",
    "expandedUrl" : "https://twitter.com/i/web/status/1309495599511683072"
  }
}, {
  "like" : {
    "tweetId" : "1309301464829837314",
    "fullText" : "中国語圏の人とのコミュニケーションは任せて欲しい。私の完璧なジェスチャーで全て伝えて見せる",
    "expandedUrl" : "https://twitter.com/i/web/status/1309301464829837314"
  }
}, {
  "like" : {
    "tweetId" : "1309305268736462848",
    "fullText" : "身のふり構わずあの坂をできる限り走ろうと思います",
    "expandedUrl" : "https://twitter.com/i/web/status/1309305268736462848"
  }
}, {
  "like" : {
    "tweetId" : "1309651342013550592",
    "fullText" : "@FortniteGame @bts_bighit I didnt like kpop that much before but this opened my ears a bit lol\nThanks fortnite!",
    "expandedUrl" : "https://twitter.com/i/web/status/1309651342013550592"
  }
}, {
  "like" : {
    "tweetId" : "1309399075909844992",
    "fullText" : "この時間が1週間で一番休んでいるかもしれない",
    "expandedUrl" : "https://twitter.com/i/web/status/1309399075909844992"
  }
}, {
  "like" : {
    "tweetId" : "1309420756174950400",
    "fullText" : "概念 https://t.co/5OTW7959oi",
    "expandedUrl" : "https://twitter.com/i/web/status/1309420756174950400"
  }
}, {
  "like" : {
    "tweetId" : "1309382174282457088",
    "fullText" : "湿気で髪が bomb🤯 ってなる",
    "expandedUrl" : "https://twitter.com/i/web/status/1309382174282457088"
  }
}, {
  "like" : {
    "tweetId" : "1309510044547915782",
    "fullText" : "@Hinata72279726 難しい話ですね、とりあえずお酒を飲んでみましょう",
    "expandedUrl" : "https://twitter.com/i/web/status/1309510044547915782"
  }
}, {
  "like" : {
    "tweetId" : "1309305374378401792",
    "fullText" : "運営許してくれ",
    "expandedUrl" : "https://twitter.com/i/web/status/1309305374378401792"
  }
}, {
  "like" : {
    "tweetId" : "1309381560970301440",
    "fullText" : "【イベント】遊舎工房 オンラインマーケット 2020.10 を10/17より開催いたします！\n出品者の募集を明日9/26 10:00から行いますのでご登録をお願いいたします 🙇‍♂️\nhttps://t.co/aShnzLEZqG",
    "expandedUrl" : "https://twitter.com/i/web/status/1309381560970301440"
  }
}, {
  "like" : {
    "tweetId" : "1309305134099300352",
    "fullText" : "あああああ間に合えええええ",
    "expandedUrl" : "https://twitter.com/i/web/status/1309305134099300352"
  }
}, {
  "like" : {
    "tweetId" : "1308649760899780608",
    "fullText" : "韓国の今年の小説の販売量が過去最多（昨対比30%増）らしい。しかもトップ10のうち１位から９位までが女性作家。チョン・セランやハン・ガンなど見知った名も。素晴らしいな。SFやジュブナイル小説の成長が著しく、若い女性読者がその人気を下支えしてるのだとか。良いニュースだ。 https://t.co/jFF6yVeIi5",
    "expandedUrl" : "https://twitter.com/i/web/status/1308649760899780608"
  }
}, {
  "like" : {
    "tweetId" : "1308681070531944450",
    "fullText" : "｡｡｡(lll __ __)ﾊﾞﾀｯ",
    "expandedUrl" : "https://twitter.com/i/web/status/1308681070531944450"
  }
}, {
  "like" : {
    "tweetId" : "1309108875782692865",
    "fullText" : "明日はまた東京。早めにおねんねしなくちゃ。",
    "expandedUrl" : "https://twitter.com/i/web/status/1309108875782692865"
  }
}, {
  "like" : {
    "tweetId" : "1309080127129743360",
    "fullText" : "ソアリン:ファンタスティック・フライト\nSoaring: Fantastic Flight\n\n海外旅行できない時期、\n世界名所と大自然の旅をディズニーシーで楽しもう https://t.co/QB64dohudC",
    "expandedUrl" : "https://twitter.com/i/web/status/1309080127129743360"
  }
}, {
  "like" : {
    "tweetId" : "1308961364010967041",
    "fullText" : "お酒飲めないのでわかんないんですが https://t.co/rFP3nag8ZB",
    "expandedUrl" : "https://twitter.com/i/web/status/1308961364010967041"
  }
}, {
  "like" : {
    "tweetId" : "1309270418272870400",
    "fullText" : "おぴー",
    "expandedUrl" : "https://twitter.com/i/web/status/1309270418272870400"
  }
}, {
  "like" : {
    "tweetId" : "1308921586297298947",
    "fullText" : "熱が上がったぉーー！！！！\n37.5だったけど。\nコロナ疑われそうで、イヤな体温だわん。\n(´-д-)-3",
    "expandedUrl" : "https://twitter.com/i/web/status/1308921586297298947"
  }
}, {
  "like" : {
    "tweetId" : "1309070369505017860",
    "fullText" : "９月２８日よりディズニーリゾートライン フリーきっぷに３種類のデザインが新登場します✨\n\n東京ディズニーランドの新アトラクション「美女と野獣“魔法のものがたり”」デザインも加わります！ https://t.co/bpqACO2OnR",
    "expandedUrl" : "https://twitter.com/i/web/status/1309070369505017860"
  }
}, {
  "like" : {
    "tweetId" : "1308555129117843456",
    "fullText" : "縦画壁紙サイズでお届けする、東京ディズニーシーの風景🌋是非タップしてみて下さい✨ https://t.co/iSTuqjocgO",
    "expandedUrl" : "https://twitter.com/i/web/status/1308555129117843456"
  }
}, {
  "like" : {
    "tweetId" : "1309114835435769865",
    "fullText" : "メンタルジェットコースターがエグい",
    "expandedUrl" : "https://twitter.com/i/web/status/1309114835435769865"
  }
}, {
  "like" : {
    "tweetId" : "1308790399943585793",
    "fullText" : "@Hinata72279726 みっしゅ",
    "expandedUrl" : "https://twitter.com/i/web/status/1308790399943585793"
  }
}, {
  "like" : {
    "tweetId" : "1309302159612149760",
    "fullText" : "TLを見る感、鹿せんべい中毒の◯◯女子のせいでgmailが開けなくて、竹中平蔵はなくなく月7万円で暮らしている？",
    "expandedUrl" : "https://twitter.com/i/web/status/1309302159612149760"
  }
}, {
  "like" : {
    "tweetId" : "1309050368077246465",
    "fullText" : "@luna_yuta えろいって見えたわ。疲れてるわ。",
    "expandedUrl" : "https://twitter.com/i/web/status/1309050368077246465"
  }
}, {
  "like" : {
    "tweetId" : "1308890535109763078",
    "fullText" : "@Hinata72279726 ありがとうです。\nいま熱あるので、明日はお休みするかもしれない。。。。\nガ━l||l(０Δ０)l||l━ン",
    "expandedUrl" : "https://twitter.com/i/web/status/1308890535109763078"
  }
}, {
  "like" : {
    "tweetId" : "1308967151617728512",
    "fullText" : "わたしBTS大好きで、しかもdynamiteが今までの曲でsave meと争うんじゃないかってくらい好きで。。。。\n何が言いたいかと言うと、買いました！！！！！！！！ https://t.co/tw4sWUAMmy",
    "expandedUrl" : "https://twitter.com/i/web/status/1308967151617728512"
  }
}, {
  "like" : {
    "tweetId" : "1309287730585591808",
    "fullText" : "こんにちは、金曜日\nって感じですね",
    "expandedUrl" : "https://twitter.com/i/web/status/1309287730585591808"
  }
}, {
  "like" : {
    "tweetId" : "1308885315868909568",
    "fullText" : "You have 3 options:\n\n1) We pretend that the last tweet was a joke and we never talk about it again.\n\n2) It's just the way it is, we accept it, but we don't talk about it.\n\n3) We accept it and we celebrate their true form. Bring on the fan art!",
    "expandedUrl" : "https://twitter.com/i/web/status/1308885315868909568"
  }
}, {
  "like" : {
    "tweetId" : "1309305079590084608",
    "fullText" : "@Hinata72279726 あと16分",
    "expandedUrl" : "https://twitter.com/i/web/status/1309305079590084608"
  }
}, {
  "like" : {
    "tweetId" : "1308934344438951939",
    "fullText" : "■ フォートナイト リレーロイヤル２ #1 ■\n人気クリエイターのコラボが日替わりで登場する配信リレー、第二弾の１回目はKUNさん @roadhog_KUN とねこくん！ @__Necko です！\n\n今夜８時から公式YouTubeチャンネルでプレミア公開！\n\nhttps://t.co/sizMPphXLD\n\n#リレーロイヤル #YouTubeGamingWeek https://t.co/lTl0ZxgI0J",
    "expandedUrl" : "https://twitter.com/i/web/status/1308934344438951939"
  }
}, {
  "like" : {
    "tweetId" : "1309293929959809025",
    "fullText" : "間に合わないかもしれない",
    "expandedUrl" : "https://twitter.com/i/web/status/1309293929959809025"
  }
}, {
  "like" : {
    "tweetId" : "1308853560411656197",
    "fullText" : "Well, you asked for it...\n\nThis is official lore now\n\nRemember: \n\n• Human shown for scale\n• Fall Guys are 183cm (6ft)\n• This Fall Guy is happy, look into his eyes\n• We can't take it back\n\nOfficial Fall Guys Artwork by Senior Concept Artist:\nhttps://t.co/OgiS6WXzno https://t.co/eCLJu1DBpP",
    "expandedUrl" : "https://twitter.com/i/web/status/1308853560411656197"
  }
}, {
  "like" : {
    "tweetId" : "1309252428118634496",
    "fullText" : "オレのMacBook、キーボードカバーしてもらってるとはいえ毎日灰降りかけられるのどんな気持ちなんやろう。",
    "expandedUrl" : "https://twitter.com/i/web/status/1309252428118634496"
  }
}, {
  "like" : {
    "tweetId" : "1309095264419033093",
    "fullText" : "今日の戦果 https://t.co/yL8w60NbCj",
    "expandedUrl" : "https://twitter.com/i/web/status/1309095264419033093"
  }
}, {
  "like" : {
    "tweetId" : "1308914970965561345",
    "fullText" : "ぽはみ",
    "expandedUrl" : "https://twitter.com/i/web/status/1308914970965561345"
  }
}, {
  "like" : {
    "tweetId" : "1308423395625885697",
    "fullText" : "ロケットリーグ @RocketLeague の無料プレイはまもなく！\n\nこれを記念にロケットリーグラジオから @SlushiiMusic が9月27日午前6時（日本時間）にパーティーロイヤルに出演します。\n\nショーのあとはロケットリーグに飛び込んで無料の報酬をゲットしよう！\n\nhttps://t.co/HxdMWKRVk0 https://t.co/qzA8oXPnpu",
    "expandedUrl" : "https://twitter.com/i/web/status/1308423395625885697"
  }
}, {
  "like" : {
    "tweetId" : "1308630170434109440",
    "fullText" : "@_unlimish まいにち温泉卵作ってたら最適な温度と時間がわかる https://t.co/ZHhnC1UEw8",
    "expandedUrl" : "https://twitter.com/i/web/status/1308630170434109440"
  }
}, {
  "like" : {
    "tweetId" : "1308196741343133697",
    "fullText" : "@Hinata72279726 合格って42じゃなくて俺の中の基準だから。",
    "expandedUrl" : "https://twitter.com/i/web/status/1308196741343133697"
  }
}, {
  "like" : {
    "tweetId" : "1307960919163465728",
    "fullText" : "絵画ラベル～！ https://t.co/Zhg3Dxey2X",
    "expandedUrl" : "https://twitter.com/i/web/status/1307960919163465728"
  }
}, {
  "like" : {
    "tweetId" : "1308192719995432960",
    "fullText" : "俺はいかれてないみたいだよかった https://t.co/JBxvBo11kf",
    "expandedUrl" : "https://twitter.com/i/web/status/1308192719995432960"
  }
}, {
  "like" : {
    "tweetId" : "1308071597664763904",
    "fullText" : "SNSが汚いって理由で落とされそう",
    "expandedUrl" : "https://twitter.com/i/web/status/1308071597664763904"
  }
}, {
  "like" : {
    "tweetId" : "1308184863044857856",
    "fullText" : "卵縦割りしたのって、人生初かもしれない https://t.co/ATmZ0jJoYd",
    "expandedUrl" : "https://twitter.com/i/web/status/1308184863044857856"
  }
}, {
  "like" : {
    "tweetId" : "1308357711952707584",
    "fullText" : "一昨日のミスが無意識に落ちていった結果　いろいろ無な状態になってきた",
    "expandedUrl" : "https://twitter.com/i/web/status/1308357711952707584"
  }
}, {
  "like" : {
    "tweetId" : "1308223597375139841",
    "fullText" : "娘がぶちまけたおもちゃを片付けるっていう肉体労働する",
    "expandedUrl" : "https://twitter.com/i/web/status/1308223597375139841"
  }
}, {
  "like" : {
    "tweetId" : "1307971721971077120",
    "fullText" : "そういえば父、「親なんて大事にしなくていい。なんぼか長く生きているだけで、優れた人間でもなんでもない。しかも、頼まれてもいないのにお前に生を与えたのだから、いくらでも文句や要求を伝えたらいい。全てに応えられるとは言いきれないが」みたいなことを、私が幼いころから繰り返し言っていた。",
    "expandedUrl" : "https://twitter.com/i/web/status/1307971721971077120"
  }
}, {
  "like" : {
    "tweetId" : "1308197062098337792",
    "fullText" : "@_unlimish @Hinata72279726 「何言ってんだこいつ」感があれば俺の中では合格です。",
    "expandedUrl" : "https://twitter.com/i/web/status/1308197062098337792"
  }
}, {
  "like" : {
    "tweetId" : "1307984096241487874",
    "fullText" : "９月２８日に東京ディズニーランドのトゥモローランドにオープンするビッグポップにて、映画「美女と野獣」のポップコーンバケットが新発売されます✨ https://t.co/3Q7bwhdKu4",
    "expandedUrl" : "https://twitter.com/i/web/status/1307984096241487874"
  }
}, {
  "like" : {
    "tweetId" : "1293114346935996416",
    "fullText" : "のちのちこれを移植して「きゃわきゃわErgo Dash」にします。",
    "expandedUrl" : "https://twitter.com/i/web/status/1293114346935996416"
  }
}, {
  "like" : {
    "tweetId" : "1308752384919613440",
    "fullText" : "一緒に笑える人と付き合いたいです。\nあとコードがスパゲティじゃない人",
    "expandedUrl" : "https://twitter.com/i/web/status/1308752384919613440"
  }
}, {
  "like" : {
    "tweetId" : "1308386645750628352",
    "fullText" : "スマートなコードを書くために読まなきゃいけないし、説明きかなきゃ。",
    "expandedUrl" : "https://twitter.com/i/web/status/1308386645750628352"
  }
}, {
  "like" : {
    "tweetId" : "1308755358135902210",
    "fullText" : "東京ディズニーランド\n「ニューファンタジーランド」\n美女と野獣の城☆\nhttps://t.co/6tEyanANLs https://t.co/qM0XnK2yXb",
    "expandedUrl" : "https://twitter.com/i/web/status/1308755358135902210"
  }
}, {
  "like" : {
    "tweetId" : "1308284871626772480",
    "fullText" : "今日はスニーク当たりまくったからプーさんグリ諦めてたんだけどエントランス出たら１００エーカーの森の仲間たちーーーーーーーーーーーーーーーーーーーーーーーーーーー運良すぎ明日死ぬ\n\n#TDR_now https://t.co/cxdOT2xylr",
    "expandedUrl" : "https://twitter.com/i/web/status/1308284871626772480"
  }
}, {
  "like" : {
    "tweetId" : "1308368237868888064",
    "fullText" : "Vimあるある(？)\nescの代わりに日本語変換を押しちゃう...",
    "expandedUrl" : "https://twitter.com/i/web/status/1308368237868888064"
  }
}, {
  "like" : {
    "tweetId" : "1308032437977448448",
    "fullText" : "ポケモンのタイプ（ノーマル除く）でずーっと疑問に思っていたこと https://t.co/oSznb1MaDP",
    "expandedUrl" : "https://twitter.com/i/web/status/1308032437977448448"
  }
}, {
  "like" : {
    "tweetId" : "1308382819245109248",
    "fullText" : "@koto_science は？",
    "expandedUrl" : "https://twitter.com/i/web/status/1308382819245109248"
  }
}, {
  "like" : {
    "tweetId" : "1308007332039675904",
    "fullText" : "ディズニーシーでアリ王子のパレードやんねえかな",
    "expandedUrl" : "https://twitter.com/i/web/status/1308007332039675904"
  }
}, {
  "like" : {
    "tweetId" : "1308015122435026946",
    "fullText" : "９月２８日、ディズニーランドの新エリア「ニューファンタジーランド」がオープンします✨\n\n「美女と野獣“魔法のものがたり”」や「ベイマックスのハッピーライド」、「ミニーのスタイルスタジオ」が導入されます！ https://t.co/If5rZq0IiD",
    "expandedUrl" : "https://twitter.com/i/web/status/1308015122435026946"
  }
}, {
  "like" : {
    "tweetId" : "1308742103225126914",
    "fullText" : "熱がでた。(ﾉ∀｀笑)\n\n知恵熱という奴さ。\n( ´-ω- )ﾌｯ https://t.co/6alLQ2UPdK",
    "expandedUrl" : "https://twitter.com/i/web/status/1308742103225126914"
  }
}, {
  "like" : {
    "tweetId" : "1308091626355527681",
    "fullText" : "コーディングしてると飲食わすれて糖分不足、水不足になるのってみんな同じなんだろうか。。。。",
    "expandedUrl" : "https://twitter.com/i/web/status/1308091626355527681"
  }
}, {
  "like" : {
    "tweetId" : "1308744615516749824",
    "fullText" : "Rushレビューエンカ面白かった",
    "expandedUrl" : "https://twitter.com/i/web/status/1308744615516749824"
  }
}, {
  "like" : {
    "tweetId" : "1307798468337913856",
    "fullText" : "製作で欠かせないどんぐり帽子\n\n譲ってくださる方の\nお子さんたちが一生懸命\n集めてくれています\n\nこどもたちの純粋な気持ちに\n製作は支えられています\n\nこどもたちが\n夢や希望を持てるように\n大人のわたしは頑張っていきたいなと思いました。\n\n#どんぐり\n#ハンドメイド https://t.co/3sD6vDhZZ1",
    "expandedUrl" : "https://twitter.com/i/web/status/1307798468337913856"
  }
}, {
  "like" : {
    "tweetId" : "1304434760467447810",
    "fullText" : "#夢見りあむ生誕祭2020\n #夢見りあむ誕生祭2020\n #デレステ5周年 \n「「「夢見りあむしか勝たん」」」\nりあむちゃんお誕生日おめでとう🎉🎉\nそして5周年もおめでとう💓🎂💓\nこれからもアイマス！！！ https://t.co/CzkF14DN5v",
    "expandedUrl" : "https://twitter.com/i/web/status/1304434760467447810"
  }
}, {
  "like" : {
    "tweetId" : "1307948199533883392",
    "fullText" : "ある人のgithubアカウント見てたら醤油ラーメンのレシピのリポジトリがあって、無限の可能性を感じた",
    "expandedUrl" : "https://twitter.com/i/web/status/1307948199533883392"
  }
}, {
  "like" : {
    "tweetId" : "1307968907022462977",
    "fullText" : "piscine、いろんな人がいるのを見て、いろんな人がいるなあという感想を抱いた",
    "expandedUrl" : "https://twitter.com/i/web/status/1307968907022462977"
  }
}, {
  "like" : {
    "tweetId" : "1298877910443589637",
    "fullText" : "この事実に気づいてしまったら、作りたい衝動を抑えられませんでした…。 \nCaps Lock専用のキーボードキャップ\n\n＿人人人人人人人人＿\n＞　CALPIS Lock　＜ \n￣Y^Y^Y^Y^Y^Y^Y￣\n\n１万ＲＴ達成でキャンペーン賞品化も検討中！ \n#カルピス自由研究 https://t.co/f4tzRAVDaY",
    "expandedUrl" : "https://twitter.com/i/web/status/1298877910443589637"
  }
}, {
  "like" : {
    "tweetId" : "1307292921872277504",
    "fullText" : "#秋の創作クラスタフォロー祭\n#絵描きさんと繫がりたい \n社会に適合できない女の子たちを描いてます👼\nRT中心に❤️も回ります💓 https://t.co/JBnoClTl54",
    "expandedUrl" : "https://twitter.com/i/web/status/1307292921872277504"
  }
}, {
  "like" : {
    "tweetId" : "1307491585110630400",
    "fullText" : "藤井聡太二冠は\n1年以内に下取りに出して\n更なる魔改造マシーンに乗り換えると予想する\n\n藤井聡太二冠「自作PC」の値段にパソコンマニアもびっくり（NEWS ポストセブン） - Yahoo!ニュース https://t.co/LH4DL65G8u",
    "expandedUrl" : "https://twitter.com/i/web/status/1307491585110630400"
  }
}, {
  "like" : {
    "tweetId" : "1308077744803254272",
    "fullText" : "ピシン、面白い人はまぁ多いんだけど真面目な人多くて、この、「何いってんだこいつ」感のある人はあんまおらんのがちょっとつらい、あんりみとひなたは合格してるので安心してください。",
    "expandedUrl" : "https://twitter.com/i/web/status/1308077744803254272"
  }
}, {
  "like" : {
    "tweetId" : "1308007705894944769",
    "fullText" : "ピシン前に、買い物行く暇もないやろなと思って大量購入した肉たち、まさか料理される暇すらないとは思ってなかった",
    "expandedUrl" : "https://twitter.com/i/web/status/1308007705894944769"
  }
}, {
  "like" : {
    "tweetId" : "1306963589698170880",
    "fullText" : "鱗粉かと思うだろ………これ全部螺鈿細工なんだぜ…………あと普通に立体造形もリアルだったしだというのに箱自体の型はクラシカルなんだ……クレイジィ……気が狂う…気が狂ってしまう精度だぜ…… https://t.co/lepx0bGjo0",
    "expandedUrl" : "https://twitter.com/i/web/status/1306963589698170880"
  }
}, {
  "like" : {
    "tweetId" : "1307122112520425473",
    "fullText" : "超現実主義の作品はどれも見てるだけで心が落ち着く https://t.co/LLmGZWMP0L",
    "expandedUrl" : "https://twitter.com/i/web/status/1307122112520425473"
  }
}, {
  "like" : {
    "tweetId" : "1307821317480239104",
    "fullText" : "寝てた沖田グッモー人",
    "expandedUrl" : "https://twitter.com/i/web/status/1307821317480239104"
  }
}, {
  "like" : {
    "tweetId" : "1307570103467171840",
    "fullText" : "何が辛いのかよくわからないけど人生が辛い",
    "expandedUrl" : "https://twitter.com/i/web/status/1307570103467171840"
  }
}, {
  "like" : {
    "tweetId" : "1307727912880222215",
    "fullText" : "ほんとに脳のスペックがもとに戻りつつあってかなり良い、あとは体力。ランニング再開したいけど進捗が予定より遅れているのでしてる暇がねぇっす、周りが失速しているので比較的いいのでは？、とか一瞬考えたけど元の想定ルートを目指す〜",
    "expandedUrl" : "https://twitter.com/i/web/status/1307727912880222215"
  }
}, {
  "like" : {
    "tweetId" : "1307861827305398272",
    "fullText" : "ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！ちんぽ！",
    "expandedUrl" : "https://twitter.com/i/web/status/1307861827305398272"
  }
}, {
  "like" : {
    "tweetId" : "1306964563426906113",
    "fullText" : "あとここらへんは24時のバカンスみを感じたので宝石の国クラスタにも刺さるんじゃ無いかと思いました　磁器とかいう中世からの東アジア最高級輸出品をもってしてそれは麗しいトラウマを作るのはやめろ(ありがとうございますとても美しいですね)の回 https://t.co/39fFa0Wp1z",
    "expandedUrl" : "https://twitter.com/i/web/status/1306964563426906113"
  }
}, {
  "like" : {
    "tweetId" : "1307613615558541313",
    "fullText" : "@NCTsmtown_127 どよち〜！\n최근에 공부한 일본어는 있습니까?\n또 일본에서 만날 날을 기대하고 있겠어요ㅠㅠ",
    "expandedUrl" : "https://twitter.com/i/web/status/1307613615558541313"
  }
}, {
  "like" : {
    "tweetId" : "1307361497488609280",
    "fullText" : "ラッシュ\nたっの死いー！",
    "expandedUrl" : "https://twitter.com/i/web/status/1307361497488609280"
  }
}, {
  "like" : {
    "tweetId" : "1307967691089608706",
    "fullText" : "主夫をし始めて、作れる料理が結構増えました。\n今日の夕飯はフランスでよく食べてたガレットを作ります。",
    "expandedUrl" : "https://twitter.com/i/web/status/1307967691089608706"
  }
}, {
  "like" : {
    "tweetId" : "1292009607003398144",
    "fullText" : "絵をほめてくれるロシア人 https://t.co/UrKvY3R6iz",
    "expandedUrl" : "https://twitter.com/i/web/status/1292009607003398144"
  }
}, {
  "like" : {
    "tweetId" : "1307412791075069952",
    "fullText" : "同僚の誕生日企画、みんなで加工動画でお祝いメッセージを送ろう！\nで、作ったのやーつ。\n顔小さくして、目を大きくして、鼻筋通して、肌から唇から目元からアプリ内で加工。ついでに髪の色も変更。\nこええよ、誰だよこいつ。\nせっかくなのでzoom会議前に撮った本当の姿も添付。\nおやすみ世界！ https://t.co/QWM0z5eDNR",
    "expandedUrl" : "https://twitter.com/i/web/status/1307412791075069952"
  }
}, {
  "like" : {
    "tweetId" : "1307614254061596675",
    "fullText" : "@Mint127Choco これから勉強おしようとお見ます　ボクも本当に会いたいです　つぎにあいましょう",
    "expandedUrl" : "https://twitter.com/i/web/status/1307614254061596675"
  }
}, {
  "like" : {
    "tweetId" : "1307823635214733313",
    "fullText" : "ぽきー",
    "expandedUrl" : "https://twitter.com/i/web/status/1307823635214733313"
  }
}, {
  "like" : {
    "tweetId" : "1308003374743171072",
    "fullText" : "その重低音、心に響く。#DynaNite がやってくる！\n\n日本時間9月26日(土)午前9時には @bts_bighit の新曲 “Dynamite” MV (Choreography ver.) がパーティーロイヤルにてプレミア公開されます！\n\nhttps://t.co/EYJ3LW6ibQ https://t.co/PgwxaSlbEs",
    "expandedUrl" : "https://twitter.com/i/web/status/1308003374743171072"
  }
}, {
  "like" : {
    "tweetId" : "1308036093569245190",
    "fullText" : "ご報告ですが、彼氏と別れました✌️感情的にならず言いたいことを言えてちょっとスッキリしたと同時にやっぱり好きだったから悲しいし悔しいけど、何よりも私のことを好きでいてくれてないのがまじでキモいし無理でした！！！！数日は病むと思うけどこれもまた時間が解決してくれることを祈ります、、",
    "expandedUrl" : "https://twitter.com/i/web/status/1308036093569245190"
  }
}, {
  "like" : {
    "tweetId" : "1313779948482514944",
    "fullText" : "@_unlimish 飼えるほどの余裕が(色んな面で)欲しい人生だった",
    "expandedUrl" : "https://twitter.com/i/web/status/1313779948482514944"
  }
}, {
  "like" : {
    "tweetId" : "1313785280667639808",
    "fullText" : "@Kahorin_42Tokyo かほりんの家で飼われたらしゃぶり尽くされて存在がnullになりそう（）",
    "expandedUrl" : "https://twitter.com/i/web/status/1313785280667639808"
  }
}, {
  "like" : {
    "tweetId" : "1313679318480871424",
    "fullText" : "@Hinata72279726 @FPr4242 出てこないから心配だったってさ",
    "expandedUrl" : "https://twitter.com/i/web/status/1313679318480871424"
  }
}, {
  "like" : {
    "tweetId" : "1313694074025639938",
    "fullText" : "@hayasaka_c @FPr4242 アイス売ってそう",
    "expandedUrl" : "https://twitter.com/i/web/status/1313694074025639938"
  }
}, {
  "like" : {
    "tweetId" : "1313680333699575808",
    "fullText" : "@FPr4242 それな？",
    "expandedUrl" : "https://twitter.com/i/web/status/1313680333699575808"
  }
}, {
  "like" : {
    "tweetId" : "1313793552497823745",
    "fullText" : "@Hinata72279726 💜(号泣)",
    "expandedUrl" : "https://twitter.com/i/web/status/1313793552497823745"
  }
}, {
  "like" : {
    "tweetId" : "1314023667890675713",
    "fullText" : "テック系女子を集めたキャバクラ\n\n経済周りそう",
    "expandedUrl" : "https://twitter.com/i/web/status/1314023667890675713"
  }
}, {
  "like" : {
    "tweetId" : "1314027305082122241",
    "fullText" : "@Hinata72279726 ひなたはきっとテクキャバで売れると思うよ",
    "expandedUrl" : "https://twitter.com/i/web/status/1314027305082122241"
  }
}, {
  "like" : {
    "tweetId" : "1314024108942790658",
    "fullText" : "@Hinata72279726 ひなたもキャストだよ。おじさんたちに沢山ガジェット買ってもらうんだよ。",
    "expandedUrl" : "https://twitter.com/i/web/status/1314024108942790658"
  }
}, {
  "like" : {
    "tweetId" : "1313789582412976128",
    "fullText" : "@_unlimish 美味しくいただきます、好みに調教します。",
    "expandedUrl" : "https://twitter.com/i/web/status/1313789582412976128"
  }
}, {
  "like" : {
    "tweetId" : "1313693324402860032",
    "fullText" : "@FPr4242 @hayasaka_c 落ちた奴らで起業",
    "expandedUrl" : "https://twitter.com/i/web/status/1313693324402860032"
  }
}, {
  "like" : {
    "tweetId" : "1313771499120021504",
    "fullText" : "誰かうちのこと飼ってくれる人いないかなって思って(null)年経った",
    "expandedUrl" : "https://twitter.com/i/web/status/1313771499120021504"
  }
}, {
  "like" : {
    "tweetId" : "1313679426970771457",
    "fullText" : "@Hinata72279726 @luna_yuta ツイーヨしてないけどゆーたニキの夢精報告ツイみてニコニコしてるし元気✌️✌️✌️✌️✌️✌️",
    "expandedUrl" : "https://twitter.com/i/web/status/1313679426970771457"
  }
}, {
  "like" : {
    "tweetId" : "1313693472717639681",
    "fullText" : "@luna_yuta @FPr4242 会社名は41",
    "expandedUrl" : "https://twitter.com/i/web/status/1313693472717639681"
  }
}, {
  "like" : {
    "tweetId" : "1313417473752932352",
    "fullText" : "スクレイピング開発案件を初めてやってるんですが、これってブラックではないにしてもグレーぐらいのハッキング技術になってしまうんでしょうかね？",
    "expandedUrl" : "https://twitter.com/i/web/status/1313417473752932352"
  }
}, {
  "like" : {
    "tweetId" : "1313733862590091266",
    "fullText" : "最近お気持ち安定しないのって季節の変わり目だからとかそいうあれ？",
    "expandedUrl" : "https://twitter.com/i/web/status/1313733862590091266"
  }
}, {
  "like" : {
    "tweetId" : "1313736321672769542",
    "fullText" : "情弱なので疲れました。 https://t.co/kqvPq5y0Cx",
    "expandedUrl" : "https://twitter.com/i/web/status/1313736321672769542"
  }
}, {
  "like" : {
    "tweetId" : "1313968469642153984",
    "fullText" : "寝た起きた",
    "expandedUrl" : "https://twitter.com/i/web/status/1313968469642153984"
  }
}, {
  "like" : {
    "tweetId" : "1313679505207173120",
    "fullText" : "新作アニゴジの脚本を円城塔氏が担当されるとの事で、ここで氏による「スペース☆ダンディ」の脚本を見てみましょう。 https://t.co/imV0P1PSeC",
    "expandedUrl" : "https://twitter.com/i/web/status/1313679505207173120"
  }
}, {
  "like" : {
    "tweetId" : "1313470227418689537",
    "fullText" : "みんなエッチなくせにエッチじゃありませんみたいな顔して仕事してるのほんとすごい",
    "expandedUrl" : "https://twitter.com/i/web/status/1313470227418689537"
  }
}, {
  "like" : {
    "tweetId" : "1313639366330183680",
    "fullText" : "10月11月限定の「すだちつけ麺」です。つけ汁は正油ベースで大根おろしが入っていて、みぞれ風になっております。すだちは今が旬なので是非❗️ https://t.co/dLn2jALx7M",
    "expandedUrl" : "https://twitter.com/i/web/status/1313639366330183680"
  }
}, {
  "like" : {
    "tweetId" : "1313694383154184193",
    "fullText" : "@luna_yuta @hayasaka_c 訴訟されそう",
    "expandedUrl" : "https://twitter.com/i/web/status/1313694383154184193"
  }
}, {
  "like" : {
    "tweetId" : "1313694500993208320",
    "fullText" : "@hayasaka_c @luna_yuta 31",
    "expandedUrl" : "https://twitter.com/i/web/status/1313694500993208320"
  }
}, {
  "like" : {
    "tweetId" : "1313785063377575936",
    "fullText" : "@Hinata72279726 まじで一人暮らしで死にそうになっちゃったら相談するかもしれない",
    "expandedUrl" : "https://twitter.com/i/web/status/1313785063377575936"
  }
}, {
  "like" : {
    "tweetId" : "1314022865826537472",
    "fullText" : "42Tokyoの未読メール42通なので43になった時に結果がわかるはず https://t.co/8EM8xSu9X3",
    "expandedUrl" : "https://twitter.com/i/web/status/1314022865826537472"
  }
}, {
  "like" : {
    "tweetId" : "1307256209456594944",
    "fullText" : "@Hinata72279726 コロナウイルスは飲酒による体内アルコール消毒で防ぐことができます(大嘘)",
    "expandedUrl" : "https://twitter.com/i/web/status/1307256209456594944"
  }
}, {
  "like" : {
    "tweetId" : "1306853301179146246",
    "fullText" : "#42Tokyo に受かりました。C言語とか触ったことなかったので、いい勉強になりました。今後とも勉強を続けていきます。\nちなみに、なんで受かったかはわかりません。\nリモートで開催されたから受かった説は濃厚です。",
    "expandedUrl" : "https://twitter.com/i/web/status/1306853301179146246"
  }
}, {
  "like" : {
    "tweetId" : "1306954589514555392",
    "fullText" : "@Hinata72279726 中身を堪能するんですが？？？？",
    "expandedUrl" : "https://twitter.com/i/web/status/1306954589514555392"
  }
}, {
  "like" : {
    "tweetId" : "1307240344564592640",
    "fullText" : "Discordの通話切ったときの顔をクリックして通話の品質評価するやつ、\nなんか見覚えあると思ったら\n海外のトイレの壁にくっついてたトイレの綺麗さアンケートだわ。",
    "expandedUrl" : "https://twitter.com/i/web/status/1307240344564592640"
  }
}, {
  "like" : {
    "tweetId" : "1307337435345494017",
    "fullText" : "寝るぞと言ってから一通りボイチャに顔出すタイプのうつ病",
    "expandedUrl" : "https://twitter.com/i/web/status/1307337435345494017"
  }
}, {
  "like" : {
    "tweetId" : "1307337636147867648",
    "fullText" : "@Hinata72279726 理解",
    "expandedUrl" : "https://twitter.com/i/web/status/1307337636147867648"
  }
}, {
  "like" : {
    "tweetId" : "1306904532278898688",
    "fullText" : "自主退出してきましたーー\n\nexamの進め方がわかったので今回は良しとします1問しかとけなかったけど。。\n\nもっと課題の解くスピードあげないとexamの範囲に追いつかない😢",
    "expandedUrl" : "https://twitter.com/i/web/status/1306904532278898688"
  }
}, {
  "like" : {
    "tweetId" : "1306853680713400320",
    "fullText" : "まずはPC組み立てます。",
    "expandedUrl" : "https://twitter.com/i/web/status/1306853680713400320"
  }
}, {
  "like" : {
    "tweetId" : "1307129433103499267",
    "fullText" : "@Hinata72279726 おつらみ…",
    "expandedUrl" : "https://twitter.com/i/web/status/1307129433103499267"
  }
}, {
  "like" : {
    "tweetId" : "1306951660929916928",
    "fullText" : "@Hinata72279726 SSDは任せとけ",
    "expandedUrl" : "https://twitter.com/i/web/status/1306951660929916928"
  }
}, {
  "like" : {
    "tweetId" : "1306647244787998720",
    "fullText" : "言っていいことと悪いことがある https://t.co/ZNl4iWpBLr",
    "expandedUrl" : "https://twitter.com/i/web/status/1306647244787998720"
  }
}, {
  "like" : {
    "tweetId" : "1307337234262228992",
    "fullText" : "@Hinata72279726 なんだこいつ",
    "expandedUrl" : "https://twitter.com/i/web/status/1307337234262228992"
  }
}, {
  "like" : {
    "tweetId" : "1306974295726403585",
    "fullText" : "@Hinata72279726 えぐいとこだけ抽出フィルターかけて圧縮するわ",
    "expandedUrl" : "https://twitter.com/i/web/status/1306974295726403585"
  }
}, {
  "like" : {
    "tweetId" : "1306949864844963840",
    "fullText" : "お腹すいた気がするけど何食べようか迷ってコンビニを彷徨いた挙げ句に松屋に吸い込まれた",
    "expandedUrl" : "https://twitter.com/i/web/status/1306949864844963840"
  }
}, {
  "like" : {
    "tweetId" : "1306984308654002176",
    "fullText" : "合格記念に42きた！！！笑 https://t.co/uPewfiMex3",
    "expandedUrl" : "https://twitter.com/i/web/status/1306984308654002176"
  }
}, {
  "like" : {
    "tweetId" : "1307146692312006656",
    "fullText" : "体内のバロメーター周り全部ヘルスケアAppでリアルタイム表示できるように体のAPI開放してほしい。",
    "expandedUrl" : "https://twitter.com/i/web/status/1307146692312006656"
  }
}, {
  "like" : {
    "tweetId" : "1306909387655581701",
    "fullText" : "ポートフォリオにかっこいい404ページを作りました\n\nhttps://t.co/g7niGW0Bxo https://t.co/lARJlbhMAZ",
    "expandedUrl" : "https://twitter.com/i/web/status/1306909387655581701"
  }
}, {
  "like" : {
    "tweetId" : "1306974502941798401",
    "fullText" : "眠いぞ寝るぞ",
    "expandedUrl" : "https://twitter.com/i/web/status/1306974502941798401"
  }
}, {
  "like" : {
    "tweetId" : "1307227017994096640",
    "fullText" : "今日の工作室ｯ!\n5mm POM 箱組分割キーボードと縦振り電鍵キーボードとEnterキー専用キーボードを自作STM32基板で組み立てたお客様です。\n5mmPOMいいですねぇ https://t.co/EEy3MY3ffJ",
    "expandedUrl" : "https://twitter.com/i/web/status/1307227017994096640"
  }
}, {
  "like" : {
    "tweetId" : "1307146873803665408",
    "fullText" : "人間の体って結構仕組み的にバグってるのいろいろ問題だよな",
    "expandedUrl" : "https://twitter.com/i/web/status/1307146873803665408"
  }
}, {
  "like" : {
    "tweetId" : "1307433009042259968",
    "fullText" : "ねた、おきた",
    "expandedUrl" : "https://twitter.com/i/web/status/1307433009042259968"
  }
}, {
  "like" : {
    "tweetId" : "1306883600827080704",
    "fullText" : "Magic Keyboard30分ぐらい使ってるとなれてくるよね",
    "expandedUrl" : "https://twitter.com/i/web/status/1306883600827080704"
  }
}, {
  "like" : {
    "tweetId" : "1307347255762907136",
    "fullText" : "Piscine落ちたショックで昨日、今日と勉強に手がついてないので、現時点で考えてる漠然とした方向性を記す。\n\nサークルでもらったアドバイスによるとC, Python, Javascriptが使えれば、くいっぱぐれはないそうだし、元々、この3言語習得を目標にしてたのでこれらを使えるようになることが現時点の目標",
    "expandedUrl" : "https://twitter.com/i/web/status/1307347255762907136"
  }
}, {
  "like" : {
    "tweetId" : "1307189357934075906",
    "fullText" : "しかし酒飲んで半日寝たらめちゃくちゃ体調良くなったな",
    "expandedUrl" : "https://twitter.com/i/web/status/1307189357934075906"
  }
}, {
  "like" : {
    "tweetId" : "1306890931585429504",
    "fullText" : "案の定42Tokyo落ちてた。\nなんだこれ、チャンスか？",
    "expandedUrl" : "https://twitter.com/i/web/status/1306890931585429504"
  }
}, {
  "like" : {
    "tweetId" : "1306623677237137408",
    "fullText" : "六本木「一丁目」！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1306623677237137408"
  }
}, {
  "like" : {
    "tweetId" : "1306420133888360448",
    "fullText" : "#デッドプール のインタラクティブヘッドが登場❗️\n\nデッドプールのヘッドの形をしたアイテムが、あなたの声や動作に反応して映画の中のフレーズや効果音を発します🔊\n\n専用アプリを使ってデッドプールヘッドとあのシーンを再現して楽しもう！\n\nhttps://t.co/p9KMQHjzKH（Amazon）\n※音声は英語のみです https://t.co/shg2QwZlVs",
    "expandedUrl" : "https://twitter.com/i/web/status/1306420133888360448"
  }
}, {
  "like" : {
    "tweetId" : "1306815674010890241",
    "fullText" : "42受かりました、これからもよろしくお願いします",
    "expandedUrl" : "https://twitter.com/i/web/status/1306815674010890241"
  }
}, {
  "like" : {
    "tweetId" : "1306834530129440768",
    "fullText" : "午前組お疲れ様です！\n\n今学校から向かいますー。。\n午後組頑張りましょう！！\n\n今回は1点でもいいから取りたいなー🤨\n\n#42tokyo #piscine #exam",
    "expandedUrl" : "https://twitter.com/i/web/status/1306834530129440768"
  }
}, {
  "like" : {
    "tweetId" : "1306245143519920128",
    "fullText" : "産む機械とか口にする世代の退場を待っていたのだけど、その下の世代でSNSも使え、日々世界の動向を見ているのに「懐かしのスカートめくり」だの「またオカマ役」だのとユーモアのつもりで言う人がどんどんいる日本ミュージカル業界の未来に絶望を感じる。",
    "expandedUrl" : "https://twitter.com/i/web/status/1306245143519920128"
  }
}, {
  "like" : {
    "tweetId" : "1128631601519157248",
    "fullText" : "ローコストでキーキャップに昇華印刷する方法をためしてみた https://t.co/wP75aDtOSg",
    "expandedUrl" : "https://twitter.com/i/web/status/1128631601519157248"
  }
}, {
  "like" : {
    "tweetId" : "1306830721022005250",
    "fullText" : "Piscine 8月合格しました🔥10月5日からもよろしくお願いします！！🙇🏻‍♂️",
    "expandedUrl" : "https://twitter.com/i/web/status/1306830721022005250"
  }
}, {
  "like" : {
    "tweetId" : "1306816627665588224",
    "fullText" : "自主退出だん！",
    "expandedUrl" : "https://twitter.com/i/web/status/1306816627665588224"
  }
}, {
  "like" : {
    "tweetId" : "1306811187896528898",
    "fullText" : "#42Tokyo \n受かってたぁああーーーーーー！　\nやばい、うれしい",
    "expandedUrl" : "https://twitter.com/i/web/status/1306811187896528898"
  }
}, {
  "like" : {
    "tweetId" : "1306753376181301248",
    "fullText" : "@_unlimish あっちはあっちで元カノがよく出てくるからやだ。",
    "expandedUrl" : "https://twitter.com/i/web/status/1306753376181301248"
  }
}, {
  "like" : {
    "tweetId" : "1301443463506845697",
    "fullText" : "VARMILOのカスタムキーボードサービスやば！！！\nケース・キーキャップ・キースイッチ全部選んでカスタムオーダーできる。\n文字色は昇華印刷で6色から選択、キーキャップは18色から好きに組み合わせられるし1キーごとに設定できる。\n\nつまり\n\n「「「軽率に推しキーボードが作れる！！！」」」 https://t.co/n0ftX6XAyw",
    "expandedUrl" : "https://twitter.com/i/web/status/1301443463506845697"
  }
}, {
  "like" : {
    "tweetId" : "1306604031213666306",
    "fullText" : "テスト前日の激辛ラーメンはアカンかった",
    "expandedUrl" : "https://twitter.com/i/web/status/1306604031213666306"
  }
}, {
  "like" : {
    "tweetId" : "1306759948412489728",
    "fullText" : "はよ一人暮らししたいんだが家事とタスク管理がやっぱりできない気がする。",
    "expandedUrl" : "https://twitter.com/i/web/status/1306759948412489728"
  }
}, {
  "like" : {
    "tweetId" : "1306770822875369474",
    "fullText" : "@Hinata72279726 こっちが見つけられなかったぴえん",
    "expandedUrl" : "https://twitter.com/i/web/status/1306770822875369474"
  }
}, {
  "like" : {
    "tweetId" : "1306772056499867650",
    "fullText" : "@Hinata72279726 (づ｡◕‿‿◕｡)づ",
    "expandedUrl" : "https://twitter.com/i/web/status/1306772056499867650"
  }
}, {
  "like" : {
    "tweetId" : "1306771482521907200",
    "fullText" : "@Hinata72279726 帰って0点になっちゃえ〜",
    "expandedUrl" : "https://twitter.com/i/web/status/1306771482521907200"
  }
}, {
  "like" : {
    "tweetId" : "1306767840834252804",
    "fullText" : "@Hinata72279726 ななふんでつく！",
    "expandedUrl" : "https://twitter.com/i/web/status/1306767840834252804"
  }
}, {
  "like" : {
    "tweetId" : "1306763073802313729",
    "fullText" : "@Hinata72279726 あっ₍₍◞( •௰• )◟₎₎",
    "expandedUrl" : "https://twitter.com/i/web/status/1306763073802313729"
  }
}, {
  "like" : {
    "tweetId" : "1306849945077440513",
    "fullText" : "42合格してました😭\n助けて頂いた方々ありがとうございました‼️",
    "expandedUrl" : "https://twitter.com/i/web/status/1306849945077440513"
  }
}, {
  "like" : {
    "tweetId" : "1306751773638455296",
    "fullText" : "@jcarol45241937 一本木「六丁目！！」",
    "expandedUrl" : "https://twitter.com/i/web/status/1306751773638455296"
  }
}, {
  "like" : {
    "tweetId" : "1306769688186114049",
    "fullText" : "@Hinata72279726 もう中入ったよ！",
    "expandedUrl" : "https://twitter.com/i/web/status/1306769688186114049"
  }
}, {
  "like" : {
    "tweetId" : "1306766002420690946",
    "fullText" : "@Hinata72279726 はえぇ",
    "expandedUrl" : "https://twitter.com/i/web/status/1306766002420690946"
  }
}, {
  "like" : {
    "tweetId" : "1306847794536177664",
    "fullText" : "US配列のキーボードがほしい！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1306847794536177664"
  }
}, {
  "like" : {
    "tweetId" : "1306748260451643392",
    "fullText" : "ほうほう。\nちょっと過ぎてたけど、教員辞めてから1年経ったんだ………… https://t.co/MJI3GwoLiD",
    "expandedUrl" : "https://twitter.com/i/web/status/1306748260451643392"
  }
}, {
  "like" : {
    "tweetId" : "1306592161094184960",
    "fullText" : "フォートナイトが新たな光に照らされる。\n\n本日より、サポートされているNVIDIA GPUカードとDirectX12を使用しているユーザーにレイトレーシングとNVIDIA DLSSが解禁されます！\n\n#FortniteRTX に関する詳細はブログをご覧ください: https://t.co/4DZYaIzGJ5 https://t.co/9HkSKmKemj",
    "expandedUrl" : "https://twitter.com/i/web/status/1306592161094184960"
  }
}, {
  "like" : {
    "tweetId" : "1306210471247114240",
    "fullText" : "Piscine続けてると吐き気が出てくるのを上昇負荷って言うやつ思いつきましたが全然何も掛かってないですね。使用権フリーです。",
    "expandedUrl" : "https://twitter.com/i/web/status/1306210471247114240"
  }
}, {
  "like" : {
    "tweetId" : "1306717940885012480",
    "fullText" : "おはよー、今日がんばろー",
    "expandedUrl" : "https://twitter.com/i/web/status/1306717940885012480"
  }
}, {
  "like" : {
    "tweetId" : "1306746882022989824",
    "fullText" : "俺ならできる俺ならできる。",
    "expandedUrl" : "https://twitter.com/i/web/status/1306746882022989824"
  }
}, {
  "like" : {
    "tweetId" : "1306151561182113792",
    "fullText" : "なんかPiscineのみんなが優しすぎてごめんなさいになってる",
    "expandedUrl" : "https://twitter.com/i/web/status/1306151561182113792"
  }
}, {
  "like" : {
    "tweetId" : "1306336153407119361",
    "fullText" : "プレイステーション®5は11月12日(木)に発売決定。\n価格はデジタル・エディションが希望小売価格39,980円＋税、ディスクドライブを備えたモデルが希望小売価格49,980円＋税。\n\n詳しくはこちら⇒ https://t.co/Y9Hv3sk3wd \n\n#PS5 https://t.co/lLPOW2yD9V",
    "expandedUrl" : "https://twitter.com/i/web/status/1306336153407119361"
  }
}, {
  "like" : {
    "tweetId" : "1306476950303551488",
    "fullText" : "あんりみ氏にデザインの作り方を学びたいお気持ち",
    "expandedUrl" : "https://twitter.com/i/web/status/1306476950303551488"
  }
}, {
  "like" : {
    "tweetId" : "1306737097739444224",
    "fullText" : "二度寝しようかと思ったけど目覚めはスッキリなのでもう起きてしまうか",
    "expandedUrl" : "https://twitter.com/i/web/status/1306737097739444224"
  }
}, {
  "like" : {
    "tweetId" : "1306341208579428352",
    "fullText" : "結構寝不足でケアレスミス増えたきたって方が多い。\n\n焦るし、もっとやりたいって思うからすごく気持ちはわかるけど、ちゃんと寝たほうがいいよ。\n\n時間に制約がある人ほど、パフォーマンス意識しないと。（自戒を込めて）\n\n#42Tokyo #piscine",
    "expandedUrl" : "https://twitter.com/i/web/status/1306341208579428352"
  }
}, {
  "like" : {
    "tweetId" : "1306348961695817729",
    "fullText" : "S00~S01。上昇負荷は軽い目眩と吐き気。\n\nC00-C03。上昇負荷は重い吐き気と頭痛、末端の痺れ。\n\nC04-07。上昇負荷は二層に加え、平衡感覚に異常をきたし、幻覚や幻聴を見る。\n\nC08-C10。上昇負荷は人間性の喪失もしくは死。詳細不明\n\nC11-\n上昇負荷は確実な死。詳細不明",
    "expandedUrl" : "https://twitter.com/i/web/status/1306348961695817729"
  }
}, {
  "like" : {
    "tweetId" : "1306159668528472064",
    "fullText" : "@_unlimish わかりみあんりみ",
    "expandedUrl" : "https://twitter.com/i/web/status/1306159668528472064"
  }
}, {
  "like" : {
    "tweetId" : "1306541966029537281",
    "fullText" : "@Hinata72279726 楽しくレビューして、気持ちよく勉強したいです！",
    "expandedUrl" : "https://twitter.com/i/web/status/1306541966029537281"
  }
}, {
  "like" : {
    "tweetId" : "1306375704741687301",
    "fullText" : "えっうそ、お湯湧くの待たなくていいのこれ！？買うわ",
    "expandedUrl" : "https://twitter.com/i/web/status/1306375704741687301"
  }
}, {
  "like" : {
    "tweetId" : "1306566451126366208",
    "fullText" : "Switch版を対象に、安定性向上のためのメンテナンスパッチを公開しました。 https://t.co/lsArkcBYgE",
    "expandedUrl" : "https://twitter.com/i/web/status/1306566451126366208"
  }
}, {
  "like" : {
    "tweetId" : "1306179384861028352",
    "fullText" : "腰痛い\nなんかいいストレッチないだろうか",
    "expandedUrl" : "https://twitter.com/i/web/status/1306179384861028352"
  }
}, {
  "like" : {
    "tweetId" : "1306377066217046022",
    "fullText" : "タワマンとか住むやつ、バカと煙はなんとやらと思ってたが、俗世を物理的に見下ろせるのいいな。アリだな。ということでよろしくおねがいします。",
    "expandedUrl" : "https://twitter.com/i/web/status/1306377066217046022"
  }
}, {
  "like" : {
    "tweetId" : "1306163307607252992",
    "fullText" : "@Kahorin_42Tokyo なー",
    "expandedUrl" : "https://twitter.com/i/web/status/1306163307607252992"
  }
}, {
  "like" : {
    "tweetId" : "1306177383074951168",
    "fullText" : "味覚的な刺激もな？ https://t.co/O6rmpzC8fA",
    "expandedUrl" : "https://twitter.com/i/web/status/1306177383074951168"
  }
}, {
  "like" : {
    "tweetId" : "1306143785181569024",
    "fullText" : "ちんちんだるだる現象 https://t.co/nW6grVJ3qE",
    "expandedUrl" : "https://twitter.com/i/web/status/1306143785181569024"
  }
}, {
  "like" : {
    "tweetId" : "1306411357114265601",
    "fullText" : "プレイステーション5上、#UE4 で撮影されたフォートナイトのゲームプレイを初公開 ！👀\n\n発売日から進行度・購入したものを引き継いで無料プレイ可能です！ https://t.co/sREsRD0uz0",
    "expandedUrl" : "https://twitter.com/i/web/status/1306411357114265601"
  }
}, {
  "like" : {
    "tweetId" : "1306159533178322944",
    "fullText" : "安倍前総理大臣、大変お疲れさまでした。7年8か月にわたって国民の負託に応えるのは政治家としての本望でしょう。私自身総統としての二期目を始めたばかりですが、引き続き先生のように日々全力投球で臨んでいきたいとおもいます。また、これからも台日関係の深化を引き続き宜しくお願い致します。",
    "expandedUrl" : "https://twitter.com/i/web/status/1306159533178322944"
  }
}, {
  "like" : {
    "tweetId" : "1306476751619407872",
    "fullText" : "笑ってくれる人とレビューしたい。",
    "expandedUrl" : "https://twitter.com/i/web/status/1306476751619407872"
  }
}, {
  "like" : {
    "tweetId" : "1306108268293414917",
    "fullText" : "人生つらいよなー",
    "expandedUrl" : "https://twitter.com/i/web/status/1306108268293414917"
  }
}, {
  "like" : {
    "tweetId" : "1306377810345259008",
    "fullText" : "世俗を見下ろしながら全裸でラジオ体操しました。ジャンプする度に息子が！息子が！",
    "expandedUrl" : "https://twitter.com/i/web/status/1306377810345259008"
  }
}, {
  "like" : {
    "tweetId" : "1306182834575478784",
    "fullText" : "家に着いたら回線が引かれていた幸せ～いえ～い（家だけに",
    "expandedUrl" : "https://twitter.com/i/web/status/1306182834575478784"
  }
}, {
  "like" : {
    "tweetId" : "1306143348588044289",
    "fullText" : "あ、マックは無事に起動しました、やったぜ",
    "expandedUrl" : "https://twitter.com/i/web/status/1306143348588044289"
  }
}, {
  "like" : {
    "tweetId" : "1306043340039757824",
    "fullText" : "@luna_yuta @Hinata72279726 おきたわw",
    "expandedUrl" : "https://twitter.com/i/web/status/1306043340039757824"
  }
}, {
  "like" : {
    "tweetId" : "1306067382935236610",
    "fullText" : "1週目はわけわからんくてがむしゃらに走るしかなかった。\n2週目はやることはわかってきた。\n\n2週目からはマラソンモードに切り替えて、持久戦に備える。\n\n全く運動できてなかったから、昨日から軽いジョギング始めた。気持ちいいよ。\n\n#42Tokyo #piscine",
    "expandedUrl" : "https://twitter.com/i/web/status/1306067382935236610"
  }
}, {
  "like" : {
    "tweetId" : "1306043736204349442",
    "fullText" : "@_unlimish @Hinata72279726 おは",
    "expandedUrl" : "https://twitter.com/i/web/status/1306043736204349442"
  }
}, {
  "like" : {
    "tweetId" : "1305031803254632448",
    "fullText" : "やっぱ一緒に頑張れる人がいないとメンタルきついな……\n1,2月組は毎日顔突合せたりするから顔見知り増えて楽しかったろうな……\n陰キャの癖にこういうとこだけ陽キャみたいなとこあるの損だな……",
    "expandedUrl" : "https://twitter.com/i/web/status/1305031803254632448"
  }
}, {
  "like" : {
    "tweetId" : "1305272960828149760",
    "fullText" : "聴きたい https://t.co/3VPguh3pYO",
    "expandedUrl" : "https://twitter.com/i/web/status/1305272960828149760"
  }
}, {
  "like" : {
    "tweetId" : "1305105155201724416",
    "fullText" : "これ覚えてるフォートナイト民いる？ https://t.co/3BEaQdtfC8",
    "expandedUrl" : "https://twitter.com/i/web/status/1305105155201724416"
  }
}, {
  "like" : {
    "tweetId" : "1306104913642971137",
    "fullText" : "落ちてる",
    "expandedUrl" : "https://twitter.com/i/web/status/1306104913642971137"
  }
}, {
  "like" : {
    "tweetId" : "1290643740864974848",
    "fullText" : "生産終了したStarryNightの代わりとしてMint60スターターセットに「ABS DarkKnight」が仲間入り！\n黒をベースに黄色が映えるオシャレなキーキャップです！\n\nこんな配色を待ち望んだ人もいるのでは！？\n要チェックです！\nhttps://t.co/tt6RUr1peq https://t.co/Px0L6Y3kwA",
    "expandedUrl" : "https://twitter.com/i/web/status/1290643740864974848"
  }
}, {
  "like" : {
    "tweetId" : "1305053062495522822",
    "fullText" : "@Hinata72279726 過去問ほちい",
    "expandedUrl" : "https://twitter.com/i/web/status/1305053062495522822"
  }
}, {
  "like" : {
    "tweetId" : "1305792426448023553",
    "fullText" : "@Hinata72279726 ひぃん（よしよし）",
    "expandedUrl" : "https://twitter.com/i/web/status/1305792426448023553"
  }
}, {
  "like" : {
    "tweetId" : "1250014109115904007",
    "fullText" : "自作キーボード「Mint60」はこちらで購入可能です！ キースイッチ、キーキャップとプレート色をそれぞれ選択することで好きな見た目と打ち心地を選ぶことができます。\n現代人にとっての必須ツールといえばキーボード！ こだわればキリのない自作キーボードの世界はこちらに。\nhttps://t.co/tt6RUrj05Y https://t.co/kzKMJyvJcM",
    "expandedUrl" : "https://twitter.com/i/web/status/1250014109115904007"
  }
}, {
  "like" : {
    "tweetId" : "1305793089466822656",
    "fullText" : "@Hinata72279726 いっぱいコード書くんだよ。",
    "expandedUrl" : "https://twitter.com/i/web/status/1305793089466822656"
  }
}, {
  "like" : {
    "tweetId" : "1305527421853032448",
    "fullText" : "今から妻の英語エッセイのレビュー。アルファベットから離れられないww",
    "expandedUrl" : "https://twitter.com/i/web/status/1305527421853032448"
  }
}, {
  "like" : {
    "tweetId" : "1292051341733318656",
    "fullText" : "今年のお盆は引きこもって自作キーボード！！\n初心者向け「Mint60」のスターターセットはこちらです！\n新しいキーキャップも大好評発売中！\n\nhttps://t.co/tt6RUrj05Y https://t.co/2xTAAEMqVz",
    "expandedUrl" : "https://twitter.com/i/web/status/1292051341733318656"
  }
}, {
  "like" : {
    "tweetId" : "1306120534598410241",
    "fullText" : "置いてかれる感じとテストで鬱になってました。再着火しようと試みてる",
    "expandedUrl" : "https://twitter.com/i/web/status/1306120534598410241"
  }
}, {
  "like" : {
    "tweetId" : "1305154073713238017",
    "fullText" : "絵画に描かれたオフィーリア。\n愛と狂気に沈む。 https://t.co/5gYEKu3E49",
    "expandedUrl" : "https://twitter.com/i/web/status/1305154073713238017"
  }
}, {
  "like" : {
    "tweetId" : "1305446233037664257",
    "fullText" : "ディスコ中毒者になりつつある。",
    "expandedUrl" : "https://twitter.com/i/web/status/1305446233037664257"
  }
}, {
  "like" : {
    "tweetId" : "1305379814933630976",
    "fullText" : "注意欠陥クソババア予備軍なのでコードを書いてコンパイルするとエラーがいっぱい出てくる",
    "expandedUrl" : "https://twitter.com/i/web/status/1305379814933630976"
  }
}, {
  "like" : {
    "tweetId" : "1306076791962963968",
    "fullText" : "@Hinata72279726 はい！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1306076791962963968"
  }
}, {
  "like" : {
    "tweetId" : "1305348629549338626",
    "fullText" : "フォートナイトで温泉作ったよ！\n#温泉ゴンテスト https://t.co/phY5wfjXJW",
    "expandedUrl" : "https://twitter.com/i/web/status/1305348629549338626"
  }
}, {
  "like" : {
    "tweetId" : "1305026139501420546",
    "fullText" : "生き別れの靴下を20組再会させたので今日は自分を褒めてあげたい",
    "expandedUrl" : "https://twitter.com/i/web/status/1305026139501420546"
  }
}, {
  "like" : {
    "tweetId" : "1305866352075341827",
    "fullText" : "C言語入って完全に溺れた民です。\n\nどなたか超基礎がわかるオススメ教えてくださいー😭\n\nそれともこういうもの、で進めた方がいいんですかね？\n\n#piscine #42tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1305866352075341827"
  }
}, {
  "like" : {
    "tweetId" : "1306045541973778432",
    "fullText" : "@Hinata72279726 @luna_yuta おはみ〜",
    "expandedUrl" : "https://twitter.com/i/web/status/1306045541973778432"
  }
}, {
  "like" : {
    "tweetId" : "1306043164734619648",
    "fullText" : "@Hinata72279726 --exclude-unlimish",
    "expandedUrl" : "https://twitter.com/i/web/status/1306043164734619648"
  }
}, {
  "like" : {
    "tweetId" : "1305634573192060928",
    "fullText" : "おはよう、息子はなぜか5時起き、今日も元気！",
    "expandedUrl" : "https://twitter.com/i/web/status/1305634573192060928"
  }
}, {
  "like" : {
    "tweetId" : "1304355965785927680",
    "fullText" : "https://t.co/ebp4A2yMlJ",
    "expandedUrl" : "https://twitter.com/i/web/status/1304355965785927680"
  }
}, {
  "like" : {
    "tweetId" : "1304353067538591744",
    "fullText" : "@Hinata72279726 ww\nよろしくお願いします！",
    "expandedUrl" : "https://twitter.com/i/web/status/1304353067538591744"
  }
}, {
  "like" : {
    "tweetId" : "1303109470810120192",
    "fullText" : "昨日は11:00からPiscineスタートして26:00まで一つの問題が解決できず💦\n#42tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1303109470810120192"
  }
}, {
  "like" : {
    "tweetId" : "1304251014778888193",
    "fullText" : "@Hinata72279726 いえグランドタワーの近くでコンビニ探してたら迷いまして！\nとはいえこの時間にTwitterにいることでお察しなんですが…（笑）",
    "expandedUrl" : "https://twitter.com/i/web/status/1304251014778888193"
  }
}, {
  "like" : {
    "tweetId" : "1304680948160626689",
    "fullText" : "久々のミラコスタぁー！！ https://t.co/YqUfkOrZeI",
    "expandedUrl" : "https://twitter.com/i/web/status/1304680948160626689"
  }
}, {
  "like" : {
    "tweetId" : "1304292887618678787",
    "fullText" : "長野パープルとシャインマスカットに慰めてもらってる https://t.co/0bQUDoVhf9",
    "expandedUrl" : "https://twitter.com/i/web/status/1304292887618678787"
  }
}, {
  "like" : {
    "tweetId" : "1304316555241467905",
    "fullText" : "@jcarol45241937 そのTLに大変貢献しているノイズ垂れ流しbotがこちら",
    "expandedUrl" : "https://twitter.com/i/web/status/1304316555241467905"
  }
}, {
  "like" : {
    "tweetId" : "1304314319853613056",
    "fullText" : "exam死亡ツイートに対して8月組の先輩たちがたくさんいいねを押してくれている件w\n\n#42Tokyo #piscine",
    "expandedUrl" : "https://twitter.com/i/web/status/1304314319853613056"
  }
}, {
  "like" : {
    "tweetId" : "1303906579222204416",
    "fullText" : "Piscineで15時間くらいはパソコンに張り付く。ほぼ悩んで調べて悩んでる時間😂\n\n寝不足続き🥱",
    "expandedUrl" : "https://twitter.com/i/web/status/1303906579222204416"
  }
}, {
  "like" : {
    "tweetId" : "1304757870798319616",
    "fullText" : "Piscineから離れた瞬間じわじわ現実に引き戻されて病むのでこれはいい現実逃避だなってなってる",
    "expandedUrl" : "https://twitter.com/i/web/status/1304757870798319616"
  }
}, {
  "like" : {
    "tweetId" : "1304312945946497025",
    "fullText" : "ワシがTwitterに浮上するのは電車移動中かウ○コ中です(ティグ",
    "expandedUrl" : "https://twitter.com/i/web/status/1304312945946497025"
  }
}, {
  "like" : {
    "tweetId" : "1304310562113769473",
    "fullText" : "@Hinata72279726 それな！！(だから違うって",
    "expandedUrl" : "https://twitter.com/i/web/status/1304310562113769473"
  }
}, {
  "like" : {
    "tweetId" : "1304343288590135297",
    "fullText" : "そーゆーことだったんですね😂😂😂",
    "expandedUrl" : "https://twitter.com/i/web/status/1304343288590135297"
  }
}, {
  "like" : {
    "tweetId" : "1304310695060582400",
    "fullText" : "わかる(わかる) https://t.co/NlM8Nl9rv3",
    "expandedUrl" : "https://twitter.com/i/web/status/1304310695060582400"
  }
}, {
  "like" : {
    "tweetId" : "1304301678863069184",
    "fullText" : "Examめっちゃおもしろくて4時間あっという間でした。脳内麻薬ドバドバ出ます。午後組頑張って！",
    "expandedUrl" : "https://twitter.com/i/web/status/1304301678863069184"
  }
}, {
  "like" : {
    "tweetId" : "1304312263315136512",
    "fullText" : "@machiko1012 @Yuki091217 頑張ってくださいー！！\nBy 午前組",
    "expandedUrl" : "https://twitter.com/i/web/status/1304312263315136512"
  }
}, {
  "like" : {
    "tweetId" : "1304319775871397889",
    "fullText" : "@Hinata72279726 ありがとうございます！\nいまは放心状態です、、、",
    "expandedUrl" : "https://twitter.com/i/web/status/1304319775871397889"
  }
}, {
  "like" : {
    "tweetId" : "1304306695993081857",
    "fullText" : "仕事じゃないのにpc持ち歩いてる自分に草\n意識高い系ですか？いいえ、何が起きるか分からなくて不安なだけです",
    "expandedUrl" : "https://twitter.com/i/web/status/1304306695993081857"
  }
}, {
  "like" : {
    "tweetId" : "1304316332352004097",
    "fullText" : "金曜日になってタイムラインがすごい進むなぁ〜",
    "expandedUrl" : "https://twitter.com/i/web/status/1304316332352004097"
  }
}, {
  "like" : {
    "tweetId" : "1304316089044672513",
    "fullText" : "@Hinata72279726 わい！すこ一丁いただきましたっ！💯",
    "expandedUrl" : "https://twitter.com/i/web/status/1304316089044672513"
  }
}, {
  "like" : {
    "tweetId" : "1304570114356903936",
    "fullText" : "おはようございます😀\n\n今日は休み！\nあいにくの雨ですが、家族でドライブに行ってきます😄\n\n今日も笑顔で素敵な1日を😉\n\n #おは戦20912sd 🍩",
    "expandedUrl" : "https://twitter.com/i/web/status/1304570114356903936"
  }
}, {
  "like" : {
    "tweetId" : "1304633051255730178",
    "fullText" : "感情の起伏がジェットコースターなだけです\n昨日はノリノリでc言語の基礎を教えてました。\n久々に教員魂がファイアーしてました https://t.co/ZxTfWXd0ty",
    "expandedUrl" : "https://twitter.com/i/web/status/1304633051255730178"
  }
}, {
  "like" : {
    "tweetId" : "1305025330663415808",
    "fullText" : "運ゲーすぎる、良い人に当たらないと地獄やんけ。。。\n1周目で楽しくできてると来週以降が心配になるわ",
    "expandedUrl" : "https://twitter.com/i/web/status/1305025330663415808"
  }
}, {
  "like" : {
    "tweetId" : "1304349770178207744",
    "fullText" : "@Hinata72279726 hi!\nミスター呼びってことは昨日のdiscordにいた方ですね？？",
    "expandedUrl" : "https://twitter.com/i/web/status/1304349770178207744"
  }
}, {
  "like" : {
    "tweetId" : "1304320758034780161",
    "fullText" : "もう金曜日ですか😂",
    "expandedUrl" : "https://twitter.com/i/web/status/1304320758034780161"
  }
}, {
  "like" : {
    "tweetId" : "1303209061089853442",
    "fullText" : "集中力のなさを実感してる🥱\n親子丼食う🥱🥱🥱 https://t.co/2rbk5WTSvC",
    "expandedUrl" : "https://twitter.com/i/web/status/1303209061089853442"
  }
}, {
  "like" : {
    "tweetId" : "1303234084148191237",
    "fullText" : "何がわからないのかわからない。\n唯一、自分がわかってないことはわかる",
    "expandedUrl" : "https://twitter.com/i/web/status/1303234084148191237"
  }
}, {
  "like" : {
    "tweetId" : "1304195933794496512",
    "fullText" : "諸々落ち着いたらアボガドディップパーティしようぜ https://t.co/uNaB6YDkk6",
    "expandedUrl" : "https://twitter.com/i/web/status/1304195933794496512"
  }
}, {
  "like" : {
    "tweetId" : "1303828395822690305",
    "fullText" : "ちょっと孤独。人に話しかけるの苦手だから姿が見えないリモートはきっかけも掴みにくいんだな。でも、レビューしてくれる人、みんな親切で、本当ありがたい。",
    "expandedUrl" : "https://twitter.com/i/web/status/1303828395822690305"
  }
}, {
  "like" : {
    "tweetId" : "1304225297051471872",
    "fullText" : "@Hinata72279726 うれぴ！",
    "expandedUrl" : "https://twitter.com/i/web/status/1304225297051471872"
  }
}, {
  "like" : {
    "tweetId" : "1304219851590758400",
    "fullText" : "+ 内側に尿カテいれるとよさそう（マジレス） https://t.co/r1UMuHlsMN",
    "expandedUrl" : "https://twitter.com/i/web/status/1304219851590758400"
  }
}, {
  "like" : {
    "tweetId" : "1302844465783042050",
    "fullText" : "アンジャッシュ児島さんのメイクシリーズ、男性が女性のメイクする動画にありがちな「こんなことやってんの！？」みたいな否定的な発言が一切なくて、\n「すごい、この一手間で変わるね」「違和感ないね」「可愛くなるね」「盛れました🤗」と全肯定してくれるから観てて何故かこっちが嬉しくなっちゃう",
    "expandedUrl" : "https://twitter.com/i/web/status/1302844465783042050"
  }
}, {
  "like" : {
    "tweetId" : "1304220461144834048",
    "fullText" : "今日は深いプールで泳いでからジャグジーバスに入るよ",
    "expandedUrl" : "https://twitter.com/i/web/status/1304220461144834048"
  }
}, {
  "like" : {
    "tweetId" : "1298929039525023744",
    "fullText" : "piscineなんとか泳ぎ切れました！wwww\nあと2日でというところで終わってしまいましたが、piscine楽しかったです！\n合否なんて関係なくまた、どっかで皆さんと会いたいです。　\nいや、会いましょう！！w\n本当にいろんな方に助けてもらいました！ありがとうございました！😊",
    "expandedUrl" : "https://twitter.com/i/web/status/1298929039525023744"
  }
}, {
  "like" : {
    "tweetId" : "1304192144198889474",
    "fullText" : "うーし、頑張るぞー\n電車に乗るのが久しぶり過ぎて緊張する…\n\n#42Tokyo #piscine",
    "expandedUrl" : "https://twitter.com/i/web/status/1304192144198889474"
  }
}, {
  "like" : {
    "tweetId" : "1304036129990041600",
    "fullText" : "01の08が…うっ…🥺あ",
    "expandedUrl" : "https://twitter.com/i/web/status/1304036129990041600"
  }
}, {
  "like" : {
    "tweetId" : "1304231478360858624",
    "fullText" : "辛くなったら窓の外の東京タワーを眺めると元気が出るとおもうんヾ(･ω･｀)ﾀﾞﾈﾀﾞﾈ♪‌‌",
    "expandedUrl" : "https://twitter.com/i/web/status/1304231478360858624"
  }
}, {
  "like" : {
    "tweetId" : "1303879027606708225",
    "fullText" : "アイマスク、本当に疲れて寝付けないのきに脳を強制シャットダウンさせてくれる　-f",
    "expandedUrl" : "https://twitter.com/i/web/status/1303879027606708225"
  }
}, {
  "like" : {
    "tweetId" : "1304227224711622656",
    "fullText" : "東京は情報量多いから好きじゃない",
    "expandedUrl" : "https://twitter.com/i/web/status/1304227224711622656"
  }
}, {
  "like" : {
    "tweetId" : "1304229552202289153",
    "fullText" : "校舎ついたけどなにこの緊張感",
    "expandedUrl" : "https://twitter.com/i/web/status/1304229552202289153"
  }
}, {
  "like" : {
    "tweetId" : "1304086917693145091",
    "fullText" : "エンジニアの知り合いに\n\nmanコマンド使いこなせたら、まだあと20年飯食えるよ\n\nって励まされたーw",
    "expandedUrl" : "https://twitter.com/i/web/status/1304086917693145091"
  }
}, {
  "like" : {
    "tweetId" : "1303862565189988353",
    "fullText" : "@Hinata72279726 私もそうなります🤯",
    "expandedUrl" : "https://twitter.com/i/web/status/1303862565189988353"
  }
}, {
  "like" : {
    "tweetId" : "1303160710885638144",
    "fullText" : "@Hinata72279726 自分も10時くらいまで寝てて自己嫌悪に陥ってます😔😔😔",
    "expandedUrl" : "https://twitter.com/i/web/status/1303160710885638144"
  }
}, {
  "like" : {
    "tweetId" : "1304012147567915009",
    "fullText" : "３日間集中の反動か\n今日いきなり\nあれっ？今までこれどうやってたっけ、、、って突然頭が真っ白けに。\n\n頭を強く打った？！みたいな\n自分のバグにおどろいた。\n\n優しく助けてくれたみなさんありがとう！！\n\n一ミリずつでも進む！\n\nそして明日は波のプールかもしれない\n\n乗るしかない！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1304012147567915009"
  }
}, {
  "like" : {
    "tweetId" : "1304092576882946050",
    "fullText" : "スローペースだけど\n着実にできること増えてる👍\n\n象形文字が読める感覚🤩\n\n#プログラミング\n#42tokyo\n#piscine",
    "expandedUrl" : "https://twitter.com/i/web/status/1304092576882946050"
  }
}, {
  "like" : {
    "tweetId" : "1304217392482975744",
    "fullText" : "ああ…(引きつった顔 https://t.co/XWaaifiPSH",
    "expandedUrl" : "https://twitter.com/i/web/status/1304217392482975744"
  }
}, {
  "like" : {
    "tweetId" : "1303879361234255872",
    "fullText" : "時に",
    "expandedUrl" : "https://twitter.com/i/web/status/1303879361234255872"
  }
}, {
  "like" : {
    "tweetId" : "1304027489300217857",
    "fullText" : "これ好き https://t.co/MlgJDWFnVk",
    "expandedUrl" : "https://twitter.com/i/web/status/1304027489300217857"
  }
}, {
  "like" : {
    "tweetId" : "1303894344307408896",
    "fullText" : "VS codeでhttps://t.co/y7EYH2jhfs使えたのね😁 https://t.co/O2e2jBE6gN",
    "expandedUrl" : "https://twitter.com/i/web/status/1303894344307408896"
  }
}, {
  "like" : {
    "tweetId" : "1303151114213142532",
    "fullText" : "@Hinata72279726 まだ2日目なので自分のペースでやりましょ",
    "expandedUrl" : "https://twitter.com/i/web/status/1303151114213142532"
  }
}, {
  "like" : {
    "tweetId" : "1301916995525378048",
    "fullText" : "piscineまであと2日だがいい気分転換になって気相入れ直せた！！一ヶ月間粉骨砕身で頑張るのみ！！！ https://t.co/OWDHrNrhaA",
    "expandedUrl" : "https://twitter.com/i/web/status/1301916995525378048"
  }
}, {
  "like" : {
    "tweetId" : "1302550166730276865",
    "fullText" : "明日からのPiscine、\n校舎通いで頑張ります。\n全くの初心者なので質問しまくるかもしれませんが、皆さん引かずに教えてください🙇‍♂️",
    "expandedUrl" : "https://twitter.com/i/web/status/1302550166730276865"
  }
}, {
  "like" : {
    "tweetId" : "1302605898385293320",
    "fullText" : "恥を捨て、聴きまくる覚悟を明日から持つ予定なので\n\n飛び込みで質問きていーよー！って方、答えられるかわからないけど一緒に考えたい！と思ってくださる方\nいいねか、りぷか、DMいただければと思います。\n\n私の方は、答えられるか不明ですが一緒に考えたいのでぜひ皆様からのDMお待ちしております！",
    "expandedUrl" : "https://twitter.com/i/web/status/1302605898385293320"
  }
}, {
  "like" : {
    "tweetId" : "1302441389850898432",
    "fullText" : "今日も１日 https://t.co/KYjQ6Lv4hF",
    "expandedUrl" : "https://twitter.com/i/web/status/1302441389850898432"
  }
}, {
  "like" : {
    "tweetId" : "1302916102125543424",
    "fullText" : "私は教祖になりました",
    "expandedUrl" : "https://twitter.com/i/web/status/1302916102125543424"
  }
}, {
  "like" : {
    "tweetId" : "1302128163229560832",
    "fullText" : "そうだよ！私はうさぎさんなので準備せずに挑むしこの土日は必死に遊ぶで。",
    "expandedUrl" : "https://twitter.com/i/web/status/1302128163229560832"
  }
}, {
  "like" : {
    "tweetId" : "1302556560716042246",
    "fullText" : "明日からpiscineか。\n今回、自分はスルーすることにしましたが、皆さん頑張って下さい！",
    "expandedUrl" : "https://twitter.com/i/web/status/1302556560716042246"
  }
}, {
  "like" : {
    "tweetId" : "1302753919458631681",
    "fullText" : "Piscine当日ですが、この時間まで寝てました",
    "expandedUrl" : "https://twitter.com/i/web/status/1302753919458631681"
  }
}, {
  "like" : {
    "tweetId" : "1301765924270215168",
    "fullText" : "強制されると学習効率めちゃくちゃ落ちる",
    "expandedUrl" : "https://twitter.com/i/web/status/1301765924270215168"
  }
}, {
  "like" : {
    "tweetId" : "1302912318301327361",
    "fullText" : "@Hinata72279726 全然わかりません！！よろしくお願いします！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1302912318301327361"
  }
}, {
  "like" : {
    "tweetId" : "1302178227700424705",
    "fullText" : "ピシンに向け1番準備したことは、今抱えている仕事を片付け、期間中に残業を出さず、休日出勤が発生しないようにしておくことだった。\n\n、、、、\n\n担当追加って、聞き間違い？\n\nいえーい、ぴーすぴーす",
    "expandedUrl" : "https://twitter.com/i/web/status/1302178227700424705"
  }
}, {
  "like" : {
    "tweetId" : "1302130924969054208",
    "fullText" : "なんだよこれwwwwwwwwwwww https://t.co/KDJsXZgNUF",
    "expandedUrl" : "https://twitter.com/i/web/status/1302130924969054208"
  }
}, {
  "like" : {
    "tweetId" : "1301873876981350411",
    "fullText" : "プログラマー、エンジニアの方にご質問\n\nズバリ去年の年収はいくら⁉️\n\n拡散して貰えると嬉しいです😌",
    "expandedUrl" : "https://twitter.com/i/web/status/1301873876981350411"
  }
}, {
  "like" : {
    "tweetId" : "1302598225233285120",
    "fullText" : "これからPiscineを受ける人へのアドバイスとして、\n”人との縁はマジで大事にする”\n“どうしても分からないことは恥捨ててガンガン人に聞きまくる”\nこの2つがとても大事なことだと思います！",
    "expandedUrl" : "https://twitter.com/i/web/status/1302598225233285120"
  }
}, {
  "like" : {
    "tweetId" : "1302488701713309696",
    "fullText" : "piscineオンライン参加だけど、たまに平日六本木に行くことは可能なのかな？金曜日以外にふらっと行けたらいいな..",
    "expandedUrl" : "https://twitter.com/i/web/status/1302488701713309696"
  }
}, {
  "like" : {
    "tweetId" : "1302971019976679424",
    "fullText" : "piscine、これはいい環境だ",
    "expandedUrl" : "https://twitter.com/i/web/status/1302971019976679424"
  }
}, {
  "like" : {
    "tweetId" : "1302912444860260365",
    "fullText" : "僕も全然わかりません！！泥臭くても頑張ります！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1302912444860260365"
  }
}, {
  "like" : {
    "tweetId" : "1302775151818190848",
    "fullText" : "やば、今起きたんだが(おっそ)",
    "expandedUrl" : "https://twitter.com/i/web/status/1302775151818190848"
  }
}, {
  "like" : {
    "tweetId" : "1302533099650076674",
    "fullText" : "先発Piscine生も15-6時間平気でやってるらしいのコミット力が半端ないな……2時間すら集中力保って自習出来ないのに登りきれる絵が思い浮かばんぜ……",
    "expandedUrl" : "https://twitter.com/i/web/status/1302533099650076674"
  }
}, {
  "like" : {
    "tweetId" : "1302041403531251712",
    "fullText" : "Piscineだれがだれだか覚えられなくてわからんになりそう",
    "expandedUrl" : "https://twitter.com/i/web/status/1302041403531251712"
  }
}, {
  "like" : {
    "tweetId" : "1302600457332826113",
    "fullText" : "後者の「人に聞く」がめちゃくちゃ苦手な私。。。聞く前に慎重になりすぎて言葉纏めてるうちに時間かかり過ぎで死亡。。。仕事では30分悩んで無理なら人に聞くをやってきたけどpiscineはなんか違う気がしてどうしたらいいか進め方のイメージがついてない。 https://t.co/6EsQCAGt6U",
    "expandedUrl" : "https://twitter.com/i/web/status/1302600457332826113"
  }
}, {
  "like" : {
    "tweetId" : "1303036194712772609",
    "fullText" : "ピシン最初の日はやばい…\n#42tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1303036194712772609"
  }
}, {
  "like" : {
    "tweetId" : "1301449468944855045",
    "fullText" : "キーボードは、親指Enter/Backspace/Delete/Tab/Shiftができると幸せになれます",
    "expandedUrl" : "https://twitter.com/i/web/status/1301449468944855045"
  }
}, {
  "like" : {
    "tweetId" : "1302479288529158145",
    "fullText" : "@Hinata72279726 よろしくお願いします😊",
    "expandedUrl" : "https://twitter.com/i/web/status/1302479288529158145"
  }
}, {
  "like" : {
    "tweetId" : "1302942848870801409",
    "fullText" : "全然進めなくて取り残されてる感がすごい（笑）\n先が思いやられるわ、、、",
    "expandedUrl" : "https://twitter.com/i/web/status/1302942848870801409"
  }
}, {
  "like" : {
    "tweetId" : "1300700573738491904",
    "fullText" : "@risacha63828392 したいけど自分に不利益のない方法がわかりません。証拠もありません。名前を出すのは簡単ですが、今のこの日本では被害者である私たちが潰される可能性が高く、簡単に告発と言いますが難しいです。できることなら、やってるんです。",
    "expandedUrl" : "https://twitter.com/i/web/status/1300700573738491904"
  }
}, {
  "like" : {
    "tweetId" : "1300719882439335937",
    "fullText" : "@Hinata72279726 自分のポンコツ具合に笑\nハート、あざます！",
    "expandedUrl" : "https://twitter.com/i/web/status/1300719882439335937"
  }
}, {
  "like" : {
    "tweetId" : "1301733086137217024",
    "fullText" : "@Hinata72279726 👏🏻👏🏻👏🏻👏🏻👏🏻👏🏻👏🏻😻",
    "expandedUrl" : "https://twitter.com/i/web/status/1301733086137217024"
  }
}, {
  "like" : {
    "tweetId" : "1300483205934411777",
    "fullText" : "@Hinata72279726 人生一度のこの機会全身で味わってきてください🕺🏻✨\nひなたさんに幸あれっ！！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1300483205934411777"
  }
}, {
  "like" : {
    "tweetId" : "1301049625671946240",
    "fullText" : "「キャストでコンパイラの警告を黙らせるようなことはやめよう。」",
    "expandedUrl" : "https://twitter.com/i/web/status/1301049625671946240"
  }
}, {
  "like" : {
    "tweetId" : "1300839149461598210",
    "fullText" : "・RTX 3090 1499ドル→23万円\n・RTX 3080 699ドル →11万円\n・RTX 3070 499ドル→8万円\n????????????????????????",
    "expandedUrl" : "https://twitter.com/i/web/status/1300839149461598210"
  }
}, {
  "like" : {
    "tweetId" : "1301030362164768768",
    "fullText" : "42ピシンのためこれを買って明日届きます。楽しみで仕方がないです😬 https://t.co/8teLNWBzkR",
    "expandedUrl" : "https://twitter.com/i/web/status/1301030362164768768"
  }
}, {
  "like" : {
    "tweetId" : "1301755584396406784",
    "fullText" : "@Hinata72279726 自作にくると、普通のキーボード触れなくなっちゃいますよ〜（にっこり）",
    "expandedUrl" : "https://twitter.com/i/web/status/1301755584396406784"
  }
}, {
  "like" : {
    "tweetId" : "1301756272291622912",
    "fullText" : "@Hinata72279726 これがくせになっちゃう…\nhttps://t.co/Ze9ptPCNwf",
    "expandedUrl" : "https://twitter.com/i/web/status/1301756272291622912"
  }
}, {
  "like" : {
    "tweetId" : "1300702908103581696",
    "fullText" : "@Hinata72279726 自分もかぶってます（笑）\nよろしくお願いします。",
    "expandedUrl" : "https://twitter.com/i/web/status/1300702908103581696"
  }
}, {
  "like" : {
    "tweetId" : "1300994225798918144",
    "fullText" : "@Hinata72279726 このメールのリンク先です。 https://t.co/NBVchsVHYX",
    "expandedUrl" : "https://twitter.com/i/web/status/1300994225798918144"
  }
}, {
  "like" : {
    "tweetId" : "1300482191357427712",
    "fullText" : "@Hinata72279726 はい…皆それを切望してます😭",
    "expandedUrl" : "https://twitter.com/i/web/status/1300482191357427712"
  }
}, {
  "like" : {
    "tweetId" : "1301006561507119105",
    "fullText" : "@Hinata72279726 僕も3月参加予定で同じ状況です！\ndiscordには登録できましたが、2月のメールでは上記の画面に飛ぶリンクが来ていません。しばらく待って問い合わせてみようと思ってます！",
    "expandedUrl" : "https://twitter.com/i/web/status/1301006561507119105"
  }
}, {
  "like" : {
    "tweetId" : "1300521946585509893",
    "fullText" : "@Hinata72279726 僕は1週間以上被ってる😭",
    "expandedUrl" : "https://twitter.com/i/web/status/1300521946585509893"
  }
}, {
  "like" : {
    "tweetId" : "1300721411011391488",
    "fullText" : "来た https://t.co/slcZx774GU",
    "expandedUrl" : "https://twitter.com/i/web/status/1300721411011391488"
  }
}, {
  "like" : {
    "tweetId" : "1301021235078262785",
    "fullText" : "@Hinata72279726 😭😭🙏🏻",
    "expandedUrl" : "https://twitter.com/i/web/status/1301021235078262785"
  }
}, {
  "like" : {
    "tweetId" : "1301000522497835008",
    "fullText" : "@Hinata72279726 運営から特に案内が無いので有れば待ちで良いんじゃ無いですかね？",
    "expandedUrl" : "https://twitter.com/i/web/status/1301000522497835008"
  }
}, {
  "like" : {
    "tweetId" : "1300994370758344705",
    "fullText" : "@Hinata72279726 (メールが)来たではなく、(リンク先に自分が)来たの「来た」ってことです",
    "expandedUrl" : "https://twitter.com/i/web/status/1300994370758344705"
  }
}, {
  "like" : {
    "tweetId" : "1300662404473184260",
    "fullText" : "一般区議会議員事務所のキーボードですわ〜 https://t.co/vsT2fhtHv0",
    "expandedUrl" : "https://twitter.com/i/web/status/1300662404473184260"
  }
}, {
  "like" : {
    "tweetId" : "1300777580711174147",
    "fullText" : "42からまだメール来てないねんけど",
    "expandedUrl" : "https://twitter.com/i/web/status/1300777580711174147"
  }
}, {
  "like" : {
    "tweetId" : "1300642187630137344",
    "fullText" : "@Hinata72279726 そうやな",
    "expandedUrl" : "https://twitter.com/i/web/status/1300642187630137344"
  }
}, {
  "like" : {
    "tweetId" : "1301000715427434496",
    "fullText" : "@Hinata72279726 責任は取れませんがurlは全員共通だと思うので手入力でリンク先行っても登録は可能かと。\n\n繰り返します。責任は取れません。",
    "expandedUrl" : "https://twitter.com/i/web/status/1301000715427434496"
  }
}, {
  "like" : {
    "tweetId" : "1301129789843992576",
    "fullText" : "来週の月曜日に興奮します。みんなに会って協力することが楽しみにしています。今42東京9月ピシンに参加者の方の年齢に興味があります。みんなも興味はありませんか？ \n#piscine #42Tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1301129789843992576"
  }
}, {
  "like" : {
    "tweetId" : "1300680213496385537",
    "fullText" : "@Hinata72279726 一緒に頑張ろ！",
    "expandedUrl" : "https://twitter.com/i/web/status/1300680213496385537"
  }
}, {
  "like" : {
    "tweetId" : "1301154700457197569",
    "fullText" : "昨夜ヤケ酒した後のストーリーの自分頭湧いてて草 https://t.co/Kwc9VgXlv3",
    "expandedUrl" : "https://twitter.com/i/web/status/1301154700457197569"
  }
}, {
  "like" : {
    "tweetId" : "1300035442612420609",
    "fullText" : "は、私がPiscine頑張ってる間に浮気されてたのですが。ぶちこ◯していい？？？",
    "expandedUrl" : "https://twitter.com/i/web/status/1300035442612420609"
  }
}, {
  "like" : {
    "tweetId" : "1300123895064743937",
    "fullText" : "わい自身参加してみて、正直しんどくて逃げ出したいときもあったけど、しんどい時に声をかけてくれる純粋に一緒に頑張りたいって思ってくれて全力で手を差し伸べてくれる仲間がたくさんいたなぁって改めて感じる\nまだやれたなって思うけど、人生レベルでがむしゃらに頑張ってたと思う(多分みんなそう",
    "expandedUrl" : "https://twitter.com/i/web/status/1300123895064743937"
  }
}, {
  "like" : {
    "tweetId" : "1300445712379817984",
    "fullText" : "@Hinata72279726 CS専攻でしたら、ハッカソン等のイベントに参加して受賞したりしながら実績を積んでインターンに応募したりすることを強くオススメします。就活・転職は実績を重視されるので。",
    "expandedUrl" : "https://twitter.com/i/web/status/1300445712379817984"
  }
}, {
  "like" : {
    "tweetId" : "1300457077744099328",
    "fullText" : "@nutimaruko @ft_ywatabe ワンコインで殺せちゃうんですかあ⁉️\n\nおもしろすぎてやばい",
    "expandedUrl" : "https://twitter.com/i/web/status/1300457077744099328"
  }
}, {
  "like" : {
    "tweetId" : "1300428153605599232",
    "fullText" : "@Hinata72279726 基本は、わからない箇所があるとヘルプを求めたり、コードレビューで細かい書き方や改善ポイント、コードの意味の確認などしながら理解を深めています。",
    "expandedUrl" : "https://twitter.com/i/web/status/1300428153605599232"
  }
}, {
  "like" : {
    "tweetId" : "1300382110205661184",
    "fullText" : "42のカリキュラムは大学のCS専攻で習うことでしたの一言な気がする。first circleは特に。",
    "expandedUrl" : "https://twitter.com/i/web/status/1300382110205661184"
  }
}, {
  "like" : {
    "tweetId" : "1300426870291226624",
    "fullText" : "管理構造体のインスタンスに書き込まれたらヘッダの情報と各プロトコルのテーブル情報を参照し出力先のインタフェースを決定しながら下位プロトコルへパケットの管理構造体のインスタンスを渡していく\n\n確かこんな感じだったかな～🥱",
    "expandedUrl" : "https://twitter.com/i/web/status/1300426870291226624"
  }
}, {
  "like" : {
    "tweetId" : "1300243051097419776",
    "fullText" : "8月ピシナーをリストに入れて監視してるのばれてた....",
    "expandedUrl" : "https://twitter.com/i/web/status/1300243051097419776"
  }
}, {
  "like" : {
    "tweetId" : "1299020216563728386",
    "fullText" : "『8月参加者のツイートを見て少しでもpiscine を有利に進めよう！』と思っているそこのあなた！\n\n無駄だ。沈んでこい。",
    "expandedUrl" : "https://twitter.com/i/web/status/1299020216563728386"
  }
}, {
  "like" : {
    "tweetId" : "1300444665859076096",
    "fullText" : "@Hinata72279726 私はPiscineでコミュ力をまあまあ取り戻して、Greenに登録して転職活動してたら普通にWebエンジニアとして働けることになりました。\n42Tokyoのことも話したのですが、認知されてなかったですね〜",
    "expandedUrl" : "https://twitter.com/i/web/status/1300444665859076096"
  }
}, {
  "like" : {
    "tweetId" : "1300454455276572672",
    "fullText" : "ID check完了メールきた！\nいよいよだ😖\nそしてこんな遅い時間までお疲れ様です42tokyoの中の人🙏\n#piscine",
    "expandedUrl" : "https://twitter.com/i/web/status/1300454455276572672"
  }
}, {
  "like" : {
    "tweetId" : "1300425849854853122",
    "fullText" : "パケットをプロトコルスタックの間でで受け渡す時はパケットよコピーではなくて、管理構造体のインスタンスのポインタを持ち回ることで処理を高速化させる。\n\nプロトコルスタックの最上位まで到達したら、今度は出力先のインタフェースを決定するために \n\n続く",
    "expandedUrl" : "https://twitter.com/i/web/status/1300425849854853122"
  }
}, {
  "like" : {
    "tweetId" : "1300429168925011969",
    "fullText" : "ルータの実装は知らなかったけど、\nやっぱ、単純コピーは性能面から極力さけるっぽい。\n(コピー処理削減＆メモリ使用量削減)\n\nイーサネットフレームは結構長いからそこら辺の工夫がかなり効きそうです。\n(品質保証は大変そうだけど) https://t.co/qdSYY3dK92",
    "expandedUrl" : "https://twitter.com/i/web/status/1300429168925011969"
  }
}, {
  "like" : {
    "tweetId" : "1300423129395650562",
    "fullText" : "ルーターの組み込みソフトはこんな感じ\n\nパケットを管理するための構造体を定義\n\n管理構造体のメンバーには\n受信バッファの先頭アドレスのポインタ変数や\nパケットを解析する中で得られる各ヘッダの先頭位置を記憶させるポインタ変数などを持つ\n\n続く",
    "expandedUrl" : "https://twitter.com/i/web/status/1300423129395650562"
  }
}, {
  "like" : {
    "tweetId" : "1300055943703486466",
    "fullText" : "@Hinata72279726 3万するらしい電動歯ブラシでピッカピカに磨いてやります🥺",
    "expandedUrl" : "https://twitter.com/i/web/status/1300055943703486466"
  }
}, {
  "like" : {
    "tweetId" : "1300456906780110849",
    "fullText" : "@ft_ywatabe えええ、ワンコインで殺せちゃうんですかあ⁉️",
    "expandedUrl" : "https://twitter.com/i/web/status/1300456906780110849"
  }
}, {
  "like" : {
    "tweetId" : "1300023707474128896",
    "fullText" : "今からでも遅くはない！(遅い)",
    "expandedUrl" : "https://twitter.com/i/web/status/1300023707474128896"
  }
}, {
  "like" : {
    "tweetId" : "1300021683068129280",
    "fullText" : "3月に延期になってから半年もあったのに一体何してたんだ僕は",
    "expandedUrl" : "https://twitter.com/i/web/status/1300021683068129280"
  }
}, {
  "like" : {
    "tweetId" : "1300424302374731778",
    "fullText" : "管理構造体のインスタンスを受信可能なバッファ分用意する\n\nDMAで受信バッファにパケットが書き込まれたら管理構造体のインスタンスをプロトコルスタックの下位レイヤから解析していき上位に渡していく\n\n解析する中でヘッダの先頭位置や各ヘッダのアトリビュートなどを管理構造体に記憶させていく 続く",
    "expandedUrl" : "https://twitter.com/i/web/status/1300424302374731778"
  }
}, {
  "like" : {
    "tweetId" : "1300442921313820673",
    "fullText" : "@Hinata72279726 本科でインターン先との繋がりを持てるのはsecond circleなので個人差ありますが1, 2年ほどかかりますよ〜\nあと、意外とスポンサー企業、IT企業の人は42Tokyoを認知してないです。\n周りの人との会話はコミュ力を鍛えるには役立ちました！（うつで2年引きこもってたので）",
    "expandedUrl" : "https://twitter.com/i/web/status/1300442921313820673"
  }
}, {
  "like" : {
    "tweetId" : "1300432874705829889",
    "fullText" : "@Hinata72279726 今はオンラインでやってます。コロナ禍以前はオフラインで同じキーボードを叩きながらやってました",
    "expandedUrl" : "https://twitter.com/i/web/status/1300432874705829889"
  }
}, {
  "like" : {
    "tweetId" : "1300442890464669696",
    "fullText" : "C言語でポインタの利用価値はこういうところにあります https://t.co/7ByCLtS3N8",
    "expandedUrl" : "https://twitter.com/i/web/status/1300442890464669696"
  }
}, {
  "like" : {
    "tweetId" : "1300428470078418944",
    "fullText" : "パケットを解析する時は予めパケットのヘッダ構造と同じ構造体を用意しておいて、それを受信バッファにキャストしてあげることで簡単に見ることができます",
    "expandedUrl" : "https://twitter.com/i/web/status/1300428470078418944"
  }
}, {
  "like" : {
    "tweetId" : "1300458676122050560",
    "fullText" : "@Hinata72279726 頑張ってください💪💪\nちなみにですが、42Tokyoに通ってますというのは実績ではなく、「プログラミングスクールに通ってる人」という印象を人事につけてしまうのであまり主張しない方がいいかと思います。\n良い就活ができることを祈ってます😊",
    "expandedUrl" : "https://twitter.com/i/web/status/1300458676122050560"
  }
}, {
  "like" : {
    "tweetId" : "1300425230117003264",
    "fullText" : "あと1週間。緊張してきた。\nもう勉強とか諦めた。\nと言いながらAtCoder登録してみたり無駄な足掻きを。。。\nどうせ初日も夜からしか参加できないんだけどさ。。",
    "expandedUrl" : "https://twitter.com/i/web/status/1300425230117003264"
  }
}, {
  "like" : {
    "tweetId" : "1297548037011542018",
    "fullText" : "@Hinata72279726 当たり前情報工学ですね。カッコいい！もっと情報工学を習うためにピシンで頑張って42入りましょう。☺️\nもちろんDMを送っていいですよ。ピシンの時はひなたさんはフルコミットですか？授業はありますか？",
    "expandedUrl" : "https://twitter.com/i/web/status/1297548037011542018"
  }
}, {
  "like" : {
    "tweetId" : "1297670617118908416",
    "fullText" : "@Hinata72279726 リアクションありがとうございます！\n遅くなってすみません、先ほどDMお送りしました！",
    "expandedUrl" : "https://twitter.com/i/web/status/1297670617118908416"
  }
}, {
  "like" : {
    "tweetId" : "1291486777736171520",
    "fullText" : "@izukinder @nhk_1945ichiro @nhk_1945yasuko @nhk_1945shun まるちさんのツイートで知りました。\n知れてよかった。",
    "expandedUrl" : "https://twitter.com/i/web/status/1291486777736171520"
  }
}, {
  "like" : {
    "tweetId" : "1291381725281452032",
    "fullText" : "@Hinata72279726 @nhk_1945ichiro 横から失礼します。\n過去形になっていなくて、かつ三単現のSが脱落してるのは敢えてでしょうか？\n\n文法的にはwasn't in there ではなくwasn't  thereですね。\nあとlaidは他動詞なので was laid onかlay onではないでしょうか。\nクソリプ失礼しました。",
    "expandedUrl" : "https://twitter.com/i/web/status/1291381725281452032"
  }
}, {
  "like" : {
    "tweetId" : "1297474832020328448",
    "fullText" : "面接で好きな食べ物聞かれたから、逆質問で面接官に好きな食べ物聞いたら怒られた上に落ちたよね。\n不条理。",
    "expandedUrl" : "https://twitter.com/i/web/status/1297474832020328448"
  }
}, {
  "like" : {
    "tweetId" : "1299669979105689602",
    "fullText" : "Piscine完泳記念で気になってたお店に来てみました！ https://t.co/plgtIJ8xfS",
    "expandedUrl" : "https://twitter.com/i/web/status/1299669979105689602"
  }
}, {
  "like" : {
    "tweetId" : "1291375701216485377",
    "fullText" : "@Hinata72279726 @nhk_1945ichiro ハロートークです。誤字です",
    "expandedUrl" : "https://twitter.com/i/web/status/1291375701216485377"
  }
}, {
  "like" : {
    "tweetId" : "1299750267219394561",
    "fullText" : "ちなみに9月参加者見つけてリストには勝手に突っ込んでますが、slackは良し悪しあると思うので勝手に招待はしとらんですたい",
    "expandedUrl" : "https://twitter.com/i/web/status/1299750267219394561"
  }
}, {
  "like" : {
    "tweetId" : "1291404877696872448",
    "fullText" : "@Hinata72279726 @nhk_1945ichiro when you need the correction, ask me anytime, I used to be a \"大学職員\" with diploma of english language and literature, having experience of living in Detroit when my youthtime.",
    "expandedUrl" : "https://twitter.com/i/web/status/1291404877696872448"
  }
}, {
  "like" : {
    "tweetId" : "1291375686926471168",
    "fullText" : "@Hinata72279726 @nhk_1945ichiro Cannot dig/ Standing next I felt~",
    "expandedUrl" : "https://twitter.com/i/web/status/1291375686926471168"
  }
}, {
  "like" : {
    "tweetId" : "1291375092983717888",
    "fullText" : "@Hinata72279726 @nhk_1945ichiro anylongerのほうがbetterな気がします。\n\n（これまで細かい添削失礼しました。言いたいことが正確に伝わるようなものはそのままにし、気になったところだけHinataさんの原文を活かすよう心がけました）",
    "expandedUrl" : "https://twitter.com/i/web/status/1291375092983717888"
  }
}, {
  "like" : {
    "tweetId" : "1291374773176381440",
    "fullText" : "@Hinata72279726 @nhk_1945ichiro バロートークでもハート１つついただけでスルーされました。難しいですね。英語力がないので陰ながら応援しています📣",
    "expandedUrl" : "https://twitter.com/i/web/status/1291374773176381440"
  }
}, {
  "like" : {
    "tweetId" : "1297913240278581250",
    "fullText" : "「このエラーを直したらコンビニに行こう」と思って4時間経ちました。",
    "expandedUrl" : "https://twitter.com/i/web/status/1297913240278581250"
  }
}, {
  "like" : {
    "tweetId" : "1296830102819319810",
    "fullText" : "@Hinata72279726 大学のレポートを頑張ってください！専攻は何ですか？\nそうですね、ポインタが難しそうです。最近ベーシックなポインタを習ったばかりなので、その難しさはまだ経験がないですけど…\nそれ以外構造体もややこしい…今週末に復習します！",
    "expandedUrl" : "https://twitter.com/i/web/status/1296830102819319810"
  }
}, {
  "like" : {
    "tweetId" : "1291486276424626176",
    "fullText" : "#ひろしまタイムライン \n一郎さん @nhk_1945ichiro のツイートを英訳してくれている方がいる！！これによって、より多くの人の目にとまりますように…！\n(他の二人、やすこさん @nhk_1945yasuko シュンくん @nhk_1945shun のも、どなたか英訳を…) https://t.co/lv3Lrs5D16",
    "expandedUrl" : "https://twitter.com/i/web/status/1291486276424626176"
  }
}, {
  "like" : {
    "tweetId" : "1291357749335343106",
    "fullText" : "@nhk_1945ichiro The sweat and dust that had solidified on my cheek fell as I touched my face.",
    "expandedUrl" : "https://twitter.com/i/web/status/1291357749335343106"
  }
}, {
  "like" : {
    "tweetId" : "1291357590182457344",
    "fullText" : "@nhk_1945ichiro [from Ichiro (a journalist)] #ひろしまタイムライン #Hiroshima75 #Hiroshima #世界平和 \n1945, August 6th 19:17\nThe explosion that happened out of nowhere this morning, and the implausible scenes of cruelty right in front of my eyes. How, how had this happened... I do not know.",
    "expandedUrl" : "https://twitter.com/i/web/status/1291357590182457344"
  }
}, {
  "like" : {
    "tweetId" : "1284569675246915585",
    "fullText" : "42Tokyo9月Piscine参加予定です！\n#42Tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1284569675246915585"
  }
}, {
  "like" : {
    "tweetId" : "1299748251650813953",
    "fullText" : "9月piscine受ける皆さん、今まで何にもアプローチしてこなかったんですが、僕と仲良くしてください。 https://t.co/CeC2r7wknE",
    "expandedUrl" : "https://twitter.com/i/web/status/1299748251650813953"
  }
}, {
  "like" : {
    "tweetId" : "1296373687923273729",
    "fullText" : "slack招待も来てないし、9月piscineのリストにも入ってないんですけど💢って方がいましたらごめんなさい、教えてくださたいmm",
    "expandedUrl" : "https://twitter.com/i/web/status/1296373687923273729"
  }
}, {
  "like" : {
    "tweetId" : "1296806637554958337",
    "fullText" : "@Hinata72279726 もうすぐ始まりますね…今から繋がらないだろうか？\n最近どうやって準備していますか？",
    "expandedUrl" : "https://twitter.com/i/web/status/1296806637554958337"
  }
}, {
  "like" : {
    "tweetId" : "1297880546119258113",
    "fullText" : "@Hinata72279726 よかった！フルコミットできるのいいですね！\n最後に授業があるのは大変ですね。私も授業があるけれど、前半2週間です。zoomで受けているので、まだピシンに集中できるかもしれない😂",
    "expandedUrl" : "https://twitter.com/i/web/status/1297880546119258113"
  }
}, {
  "like" : {
    "tweetId" : "1291372427616768002",
    "fullText" : "@Hinata72279726 @nhk_1945ichiro Cant even tell/Sitting down on the ground/burnt bodies in front of my eyes",
    "expandedUrl" : "https://twitter.com/i/web/status/1291372427616768002"
  }
}, {
  "like" : {
    "tweetId" : "1291488670692724736",
    "fullText" : "@gete19 @nhk_1945ichiro @nhk_1945yasuko @nhk_1945shun 私もこの #ひろしまタイムライン は昨日の朝初めて知りました。もっと早く知っていれば…と思いましたが、でも知ることができてよかったです。こんなに生々しく感じた1945年8月はありません…この企画を考えた人に感謝したいです。",
    "expandedUrl" : "https://twitter.com/i/web/status/1291488670692724736"
  }
}, {
  "like" : {
    "tweetId" : "1299738662502977538",
    "fullText" : "42Tokyoの１ヶ月の入学試験Piscineが先日終わりました。難しい課題がたくさんで、寝る時以外ほぼずっとコーディングして、とても楽しく、新しくできることが増えるのが嬉しかったです。入学してまだこれを続けたいと思いながら、解ききれなかった問題に取り組んでいます。運営の方と同期受験生に感謝。",
    "expandedUrl" : "https://twitter.com/i/web/status/1299738662502977538"
  }
}, {
  "like" : {
    "tweetId" : "1313638009548410880",
    "fullText" : "個人的お気に入り https://t.co/B1Io9kUIM1",
    "expandedUrl" : "https://twitter.com/i/web/status/1313638009548410880"
  }
}, {
  "like" : {
    "tweetId" : "1313671668460470272",
    "fullText" : "@Hinata72279726 @FPr4242 本垢引きこもりマンか",
    "expandedUrl" : "https://twitter.com/i/web/status/1313671668460470272"
  }
}, {
  "like" : {
    "tweetId" : "1313471293707124742",
    "fullText" : "あああああああいいいいいいいああああ電車で背後に立つな\nめっちゃ鳥肌が立つし\n異常なまでに脂汗出てくるし良くない\nトラウマがほじくり返される",
    "expandedUrl" : "https://twitter.com/i/web/status/1313471293707124742"
  }
}, {
  "like" : {
    "tweetId" : "1313677611424337920",
    "fullText" : "@luna_yuta @Hinata72279726 え、なになになに(本垢引きこもりマン)",
    "expandedUrl" : "https://twitter.com/i/web/status/1313677611424337920"
  }
}, {
  "like" : {
    "tweetId" : "1313638393545281536",
    "fullText" : "むむっ、これは……契約書の誤字脱字なのじゃ？\nhttps://t.co/5Y33x7kizU https://t.co/nxdu9TyvCA",
    "expandedUrl" : "https://twitter.com/i/web/status/1313638393545281536"
  }
}, {
  "like" : {
    "tweetId" : "1313494885501198336",
    "fullText" : "シーザー暗号を解読するコード書きました。勉強用にgithubにプッシュするのでご自由にお使いください。\nhttps://t.co/qjesajsTHc",
    "expandedUrl" : "https://twitter.com/i/web/status/1313494885501198336"
  }
}, {
  "like" : {
    "tweetId" : "1313672339029016578",
    "fullText" : "Note書こうと筆を取ったのはいいが絶望的なまでに文章の書き方がわからない",
    "expandedUrl" : "https://twitter.com/i/web/status/1313672339029016578"
  }
}, {
  "like" : {
    "tweetId" : "1313607505432383488",
    "fullText" : "Appleイベント、日本時間10月14日午前2時に開催決定！ iPhone12、5G対応など発表なるか？\n https://t.co/B1CMXD00gb https://t.co/pcq3CA32yL",
    "expandedUrl" : "https://twitter.com/i/web/status/1313607505432383488"
  }
}, {
  "like" : {
    "tweetId" : "1313647723569008640",
    "fullText" : "しかも、\\0ってテープのためにできたの？！",
    "expandedUrl" : "https://twitter.com/i/web/status/1313647723569008640"
  }
}, {
  "like" : {
    "tweetId" : "1313496966672900097",
    "fullText" : "亀か\n\nhttps://t.co/JBcto7wmB6 https://t.co/crbcHFA1Di",
    "expandedUrl" : "https://twitter.com/i/web/status/1313496966672900097"
  }
}, {
  "like" : {
    "tweetId" : "1313608649051238400",
    "fullText" : "【小学１年生から読む 飛浩隆SF 】\n飛浩隆さんが「小学一年生」付録のアンキパン用に、ほぼ100字の小説をお書きになった‼︎\n\n食パンに実装したどこでもドアをくぐると、遠い未来の遠い星に連れて行ってくれます。\n＃アンキパンコンテスト  #食パン小説 https://t.co/qvNsmY8xXM https://t.co/wb0cnLmywg",
    "expandedUrl" : "https://twitter.com/i/web/status/1313608649051238400"
  }
}, {
  "like" : {
    "tweetId" : "1313644282775920641",
    "fullText" : "Linuxの仮想環境作るのめんどくさ....",
    "expandedUrl" : "https://twitter.com/i/web/status/1313644282775920641"
  }
}, {
  "like" : {
    "tweetId" : "1313631527842971648",
    "fullText" : "あなたのー髪を切らなきゃー真っ黒なその目がー",
    "expandedUrl" : "https://twitter.com/i/web/status/1313631527842971648"
  }
}, {
  "like" : {
    "tweetId" : "1313104979893252096",
    "fullText" : "言葉が全く必要ない。 https://t.co/jXuegS00ns",
    "expandedUrl" : "https://twitter.com/i/web/status/1313104979893252096"
  }
}, {
  "like" : {
    "tweetId" : "1313349869893902337",
    "fullText" : "鮮魚が雑魚に見えて草",
    "expandedUrl" : "https://twitter.com/i/web/status/1313349869893902337"
  }
}, {
  "like" : {
    "tweetId" : "1313647486884483072",
    "fullText" : "^@って、ASCIIのNULLがでてたのかぁ",
    "expandedUrl" : "https://twitter.com/i/web/status/1313647486884483072"
  }
}, {
  "like" : {
    "tweetId" : "1313627841603358721",
    "fullText" : "お、この本さては可読性低いな？？？？？ https://t.co/k9HtyXC6hC",
    "expandedUrl" : "https://twitter.com/i/web/status/1313627841603358721"
  }
}, {
  "like" : {
    "tweetId" : "1313628365371310081",
    "fullText" : "本「このコードは何をしようとしているでしょうか？」わからん・・・書いてみよう・・・やっぱりわからん、実行してみよう・・・わからん....泣",
    "expandedUrl" : "https://twitter.com/i/web/status/1313628365371310081"
  }
}, {
  "like" : {
    "tweetId" : "1313630308474871808",
    "fullText" : "公明党、受験生らに応援金２万円支給を要請(TBS系（JNN）)\n#Yahooニュース\nhttps://t.co/9jKnZiehKJ \nまた意味わからんことを……。素直にセンター試験の受験料無料にして全体に給付金出せばいいじゃん。",
    "expandedUrl" : "https://twitter.com/i/web/status/1313630308474871808"
  }
}, {
  "like" : {
    "tweetId" : "1313650565180608522",
    "fullText" : "わーい\n#日食なつこ\n#かもめの玉子 https://t.co/NClzuisDgJ",
    "expandedUrl" : "https://twitter.com/i/web/status/1313650565180608522"
  }
}, {
  "like" : {
    "tweetId" : "1313551938122706944",
    "fullText" : "シャドバの今回の背徳ヴァンプが扱いきれなくて負ける。。。。\nロイヤルに、変えようかなー。\nε- (´ー`*) ﾌｩ",
    "expandedUrl" : "https://twitter.com/i/web/status/1313551938122706944"
  }
}, {
  "like" : {
    "tweetId" : "1313680218918285314",
    "fullText" : "Piscine落ちたら就職活動しなきゃだから受かってくれ()",
    "expandedUrl" : "https://twitter.com/i/web/status/1313680218918285314"
  }
}, {
  "like" : {
    "tweetId" : "1313632489303285760",
    "fullText" : "放射性超次元超越知的生命体ゴジラになっちゃうじゃん",
    "expandedUrl" : "https://twitter.com/i/web/status/1313632489303285760"
  }
}, {
  "like" : {
    "tweetId" : "1313347257232580609",
    "fullText" : "11月1日には\n主催イベントがあることと\n刺青メインな♥\nグラビアの単体DVD撮影を控えておりますので…\n\nそりゃあもう…はい🤓\nハイペースに刺青進めております。\n\nmy鳳凰ちゃん♥も早く開眼させてあげたいですし♥\n\n娘（乃愛）に負けじと\nマネージャーも（←私もw）\nグラビアDVDリースします🥰 https://t.co/XDl7lYwPyH",
    "expandedUrl" : "https://twitter.com/i/web/status/1313347257232580609"
  }
}, {
  "like" : {
    "tweetId" : "1313440553741164545",
    "fullText" : "GitHubのメインブランチがmainになったことで、「masterブランチにほとんどマージされずdevelopで永遠に開発されてる状態」を「idle master、略してアイマス」と呼べなくなるのか...",
    "expandedUrl" : "https://twitter.com/i/web/status/1313440553741164545"
  }
}, {
  "like" : {
    "tweetId" : "1291348517865177088",
    "fullText" : "@Hinata72279726 @nhk_1945ichiro 英語版あったらいいなと思ってました。行動が早くてさすがです！\n英語不慣れで時間かかると思いますが、お手伝いできるところはさせていただきますね！\n課題頑張られてください！",
    "expandedUrl" : "https://twitter.com/i/web/status/1291348517865177088"
  }
}, {
  "like" : {
    "tweetId" : "1291389715149512711",
    "fullText" : "@Hinata72279726 @nhk_1945ichiro いえいえ…\n自分もがっつり英語に触れてた時から数年経ってるので、人のこと言えません(^_^;)\nお手伝いしたり自分も英訳投稿したりしたいのですが、技術もなく自信もなく…\n皆さんの活動をきっかけに、きちんとプロジェクトとして英訳がリリースされるといいですね。",
    "expandedUrl" : "https://twitter.com/i/web/status/1291389715149512711"
  }
}, {
  "like" : {
    "tweetId" : "1234417092033576960",
    "fullText" : "@Hinata72279726 4月になると環境がガラッと変わっちゃう人多そうですよね。。\n上手いこと通えるようになることを祈っています🙏",
    "expandedUrl" : "https://twitter.com/i/web/status/1234417092033576960"
  }
}, {
  "like" : {
    "tweetId" : "1253710150310846465",
    "fullText" : "ワンタイム前のランブルで何十キルもしてる奴はなんなん？\nちゃんと考えろよ🙃🙃🙃",
    "expandedUrl" : "https://twitter.com/i/web/status/1253710150310846465"
  }
}, {
  "like" : {
    "tweetId" : "1242736775086239745",
    "fullText" : "日本が東京五輪．パラの開催延期という難しい決断を下したことに敬意を表します。今年は共に新型コロナウイルスと闘い、そして来年は ＃完全な形 で開催される東京五輪．パラの会場で戦いましょう。どちらのたたかいにも一緒に勝ちましょう！\n\n#コロナに負けるな\n#東京オリンピック\n#台日加油 https://t.co/EJfoUu30hM",
    "expandedUrl" : "https://twitter.com/i/web/status/1242736775086239745"
  }
}, {
  "like" : {
    "tweetId" : "1291368755092578311",
    "fullText" : "@Hinata72279726 @nhk_1945ichiro バロートークという日本語を勉強している外国人と繋がれるアプリでぜひ翻訳して！と頼みました。やってくれる人がいるかはわかりませんが少しでも力になれれば嬉しいです",
    "expandedUrl" : "https://twitter.com/i/web/status/1291368755092578311"
  }
}, {
  "like" : {
    "tweetId" : "1291376291514445824",
    "fullText" : "@Hinata72279726 @nhk_1945ichiro 学校の課題を優先してくださいね！",
    "expandedUrl" : "https://twitter.com/i/web/status/1291376291514445824"
  }
}, {
  "like" : {
    "tweetId" : "1233312441380950016",
    "fullText" : "@Hinata72279726 @Wolke0225 いいと思う",
    "expandedUrl" : "https://twitter.com/i/web/status/1233312441380950016"
  }
}, {
  "like" : {
    "tweetId" : "1233309008347316224",
    "fullText" : "虚無になった3月ですがこのあたりをやっていきますかね\n\nC言語完全理解\nUnity完全理解\n作曲完全理解",
    "expandedUrl" : "https://twitter.com/i/web/status/1233309008347316224"
  }
}, {
  "like" : {
    "tweetId" : "1237391311289769989",
    "fullText" : "ポインタ変数むずーーい",
    "expandedUrl" : "https://twitter.com/i/web/status/1237391311289769989"
  }
}, {
  "like" : {
    "tweetId" : "1253690320677560320",
    "fullText" : "あの…\nワンタイムイベント始まる前に試合が終わっちゃったんだけど…\nなんでみんな倒すのよ…☹️ https://t.co/SkAAZxUDYG",
    "expandedUrl" : "https://twitter.com/i/web/status/1253690320677560320"
  }
}, {
  "like" : {
    "tweetId" : "1267365483092668416",
    "fullText" : "現在アメリカで起きている暴動に、黒人は必ずしも賛同しているわけじゃない。むしろ彼らの多くはもっと「マシな方法」を模索しようとしている。\n\n悲劇を止めるのは暴動じゃない。\n\n#BlackLivesMatter https://t.co/ohBURhDxjn",
    "expandedUrl" : "https://twitter.com/i/web/status/1267365483092668416"
  }
}, {
  "like" : {
    "tweetId" : "1253713259452002304",
    "fullText" : "あれ、もしかして貴方ゴミゴミの実の能力者ですか？？？貴方のようなゴミ人間が界隈ぶっ壊してるんですよ😇自覚持って下さい😂いや〜まさかこんなドクズだったとは思いもよりませんでしたPC買ってイキっちゃったのかな🤣🤣\n#フォートナイト #ワンタイム https://t.co/wlgFcFsasW",
    "expandedUrl" : "https://twitter.com/i/web/status/1253713259452002304"
  }
}, {
  "like" : {
    "tweetId" : "1231860746134286337",
    "fullText" : "C言語、ポインタの話になった途端急に訳わからんくなってきたぞ😂😂",
    "expandedUrl" : "https://twitter.com/i/web/status/1231860746134286337"
  }
}, {
  "like" : {
    "tweetId" : "1230508180897067008",
    "fullText" : "登録行ってきました！\n3月からpiscineの方よろしくお願いします。多分終電後の深夜とかにいるタイプです！完全初心者です。\n\n暑がりでのぼせやすいので冬なのに薄着してるかもしれませんが、気にしないでください！\n\n#42Tokyo\n\n#42Tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1230508180897067008"
  }
}, {
  "like" : {
    "tweetId" : "1233031563811508224",
    "fullText" : "3月Piscine参加します\n登録会に時間勘違いして汗だくで走ってきましたが更に時間勘違いして余裕で間に合いました。\n登録終わった後も何かあるのか？とずっとうろうろしてました。\n\n不安ですが頑張ります。\n#42Tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1233031563811508224"
  }
}, {
  "like" : {
    "tweetId" : "1233577723257188352",
    "fullText" : "流行りの病気と同じ名前というだけで38%のアメリカ人がコロナビールを忌避する一方、この騒ぎの中でフィンランドから日本に来てマジの普通の居酒屋でプレモルの大ジョッキ持って励ましの乾杯してくれてるコルピクラーニとかいうバンド、本当に愛すべきバカだし感謝しかない。 https://t.co/Dx551dAzG3",
    "expandedUrl" : "https://twitter.com/i/web/status/1233577723257188352"
  }
}, {
  "like" : {
    "tweetId" : "1244494296943742976",
    "fullText" : "志村けんさん、国境を超えて台湾人にたくさんの笑いと元気を届けくれてありがとうございました。きっと天国でもたくさんの人を笑わせてくれることでしょう。\nご冥福を心から祈ります。 https://t.co/8TCe9udxpC",
    "expandedUrl" : "https://twitter.com/i/web/status/1244494296943742976"
  }
}, {
  "like" : {
    "tweetId" : "1291303978609721344",
    "fullText" : "@konosekai1945 @nhk_1945ichiro だれか。英訳して全世界発信して。",
    "expandedUrl" : "https://twitter.com/i/web/status/1291303978609721344"
  }
}, {
  "like" : {
    "tweetId" : "1233306447808565248",
    "fullText" : "piscineとか42はスクールとかに通ってなくて1人で独学してる自分にとってはスキルアップっていう目的はもちろんあるんだけど、同じぐらいにスタートしてオフラインで一緒にプログラミングの勉強を頑張れる仲間が欲しかったっていうのが大きいんだよなあ",
    "expandedUrl" : "https://twitter.com/i/web/status/1233306447808565248"
  }
}, {
  "like" : {
    "tweetId" : "1273651160432340992",
    "fullText" : "Piscineの情報出ましたね！\n2カ月やるようですが、両方MAX300人でやるとしたら200人合格者が出ますが、オーバーしてしまいますよね。\nそこで、\n①42tokyoとしてのキャパを増やす\n②合格率従来比半分\n③受験者数半分(2カ月で300人)\n④合格者の辞退が起きている\nのどれですかね...",
    "expandedUrl" : "https://twitter.com/i/web/status/1273651160432340992"
  }
}, {
  "like" : {
    "tweetId" : "1233288581013131264",
    "fullText" : "もう３月組で集まってなんかしたらいいのか？ #42Tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1233288581013131264"
  }
}, {
  "like" : {
    "tweetId" : "1233279145192259584",
    "fullText" : "あら。\n\n#piscine #42tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1233279145192259584"
  }
}, {
  "like" : {
    "tweetId" : "1284045772074258432",
    "fullText" : "@misakism13 ズバリ 『Ｉ』ですね。\n\n若い人を応援する気持ち。\n青春の人、青少年の人様々ですが『青』の文字が入っているため若者を応援する思いを込めて青。\n\nそしてアルファベット と 日本語で書く事により、日本人にも外国人にも分かりやすい標記になります。\n\n世界にも目を向け活躍してほしい期待を込めて。 https://t.co/zDSWMIqTKI",
    "expandedUrl" : "https://twitter.com/i/web/status/1284045772074258432"
  }
}, {
  "like" : {
    "tweetId" : "1232621756487127046",
    "fullText" : "@Hinata72279726 3月参加組です。良かったらよろしくお願いします。",
    "expandedUrl" : "https://twitter.com/i/web/status/1232621756487127046"
  }
}, {
  "like" : {
    "tweetId" : "1228639674312187904",
    "fullText" : "今日電車で「C言語で学ぶアルゴリズムとデータ構造」を読んでる人がいて、42関係者かと思いジロジロ見てしまい申し訳なかった🙏\n\n#42tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1228639674312187904"
  }
}, {
  "like" : {
    "tweetId" : "1228627451913199621",
    "fullText" : "13日目。 -\n折り返し地点到達。\n泳ぎに行きたい！\n\n行きたい行きたい行きたい！\n\nが、投げ出せないものもある。\n\n(`･ω･´)=3\n\n#42Tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1228627451913199621"
  }
}, {
  "like" : {
    "tweetId" : "1228976314993893377",
    "fullText" : "正解発表：なんと17歳女子高校生でした https://t.co/0oBoI7Sajc",
    "expandedUrl" : "https://twitter.com/i/web/status/1228976314993893377"
  }
}, {
  "like" : {
    "tweetId" : "1228707798919237632",
    "fullText" : "Registration、余裕なふりして普通に緊張したぞ　#42tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1228707798919237632"
  }
}, {
  "like" : {
    "tweetId" : "1228665220513447937",
    "fullText" : "もう胸にTwitterアイコンとSlackアイコン掲げた方がいいよね？\n#42Tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1228665220513447937"
  }
}, {
  "like" : {
    "tweetId" : "1228832217318604800",
    "fullText" : "レジストレーションで会場に入ったときに恐怖を感じたのを覚えている。\nなぜ自分は、ほんの一週間前まで田舎で、たった1人で書籍を読み漁る生活を送っていたんだって。\nあそこに行かなければ、多分ずっと同じことをしていたかもしれない。\n\n#42tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1228832217318604800"
  }
}, {
  "like" : {
    "tweetId" : "1228088666964148224",
    "fullText" : "結局大学の通知がPiscineよりも先に来た笑笑\n奨学金が足りない...全く😇😇😇\n\n#NYUAD",
    "expandedUrl" : "https://twitter.com/i/web/status/1228088666964148224"
  }
}, {
  "like" : {
    "tweetId" : "1228871170780327937",
    "fullText" : "私は日本人じゃありませんが、今回の日本政府と日本社会が新型肺炎に対する反応はとても遅い、香港政府より遅い、と感じました。新型肺炎が中国で流行っているに関わらず、多くの中国観光客を受け入れ、経路がわからない感染者がどんどん増えました。冷静さより、警戒心の方が重要だと思います。",
    "expandedUrl" : "https://twitter.com/i/web/status/1228871170780327937"
  }
}, {
  "like" : {
    "tweetId" : "1228629559089623040",
    "fullText" : "誤字ってたからもう1回、、\n42tokyoの3月Piscineに参加できることになりました🙆🏻‍♀️\nよろしくお願いします〜！\n#42tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1228629559089623040"
  }
}, {
  "like" : {
    "tweetId" : "1228581981543227394",
    "fullText" : "#42Tokyo エレベーターどれですか🤔",
    "expandedUrl" : "https://twitter.com/i/web/status/1228581981543227394"
  }
}, {
  "like" : {
    "tweetId" : "1228567282952986626",
    "fullText" : "#42tokyo registration行ってきました\n写真盛れてるといいな\n\n同期の方、3月からよろしくお願いします！",
    "expandedUrl" : "https://twitter.com/i/web/status/1228567282952986626"
  }
}, {
  "like" : {
    "tweetId" : "1230058695695859713",
    "fullText" : "明日20日のRegistrationに行き、 42Tokyoの3月piscineに参加します！\n一緒に受けることになる方々、どうぞよろしくお願いします！\n#42tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1230058695695859713"
  }
}, {
  "like" : {
    "tweetId" : "1228567394123055106",
    "fullText" : "Piscine登録おわったー。\nなんかみんなめっちゃ若い。即死しないよう頑張ります。。",
    "expandedUrl" : "https://twitter.com/i/web/status/1228567394123055106"
  }
}, {
  "like" : {
    "tweetId" : "1228201421880741888",
    "fullText" : "#42Tokyo\n受かってました！入学します！",
    "expandedUrl" : "https://twitter.com/i/web/status/1228201421880741888"
  }
}, {
  "like" : {
    "tweetId" : "1228700851851550722",
    "fullText" : "ピシン用に埋まってたTwitterアカウントを掘り出した。\nプログラミング未経験で通った人いるのかな、、笑\n頑張ろう。\n#42tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1228700851851550722"
  }
}, {
  "like" : {
    "tweetId" : "1228477171779268608",
    "fullText" : "かなりつかれが溜まってるのを感じる\n\n皆さんも体調管理気をつけましょう\n1時間早く帰るのは何とかなっても1日寝込むのは大変です。\n\n#42Tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1228477171779268608"
  }
}, {
  "like" : {
    "tweetId" : "1229293178135515136",
    "fullText" : "三度の飯よりビリヤニがうまい",
    "expandedUrl" : "https://twitter.com/i/web/status/1229293178135515136"
  }
}, {
  "like" : {
    "tweetId" : "1228571350274412546",
    "fullText" : "42tokyo 会場のビルについた俺「デカすぎんだろ...」",
    "expandedUrl" : "https://twitter.com/i/web/status/1228571350274412546"
  }
}, {
  "like" : {
    "tweetId" : "1228695002194141184",
    "fullText" : "前の名前はプログラミングを始めるきっかけになった人に名付けてもらったけど、いざ42とかに参加してTwitter上の人と実際に会うとなると恥ずかしいから本名に変えました😂",
    "expandedUrl" : "https://twitter.com/i/web/status/1228695002194141184"
  }
}, {
  "like" : {
    "tweetId" : "1228649175681662976",
    "fullText" : "registration行ってきました！\n3月にpiscine泳ぎます😡\n合格出来るように頑張ります😆\n#42Tokyo https://t.co/uLvff5py62",
    "expandedUrl" : "https://twitter.com/i/web/status/1228649175681662976"
  }
}, {
  "like" : {
    "tweetId" : "1228318679160377344",
    "fullText" : "結果不合格でしたが、\n1ヶ月の中で、様々なバックグランドを持つ方々に出会えて沢山刺激をもらいました。無知な自分が１ヶ月泳ぎ切れたのも\n皆さんのおかげです。\n\n自分自身もっと成長出来る様に\n新しい場所で頑張っていきます。\n\n1月piscine生の皆さん、本当にありがとうございました😌\n#42tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1228318679160377344"
  }
}, {
  "like" : {
    "tweetId" : "1228691649544351745",
    "fullText" : "今日の朝、ツイッター見てて共感してるって励ましに来てくれた人いてめっちゃ嬉しくて涙出た。\n\nチョコレート買ってきて、くれた人もいた。こういう人もいるよってテスト失敗しても合格してる人の情報くれた人もいた。\n\nほんとみんなに励まされてばっかりだ。感謝だなぁ…",
    "expandedUrl" : "https://twitter.com/i/web/status/1228691649544351745"
  }
}, {
  "like" : {
    "tweetId" : "1228839231210053634",
    "fullText" : "【六本木一丁目のランチ調査結果】\n\n※土日\nグランドタワー前：タリーズ\nグランドタワー1F：六本木価格コンビニ\nグランドタワー近く：ファミマ\nグランドタワー2F：インドカレー屋\nアークヒルズB1F：福島屋（教えてもらた）\n土日は周辺飲食店はほぼおやすみ\n\n土日はファミマか福島屋かな〜🤔\n#42tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1228839231210053634"
  }
}, {
  "like" : {
    "tweetId" : "1230416063298277377",
    "fullText" : "Piscine 始まるから今の黒髪のプロフィール画像にしといた笑\n\nこれからよろしくお願いします🙇🏻‍♀️\n\n#42Tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1230416063298277377"
  }
}, {
  "like" : {
    "tweetId" : "1228839273580789760",
    "fullText" : "定期的に「駆け出しエンジニア同士で繋がって意味あんの？」っての見かけるけどさ。\n\nそりゃま、Twitterアカウントを「情報」としてしか見ないなら意味は薄い「かもしれない」けどさ…\n\nおんなじレイヤで頑張る友達増えたら単純に楽しいやん。そういうのじゃあかんのかね。",
    "expandedUrl" : "https://twitter.com/i/web/status/1228839273580789760"
  }
}, {
  "like" : {
    "tweetId" : "1228564631322386432",
    "fullText" : "registration来ました\n\n再来週から頑張りたいと思います.\n\n#42tokyo https://t.co/jEL5tLDkQl",
    "expandedUrl" : "https://twitter.com/i/web/status/1228564631322386432"
  }
}, {
  "like" : {
    "tweetId" : "1228545674255355904",
    "fullText" : "若い子多いわー！\nそしてワークスペースすげーw https://t.co/SCSaDJlUAQ",
    "expandedUrl" : "https://twitter.com/i/web/status/1228545674255355904"
  }
}, {
  "like" : {
    "tweetId" : "1228564250047549441",
    "fullText" : "#42Tokyo https://t.co/2YB6lrVs5e",
    "expandedUrl" : "https://twitter.com/i/web/status/1228564250047549441"
  }
}, {
  "like" : {
    "tweetId" : "1228562393304829952",
    "fullText" : "緊張してしまい誰にも話しかけられなかったで候\n3/2に真価を発揮するぞい😂",
    "expandedUrl" : "https://twitter.com/i/web/status/1228562393304829952"
  }
}, {
  "like" : {
    "tweetId" : "1228549932908367872",
    "fullText" : "いざ六本木\n#42Tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1228549932908367872"
  }
}, {
  "like" : {
    "tweetId" : "1228495624577765383",
    "fullText" : "13時頃登録会いきます！\nお時間ある方とお話したいです！\n\n#42Tokyo #Piscine",
    "expandedUrl" : "https://twitter.com/i/web/status/1228495624577765383"
  }
}, {
  "like" : {
    "tweetId" : "1228535633456631809",
    "fullText" : "42東京のPiscineのRegistration(登録会)にきました！懐かしいな。\n\nTranseSalonのイベントもあるっぽいです！\n\n#42tokyo https://t.co/jlCTGeFaGc",
    "expandedUrl" : "https://twitter.com/i/web/status/1228535633456631809"
  }
}, {
  "like" : {
    "tweetId" : "1228551351493222400",
    "fullText" : "Registration思ったより直ぐに終わった！\n田舎モンだから六本木は緊張しました。",
    "expandedUrl" : "https://twitter.com/i/web/status/1228551351493222400"
  }
}, {
  "like" : {
    "tweetId" : "1194420350840262657",
    "fullText" : "フランス発のエンジニア養成機関「#42Tokyo」が本日応募開始！\n2020年1月から入学試験を開始し、2020年4月に開校予定です。詳細は以下ご確認お願いします。\n\n■プレスリリースURL\nhttps://t.co/p2oXVA88BM",
    "expandedUrl" : "https://twitter.com/i/web/status/1194420350840262657"
  }
}, {
  "like" : {
    "tweetId" : "1228549046479884293",
    "fullText" : "協賛も超一流IT企業w https://t.co/5QYugZ02rU",
    "expandedUrl" : "https://twitter.com/i/web/status/1228549046479884293"
  }
}, {
  "like" : {
    "tweetId" : "1228631154699333632",
    "fullText" : "@Hinata72279726 よろしくおねがいします！",
    "expandedUrl" : "https://twitter.com/i/web/status/1228631154699333632"
  }
}, {
  "like" : {
    "tweetId" : "1228465885339193346",
    "fullText" : "昨日出てきた名言は\n「昨日は寝るんですか？」\n「僕がポインタやります」\nでした。おやすみなさい\n\n#42tokyo",
    "expandedUrl" : "https://twitter.com/i/web/status/1228465885339193346"
  }
}, {
  "like" : {
    "tweetId" : "1313417572310679553",
    "fullText" : "メンヘラ認定されてもうて草",
    "expandedUrl" : "https://twitter.com/i/web/status/1313417572310679553"
  }
}, {
  "like" : {
    "tweetId" : "1313424410867449857",
    "fullText" : "@Hinata72279726 あああああああああああああああああああああああああああああああああああああああああああああああああああああああああああああああああああああああああああああああああああ（死）",
    "expandedUrl" : "https://twitter.com/i/web/status/1313424410867449857"
  }
}, {
  "like" : {
    "tweetId" : "1313047231134535682",
    "fullText" : "アフター6 パスポート2900円が未だに身体に染みついてるものとしては\nポップコーンバケット3400円をみるとついにここまできたか！と思ってしまう。\n段々とUSJ価格(4500円)に近づいている。\n生きている間に、5000円のポップコーンバケツが見れそうな勢い。 https://t.co/SBZKgnYkYT",
    "expandedUrl" : "https://twitter.com/i/web/status/1313047231134535682"
  }
}, {
  "like" : {
    "tweetId" : "1313455922337914880",
    "fullText" : "今まで何個作り上げられなかったプロジェクトファイルがあるかなーって数えたらなんか辛くなった。創作って難しいよなー",
    "expandedUrl" : "https://twitter.com/i/web/status/1313455922337914880"
  }
}, {
  "like" : {
    "tweetId" : "1313335616579330048",
    "fullText" : "お気持ちが安定しないえぶりでい",
    "expandedUrl" : "https://twitter.com/i/web/status/1313335616579330048"
  }
}, {
  "like" : {
    "tweetId" : "1313426064165617671",
    "fullText" : "@Hinata72279726 神すぎてやばい",
    "expandedUrl" : "https://twitter.com/i/web/status/1313426064165617671"
  }
}, {
  "like" : {
    "tweetId" : "1313445315416997888",
    "fullText" : "@Hinata72279726 小指と薬指浮いてるのエッチだよね、わかる",
    "expandedUrl" : "https://twitter.com/i/web/status/1313445315416997888"
  }
}, {
  "like" : {
    "tweetId" : "1313145736964448258",
    "fullText" : "この時期になると、「日本のキンモクセイはオスしかいないので実がつかないんだよ」というウンチクを120回くらい言ってたの、さすがにもうやめた",
    "expandedUrl" : "https://twitter.com/i/web/status/1313145736964448258"
  }
}, {
  "like" : {
    "tweetId" : "1313403675830751233",
    "fullText" : "2008年って、まだ生まれてなかった人ツイッターにいるんじゃないかってぐらい昔のできごとなので知らない人多いかもしれないですが私がかきました。 #ワールドイズマイン https://t.co/On6ZlUunl7",
    "expandedUrl" : "https://twitter.com/i/web/status/1313403675830751233"
  }
}, {
  "like" : {
    "tweetId" : "1313416391781871616",
    "fullText" : "生きづらい、誰とも分かり合えない",
    "expandedUrl" : "https://twitter.com/i/web/status/1313416391781871616"
  }
}, {
  "like" : {
    "tweetId" : "1313368845730549761",
    "fullText" : "本日健康診断。\n視力は無事、失いました。\n体重も失いました。 https://t.co/ADUO1V8m8i",
    "expandedUrl" : "https://twitter.com/i/web/status/1313368845730549761"
  }
}, {
  "like" : {
    "tweetId" : "1313427288038363138",
    "fullText" : "@Kahorin_42Tokyo ソーシャルビッチの皮をかぶったメンヘラだろ？（うちにはわかる）",
    "expandedUrl" : "https://twitter.com/i/web/status/1313427288038363138"
  }
}, {
  "like" : {
    "tweetId" : "1312261342728912896",
    "fullText" : "ディープフェイク事件関連のサイト見てたら急に俺の事disってきた… https://t.co/jJAfDVOYl7",
    "expandedUrl" : "https://twitter.com/i/web/status/1312261342728912896"
  }
}, {
  "like" : {
    "tweetId" : "1313349723961487360",
    "fullText" : "@maitake55 @Hinata72279726 これからは私が言っていく",
    "expandedUrl" : "https://twitter.com/i/web/status/1313349723961487360"
  }
}, {
  "like" : {
    "tweetId" : "1313414146143088640",
    "fullText" : "見てみんな、受かった後もハゲるらしいよ https://t.co/lJO4n6cFhg",
    "expandedUrl" : "https://twitter.com/i/web/status/1313414146143088640"
  }
}, {
  "like" : {
    "tweetId" : "1313417703021920256",
    "fullText" : "メンヘラじゃないからぁぁぁぁ！私メンヘラじゃないから！\nヘラっ",
    "expandedUrl" : "https://twitter.com/i/web/status/1313417703021920256"
  }
}, {
  "like" : {
    "tweetId" : "1313432405651329025",
    "fullText" : "使いまわしでタグ失礼します🙏\n\n♡♻巡回します。挨拶は不要です。無言でまわらせてもらいます🙌\n\n#絵描きさんと繫がりたい \n#相互さんの相互さんと繋がりたい \n#秋の創作クラスタフォロー祭 https://t.co/51WrT7G7uq",
    "expandedUrl" : "https://twitter.com/i/web/status/1313432405651329025"
  }
}, {
  "like" : {
    "tweetId" : "1313426752824176640",
    "fullText" : "姫カット復活させたけど、実家のような安心感やゔぁいから好き💜",
    "expandedUrl" : "https://twitter.com/i/web/status/1313426752824176640"
  }
}, {
  "like" : {
    "tweetId" : "1313444130496770049",
    "fullText" : "お投資のお勉強もしたい。",
    "expandedUrl" : "https://twitter.com/i/web/status/1313444130496770049"
  }
}, {
  "like" : {
    "tweetId" : "1313530292125138945",
    "fullText" : "いつものように、メネシスとネクロマンサーとドラゴンのカードを全て砕きまして、ヴァンプのデッキ作りました。\n(∀｀*ゞ)ﾃﾍｯ",
    "expandedUrl" : "https://twitter.com/i/web/status/1313530292125138945"
  }
}, {
  "like" : {
    "tweetId" : "1313428631490756609",
    "fullText" : "お前らさてはぽれのことを見てるな？",
    "expandedUrl" : "https://twitter.com/i/web/status/1313428631490756609"
  }
}, {
  "like" : {
    "tweetId" : "1313529486210523136",
    "fullText" : "シャドバのデッキ作りました。\n(´・ω・｀)",
    "expandedUrl" : "https://twitter.com/i/web/status/1313529486210523136"
  }
}, {
  "like" : {
    "tweetId" : "1313417774094454784",
    "fullText" : "鳴き声「ヘラッ」",
    "expandedUrl" : "https://twitter.com/i/web/status/1313417774094454784"
  }
}, {
  "like" : {
    "tweetId" : "1313302682480779265",
    "fullText" : "エンジニアとして3年以上働いて次にステップアップしたいと思ったときに学ぶコスパいいモノに\n\n- SQL\n- CSS\n- vim\n\nがある。特にSQLとCSSはマジおすすめ。できないエンジニア多数なので市場価値が間違いなく上がる。\nあと、女の子からモテたいならvimやな。うん。vim使えたら年収も市場価値も文字数",
    "expandedUrl" : "https://twitter.com/i/web/status/1313302682480779265"
  }
}, {
  "like" : {
    "tweetId" : "1313453256064995333",
    "fullText" : "なんでTIG喰らわなかったんだろう... https://t.co/3USw1f8zGb",
    "expandedUrl" : "https://twitter.com/i/web/status/1313453256064995333"
  }
}, {
  "like" : {
    "tweetId" : "1313273904622780416",
    "fullText" : "#駆け出しエンジニアとつながりたくない\n#駆け出し低レイヤエンジニアとつながりたくない",
    "expandedUrl" : "https://twitter.com/i/web/status/1313273904622780416"
  }
}, {
  "like" : {
    "tweetId" : "1313062607285149696",
    "fullText" : "Kickoff! https://t.co/wQFQ4kprND",
    "expandedUrl" : "https://twitter.com/i/web/status/1313062607285149696"
  }
}, {
  "like" : {
    "tweetId" : "1313269466503933952",
    "fullText" : "グループ通話は気軽にできるけど、一対一で電話するのがやっぱ苦手だ",
    "expandedUrl" : "https://twitter.com/i/web/status/1313269466503933952"
  }
}, {
  "like" : {
    "tweetId" : "1313281482878713858",
    "fullText" : "@Hinata72279726 おっふ",
    "expandedUrl" : "https://twitter.com/i/web/status/1313281482878713858"
  }
}, {
  "like" : {
    "tweetId" : "1313094390584205313",
    "fullText" : "とりあえず若いうちは髪染めたり、メイクしたり、好きな服着たり、何だりして遊べ",
    "expandedUrl" : "https://twitter.com/i/web/status/1313094390584205313"
  }
}, {
  "like" : {
    "tweetId" : "1312937879933345793",
    "fullText" : "軽率に左右分割キーボードを布教しておりますので、みなさん、はんだ付けしましょう。",
    "expandedUrl" : "https://twitter.com/i/web/status/1312937879933345793"
  }
}, {
  "like" : {
    "tweetId" : "1312937702975709185",
    "fullText" : "最近キーボードを自作すればいいよ老害になってる。",
    "expandedUrl" : "https://twitter.com/i/web/status/1312937702975709185"
  }
}, {
  "like" : {
    "tweetId" : "1313104844241006598",
    "fullText" : "@igo1500013 めっちゃイゴさんの話楽しいから、なんだかんだ言って繋がってそうってのあるよね笑",
    "expandedUrl" : "https://twitter.com/i/web/status/1313104844241006598"
  }
}, {
  "like" : {
    "tweetId" : "1313129925201723392",
    "fullText" : "@Hinata72279726 使い分け大事よね、何言ってるかわからんけどありがとう",
    "expandedUrl" : "https://twitter.com/i/web/status/1313129925201723392"
  }
}, {
  "like" : {
    "tweetId" : "1313101833812930560",
    "fullText" : "@_unlimish 僕はpiscineがダメでも、アンリミさんとは繋がってたいんだ！ アンリミさんに興味持ってもらえるよーに頑張るね。",
    "expandedUrl" : "https://twitter.com/i/web/status/1313101833812930560"
  }
}, {
  "like" : {
    "tweetId" : "1313252670367387648",
    "fullText" : "@Hinata72279726 やったね♡",
    "expandedUrl" : "https://twitter.com/i/web/status/1313252670367387648"
  }
}, {
  "like" : {
    "tweetId" : "1313274365010612224",
    "fullText" : "Xcode勝手にアップデートしてんじゃねえええええええええええええええ",
    "expandedUrl" : "https://twitter.com/i/web/status/1313274365010612224"
  }
}, {
  "like" : {
    "tweetId" : "1313099320862732289",
    "fullText" : "気分的につらいからはやく寝る",
    "expandedUrl" : "https://twitter.com/i/web/status/1313099320862732289"
  }
}, {
  "like" : {
    "tweetId" : "1313073398658945025",
    "fullText" : "https://t.co/sRIBFphJbB",
    "expandedUrl" : "https://twitter.com/i/web/status/1313073398658945025"
  }
}, {
  "like" : {
    "tweetId" : "1313258229602807808",
    "fullText" : "#駆け出しエンジニアとつながりたい \n#stdioは甘え",
    "expandedUrl" : "https://twitter.com/i/web/status/1313258229602807808"
  }
}, {
  "like" : {
    "tweetId" : "1313009090449162242",
    "fullText" : "ピシン前ってなに考えて過ごしてたんやっけか、、、",
    "expandedUrl" : "https://twitter.com/i/web/status/1313009090449162242"
  }
}, {
  "like" : {
    "tweetId" : "1313273228287066112",
    "fullText" : "朝から何いってんだこいつら",
    "expandedUrl" : "https://twitter.com/i/web/status/1313273228287066112"
  }
}, {
  "like" : {
    "tweetId" : "1313274065474342913",
    "fullText" : "studio.hをincludeするな（老害）",
    "expandedUrl" : "https://twitter.com/i/web/status/1313274065474342913"
  }
}, {
  "like" : {
    "tweetId" : "1313131991882113024",
    "fullText" : "@Hinata72279726 前言撤回\nようやく理解できた。多分あってる",
    "expandedUrl" : "https://twitter.com/i/web/status/1313131991882113024"
  }
}, {
  "like" : {
    "tweetId" : "1313128307362164736",
    "fullText" : "んあーpythonから逃げられない。。。",
    "expandedUrl" : "https://twitter.com/i/web/status/1313128307362164736"
  }
}, {
  "like" : {
    "tweetId" : "1313081401042903041",
    "fullText" : "お洒落を追求すると処理時間がアホみたいに伸びるな....?",
    "expandedUrl" : "https://twitter.com/i/web/status/1313081401042903041"
  }
}, {
  "like" : {
    "tweetId" : "1313150236466896897",
    "fullText" : "働きながらも最後までやり切れたのは、お世辞でも綺麗事でもなく一緒に頑張る仲間がいたからでした。本当に。次のPiscineに参加される方それぞれに素敵な出会いがあればと思います。 https://t.co/ws3Zy5YVcs",
    "expandedUrl" : "https://twitter.com/i/web/status/1313150236466896897"
  }
}, {
  "like" : {
    "tweetId" : "1313161541080891392",
    "fullText" : "piscine終わって、己の不甲斐なさへの絶望と、彼女を失ったかのような空虚さとが折り重なって京都帰るまでにだいぶ時間かかったけど、やっと今日帰ってきた。そしてさっき、彼女とよりを戻せたかのような全能感にみまわれた。お母さん僕がんばるからお金ちょうだい",
    "expandedUrl" : "https://twitter.com/i/web/status/1313161541080891392"
  }
}, {
  "like" : {
    "tweetId" : "1313136391241388034",
    "fullText" : "@Hinata72279726 制服姿の女の子の画像にピン刺してただけなんだけどなーおかしいなー",
    "expandedUrl" : "https://twitter.com/i/web/status/1313136391241388034"
  }
}, {
  "like" : {
    "tweetId" : "1313133833194094593",
    "fullText" : "@Hinata72279726 眠すぎて頭が回ってないだけと信じたい",
    "expandedUrl" : "https://twitter.com/i/web/status/1313133833194094593"
  }
}, {
  "like" : {
    "tweetId" : "1312941012923211776",
    "fullText" : "【今日の東京ディズニーランド2020 ～「美女と野獣“魔法のものがたり”」編②～】\n今日は、「美女と野獣“魔法のものがたり”」の見どころをイマジニアたちが語る動画の続編をお届けします。\nこちらから♪＞＞ https://t.co/97PJAgcNhU\n\n#東京ディズニーランド2020 https://t.co/D7SmezedId",
    "expandedUrl" : "https://twitter.com/i/web/status/1312941012923211776"
  }
}, {
  "like" : {
    "tweetId" : "1312956186119950336",
    "fullText" : "夢の中でC言語書いてた。\nもう病気だ。\nΣ(ﾟдﾟlll)",
    "expandedUrl" : "https://twitter.com/i/web/status/1312956186119950336"
  }
}, {
  "like" : {
    "tweetId" : "1312746189620572160",
    "fullText" : "興味のないものなんてほとんど存在しないので軽率にコミュニティを渡り歩いてしまう",
    "expandedUrl" : "https://twitter.com/i/web/status/1312746189620572160"
  }
}, {
  "like" : {
    "tweetId" : "1312709178436149248",
    "fullText" : "ネタバレしない範囲での具体的なテネットの感想としては、「俺も『ｲﾅｧｧｧｱｱﾌ!!ｲｴｴｪｪｪ!!』って叫びながら女に暴力を振るう強さが欲しい」です。",
    "expandedUrl" : "https://twitter.com/i/web/status/1312709178436149248"
  }
}, {
  "like" : {
    "tweetId" : "1312948540969082886",
    "fullText" : "こちらをメインアカウントにしよう",
    "expandedUrl" : "https://twitter.com/i/web/status/1312948540969082886"
  }
}, {
  "like" : {
    "tweetId" : "1312722598669611010",
    "fullText" : "@Hinata72279726 わ💕",
    "expandedUrl" : "https://twitter.com/i/web/status/1312722598669611010"
  }
}, {
  "like" : {
    "tweetId" : "1312715674620432386",
    "fullText" : "@Hinata72279726 それは、えちじゃないってば…（小声）",
    "expandedUrl" : "https://twitter.com/i/web/status/1312715674620432386"
  }
}, {
  "like" : {
    "tweetId" : "1312717682974711814",
    "fullText" : "@_unlimish @Hinata72279726 撮影やりますよ！！いつでも言ってください！！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1312717682974711814"
  }
}, {
  "like" : {
    "tweetId" : "1312940081817108480",
    "fullText" : "自作キーボードの何がいいって、\nBlenderのためにテンキー買わなくていいってとこ",
    "expandedUrl" : "https://twitter.com/i/web/status/1312940081817108480"
  }
}, {
  "like" : {
    "tweetId" : "1312714873831260161",
    "fullText" : "@Hinata72279726 私はどこを目指しているのだろう....笑",
    "expandedUrl" : "https://twitter.com/i/web/status/1312714873831260161"
  }
}, {
  "like" : {
    "tweetId" : "1310677429204258817",
    "fullText" : "New Keycaps!😈 https://t.co/Vpbvhx7lH7",
    "expandedUrl" : "https://twitter.com/i/web/status/1310677429204258817"
  }
}, {
  "like" : {
    "tweetId" : "1312920981493542913",
    "fullText" : "電車の中でコード書かずに調べ物しながら通勤できる日が戻ってきた",
    "expandedUrl" : "https://twitter.com/i/web/status/1312920981493542913"
  }
}, {
  "like" : {
    "tweetId" : "1312713740668731394",
    "fullText" : "@Hinata72279726 でも休んだら逆に自己嫌悪感に苛まれるループにハマって逆につらくて、泣きながら頑張るほうが頑張れる気がする…",
    "expandedUrl" : "https://twitter.com/i/web/status/1312713740668731394"
  }
}, {
  "like" : {
    "tweetId" : "1312814438358020097",
    "fullText" : "ｳｯ 昔は先が見えなくて焦ってたな、辛かったな、図太く生きたな…今は下降線が堪えるけどunhappyを流せるようになるらしく、頑張る&amp;楽しむしかない そして若者にエールを送りたい老害、これ気にはしてるんです、これでも…　あー、なのに…🙏🙇",
    "expandedUrl" : "https://twitter.com/i/web/status/1312814438358020097"
  }
}, {
  "like" : {
    "tweetId" : "1312747088262750209",
    "fullText" : "明日10月5日より\n東京ディズニーシー\n「ブロードウェイ・ミュージックシアター」\n「ドックサイドステージ」\nがキャラクターグリーティングとして運営されます。\nグリーティングには、東京ディズニーリゾート・アプリにてエントリー受付が必要です☆\nhttps://t.co/uJ6PwfL6Pn https://t.co/KfuEqzEu8I",
    "expandedUrl" : "https://twitter.com/i/web/status/1312747088262750209"
  }
}, {
  "like" : {
    "tweetId" : "1312575801422827520",
    "fullText" : "ロシア、カムチャッカの海洋汚染、海水は苦くなり、サーファーに中毒症状、甲殻類からアザラシまで海の様々な生物に影響が出ている模様。汚染元は河川のようで、現在原因を調査中とのこと。。。 https://t.co/ZAVXrljZwg",
    "expandedUrl" : "https://twitter.com/i/web/status/1312575801422827520"
  }
}, {
  "like" : {
    "tweetId" : "1312708007105495040",
    "fullText" : "@Hinata72279726 そういうこというともっと感情がぐちゃぐちゃになって泣きたくなっちゃうぢゃん",
    "expandedUrl" : "https://twitter.com/i/web/status/1312708007105495040"
  }
}, {
  "like" : {
    "tweetId" : "1313029642203193344",
    "fullText" : "ʕ•ᴥ•ʔ https://t.co/7Nyu76wZ2I",
    "expandedUrl" : "https://twitter.com/i/web/status/1313029642203193344"
  }
}, {
  "like" : {
    "tweetId" : "1312737273956319232",
    "fullText" : "NVIDIAが、開発してきた様々なGAN系の手法をまとめたPyTorch実装のライブラリ\"Imaginaire\"を公開した模様\nhttps://t.co/1AmIhkExoB\n https://t.co/X0B1ev7gKQ",
    "expandedUrl" : "https://twitter.com/i/web/status/1312737273956319232"
  }
}, {
  "like" : {
    "tweetId" : "1312716853211402240",
    "fullText" : "@Hinata72279726 な  る  ほ  ど\nひなたにうちが泣かされるんですね？",
    "expandedUrl" : "https://twitter.com/i/web/status/1312716853211402240"
  }
}, {
  "like" : {
    "tweetId" : "1312777866480766977",
    "fullText" : "誕生日ですみんな祝って！！！！！！！ https://t.co/oo7BDeVv8U",
    "expandedUrl" : "https://twitter.com/i/web/status/1312777866480766977"
  }
}, {
  "like" : {
    "tweetId" : "1313030173114032129",
    "fullText" : "CTFで問題解かせるコードもCで書くくらい1ヶ月で調教された",
    "expandedUrl" : "https://twitter.com/i/web/status/1313030173114032129"
  }
}, {
  "like" : {
    "tweetId" : "1312715759169093632",
    "fullText" : "@Hinata72279726 下戸のバーテンダー...なしで。",
    "expandedUrl" : "https://twitter.com/i/web/status/1312715759169093632"
  }
}, {
  "like" : {
    "tweetId" : "1312714217540050944",
    "fullText" : "@Hinata72279726 家がバーになりそう....ミントリキュール今日買いかけたのは内緒",
    "expandedUrl" : "https://twitter.com/i/web/status/1312714217540050944"
  }
}, {
  "like" : {
    "tweetId" : "1312739533352386562",
    "fullText" : "何個か作ったらBoothに出します！カラバリ3種用意予定。#見せびらかしバッグ https://t.co/nGGQAFcTPl",
    "expandedUrl" : "https://twitter.com/i/web/status/1312739533352386562"
  }
}, {
  "like" : {
    "tweetId" : "1312641053128683521",
    "fullText" : "Piscineロスを紛らわすために採用 https://t.co/3A5PWdT0UN",
    "expandedUrl" : "https://twitter.com/i/web/status/1312641053128683521"
  }
}, {
  "like" : {
    "tweetId" : "1312658283551834114",
    "fullText" : "そうだ💡\n酒を呑もう",
    "expandedUrl" : "https://twitter.com/i/web/status/1312658283551834114"
  }
}, {
  "like" : {
    "tweetId" : "1312661905383723011",
    "fullText" : "首から下の毛、何のためにあるの？って思ってる人",
    "expandedUrl" : "https://twitter.com/i/web/status/1312661905383723011"
  }
}, {
  "like" : {
    "tweetId" : "1312697084001226755",
    "fullText" : "@Hinata72279726 au光",
    "expandedUrl" : "https://twitter.com/i/web/status/1312697084001226755"
  }
}, {
  "like" : {
    "tweetId" : "1312629205281075200",
    "fullText" : "涙と一緒にぼーっとしてる",
    "expandedUrl" : "https://twitter.com/i/web/status/1312629205281075200"
  }
}, {
  "like" : {
    "tweetId" : "1312634522110889984",
    "fullText" : "みんな作業して生活してえらい",
    "expandedUrl" : "https://twitter.com/i/web/status/1312634522110889984"
  }
}, {
  "like" : {
    "tweetId" : "1312679639395885058",
    "fullText" : "@Kahorin_42Tokyo @luna_yuta @Hinata72279726 はいっ、解散解散ー",
    "expandedUrl" : "https://twitter.com/i/web/status/1312679639395885058"
  }
}, {
  "like" : {
    "tweetId" : "1312697211197685763",
    "fullText" : "これずっと欲しかった https://t.co/tlaKtek7js",
    "expandedUrl" : "https://twitter.com/i/web/status/1312697211197685763"
  }
}, {
  "like" : {
    "tweetId" : "1312670823069577216",
    "fullText" : "@Hinata72279726 @luna_yuta @Kahorin_42Tokyo もー！！！\nゆーたったら、\nかっほの事しか見えてないんだからぁ！",
    "expandedUrl" : "https://twitter.com/i/web/status/1312670823069577216"
  }
}, {
  "like" : {
    "tweetId" : "1312660013094109184",
    "fullText" : "エスカレーター歩く人が左側\npwd\n/kansai\n\n!= TOKYO",
    "expandedUrl" : "https://twitter.com/i/web/status/1312660013094109184"
  }
}, {
  "like" : {
    "tweetId" : "1312667003363049472",
    "fullText" : "@luna_yuta @Kahorin_42Tokyo なによっ！かっほばっかじゃなくて\nあたしのことも見てよ！！！",
    "expandedUrl" : "https://twitter.com/i/web/status/1312667003363049472"
  }
}, {
  "like" : {
    "tweetId" : "1312679383031709696",
    "fullText" : "@luna_yuta @nuts_codie @Hinata72279726 全人類私が好きってことだけは把握した(だまれ",
    "expandedUrl" : "https://twitter.com/i/web/status/1312679383031709696"
  }
}, {
  "like" : {
    "tweetId" : "1312657052892708864",
    "fullText" : "与えられた問題を解いてるだけではダメ\n自分で問題作って解いてみな\nできた時の快感が桁違い",
    "expandedUrl" : "https://twitter.com/i/web/status/1312657052892708864"
  }
}, {
  "like" : {
    "tweetId" : "1312656078933389312",
    "fullText" : "@Hinata72279726 美化、というか、肩書にこだわらず好きなことをただやってる人って感じ？\n何にでもなる≠何にでもなれる",
    "expandedUrl" : "https://twitter.com/i/web/status/1312656078933389312"
  }
}, {
  "like" : {
    "tweetId" : "1312694797820334080",
    "fullText" : "落ち葉味🦊🦊\n #蔵王キツネ村 https://t.co/VwDQHimbMI https://t.co/jrBNdtqV6H",
    "expandedUrl" : "https://twitter.com/i/web/status/1312694797820334080"
  }
}, {
  "like" : {
    "tweetId" : "1312659814489616386",
    "fullText" : "@Hinata72279726 や、まじそれな。ひなたと酒呑んでみたいとは思ってたんよ！",
    "expandedUrl" : "https://twitter.com/i/web/status/1312659814489616386"
  }
}, {
  "like" : {
    "tweetId" : "1312660176952942593",
    "fullText" : "一緒に呑んでみたい人\nひなた、イゴさん、がみさん",
    "expandedUrl" : "https://twitter.com/i/web/status/1312660176952942593"
  }
}, {
  "like" : {
    "tweetId" : "1312678944387133443",
    "fullText" : "@Teddie9Piscine1 @Hinata72279726 @igo1500013 ざわ…ざわざわ…\n\nとりあえず金土とかの翌日が休みの日に適当に今度呑みましょー！みんな浮輪入ってるよね？詳細はアル中でチャンネルで笑",
    "expandedUrl" : "https://twitter.com/i/web/status/1312678944387133443"
  }
}, {
  "like" : {
    "tweetId" : "1312679524555866120",
    "fullText" : "@Kahorin_42Tokyo @Hinata72279726 @igo1500013 イエス、ユア・ハイネス",
    "expandedUrl" : "https://twitter.com/i/web/status/1312679524555866120"
  }
}, {
  "like" : {
    "tweetId" : "1312707684123045894",
    "fullText" : "@Hinata72279726 これでハイボールが美味しく作れるぜ",
    "expandedUrl" : "https://twitter.com/i/web/status/1312707684123045894"
  }
}, {
  "like" : {
    "tweetId" : "1312686864504029185",
    "fullText" : "origin masterじゃなくてorigin mainになったのか",
    "expandedUrl" : "https://twitter.com/i/web/status/1312686864504029185"
  }
}, {
  "like" : {
    "tweetId" : "1312665797181882368",
    "fullText" : "@Kahorin_42Tokyo いつでも！",
    "expandedUrl" : "https://twitter.com/i/web/status/1312665797181882368"
  }
}, {
  "like" : {
    "tweetId" : "1312657541378183168",
    "fullText" : "いやfinal exam受けもしてへんのに合格するわけなくね？浅草寺きた。",
    "expandedUrl" : "https://twitter.com/i/web/status/1312657541378183168"
  }
}, {
  "like" : {
    "tweetId" : "1312687660729729024",
    "fullText" : "ピンクアッシュきゃわみすぎて染めたいですねー",
    "expandedUrl" : "https://twitter.com/i/web/status/1312687660729729024"
  }
}, {
  "like" : {
    "tweetId" : "1312696881911275524",
    "fullText" : "@Hinata72279726 ソフバン勢だけどオススメしない",
    "expandedUrl" : "https://twitter.com/i/web/status/1312696881911275524"
  }
}, {
  "like" : {
    "tweetId" : "1312602256194199552",
    "fullText" : "@Hinata72279726 毛先だけ染めるならセルフカラーでも全然できるだろうから折角お店で染めるならこんな風にに全体も染めてみては？ https://t.co/Rq6IMYfOAO",
    "expandedUrl" : "https://twitter.com/i/web/status/1312602256194199552"
  }
}, {
  "like" : {
    "tweetId" : "1312573416352882688",
    "fullText" : "めっちゃ通話したあとに毎度のこと頭の中でめっちゃ後悔してるけど、喋りたいよなー",
    "expandedUrl" : "https://twitter.com/i/web/status/1312573416352882688"
  }
}, {
  "like" : {
    "tweetId" : "1312289002850971651",
    "fullText" : "事前にお知らせがあった通り、GitHub のデフォルトブランチが master から main に変更された。 / “The default branch for newly-created repositories is now main - GitHub Changelog” https://t.co/PnZqK9aaDm",
    "expandedUrl" : "https://twitter.com/i/web/status/1312289002850971651"
  }
}, {
  "like" : {
    "tweetId" : "1312374254222995456",
    "fullText" : "@Hinata72279726 やめろぉぉぉぉ。ただの胃腸の不調だ。",
    "expandedUrl" : "https://twitter.com/i/web/status/1312374254222995456"
  }
}, {
  "like" : {
    "tweetId" : "1312644087200194561",
    "fullText" : "いや、かわいいんだよなぁ・・・・。 https://t.co/gTLJk0yoct",
    "expandedUrl" : "https://twitter.com/i/web/status/1312644087200194561"
  }
}, {
  "like" : {
    "tweetId" : "1312649137301549057",
    "fullText" : "@Hinata72279726 草",
    "expandedUrl" : "https://twitter.com/i/web/status/1312649137301549057"
  }
}, {
  "like" : {
    "tweetId" : "1312390352184123393",
    "fullText" : "ピシン終わってlatexの毎日になった",
    "expandedUrl" : "https://twitter.com/i/web/status/1312390352184123393"
  }
}, {
  "like" : {
    "tweetId" : "1312606773191168000",
    "fullText" : "@luna_yuta @Hinata72279726 だけど良き色やな。ゆーた氏の紫は結構好きだった。",
    "expandedUrl" : "https://twitter.com/i/web/status/1312606773191168000"
  }
}, {
  "like" : {
    "tweetId" : "1312393600135622657",
    "fullText" : "今日の池袋は治安が悪い",
    "expandedUrl" : "https://twitter.com/i/web/status/1312393600135622657"
  }
}, {
  "like" : {
    "tweetId" : "1312370431685402626",
    "fullText" : "サツ意マシマシだった頃に描いたマイアミのイラスト　癒される https://t.co/vxxylhD87S",
    "expandedUrl" : "https://twitter.com/i/web/status/1312370431685402626"
  }
}, {
  "like" : {
    "tweetId" : "1312340321036951552",
    "fullText" : "@Hinata72279726 リア垢だと話すことがないのにPiscine垢はいくらでも喋れる",
    "expandedUrl" : "https://twitter.com/i/web/status/1312340321036951552"
  }
}, {
  "like" : {
    "tweetId" : "1312381248304685056",
    "fullText" : "unityもunrealもエンジン自体の実装はC++だったような",
    "expandedUrl" : "https://twitter.com/i/web/status/1312381248304685056"
  }
}, {
  "like" : {
    "tweetId" : "1312652103303614466",
    "fullText" : "@Hinata72279726 天才じゃん、次やるときも解けるように知識つけるからまたみんなでやろうね",
    "expandedUrl" : "https://twitter.com/i/web/status/1312652103303614466"
  }
}, {
  "like" : {
    "tweetId" : "1312351934108463106",
    "fullText" : "@Hinata72279726 大丈夫、いい距離感保とうと思ってる",
    "expandedUrl" : "https://twitter.com/i/web/status/1312351934108463106"
  }
}, {
  "like" : {
    "tweetId" : "1312400493843374081",
    "fullText" : "@Kahorin_42Tokyo かっほ歌うまそう",
    "expandedUrl" : "https://twitter.com/i/web/status/1312400493843374081"
  }
}, {
  "like" : {
    "tweetId" : "1312605992455041025",
    "fullText" : "@luna_yuta @Hinata72279726 全体をそこまで染めるとメンテが面倒なのと、暗く戻したいときにだいぶ苦労する",
    "expandedUrl" : "https://twitter.com/i/web/status/1312605992455041025"
  }
}, {
  "like" : {
    "tweetId" : "1312617518503088129",
    "fullText" : "piscineで出会った人たちとのコミュニケーション、遥か昔に失った何かを刺激してエモい気持ちになるのがイライラするのと同時に好き",
    "expandedUrl" : "https://twitter.com/i/web/status/1312617518503088129"
  }
}, {
  "like" : {
    "tweetId" : "1312602554610577408",
    "fullText" : "@Hinata72279726 複数の色mixもかわゆし https://t.co/qSvxUkIwKm",
    "expandedUrl" : "https://twitter.com/i/web/status/1312602554610577408"
  }
}, {
  "like" : {
    "tweetId" : "1312611989366083584",
    "fullText" : "@Kahorin_42Tokyo @Hinata72279726 まぁほんとは白を目指してたんですけどね、、、ピシン終わったし再チャレンジや！",
    "expandedUrl" : "https://twitter.com/i/web/status/1312611989366083584"
  }
}, {
  "like" : {
    "tweetId" : "1312584786565754881",
    "fullText" : "変態すぎる",
    "expandedUrl" : "https://twitter.com/i/web/status/1312584786565754881"
  }
}, {
  "like" : {
    "tweetId" : "1312628079584407552",
    "fullText" : "うううめんったるぅ",
    "expandedUrl" : "https://twitter.com/i/web/status/1312628079584407552"
  }
}, {
  "like" : {
    "tweetId" : "1312581365875929089",
    "fullText" : ".｡oO（ 本日は #天使の日 ということで…ガブリエル様…置いておきますね…🙏✨\n\n#コンスタンティン https://t.co/IFJStsTSLb",
    "expandedUrl" : "https://twitter.com/i/web/status/1312581365875929089"
  }
}, {
  "like" : {
    "tweetId" : "1312649096742596608",
    "fullText" : "@sleepyfox_42 きつねさん可愛い",
    "expandedUrl" : "https://twitter.com/i/web/status/1312649096742596608"
  }
}, {
  "like" : {
    "tweetId" : "1312575965608861696",
    "fullText" : "@Hinata72279726 毎日チェックせねばw",
    "expandedUrl" : "https://twitter.com/i/web/status/1312575965608861696"
  }
}, {
  "like" : {
    "tweetId" : "1312594963964719105",
    "fullText" : "@Hinata72279726 Vimer怖って思ったけど...あなたバリバリVS使ってたよね🤔🤔",
    "expandedUrl" : "https://twitter.com/i/web/status/1312594963964719105"
  }
}, {
  "like" : {
    "tweetId" : "1311972981267197953",
    "fullText" : "これまだ知らない人いますかね？ \n \nChromeの拡張機能「Language Learning with Netflix」 \n \n・再生速度を変えられる \n・英語・日本語字幕を同時に表示 \n・単語をクリックすると意味が表示される \n・1クリックでセリフを繰り返し再生できる \n \nこれで無料！最強です。\nhttps://t.co/KJptqWqZ8l",
    "expandedUrl" : "https://twitter.com/i/web/status/1311972981267197953"
  }
}, {
  "like" : {
    "tweetId" : "1312276936131919872",
    "fullText" : "Piscine 終わったのになんか習慣でボイチャ入って勉強し始めそうになってしまった",
    "expandedUrl" : "https://twitter.com/i/web/status/1312276936131919872"
  }
}, {
  "like" : {
    "tweetId" : "1312325334553882625",
    "fullText" : "私もまだやってますねー",
    "expandedUrl" : "https://twitter.com/i/web/status/1312325334553882625"
  }
}, {
  "like" : {
    "tweetId" : "1312312397521059841",
    "fullText" : "ほとんど公式サーバーしか使ってなかったからすごい空虚。",
    "expandedUrl" : "https://twitter.com/i/web/status/1312312397521059841"
  }
}, {
  "like" : {
    "tweetId" : "1311993738944684033",
    "fullText" : "#絵描きさんと繫がりたい \n#秋の創作クラスタフォロー祭り \n\nタグ失礼します〜\nしゅわしゅわできらきらした世界と可愛い女の子を描くのが好きです💫\n素敵なご縁がありますように！ https://t.co/V6jGt3fuLy",
    "expandedUrl" : "https://twitter.com/i/web/status/1311993738944684033"
  }
}, {
  "like" : {
    "tweetId" : "1312302799485427712",
    "fullText" : "音楽勢と文学勢と頭おかしい勢に加えて頭のおかしいエンジニア志望者たちをTLに追加してしまったのでもうTLがめちゃくちゃだよわかる",
    "expandedUrl" : "https://twitter.com/i/web/status/1312302799485427712"
  }
}, {
  "like" : {
    "tweetId" : "1312321895535054849",
    "fullText" : "@Kahorin_42Tokyo @takehitopistol 送っといた。",
    "expandedUrl" : "https://twitter.com/i/web/status/1312321895535054849"
  }
}, {
  "like" : {
    "tweetId" : "1312313575583608832",
    "fullText" : "@takehitopistol ウェルカム浮輪サーバー",
    "expandedUrl" : "https://twitter.com/i/web/status/1312313575583608832"
  }
}, {
  "like" : {
    "tweetId" : "1312294551868960768",
    "fullText" : "@Kahorin_42Tokyo @Hinata72279726 @luna_yuta [チケットがすでに発行されています]",
    "expandedUrl" : "https://twitter.com/i/web/status/1312294551868960768"
  }
}, {
  "like" : {
    "tweetId" : "1312304312094138370",
    "fullText" : "あーくず...",
    "expandedUrl" : "https://twitter.com/i/web/status/1312304312094138370"
  }
}, {
  "like" : {
    "tweetId" : "1312235148058918912",
    "fullText" : "@Hinata72279726 @Kahorin_42Tokyo @luna_yuta バブルソートでスワッピングがいいなー",
    "expandedUrl" : "https://twitter.com/i/web/status/1312235148058918912"
  }
}, {
  "like" : {
    "tweetId" : "1312320187639623683",
    "fullText" : "@Hinata72279726 うわ、野方ホープなっつかし、行きてぇ",
    "expandedUrl" : "https://twitter.com/i/web/status/1312320187639623683"
  }
}, {
  "like" : {
    "tweetId" : "1312293667663536129",
    "fullText" : "@_unlimish @Hinata72279726 @luna_yuta ロ…ログインできませんっ///",
    "expandedUrl" : "https://twitter.com/i/web/status/1312293667663536129"
  }
}, {
  "like" : {
    "tweetId" : "1312231321956085762",
    "fullText" : "１ヶ月ぶりのお休みの今日は、何をしょう。\n(´・ω・｀)",
    "expandedUrl" : "https://twitter.com/i/web/status/1312231321956085762"
  }
}, {
  "like" : {
    "tweetId" : "1312199293265043457",
    "fullText" : "Piscine終了！\n濃い一ヶ月が終わったー！\n楽しかったです！",
    "expandedUrl" : "https://twitter.com/i/web/status/1312199293265043457"
  }
}, {
  "like" : {
    "tweetId" : "1312300178469081088",
    "fullText" : "rexさんとフランキーさん… https://t.co/sEdQ7iGPme",
    "expandedUrl" : "https://twitter.com/i/web/status/1312300178469081088"
  }
}, {
  "like" : {
    "tweetId" : "1312000525441802240",
    "fullText" : "みんな、感覚マヒってるだけで、相当疲れ溜まってるからね、気が抜けて体調崩さないようにね（特にオレ）",
    "expandedUrl" : "https://twitter.com/i/web/status/1312000525441802240"
  }
}, {
  "like" : {
    "tweetId" : "1312292393480146946",
    "fullText" : "@_unlimish @Hinata72279726 @Kahorin_42Tokyo これがチケットか。",
    "expandedUrl" : "https://twitter.com/i/web/status/1312292393480146946"
  }
}, {
  "like" : {
    "tweetId" : "1312236052053020673",
    "fullText" : "@Hinata72279726 @Kahorin_42Tokyo @luna_yuta あと、何かあったときのためにRAIDを組んでホットスワップもできるようにしたいね",
    "expandedUrl" : "https://twitter.com/i/web/status/1312236052053020673"
  }
}, {
  "like" : {
    "tweetId" : "1312324842050347008",
    "fullText" : "まだP2Pラーニングしてるみなさん。",
    "expandedUrl" : "https://twitter.com/i/web/status/1312324842050347008"
  }
}, {
  "like" : {
    "tweetId" : "1312291365397487616",
    "fullText" : "@Hinata72279726 @luna_yuta @Kahorin_42Tokyo けるべろす\nhttps://t.co/nmT2obH8xA",
    "expandedUrl" : "https://twitter.com/i/web/status/1312291365397487616"
  }
}, {
  "like" : {
    "tweetId" : "1312216182624198657",
    "fullText" : "プログラミングスクールの試験に参加してたはずなのに全体の環境整備とかニコ生配信始めちゃう辺り意味が分からん",
    "expandedUrl" : "https://twitter.com/i/web/status/1312216182624198657"
  }
}, {
  "like" : {
    "tweetId" : "1312275959937032193",
    "fullText" : "@_unlimish @Hinata72279726 @Kahorin_42Tokyo 僕の股間は一本木なので・・・・すみません・・・・・",
    "expandedUrl" : "https://twitter.com/i/web/status/1312275959937032193"
  }
}, {
  "like" : {
    "tweetId" : "1312280102009360384",
    "fullText" : "合格ライン分らないけどSNSの汚さでいえば確実に不合格",
    "expandedUrl" : "https://twitter.com/i/web/status/1312280102009360384"
  }
}, {
  "like" : {
    "tweetId" : "1312321844788097024",
    "fullText" : "東京来てから何回食ったかわからん、太陽のトマト麺のチーズトマトラーメン https://t.co/s4mX7m5z4u",
    "expandedUrl" : "https://twitter.com/i/web/status/1312321844788097024"
  }
} ]