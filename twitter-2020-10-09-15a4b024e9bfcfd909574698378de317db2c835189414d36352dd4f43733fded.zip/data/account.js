window.YTD.account.part0 = [ {
  "account" : {
    "email" : "182922a@gmail.com",
    "createdVia" : "oauth:129032",
    "username" : "Hinata72279726",
    "accountId" : "1228559135093821441",
    "createdAt" : "2020-02-15T05:58:41.232Z",
    "accountDisplayName" : "Hinata"
  }
} ]