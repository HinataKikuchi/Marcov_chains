window.YTD.user_link_clicks.part0 = [ {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1305254228986744832",
      "finalUrl" : "https://headlines.yahoo.co.jp/article?a=20200910-00010000-wired-sctch",
      "timeStampOfInteraction" : "2020-09-13T22:42:38.373Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1305444174435504133",
      "finalUrl" : "https://www.jiji.com/jc/article?k=2020091400934&g=int",
      "timeStampOfInteraction" : "2020-09-15T14:30:22.269Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1249581373402148864",
      "finalUrl" : "https://www.change.org/p/%E9%98%B2%E5%BC%BE%E5%B0%91%E5%B9%B4%E5%9B%A3-bts-%E3%82%92%E6%97%A5%E6%9C%AC%E3%81%8B%E3%82%89%E8%BF%BD%E6%94%BE%E3%81%97%E3%82%88%E3%81%86-bts-get-out-of-japan-%EB%B9%85%ED%9E%88%ED%8A%B8-%EC%9D%BC%EB%B3%B8%EC%BD%98-%EC%B7%A8%EC%86%8C%ED%95%B4%EC%A3%BC%EC%84%B8%EC%9A%94",
      "timeStampOfInteraction" : "2020-09-23T02:31:26.041Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1308447923441561601",
      "finalUrl" : "https://fnjpnews.com/wp-content/uploads/2020/09/bts.mp4",
      "timeStampOfInteraction" : "2020-09-23T01:21:22.842Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1287732608386732032",
      "finalUrl" : "https://mkaigawa.hatenablog.jp/entry/2018/11/08/120000",
      "timeStampOfInteraction" : "2020-09-23T15:15:16.655Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1309040476067180546",
      "finalUrl" : "https://times.abema.tv/news-article/8625589",
      "timeStampOfInteraction" : "2020-09-24T08:14:55.238Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1309365870616027136",
      "finalUrl" : "https://buff.ly/3kP5pHQ",
      "timeStampOfInteraction" : "2020-09-25T07:41:48.367Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1309344574456823810",
      "finalUrl" : "https://theriver.jp/yakuza-sega-hollywood-movie/",
      "timeStampOfInteraction" : "2020-09-25T09:34:13.060Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1309801334703419392",
      "finalUrl" : "https://www.gifu-np.co.jp/news/20200926/20200926-277107.html",
      "timeStampOfInteraction" : "2020-09-26T14:27:00.305Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1310011112801202176",
      "finalUrl" : "https://www.excite.co.jp/news/article/Narinari_20200927_61691/",
      "timeStampOfInteraction" : "2020-09-27T01:22:03.558Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1309881763712233473",
      "finalUrl" : "https://laurier-excite-co-jp.cdn.ampproject.org/v/s/laurier.excite.co.jp/a/E1599460947890?amp_js_v=a6&amp_gsa=1&usqp=mq331AQFKAGwASA%3D#aoh=16011349068751&referrer=https%3A%2F%2Fwww.google.com&amp_tf=%E3%82%BD%E3%83%BC%E3%82%B9%3A%20%251%24s&ampshare=https%3A%2F%2Flaurier.excite.co.jp%2Fi%2FE1599460947890",
      "timeStampOfInteraction" : "2020-09-29T21:34:05.527Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1312289002850971651",
      "finalUrl" : "https://htn.to/2tsS6tCsw1",
      "timeStampOfInteraction" : "2020-10-04T03:06:55.071Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1312480245862199296",
      "finalUrl" : "https://news.yahoo.co.jp/articles/bdc36dd2e90c71e639018d1a59238b4bd0306ada",
      "timeStampOfInteraction" : "2020-10-04T02:01:32.871Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1312587307782860803",
      "finalUrl" : "https://toyokeizai.net/articles/-/375731",
      "timeStampOfInteraction" : "2020-10-04T12:11:42.020Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1312941012923211776",
      "finalUrl" : "http://tdr.eng.mg/58e51",
      "timeStampOfInteraction" : "2020-10-05T03:34:05.560Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1306168887344463873",
      "finalUrl" : "https://www.nikkei.com/article/DGXMZO63905840W0A910C2EE9000/?n_cid=SNSTW001",
      "timeStampOfInteraction" : "2020-09-16T10:48:23.703Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1311864689702301700",
      "finalUrl" : "https://blog.ue-y.me/42tokyo/",
      "timeStampOfInteraction" : "2020-10-05T16:15:55.356Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1301782042451914752",
      "finalUrl" : "https://www.youtube.com/playlist?list=PLL-CP7E7Ze8w4mVQIrkgKdq0gd0uoJYFQ",
      "timeStampOfInteraction" : "2020-10-06T13:21:11.221Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1128631601519157248",
      "finalUrl" : "https://www.machinanette.com/2019/05/08/%e6%98%87%e8%8f%af%e3%82%a4%e3%83%b3%e3%82%af%e3%81%a7%e3%82%ad%e3%83%bc%e3%82%ad%e3%83%a3%e3%83%83%e3%83%97%e3%81%ab%e5%8d%b0%e5%ad%97%e3%81%97%e3%81%a6%e3%81%bf%e3%82%8b/",
      "timeStampOfInteraction" : "2020-09-18T00:40:37.309Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1307071552752619521",
      "finalUrl" : "https://advances.sciencemag.org/content/early/2020/09/18/sciadv.abd3916",
      "timeStampOfInteraction" : "2020-09-19T04:55:12.717Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1306902528014000129",
      "finalUrl" : "https://news.livedoor.com/lite/article_detail/18920507/",
      "timeStampOfInteraction" : "2020-09-19T00:30:44.906Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1273846644425940993",
      "finalUrl" : "https://a.aliexpress.com/_d7yUD4C",
      "timeStampOfInteraction" : "2020-09-18T23:04:34.753Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1307475429561757696",
      "finalUrl" : "https://www.news-postseven.com/archives/20200920_1596562.html?DETAIL",
      "timeStampOfInteraction" : "2020-09-20T03:01:22.923Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1307590590767407104",
      "finalUrl" : "https://yushakobo.jp/shop/gb-zen-pond-iii/",
      "timeStampOfInteraction" : "2020-09-21T05:33:26.614Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1307951077950550017",
      "finalUrl" : "https://github.com/niw/ramen/commit/a1e3211f649d96433833f8b489198c3d79199d66#diff-ce1c82794fc9d3c14ff9036921d291ba",
      "timeStampOfInteraction" : "2020-09-21T11:57:05.116Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1307877268434411521",
      "finalUrl" : "https://bts-official.jp/news/detail.php?nid=oP05nCXAgO8=",
      "timeStampOfInteraction" : "2020-09-21T22:44:14.313Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1294035710236749825",
      "finalUrl" : "https://www.oricon.co.jp/news/2169406/full/",
      "timeStampOfInteraction" : "2020-09-22T12:18:32.815Z"
    }
  }
} ]