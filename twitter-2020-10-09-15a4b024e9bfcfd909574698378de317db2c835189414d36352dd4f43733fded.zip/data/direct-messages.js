window.YTD.direct_messages.part0 = [ {
  "dmConversation" : {
    "conversationId" : "518608419-1228559135093821441",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "518608419",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "結果的に車を使って移動できて、パッと買えるサービスは繁盛するのかと思ったのですがどうでしょう…\n\n都内の事情には合わないかもしれませんが、マクドナルド全体の利益が上がっているなら全国規模での要因かと…",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1268963872037199877",
        "createdAt" : "2020-06-05T17:52:18.029Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "518608419",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "あともう一点、工場労働者の方々で一番多いのは海外からの技能研修生の方々です。\n\nこちらは本当に多国籍の方ばかりで、一様には言いがたいですが\n\n全国チェーンであるマクドナルドの印象は強いと思います。知らない土地で母国にあったチェーン店で馴染みの注文をする方は多いです。以前はブラジルや南米から来てくださっていた方が多かったですが、今はベトナムやインドネシアの近い国々からきてくださる方が多いように感じます。",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1268963509041197061",
        "createdAt" : "2020-06-05T17:50:51.479Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "518608419",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "製造、運送は特にラインを止められないので労働者の方々がドライブスルーを利用されます。\n\n加えて、家族づれ、一人暮らし、すべての人が車を使う地方社会では特にドライブスルーはとてもありがたいサービスだと思います。",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1268962949072211972",
        "createdAt" : "2020-06-05T17:48:37.983Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "518608419",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "私は地方大学に通っています。\n\n地方は車がないと生きていけない社会で、uberは愚か出前館もファミレスもなかなかないです。特にデリバリーは本当に少なくて、大手外食チェーンが主です。\n\nそうなるとドライブスルーをやっているチェーンはとても繁盛します。こういうコロナでない時もそうです。買って行く方達は家族づれもそうですが、工場労働者の方やお仕事されている方も多いです",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1268962479905763334",
        "createdAt" : "2020-06-05T17:46:46.135Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "518608419",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "本当は店舗ごとの商品や利用者の情報があったら可視化してわかることを伝えたかったのですが一瞬探したところなかったのですみません私の考えで話します",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1268961863921852421",
        "createdAt" : "2020-06-05T17:44:19.260Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "518608419",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "先ほどこちらのツイートをお見かけしてお声がけさせていただきました、私見ですがお聞きいただければ幸いです。",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1268961436102873097",
        "createdAt" : "2020-06-05T17:42:37.254Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "518608419",
        "reactions" : [ ],
        "urls" : [ {
          "url" : "https://t.co/vVY0saZMeN",
          "expanded" : "https://twitter.com/yusuke_horie/status/1268800288061702144",
          "display" : "twitter.com/yusuke_horie/s…"
        } ],
        "text" : "https://t.co/vVY0saZMeN",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1268961299569860612",
        "createdAt" : "2020-06-05T17:42:04.717Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "994606316667600896-1228559135093821441",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "994606316667600896",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "よろしくね",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298143038204592132",
        "createdAt" : "2020-08-25T06:19:53.320Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "994606316667600896",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ありがとう！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298143020680798215",
        "createdAt" : "2020-08-25T06:19:49.143Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "一緒に乗り越えよう！！",
        "mediaUrls" : [ ],
        "senderId" : "994606316667600896",
        "id" : "1298141072208535556",
        "createdAt" : "2020-08-25T06:12:04.596Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ {
          "url" : "https://t.co/9GQBrAFLKb",
          "expanded" : "https://twitter.com/messages/media/1298141028206092292",
          "display" : "pic.twitter.com/9GQBrAFLKb"
        } ],
        "text" : "いいよ！\nよろしく！！ https://t.co/9GQBrAFLKb",
        "mediaUrls" : [ "https://ton.twitter.com/dm/1298141028206092292/1298140940037578753/oqT0m1FW.jpg" ],
        "senderId" : "994606316667600896",
        "id" : "1298141028206092292",
        "createdAt" : "2020-08-25T06:11:54.148Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "994606316667600896",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "全然ダメでも大丈夫、とりあえず乗り越えられるように一緒にいられるpiscine生が欲しい😭",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298091719850786820",
        "createdAt" : "2020-08-25T02:55:58.073Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "994606316667600896",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "よかったらライン交換しない？ファイルの送信とかkeepあるの楽だし…",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298091600023662596",
        "createdAt" : "2020-08-25T02:55:29.509Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1298091540875628544",
          "createdAt" : "2020-08-25T02:55:15.386Z"
        } ],
        "urls" : [ ],
        "text" : "協力し合うって言うのがかなり重要だと思うから直接会うメリットは大きいけどね",
        "mediaUrls" : [ ],
        "senderId" : "994606316667600896",
        "id" : "1298059820952510468",
        "createdAt" : "2020-08-25T00:49:12.780Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "僕は自宅から受けるよ\n流石にpcのスペックが影響するようなコードは書かないと思うし",
        "mediaUrls" : [ ],
        "senderId" : "994606316667600896",
        "id" : "1298059592606220293",
        "createdAt" : "2020-08-25T00:48:18.339Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "c++の方が複雑だし大丈夫だと思う\n研究で使ってる感じかな。ポインタのポインタとかは僕もちょっと苦手だな〜\nでも、正直piscineって最後までくらいついてればほとんど受かると思ってる。",
        "mediaUrls" : [ ],
        "senderId" : "994606316667600896",
        "id" : "1298059097506373636",
        "createdAt" : "2020-08-25T00:46:20.306Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "994606316667600896",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ちなみに、私の周りで校舎に行ってpiscine受ける人たくさんいるんだけど、ゆーたくんもそうなのかな？",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298050215300096004",
        "createdAt" : "2020-08-25T00:11:02.623Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "994606316667600896",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "こんにちは！ひなたです！\n\nありがとう！私もタメ口使うねw\nきっとゆーたくんのほうがcは得意だと思う、一応学校の授業で扱って2年半触ってるけど、未だにポインタがやばい…\n\n今は3年になっちゃってC++やってるのでもっと忘れてると思う…\n\nゆーたくんは、おしごととかでc使ってる感じ？",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298050067304128517",
        "createdAt" : "2020-08-25T00:10:27.350Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1298049662000144384",
          "createdAt" : "2020-08-25T00:08:50.682Z"
        } ],
        "urls" : [ ],
        "text" : "9月piscineよろしくお願いします！！",
        "mediaUrls" : [ ],
        "senderId" : "994606316667600896",
        "id" : "1297977103036452869",
        "createdAt" : "2020-08-24T19:20:31.294Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "c言語は結構やってるから多少力になれるかもしれない\n\nプログラミングはどのぐらいやってる？？",
        "mediaUrls" : [ ],
        "senderId" : "994606316667600896",
        "id" : "1297976263701753860",
        "createdAt" : "2020-08-24T19:17:11.181Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ツイートにあったように全然タメ口でいいよ。\n(こっちも勝手にタメ口使っちゃってごめんね)",
        "mediaUrls" : [ ],
        "senderId" : "994606316667600896",
        "id" : "1297976092204994564",
        "createdAt" : "2020-08-24T19:16:30.295Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "こんにちは\nYutaです。",
        "mediaUrls" : [ ],
        "senderId" : "994606316667600896",
        "id" : "1297975462526820356",
        "createdAt" : "2020-08-24T19:14:00.166Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "1228559135093821441-1275038994913390594",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "suru",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1302857448441524228",
        "createdAt" : "2020-09-07T06:33:16.314Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1302857437364457472",
          "createdAt" : "2020-09-07T06:33:13.654Z"
        } ],
        "urls" : [ ],
        "text" : "する？",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1302711549912465412",
        "createdAt" : "2020-09-06T20:53:31.392Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "LINEまだ追加してない",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1302711538000642053",
        "createdAt" : "2020-09-06T20:53:28.550Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "でも今は入学後のこと一切考えんようにしてる",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1302711424460881925",
        "createdAt" : "2020-09-06T20:53:01.488Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "結構きつそうやんな",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1302711297419538436",
        "createdAt" : "2020-09-06T20:52:31.193Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "あれ？まっちゃんライン追加してたっけ？",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1302612997899038725",
        "createdAt" : "2020-09-06T14:21:54.763Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "やばいぞまじで、入学できると1日最低コミット5時間らしいし…",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1302601102550994950",
        "createdAt" : "2020-09-06T13:34:38.699Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1302601027724558338",
          "createdAt" : "2020-09-06T13:34:20.838Z"
        } ],
        "urls" : [ ],
        "text" : "分からん笑笑",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1302577706450604036",
        "createdAt" : "2020-09-06T12:01:40.630Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ {
          "senderId" : "1275038994913390594",
          "reactionKey" : "like",
          "eventId" : "1302577669649833984",
          "createdAt" : "2020-09-06T12:01:31.836Z"
        } ],
        "urls" : [ ],
        "text" : "そしたら大学どーすんだよw",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1302566580073631748",
        "createdAt" : "2020-09-06T11:17:27.891Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "東京に引っ越すしか無いな笑",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1302533596645748740",
        "createdAt" : "2020-09-06T09:06:24.027Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "入学できたらどーすんの？",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1302510487653867525",
        "createdAt" : "2020-09-06T07:34:34.415Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "そうだね…関西か…",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1302510455563272197",
        "createdAt" : "2020-09-06T07:34:26.767Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1302510399015641089",
          "createdAt" : "2020-09-06T07:34:13.266Z"
        } ],
        "urls" : [ ],
        "text" : "金曜だけ通うのも考えたけど東京と行き帰りするのは周りにリスクあるなーと思って",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1302346077178228740",
        "createdAt" : "2020-09-05T20:41:15.900Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "僕は関西に住んでるから校舎近くの安いホテル予約してる！",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1302345926049062917",
        "createdAt" : "2020-09-05T20:40:39.870Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "まっちゃんは？",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1302293243707551753",
        "createdAt" : "2020-09-05T17:11:19.424Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1302293184928571392",
          "createdAt" : "2020-09-05T17:11:05.389Z"
        } ],
        "urls" : [ ],
        "text" : "そうなんや",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1302176735421587460",
        "createdAt" : "2020-09-05T09:28:21.683Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "結構距離ある",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1301919677149376516",
        "createdAt" : "2020-09-04T16:26:54.212Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "no!",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1301919661047521285",
        "createdAt" : "2020-09-04T16:26:50.379Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1301919574309265413",
          "createdAt" : "2020-09-04T16:26:29.677Z"
        } ],
        "urls" : [ ],
        "text" : "校舎から家近いの？",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1301843186575319045",
        "createdAt" : "2020-09-04T11:22:57.447Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "楽しみ",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1301842602711330820",
        "createdAt" : "2020-09-04T11:20:38.234Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "そうやな〜",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1301842589302153220",
        "createdAt" : "2020-09-04T11:20:35.040Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "月曜には始まるで〜",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1301840539092840453",
        "createdAt" : "2020-09-04T11:12:26.236Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ {
          "senderId" : "1275038994913390594",
          "reactionKey" : "like",
          "eventId" : "1298733557586698240",
          "createdAt" : "2020-08-26T21:26:24.103Z"
        } ],
        "urls" : [ ],
        "text" : "マジ途中で死なないためもあるし、普通に友達も欲しいw",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298634636625494022",
        "createdAt" : "2020-08-26T14:53:19.518Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ほんそれ",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298634558825349124",
        "createdAt" : "2020-08-26T14:53:00.971Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1298634536897507328",
          "createdAt" : "2020-08-26T14:52:55.727Z"
        } ],
        "urls" : [ ],
        "text" : "ひなたみたいに気軽に話せる人がいて嬉しいわ",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1298462548950360068",
        "createdAt" : "2020-08-26T03:29:30.618Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "でも友達みたいな感じになっといたほうがいろいろ聞きやすいよね",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1298462481010966532",
        "createdAt" : "2020-08-26T03:29:14.425Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "僕も同じ感じ",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1298462252102586373",
        "createdAt" : "2020-08-26T03:28:19.846Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "まっちゃんは？",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298456165706158087",
        "createdAt" : "2020-08-26T03:04:08.736Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ちと寂しさあるわ",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298456129073057796",
        "createdAt" : "2020-08-26T03:04:00.002Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "一応、前の時のツイート見て何人か声かけてくれたよ、こんな風な感じよりはなんかあったら声かけてーみたいな感じだけど…",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298456104062468101",
        "createdAt" : "2020-08-26T03:03:54.038Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "他のpiscine受験生とも結構繋がってる？",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1298451330470514692",
        "createdAt" : "2020-08-26T02:44:55.924Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "なるほど",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1298451217459290116",
        "createdAt" : "2020-08-26T02:44:28.981Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "私も誰かに習いたい(((",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298435689764151300",
        "createdAt" : "2020-08-26T01:42:46.896Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "そこらへんは私もわからんw\ngitとかは、正直フリーソフト入れてなんとかしてるんだよなぁ",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298435647959527429",
        "createdAt" : "2020-08-26T01:42:36.923Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "Unixとがgitとかが全然わからん",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1298200022832435205",
        "createdAt" : "2020-08-25T10:06:19.514Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "一応xcode使って参考書ゆっくり進めてる感じやけど",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1298199873108377604",
        "createdAt" : "2020-08-25T10:05:43.816Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "pcあるよ",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1298199469708566533",
        "createdAt" : "2020-08-25T10:04:07.644Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "C言語使うみたいだし、開発環境だけでも用意しといた方がよさそう",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298191609557692420",
        "createdAt" : "2020-08-25T09:32:53.634Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ちな、pcいえにある？",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298191316581400580",
        "createdAt" : "2020-08-25T09:31:43.783Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "okok",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298191295404322821",
        "createdAt" : "2020-08-25T09:31:38.730Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ま？",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298191286134927365",
        "createdAt" : "2020-08-25T09:31:36.523Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1298191636732628992",
          "createdAt" : "2020-08-25T09:33:00.097Z"
        } ],
        "urls" : [ ],
        "text" : "もし時間あったら基本的なことだけでも教えてほしいで",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1298147093672890372",
        "createdAt" : "2020-08-25T06:36:00.220Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "僕文系やから全くやってない😭",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1298146954673758214",
        "createdAt" : "2020-08-25T06:35:27.079Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "まっちゃんは？",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298142921254793220",
        "createdAt" : "2020-08-25T06:19:25.437Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "してるよ",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298142788412796932",
        "createdAt" : "2020-08-25T06:18:53.767Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "学校でプログラミングとか勉強するの？",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1298142243828592645",
        "createdAt" : "2020-08-25T06:16:43.929Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ {
          "senderId" : "1275038994913390594",
          "reactionKey" : "like",
          "eventId" : "1298142240825458688",
          "createdAt" : "2020-08-25T06:16:43.202Z"
        } ],
        "urls" : [ ],
        "text" : "ぜんぜんおっけーw",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298134382700445700",
        "createdAt" : "2020-08-25T05:45:29.689Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "じゃあひなたって呼ぶね〜",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1298113623546445828",
        "createdAt" : "2020-08-25T04:23:00.321Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "おーまじか男の子やと思ってたごめん！",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1298113454608281604",
        "createdAt" : "2020-08-25T04:22:20.043Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ひなたで大丈夫よ！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298049495259742213",
        "createdAt" : "2020-08-25T00:08:10.944Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "実は女子w",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298049267215372293",
        "createdAt" : "2020-08-25T00:07:16.583Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "Hinata君で良い？",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1298031562680725511",
        "createdAt" : "2020-08-24T22:56:55.485Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "オッケーっす",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1298031445642944516",
        "createdAt" : "2020-08-24T22:56:27.584Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "まっちゃんでもおけい？w",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1297906028873310222",
        "createdAt" : "2020-08-24T14:38:05.902Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "マツでよろしく！",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1297898540564221957",
        "createdAt" : "2020-08-24T14:08:20.542Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ありがとう！なんて呼んだらいいかな？",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1297879237798420484",
        "createdAt" : "2020-08-24T12:51:38.404Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "はい",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1297837088943923204",
        "createdAt" : "2020-08-24T10:04:09.333Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "早速ですが、敬語…やめても大丈夫ですか？",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1297825200755499014",
        "createdAt" : "2020-08-24T09:16:54.966Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1275038994913390594",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "こちらこそ！よろしくお願いします！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1297825164768362507",
        "createdAt" : "2020-08-24T09:16:46.389Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "年下ですが、よろしくお願いします。",
        "mediaUrls" : [ ],
        "senderId" : "1275038994913390594",
        "id" : "1297739767656849413",
        "createdAt" : "2020-08-24T03:37:26.130Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "1228559135093821441-1280326248523169793",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "1280326248523169793",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ありがとうございます！行けると思うのでぜひ！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1297886689205993480",
        "createdAt" : "2020-08-24T13:21:14.957Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "日曜昼間にzoomにて、数人集まりそうな感じなのでご都合良ければぜひ◎",
        "mediaUrls" : [ ],
        "senderId" : "1280326248523169793",
        "id" : "1297826756171141124",
        "createdAt" : "2020-08-24T09:23:05.808Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1280326248523169793",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ぜひぜひやりたいです！\n人が集まらなかったとしても、かほさんと繋がれただけでも本当にありがたい…🙇‍♀️",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1297825563499847684",
        "createdAt" : "2020-08-24T09:18:21.467Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1297825254027300864",
          "createdAt" : "2020-08-24T09:17:07.653Z"
        } ],
        "urls" : [ ],
        "text" : "一応slack経由で何度か勉強会を行なってきたので参加されていた方とはやり取りしたことありますよ！\n何度かやってますがあれだったらオンラインで懇談会でもしましょうか⁇人が集まるか分かりませんが…笑",
        "mediaUrls" : [ ],
        "senderId" : "1280326248523169793",
        "id" : "1297762430882209797",
        "createdAt" : "2020-08-24T05:07:29.468Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1280326248523169793",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "かほりんさんは、9月piscine生さんたちとつながられてるのでしょうか…？\n自分はあまりTwitterを触っていなかったので全くです…",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1297737428396986372",
        "createdAt" : "2020-08-24T03:28:08.406Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1280326248523169793",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ご対応ありがとうございます！！！後ほど参加しますね！\nもしまた勉強会等ありましたら、よろしくお願いします🤲",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1297737218077777924",
        "createdAt" : "2020-08-24T03:27:18.266Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1297736994848509952",
          "createdAt" : "2020-08-24T03:26:25.023Z"
        } ],
        "urls" : [ ],
        "text" : "こちらから登録をお願いいたします。ただ、定期開催の勉強会はやめてしまったので、コミュニティとしてお使いください◎",
        "mediaUrls" : [ ],
        "senderId" : "1280326248523169793",
        "id" : "1297670392102842372",
        "createdAt" : "2020-08-23T23:01:45.708Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "はじめまして！遅くなってすみません",
        "mediaUrls" : [ ],
        "senderId" : "1280326248523169793",
        "id" : "1297670290697105412",
        "createdAt" : "2020-08-23T23:01:21.533Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ {
          "url" : "https://t.co/7gdh71Ro4U",
          "expanded" : "https://join.slack.com/t/42tokyoseptember/shared_invite/zt-gmzvihgl-Drya2ge00a8Rzldf8n0UpQ",
          "display" : "join.slack.com/t/42tokyosepte…"
        } ],
        "text" : "Slack を使ってみましょう。連携するチームのためのシンプルで集中型のメッセージングアプリです。ここから新規登録 : https://t.co/7gdh71Ro4U",
        "mediaUrls" : [ ],
        "senderId" : "1280326248523169793",
        "id" : "1297670231309996036",
        "createdAt" : "2020-08-23T23:01:07.391Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "1228559135093821441-1281824169278058498",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "おー！それはうれしいです！\n実は大学で専攻しているわけではなく（受験時代はまだ関心なかった…😂）おもしろそうだなーとおもって書いたので、もしおすすめの本とかあれば教えてもらえるとうれしいですー✨",
        "mediaUrls" : [ ],
        "senderId" : "1281824169278058498",
        "id" : "1309776035752210436",
        "createdAt" : "2020-09-26T08:45:16.071Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1281824169278058498",
        "reactions" : [ {
          "senderId" : "1281824169278058498",
          "reactionKey" : "like",
          "eventId" : "1309775564434108417",
          "createdAt" : "2020-09-26T08:43:23.681Z"
        } ],
        "urls" : [ ],
        "text" : "こちらこそ！フォローありがとうございます！\n\n哲学方面は興味そそられるものがあります！自分はわりと言語学と哲学の分野に興味があるのでお話が合えばなと思います_(┐「ε:)_",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1309062018654240773",
        "createdAt" : "2020-09-24T09:28:01.128Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1309061784934940672",
          "createdAt" : "2020-09-24T09:27:05.390Z"
        } ],
        "urls" : [ ],
        "text" : "はじめまして！\n遅くなりましたがフォロバありがとうございます✨\n\n固定ツイとかに関心持ってもらえたんでしょうか、、？\nもしそうならうれしいです〜(´∀`)",
        "mediaUrls" : [ ],
        "senderId" : "1281824169278058498",
        "id" : "1309004647391203332",
        "createdAt" : "2020-09-24T05:40:02.774Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "1228559135093821441-1284139705273995265",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "1284139705273995265",
        "reactions" : [ {
          "senderId" : "1284139705273995265",
          "reactionKey" : "like",
          "eventId" : "1312054408386019328",
          "createdAt" : "2020-10-02T15:38:42.418Z"
        } ],
        "urls" : [ ],
        "text" : "ま？明日からやるわwww",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1312053927311896581",
        "createdAt" : "2020-10-02T15:36:47.747Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "しかも確かクロスプレイ対応だったはず",
        "mediaUrls" : [ ],
        "senderId" : "1284139705273995265",
        "id" : "1312052747705831429",
        "createdAt" : "2020-10-02T15:32:06.498Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "うん",
        "mediaUrls" : [ ],
        "senderId" : "1284139705273995265",
        "id" : "1312052712293376005",
        "createdAt" : "2020-10-02T15:31:58.058Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1284139705273995265",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ニンテンドースイッチやぞ？",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1312052605468565510",
        "createdAt" : "2020-10-02T15:31:32.584Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1284139705273995265",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "まじかよ",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1312052586141286406",
        "createdAt" : "2020-10-02T15:31:27.977Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "あるらしい",
        "mediaUrls" : [ ],
        "senderId" : "1284139705273995265",
        "id" : "1312052276094070788",
        "createdAt" : "2020-10-02T15:30:14.056Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1284139705273995265",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "スイッチはないよなぁw",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1312051368283172870",
        "createdAt" : "2020-10-02T15:26:37.618Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "けどpcにしたー",
        "mediaUrls" : [ ],
        "senderId" : "1284139705273995265",
        "id" : "1312051134593286150",
        "createdAt" : "2020-10-02T15:25:41.897Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ps4でもあるらしい",
        "mediaUrls" : [ ],
        "senderId" : "1284139705273995265",
        "id" : "1312051117522448390",
        "createdAt" : "2020-10-02T15:25:37.831Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1284139705273995265",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "これpcげー？",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1312051028372541445",
        "createdAt" : "2020-10-02T15:25:16.588Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1284139705273995265",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "あざあざ丸だけど実はまだ入れてない節！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1312050987901747204",
        "createdAt" : "2020-10-02T15:25:06.930Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ {
          "url" : "https://t.co/y106m1tun7",
          "expanded" : "https://twitter.com/messages/media/1312050778102587401",
          "display" : "pic.twitter.com/y106m1tun7"
        } ],
        "text" : "もし嫌じゃなければよろ！w https://t.co/y106m1tun7",
        "mediaUrls" : [ "https://ton.twitter.com/dm/1312050778102587401/1312050666051760128/onOlChbR.jpg" ],
        "senderId" : "1284139705273995265",
        "id" : "1312050778102587401",
        "createdAt" : "2020-10-02T15:24:17.099Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "1228559135093821441-1289525542446698497",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1314426808956194817",
          "createdAt" : "2020-10-09T04:45:46.789Z"
        } ],
        "urls" : [ ],
        "text" : "私もこんな勝手してるから、スルーしてくださいね🙏",
        "mediaUrls" : [ ],
        "senderId" : "1289525542446698497",
        "id" : "1314353831543676933",
        "createdAt" : "2020-10-08T23:55:47.636Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ひなたさん、すごいよ\n何か動くと、その返しが大変だけど、できる範囲で対応して、経験値にしていければと思うのだけど\nひなたさんはひなたさんのやり方でいいと思う\n\nTwitter海に飛び込めずDMにて応援…💦\nしかも当たり前のこと言ってるだけだけど\nこっそり応援してます",
        "mediaUrls" : [ ],
        "senderId" : "1289525542446698497",
        "id" : "1314352956850855940",
        "createdAt" : "2020-10-08T23:52:19.097Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1289525542446698497",
        "reactions" : [ {
          "senderId" : "1289525542446698497",
          "reactionKey" : "like",
          "eventId" : "1313072224346107904",
          "createdAt" : "2020-10-05T11:03:08.652Z"
        } ],
        "urls" : [ ],
        "text" : "そのように思っていただけて良かったです！ぜひ遠慮なくかみつきつつ絡んできていただければと思いますw",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1313062972244127748",
        "createdAt" : "2020-10-05T10:26:22.795Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "あれもこれも迷子してますが、変わらずよろしくお願いしますです…\n\nお騒がせしました、ありがとうございましたー",
        "mediaUrls" : [ ],
        "senderId" : "1289525542446698497",
        "id" : "1313057829679370244",
        "createdAt" : "2020-10-05T10:05:56.714Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1313057547465551873",
          "createdAt" : "2020-10-05T10:04:49.414Z"
        } ],
        "urls" : [ ],
        "text" : "返信遅くなってすみませんー\nひなたさん、みなさんのやりとり楽しませてもらってて、私は不慣れだからドキドキしてる、そんな感じ？\n\n今夜また覗きに行って呟いたりしちゃうかもだししないかもだし\n\nその後はちょっと現実に専念するつもり…",
        "mediaUrls" : [ ],
        "senderId" : "1289525542446698497",
        "id" : "1313057336328515588",
        "createdAt" : "2020-10-05T10:03:59.102Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1289525542446698497",
        "reactions" : [ {
          "senderId" : "1289525542446698497",
          "reactionKey" : "like",
          "eventId" : "1313072208051204099",
          "createdAt" : "2020-10-05T11:03:04.767Z"
        } ],
        "urls" : [ ],
        "text" : "ハルさんが絡んでくれるのとても嬉しいので自分は是非お話ししたいです_(:3」z)_",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1312920665771532292",
        "createdAt" : "2020-10-05T01:00:54.285Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1289525542446698497",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "どしたんですかwww",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1312918803441831941",
        "createdAt" : "2020-10-05T00:53:30.274Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1312918766632660992",
          "createdAt" : "2020-10-05T00:53:21.483Z"
        } ],
        "urls" : [ ],
        "text" : "次々と楽しみ止まらず\n不慣れな私はDiscordにてやらかしたことにまた改めて気づき・・けど仕方ないや、これから気をつけよう\n・・って、ひなたさんに話すことでないですが、↑の続きから・・ごめんなさいね　ではまた",
        "mediaUrls" : [ ],
        "senderId" : "1289525542446698497",
        "id" : "1312800169402855428",
        "createdAt" : "2020-10-04T17:02:05.714Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "反応せずにいられなくなり・・　楽しませてもらってます\nピシンお世話になりました！これからもよろしくお願いします。\nbyハルと言う者でした",
        "mediaUrls" : [ ],
        "senderId" : "1289525542446698497",
        "id" : "1312793688729219077",
        "createdAt" : "2020-10-04T16:36:20.601Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "1228559135093821441-1300964966317436928",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "1300964966317436928",
        "reactions" : [ {
          "senderId" : "1300964966317436928",
          "reactionKey" : "like",
          "eventId" : "1300975570742697989",
          "createdAt" : "2020-09-02T01:55:21.686Z"
        } ],
        "urls" : [ ],
        "text" : "こちらこそ！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1300975384721158152",
        "createdAt" : "2020-09-02T01:54:37.356Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1300975369374162944",
          "createdAt" : "2020-09-02T01:54:33.679Z"
        } ],
        "urls" : [ ],
        "text" : "リフォローありがとうございます！\nよろしくお願いします🙇‍♂️",
        "mediaUrls" : [ ],
        "senderId" : "1300964966317436928",
        "id" : "1300975310402322436",
        "createdAt" : "2020-09-02T01:54:19.634Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "1033030946478419973-1228559135093821441",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "1033030946478419973",
        "reactions" : [ {
          "senderId" : "1033030946478419973",
          "reactionKey" : "agree",
          "eventId" : "1302631739047571457",
          "createdAt" : "2020-09-06T15:36:22.984Z"
        } ],
        "urls" : [ ],
        "text" : "ありがとうございます！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1302628919707799556",
        "createdAt" : "2020-09-06T15:25:10.829Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1302628882084843520",
          "createdAt" : "2020-09-06T15:25:01.832Z"
        } ],
        "urls" : [ ],
        "text" : "学生の参加者で知り合いの方いたら誘ってみてください！\nもちろん高校生とか専門学生も全然大丈夫です！",
        "mediaUrls" : [ ],
        "senderId" : "1033030946478419973",
        "id" : "1302621948111798277",
        "createdAt" : "2020-09-06T14:57:28.656Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1302628867861934080",
          "createdAt" : "2020-09-06T15:24:58.440Z"
        } ],
        "urls" : [ {
          "url" : "https://t.co/6tNsaKjHB0",
          "expanded" : "https://discord.gg/eDvySs",
          "display" : "discord.gg/eDvySs"
        } ],
        "text" : "https://t.co/6tNsaKjHB0",
        "mediaUrls" : [ ],
        "senderId" : "1033030946478419973",
        "id" : "1302621513355390980",
        "createdAt" : "2020-09-06T14:55:45.012Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "とんでもないです！\n全然ペーペーなんで、、笑\n協力して頑張りましょう！\nリンク送ります。",
        "mediaUrls" : [ ],
        "senderId" : "1033030946478419973",
        "id" : "1302621494225154057",
        "createdAt" : "2020-09-06T14:55:40.451Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1033030946478419973",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "こんばんは！ぜひ参加させてください！！！まさかお誘いいただけるなんて光栄です！！！！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1302619346640879620",
        "createdAt" : "2020-09-06T14:47:08.423Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1302619239988129793",
          "createdAt" : "2020-09-06T14:46:42.977Z"
        } ],
        "urls" : [ ],
        "text" : "こんばんは。\nDM失礼します！\nPiscineが不安で今9月Piscineに参加する大学生集めてdiscordのサーバーを１つ作ろうと思ってるんですが、もし良かったら参加しませんか？？\n年齢とか境遇が近いと聞きやすかったりするかと思って！\nもちろん興味なかったら全然断ってください！！",
        "mediaUrls" : [ ],
        "senderId" : "1033030946478419973",
        "id" : "1302616801214300165",
        "createdAt" : "2020-09-06T14:37:01.555Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "1136877060624748544-1228559135093821441",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "こんばんは！\nすいません、あれ以来連絡もせず汗\n\nそれでとりあえず、\n取り込みたいのはファイルでしょうか？\n\nローカルでファイルを作成→コミットしてリモートにあげるというのではなくて？",
        "mediaUrls" : [ ],
        "senderId" : "1136877060624748544",
        "id" : "1246435126898130948",
        "createdAt" : "2020-04-04T13:51:06.607Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ってしたらもう入るのでしょうか",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1246077658078695428",
        "createdAt" : "2020-04-03T14:10:39.377Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ {
          "url" : "https://t.co/dRKXjEYOED",
          "expanded" : "https://github.com/u-lab/covid19.git",
          "display" : "github.com/u-lab/covid19.…"
        } ],
        "text" : "git remote add origin https://t.co/dRKXjEYOED",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1246077627296706570",
        "createdAt" : "2020-04-03T14:10:33.016Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "gitでネット上のファイルをこちらに入れるのはどうするのでしたっけ…",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1246077558078066695",
        "createdAt" : "2020-04-03T14:10:15.535Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "夜分遅くに失礼します。",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1246077478059118597",
        "createdAt" : "2020-04-03T14:09:56.462Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "そうですそうです",
        "mediaUrls" : [ ],
        "senderId" : "1136877060624748544",
        "id" : "1238692407266295813",
        "createdAt" : "2020-03-14T05:04:18.372Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "券売機の前ですかね？",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1238692358570381316",
        "createdAt" : "2020-03-14T05:04:06.764Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "お待ちしてます。",
        "mediaUrls" : [ ],
        "senderId" : "1136877060624748544",
        "id" : "1238692308779823108",
        "createdAt" : "2020-03-14T05:03:54.887Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "なるほど笑",
        "mediaUrls" : [ ],
        "senderId" : "1136877060624748544",
        "id" : "1238692277960060932",
        "createdAt" : "2020-03-14T05:03:47.540Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "改札まで行きますね！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1238692267109388292",
        "createdAt" : "2020-03-14T05:03:44.954Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "車で送ってきてもらっちゃったので😭",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1238692247152910343",
        "createdAt" : "2020-03-14T05:03:40.193Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "いえ、ロータリーのそばでしたすみません",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1238692203792224261",
        "createdAt" : "2020-03-14T05:03:29.864Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "改札近くにいらっしゃいますか？",
        "mediaUrls" : [ ],
        "senderId" : "1136877060624748544",
        "id" : "1238692144707014661",
        "createdAt" : "2020-03-14T05:03:15.773Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "スイーツ屋の前ですね",
        "mediaUrls" : [ ],
        "senderId" : "1136877060624748544",
        "id" : "1238692012930371589",
        "createdAt" : "2020-03-14T05:02:44.354Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "いらっしゃいますか？",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1238691942516420613",
        "createdAt" : "2020-03-14T05:02:27.568Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "どちらに",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1238691897951936516",
        "createdAt" : "2020-03-14T05:02:16.939Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "それです",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1238691710017753095",
        "createdAt" : "2020-03-14T05:01:32.134Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "に",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1238691699439763460",
        "createdAt" : "2020-03-14T05:01:29.620Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "まさち",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1238691680271790084",
        "createdAt" : "2020-03-14T05:01:25.043Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "真っ黒？笑\n赤いマフラーですね",
        "mediaUrls" : [ ],
        "senderId" : "1136877060624748544",
        "id" : "1238691551368196102",
        "createdAt" : "2020-03-14T05:00:54.308Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "私は赤のマフラーしてます！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1238691402071994372",
        "createdAt" : "2020-03-14T05:00:18.718Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "今どんな格好してますか！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1238691367242461188",
        "createdAt" : "2020-03-14T05:00:10.411Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "お気遣いありがとうございます。\nでも大丈夫です。\nお待ちしてますね。",
        "mediaUrls" : [ ],
        "senderId" : "1136877060624748544",
        "id" : "1238691107883470853",
        "createdAt" : "2020-03-14T04:59:08.580Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "雪降ってるので是非屋内に",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1238690522501283844",
        "createdAt" : "2020-03-14T04:56:49.022Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "すみません🙇‍♀️",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1238690488812634117",
        "createdAt" : "2020-03-14T04:56:40.977Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "お待たせしてすみません！駅のそばなんですが、ロータリーが反対側なのであと2,3分かかりそうです",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1238690476061945861",
        "createdAt" : "2020-03-14T04:56:37.950Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "agree",
          "eventId" : "1238690764751663106",
          "createdAt" : "2020-03-14T04:57:46.745Z"
        } ],
        "urls" : [ ],
        "text" : "着きました！もしお着きでしたら連絡ください。",
        "mediaUrls" : [ ],
        "senderId" : "1136877060624748544",
        "id" : "1238689996644552708",
        "createdAt" : "2020-03-14T04:54:43.635Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "おはようございます！こちらこそよろしくお願いします！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1238645630160920582",
        "createdAt" : "2020-03-14T01:58:25.843Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "おはようございます！\n今日は、生憎の雨ですがよろしくお願いします。",
        "mediaUrls" : [ ],
        "senderId" : "1136877060624748544",
        "id" : "1238614589836677124",
        "createdAt" : "2020-03-13T23:55:05.253Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ {
          "senderId" : "1136877060624748544",
          "reactionKey" : "agree",
          "eventId" : "1238087192280330240",
          "createdAt" : "2020-03-12T12:59:23.851Z"
        } ],
        "urls" : [ ],
        "text" : "是非土曜日よろしくお願いします！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1238085428919406597",
        "createdAt" : "2020-03-12T12:52:23.460Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "それはとても便利！！！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1238085389954342916",
        "createdAt" : "2020-03-12T12:52:14.168Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "こちらこそ、確認ありがとうございます！\nちゃんとインストールされてるようです。これで当日スムーズに入れると思います。\n\nちなみに、ディレクトリを移動されてるようですが、gitの場合はダウンロードした段階でパスが通ると思うので、どのディレクトリにいても「git -version」と打てると思います。Macだけかもしれないですが汗\n\nとかく、その辺りもまた当日確認していければいいのかなと思ってます。",
        "mediaUrls" : [ ],
        "senderId" : "1136877060624748544",
        "id" : "1238062379423813637",
        "createdAt" : "2020-03-12T11:20:48.050Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ {
          "url" : "https://t.co/SdbnTh9sm8",
          "expanded" : "https://twitter.com/messages/media/1237966133723987972",
          "display" : "pic.twitter.com/SdbnTh9sm8"
        } ],
        "text" : "ありがとうございます！今確認したらこのような感じでした、お納めください https://t.co/SdbnTh9sm8",
        "mediaUrls" : [ "https://ton.twitter.com/dm/1237966133723987972/1237965717791633408/acjpUVHJ.png" ],
        "senderId" : "1228559135093821441",
        "id" : "1237966133723987972",
        "createdAt" : "2020-03-12T04:58:21.450Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "いえいえ、教える側の方が勉強になること多いと言いますし。\n確認はまぁ急ぎではないのでごゆっくり。\n\nそれでは今週土曜、14時に南大沢の改札で！お互いパソコンと充電忘れないようにしましょう笑",
        "mediaUrls" : [ ],
        "senderId" : "1136877060624748544",
        "id" : "1237723544810696713",
        "createdAt" : "2020-03-11T12:54:23.575Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "では南大沢で土曜日の14時に！突然のDMにもご対応いただきありがとうございます！急いで帰ってgit確認します🙇‍♀️",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1237719416814465028",
        "createdAt" : "2020-03-11T12:37:59.374Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "よろしくお願いします。\n\nそれでは南大沢でも良いですかね？都心部はやはりコロナのリスクがあるので。南大沢なら駅からすぐの大学が自分の母校なので、勝手がわかっている分、適当なスペース見つけて作業できると思います。\n\nGit、確認のほどよろしくお願いします。",
        "mediaUrls" : [ ],
        "senderId" : "1136877060624748544",
        "id" : "1237688593771933700",
        "createdAt" : "2020-03-11T10:35:30.595Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "こんにちは。\n\nでは今週末の土曜日、14時からよろしくお願いします。\n\n私の最寄駅が京王線の百草園駅というところで、八王子方面なので南大沢へは調布で乗り換えます。乗り換え時間含むと新宿に行くのと同じくらいの時間ですね\n私は時間が有り余ってるのでどこへでもいけます！\n\n使っているpcはOSがWindowsのhpです。家にパソコンを置いてきてしまったので帰ったら確認します！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1237616346818437125",
        "createdAt" : "2020-03-11T05:48:25.576Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "おはようございます。\n\nそれでは14時に待ち合わせて、どこか場所を見つけてやりましょう。\n\n場所についてなのですが、もしかして南大沢って近いですか？\n\ngitダウンロード済みですか、良いですね！お使いのpcはMacですか？それと、一応、ターミナル上で「git -version」と叩いてバージョンが表示されますか？",
        "mediaUrls" : [ ],
        "senderId" : "1136877060624748544",
        "id" : "1237538071802810372",
        "createdAt" : "2020-03-11T00:37:23.368Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "返信遅くなってしまい申し訳ありません。夜分遅くに失礼します。\n\nそうですね、新宿などに出ることもできます！私も土曜日であれば何時でも構いません\n\n一応gitはpcに入っています。\nただ、使い方がよくわからないのでお教えいただけると幸いです！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1237407383761997828",
        "createdAt" : "2020-03-10T15:58:04.890Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "京王線ですね、\n中間地点となるとどのあたりでしょうかね？明大前とかですか？\n\n自分は土曜日だとありがたいですね。時間は何時でも構いませんが。\n\nあと、事前に伝えておくと、前回やった時は早足でやっても2時間半くらいかかりました。",
        "mediaUrls" : [ ],
        "senderId" : "1136877060624748544",
        "id" : "1237317177646002181",
        "createdAt" : "2020-03-10T09:59:38.079Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "私は東京都の日野市に住んでいます！最寄りが京王線沿線なので区内に出るのは問題なくできます！\n\n私も平日はバイトがあるので是非土日にしましょう。私も今週末はどちらも大丈夫です！SAIさんにとってどちらの日が一番都合が良いですか？",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1237257181214306309",
        "createdAt" : "2020-03-10T06:01:13.823Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "なるほど、ご実家東京なのですね。なら、話が早そうです！\n\nちなみにどのあたりお住まいですか？自分は大田区なのですが。\n\nそれと、平日は仕事あるので、土日でもよろしいでしょうか？早ければ、今週でも自分は大丈夫です。",
        "mediaUrls" : [ ],
        "senderId" : "1136877060624748544",
        "id" : "1237191870402277381",
        "createdAt" : "2020-03-10T01:41:42.505Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "返信ありがとうございます！\n\n大学は栃木なのですが、実家が東京にあり三月末までは確実に東京に居ます。もし今月中でご都合よろしければ是非一度お会いさせていただければ幸いです😭",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1237173964939513861",
        "createdAt" : "2020-03-10T00:30:33.515Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "初めまして、もちろん喜んで。ただ、うまく教えられるかは分かりませんが笑\nちなみに、昨日教えた方は東京に居を構えていたので実際にお会いして教えることできたんですよね。\n\n拝見するに、地方にお住まいの方ですか？",
        "mediaUrls" : [ ],
        "senderId" : "1136877060624748544",
        "id" : "1236994917957656580",
        "createdAt" : "2020-03-09T12:39:05.386Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1136877060624748544",
        "reactions" : [ ],
        "urls" : [ {
          "url" : "https://t.co/0m2z2VpH2C",
          "expanded" : "https://twitter.com/42_piscine_3/status/1236574976427184128",
          "display" : "twitter.com/42_piscine_3/s…"
        } ],
        "text" : "突然すみません、3月ピシン参加予定だった者です。TLで見かけて思わず声をかけてしまいました\nわたしにもお教えいただけませんか…🙇‍♀️ https://t.co/0m2z2VpH2C",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1236980170117931012",
        "createdAt" : "2020-03-09T11:40:29.239Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "1157252356947369985-1228559135093821441",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "1157252356947369985",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "お返事遅くなってごめんなさい！\n私はもともと出身が東京で、地方大学に出学び学生なのです\n旅はとても楽しいですが、自作pcとか持ち運べないとか考えると旅はたまにでもって思っちゃいますw\n\nどこでもプログラムはかけるかもしれないけれど、機械いじりは家でしかできないので…w",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1274194514379304965",
        "createdAt" : "2020-06-20T04:17:00.306Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "プログラミング界隈、「旅したい」と「田舎こもりたい」の二極だなって思いながら色んな人に聞いてますが、ひなたさんはどんな働き方したい派ですか？笑",
        "mediaUrls" : [ ],
        "senderId" : "1157252356947369985",
        "id" : "1272084568003076103",
        "createdAt" : "2020-06-14T08:32:49.889Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ありがとうございます！\n面白いことやってます😌\n\nひなたさんお願いしまーす！！",
        "mediaUrls" : [ ],
        "senderId" : "1157252356947369985",
        "id" : "1272084471039180804",
        "createdAt" : "2020-06-14T08:32:26.768Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1157252356947369985",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "すごい！とっても面白そうな企画…🤔\n地方大の工学部情報工学科3年のひなたです💪\nよろしくおねがいします🙇‍♀️",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1272071139490033669",
        "createdAt" : "2020-06-14T07:39:28.279Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "フリーランスまみれのシェアハウスづくりを企んでおるサカモトと申しますです😇よろしくお願い致します😌",
        "mediaUrls" : [ ],
        "senderId" : "1157252356947369985",
        "id" : "1271706113897947140",
        "createdAt" : "2020-06-13T07:28:59.398Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1157252356947369985",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "こちらこそです！🍅┌(┌＾o＾)┐トマトォ…",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1271655397678395396",
        "createdAt" : "2020-06-13T04:07:27.708Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "フォロありです！🍅=͟͟͞͞🍅=͟͟͞͞=( '-' 🍅 )ﾄﾏﾄﾊﾟﾝﾁ",
        "mediaUrls" : [ ],
        "senderId" : "1157252356947369985",
        "id" : "1270306113347416069",
        "createdAt" : "2020-06-09T10:45:53.250Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "1175310221238890497-1228559135093821441",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "はいー！楽しみにしてます！",
        "mediaUrls" : [ ],
        "senderId" : "1175310221238890497",
        "id" : "1268955398179966980",
        "createdAt" : "2020-06-05T17:18:37.663Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1175310221238890497",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ありがとうございます！6/22の発表次第ですね…\nもし会えたらその時はぜひよろしくお願いします！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1268954681163694084",
        "createdAt" : "2020-06-05T17:15:46.715Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "関係なく辞退されるのであれば、問い合わせれば返金されそうな気はします、、！",
        "mediaUrls" : [ ],
        "senderId" : "1175310221238890497",
        "id" : "1268950604262461444",
        "createdAt" : "2020-06-05T16:59:34.702Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "もし予定通り6/22に3月ピシンについての情報が発表されれば、そこでIDについての説明まあるかもですね！",
        "mediaUrls" : [ ],
        "senderId" : "1175310221238890497",
        "id" : "1268950468232835076",
        "createdAt" : "2020-06-05T16:59:02.274Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1175310221238890497",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "なんと！！！ありがとうございます！！！！！\nそしたら…IDどうするんでしょう、なんだかたかそうに感じるのと、IDのインシュランスに三千円かけてると思うのですが掛け捨てになりそうで…",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1268940655322992644",
        "createdAt" : "2020-06-05T16:20:02.708Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "6/22にフルリモートで開校する予定なのですが、そのときに詳細発表できるように進めているとこの前言われてました(ねんのため、内密にお願いします🙇‍♂️)",
        "mediaUrls" : [ ],
        "senderId" : "1175310221238890497",
        "id" : "1268933512322617349",
        "createdAt" : "2020-06-05T15:51:39.670Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "3月ピシン、まだ検討中らしいですよ！",
        "mediaUrls" : [ ],
        "senderId" : "1175310221238890497",
        "id" : "1268933269380190214",
        "createdAt" : "2020-06-05T15:50:41.747Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "1196027845836824578-1228559135093821441",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1301075226604613632",
          "createdAt" : "2020-09-02T08:31:21.495Z"
        } ],
        "urls" : [ ],
        "text" : "よかった！もうすぐ始まるですね。楽しみにしています！でもひなたさん２月から待っています😱",
        "mediaUrls" : [ ],
        "senderId" : "1196027845836824578",
        "id" : "1301067876292386821",
        "createdAt" : "2020-09-02T08:02:09.063Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "わかりました、PC作ることを頑張ってください！今まで132人ぐらいdiscordに参加しました。ピシンに参加者の方はいくつなんだろう。",
        "mediaUrls" : [ ],
        "senderId" : "1196027845836824578",
        "id" : "1301067330491805708",
        "createdAt" : "2020-09-02T07:59:58.933Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1196027845836824578",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "先程Twitterで質問に答えてくださった方から、urlを教えてもらえました！\nログインできました！💪",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1301052136780750852",
        "createdAt" : "2020-09-02T06:59:36.476Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1196027845836824578",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ぜひなりましょう！今pcから離れてるので後でアカウントの情報送ります！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1301051700573167620",
        "createdAt" : "2020-09-02T06:57:52.470Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1301051709645496320",
          "createdAt" : "2020-09-02T06:57:54.617Z"
        } ],
        "urls" : [ ],
        "text" : "ああ、ひなたさんごめんなさい。私は勘違いしていました。今infraリンクを取れましたか？？☺️",
        "mediaUrls" : [ ],
        "senderId" : "1196027845836824578",
        "id" : "1301026323767255044",
        "createdAt" : "2020-09-02T05:17:02.292Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ひなたさんdiscordで友達になっていいですか？",
        "mediaUrls" : [ ],
        "senderId" : "1196027845836824578",
        "id" : "1301021043822223364",
        "createdAt" : "2020-09-02T04:56:03.336Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "よかった！！みんなメールが届いているみたいで嬉しい。この人も届いたそうです😁😁",
        "mediaUrls" : [ ],
        "senderId" : "1196027845836824578",
        "id" : "1301020916692869125",
        "createdAt" : "2020-09-02T04:55:33.025Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1196027845836824578",
        "reactions" : [ {
          "senderId" : "1196027845836824578",
          "reactionKey" : "like",
          "eventId" : "1301020933868498949",
          "createdAt" : "2020-09-02T04:55:37.104Z"
        } ],
        "urls" : [ {
          "url" : "https://t.co/IODqKjGl5H",
          "expanded" : "https://twitter.com/42_sept_join/status/1300721411011391488",
          "display" : "twitter.com/42_sept_join/s…"
        } ],
        "text" : "これが来てないので不安になっています https://t.co/IODqKjGl5H",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1300976342507249670",
        "createdAt" : "2020-09-02T01:58:25.729Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1196027845836824578",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "そうです！login情報のメールは、ログインIDと初期パスワードの設定の仕方が書かれていました。",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1300976230817132548",
        "createdAt" : "2020-09-02T01:57:59.081Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1300976116669145088",
          "createdAt" : "2020-09-02T01:57:31.847Z"
        } ],
        "urls" : [ ],
        "text" : "やった！いい感じですね！☺️☺️メールは二つ来ましたか？loginの情報メールとdiscordメールでしょうか？？",
        "mediaUrls" : [ ],
        "senderId" : "1196027845836824578",
        "id" : "1300848875767394308",
        "createdAt" : "2020-09-01T17:31:55.268Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1196027845836824578",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "来ました！Discordの登録用メール",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1300779254905356292",
        "createdAt" : "2020-09-01T12:55:16.362Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1196027845836824578",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "IDチェックはかなり前に受けましたが、なんのメールでしょうか？",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1300718768759267332",
        "createdAt" : "2020-09-01T08:54:55.344Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1300718686139895809",
          "createdAt" : "2020-09-01T08:54:35.625Z"
        } ],
        "urls" : [ ],
        "text" : "ひなたさん42からもうメールをもらいましたか？？",
        "mediaUrls" : [ ],
        "senderId" : "1196027845836824578",
        "id" : "1300697139522105348",
        "createdAt" : "2020-09-01T07:28:58.529Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "そうですね。家から受けられることはいいですね。最も心地よいところはずだ！",
        "mediaUrls" : [ ],
        "senderId" : "1196027845836824578",
        "id" : "1300696841785286666",
        "createdAt" : "2020-09-01T07:27:47.543Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1196027845836824578",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "旅行に行く時はAirbnbよく使います！\nでもPiscineが家でも受けられるようになったから、みんな家にいるのかも🤔",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1300458251738259461",
        "createdAt" : "2020-08-31T15:39:43.248Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1300457934489493504",
          "createdAt" : "2020-08-31T15:38:27.590Z"
        } ],
        "urls" : [ ],
        "text" : "自作のデスクトップはカッコいい！ひなたさん家から方がいいですね。\nAirbnbについてツイートをしたのに誰も興味がなさそうです。お金を貯めれるね😂",
        "mediaUrls" : [ ],
        "senderId" : "1196027845836824578",
        "id" : "1300349996798111749",
        "createdAt" : "2020-08-31T08:29:33.265Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1196027845836824578",
        "reactions" : [ {
          "senderId" : "1196027845836824578",
          "reactionKey" : "like",
          "eventId" : "1300347604547506176",
          "createdAt" : "2020-08-31T08:20:02.881Z"
        } ],
        "urls" : [ ],
        "text" : "私は、家に自作のデスクトップPCを置くつもりなので、あまり外に出歩くのはやらないかもしれません😭\nでも、多分他の参加者の人は興味があると思います！特に地方の人とかは、週に1度通うより、毎日通ったほうが楽そうなので👍",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298635095721431046",
        "createdAt" : "2020-08-26T14:55:08.980Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1298634715939799040",
          "createdAt" : "2020-08-26T14:53:38.420Z"
        } ],
        "urls" : [ ],
        "text" : "昨日ツイッターで42に近いシェアハウスの広告を見ました。piscineの参加者の方と一緒に住めると書いてありました。このシェアハウスは少し高いのにこのアイディアが素晴らしいと思います！Airbnbで数いい家を見つけました。ひなたさん興味はありますか？他の参加者の方はこれに興味はあると思いますか？",
        "mediaUrls" : [ ],
        "senderId" : "1196027845836824578",
        "id" : "1298506425832857606",
        "createdAt" : "2020-08-26T06:23:51.701Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "おお、少し遠いです！週一回42に来るのはよかったね😂時間を節約できる！",
        "mediaUrls" : [ ],
        "senderId" : "1196027845836824578",
        "id" : "1298504206978912260",
        "createdAt" : "2020-08-26T06:15:02.698Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1196027845836824578",
        "reactions" : [ {
          "senderId" : "1196027845836824578",
          "reactionKey" : "like",
          "eventId" : "1298504231846989825",
          "createdAt" : "2020-08-26T06:15:08.582Z"
        } ],
        "urls" : [ ],
        "text" : "もちろんです！お互い助け合いで頑張りましょう💪\n私は42からちょっと遠いです、京王線の高幡不動という駅に近い場所に住んでいます。\n\n東京の西の方です",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298435205837942788",
        "createdAt" : "2020-08-26T01:40:51.520Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "本当にありがといございます！ひなたさんピシンか英語の質問があれば教えてください☺️\nところでどの辺に住んでいますか？42に近いですか？",
        "mediaUrls" : [ ],
        "senderId" : "1196027845836824578",
        "id" : "1298273332710633477",
        "createdAt" : "2020-08-25T14:57:37.967Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1196027845836824578",
        "reactions" : [ {
          "senderId" : "1196027845836824578",
          "reactionKey" : "like",
          "eventId" : "1298272651404652544",
          "createdAt" : "2020-08-25T14:54:55.535Z"
        } ],
        "urls" : [ ],
        "text" : "ジェイドさんはもう日本語がとても上手なので大丈夫だよ！\n\nきっと、毎日piscine行ってたらもっと日本語上手になるね🥰\n\n私の英語はあまり上手じゃないけれど、でも話すことはできるはず！わからなくなったら聞いて欲しい👍",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298193135873359877",
        "createdAt" : "2020-08-25T09:38:57.537Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1298192612168364040",
          "createdAt" : "2020-08-25T09:36:52.658Z"
        } ],
        "urls" : [ ],
        "text" : "お！栃木が少し遠いですね。リモートの授業おかげで東京に住んで六本木へ簡単に通うのよかった！\nああ、英語できますか？☺️ピシンの頃時々英語を使った方がいいかも🥺\n一緒に英語と日本語頑張りましょうね！",
        "mediaUrls" : [ ],
        "senderId" : "1196027845836824578",
        "id" : "1298182968716869637",
        "createdAt" : "2020-08-25T08:58:33.498Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "本当ですか？！嬉しい！でも実は書くのはほとんど大丈夫けど差し向かってあまり会話できない🥴聞くことと話すことがだいぶ大変です！それは毎日会いたい理由なんです。対面コミュニケーションの実際経験積むから！まあ、金曜日だね☺️",
        "mediaUrls" : [ ],
        "senderId" : "1196027845836824578",
        "id" : "1298182505221087236",
        "createdAt" : "2020-08-25T08:56:42.990Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1196027845836824578",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "もし、英語のほうがよかったら言ってもらえたら頑張りますw",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298134700922269700",
        "createdAt" : "2020-08-25T05:46:45.562Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1196027845836824578",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "私は、大学が栃木にあり、普段はそこに住んでいます。今は、大学がリモート授業なので、実家がある東京に住んでいます！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298134653027512324",
        "createdAt" : "2020-08-25T05:46:34.143Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1196027845836824578",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "とっても日本語が上手で、初め日本語が母語なのかと思っていましたw",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298134465139548164",
        "createdAt" : "2020-08-25T05:45:49.343Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "そうそう！私はアメリカ出身です。去年の4月に日本語を勉強するために日本に引っ越すしました。ひなたさんどこからきましたか？\nよろしくお願いします！☺️",
        "mediaUrls" : [ ],
        "senderId" : "1196027845836824578",
        "id" : "1298074152079781892",
        "createdAt" : "2020-08-25T01:46:09.592Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1196027845836824578",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "ジェイドさん！もしかして、母国語は別の言語ですか？\n9月のピシンからよろしくお願いします！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1298050475753746436",
        "createdAt" : "2020-08-25T00:12:04.715Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1298050237848666112",
          "createdAt" : "2020-08-25T00:11:07.983Z"
        } ],
        "urls" : [ ],
        "text" : "よかった！私も元気です。ジェイドと呼ばれます☺️\nそうですか。段落頑張って！でも準備できないのは大変だね🥺\nそうですね！金曜日新友達と会えますね。それけど毎日会える方がいい",
        "mediaUrls" : [ ],
        "senderId" : "1196027845836824578",
        "id" : "1297930191189102597",
        "createdAt" : "2020-08-24T16:14:06.641Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1196027845836824578",
        "reactions" : [ {
          "senderId" : "1196027845836824578",
          "reactionKey" : "like",
          "eventId" : "1297926753554292736",
          "createdAt" : "2020-08-24T16:00:27.028Z"
        } ],
        "urls" : [ ],
        "text" : "私は元気ですよー！豚婦村さんもお元気ですか？\nピシンの準備はあまりできてません…、学校がそろそろひと段落するのでそしたら勉強始めようと思います！\n私は家からリモートで参加になっちゃいました…\n\n週一回金曜日に学校に行くことになるはずですが、その時に会えるかも？🤔",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1297913176999129092",
        "createdAt" : "2020-08-24T15:06:30.142Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ {
          "senderId" : "1228559135093821441",
          "reactionKey" : "like",
          "eventId" : "1297912744302108673",
          "createdAt" : "2020-08-24T15:04:46.961Z"
        } ],
        "urls" : [ ],
        "text" : "Hinataさん、元気？最近ピシンに準備していますか？学校が忙しい？\nピシンは家からピアラーニングが気にしています🙄42に毎日行きたいです！",
        "mediaUrls" : [ ],
        "senderId" : "1196027845836824578",
        "id" : "1297906434747691014",
        "createdAt" : "2020-08-24T14:39:42.665Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "1199683722787713026-1228559135093821441",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "1199683722787713026",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "さにーさんどこまでいきました？",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1303185565232242693",
        "createdAt" : "2020-09-08T04:17:05.449Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1199683722787713026",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "おおおお！ありがとうございます！\n初めまして！hkikuchiといいます！一緒に頑張りましょう！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1303185547851001861",
        "createdAt" : "2020-09-08T04:17:01.311Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "はじめまして！ピシン生のtsekigucです！\n僕も全然わからないですが一緒に頑張りましょう！",
        "mediaUrls" : [ ],
        "senderId" : "1199683722787713026",
        "id" : "1303170178046287877",
        "createdAt" : "2020-09-08T03:15:56.860Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "1203088970906619905-1228559135093821441",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "もし良かったら仲良くしてください。",
        "mediaUrls" : [ ],
        "senderId" : "1203088970906619905",
        "id" : "1297738638743150596",
        "createdAt" : "2020-08-24T03:32:56.972Z"
      }
    } ]
  }
}, {
  "dmConversation" : {
    "conversationId" : "1228559135093821441-1233325714100801537",
    "messages" : [ {
      "messageCreate" : {
        "recipientId" : "1233325714100801537",
        "reactions" : [ {
          "senderId" : "1233325714100801537",
          "reactionKey" : "agree",
          "eventId" : "1234438697610706944",
          "createdAt" : "2020-03-02T11:21:34.939Z"
        } ],
        "urls" : [ ],
        "text" : "こちらこそ！",
        "mediaUrls" : [ ],
        "senderId" : "1228559135093821441",
        "id" : "1234307221476929541",
        "createdAt" : "2020-03-02T02:39:08.602Z"
      }
    }, {
      "messageCreate" : {
        "recipientId" : "1228559135093821441",
        "reactions" : [ ],
        "urls" : [ ],
        "text" : "フォローありがとうございます！",
        "mediaUrls" : [ ],
        "senderId" : "1233325714100801537",
        "id" : "1234128536467726340",
        "createdAt" : "2020-03-01T14:49:06.786Z"
      }
    } ]
  }
} ]