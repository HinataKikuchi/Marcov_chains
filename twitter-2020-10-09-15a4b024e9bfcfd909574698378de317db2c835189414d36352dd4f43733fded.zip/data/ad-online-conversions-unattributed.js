window.YTD.ad_online_conversions_unattributed.part0 = [ {
  "ad" : {
    "adsUserData" : {
      "unattributedOnlineConversions" : {
        "conversions" : [ {
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/2019Shun/items/5ab290a4117a00e373b6",
          "advertiserInfo" : { },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 01:49:02",
          "additionalParameters" : { }
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/2019Shun/items/5ab290a4117a00e373b6",
          "advertiserInfo" : {
            "advertiserName" : "Udemy Japan",
            "screenName" : "@UdemyJapan"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 01:49:01"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/2019Shun/items/5ab290a4117a00e373b6",
          "advertiserInfo" : {
            "advertiserName" : "moffers by CodeIQ",
            "screenName" : "@codeiq_moffers"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 01:49:01"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/2019Shun/items/5ab290a4117a00e373b6",
          "advertiserInfo" : {
            "advertiserName" : "【公式】FINDJOB!＠9月1日に生まれ変わりました",
            "screenName" : "@find_job"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 01:49:01"
        }, {
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/2019Shun/items/5ab290a4117a00e373b6",
          "advertiserInfo" : {
            "advertiserName" : "moffers by CodeIQ",
            "screenName" : "@codeiq_moffers"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 01:49:01",
          "additionalParameters" : { }
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/2019Shun/items/5ab290a4117a00e373b6",
          "advertiserInfo" : { },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 01:49:01"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/2019Shun/items/5ab290a4117a00e373b6",
          "advertiserInfo" : {
            "advertiserName" : "geek.info",
            "screenName" : "@geek_info_"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 01:49:01"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/2019Shun/items/5ab290a4117a00e373b6",
          "advertiserInfo" : {
            "advertiserName" : "クラウドテック",
            "screenName" : "@crowdtech_cw"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 01:49:01"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/2019Shun/items/5ab290a4117a00e373b6",
          "advertiserInfo" : {
            "advertiserName" : "株式会社PE-BANK",
            "screenName" : "@ProEngineerBank"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 01:49:01"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/2019Shun/items/5ab290a4117a00e373b6",
          "advertiserInfo" : {
            "advertiserName" : "Midworks",
            "screenName" : "@mid_works"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 01:49:01"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/2019Shun/items/5ab290a4117a00e373b6",
          "advertiserInfo" : {
            "advertiserName" : "Udemy Japan",
            "screenName" : "@UdemyJapan"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 01:49:01"
        }, {
          "conversionTime" : "2020-10-01 01:49:01",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/"
        }, {
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://www.sejuku.net/blog/24473",
          "advertiserInfo" : {
            "advertiserName" : "侍エンジニア塾",
            "screenName" : "@samuraijuku"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 02:20:50",
          "additionalParameters" : { }
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedOnlineConversions" : {
        "conversions" : [ {
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/yz2cm/items/77b98658bfd922236817",
          "advertiserInfo" : { },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 09:57:13",
          "additionalParameters" : { }
        }, {
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/yz2cm/items/77b98658bfd922236817",
          "advertiserInfo" : {
            "advertiserName" : "侍エンジニア塾",
            "screenName" : "@samuraijuku"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 09:57:13",
          "additionalParameters" : { }
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/yz2cm/items/77b98658bfd922236817",
          "advertiserInfo" : {
            "advertiserName" : "FLEXY",
            "screenName" : "@flexy_circu"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 09:57:13"
        }, {
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/yz2cm/items/77b98658bfd922236817",
          "advertiserInfo" : {
            "advertiserName" : "Green",
            "screenName" : "@green_japan"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 09:57:13",
          "additionalParameters" : { }
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/yz2cm/items/77b98658bfd922236817",
          "advertiserInfo" : {
            "advertiserName" : "techcareer haken",
            "screenName" : "@tc_haken"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 09:57:13"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/yz2cm/items/77b98658bfd922236817",
          "advertiserInfo" : {
            "advertiserName" : "techcareer",
            "screenName" : "@techcareer0808"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 09:57:13"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/yz2cm/items/77b98658bfd922236817",
          "advertiserInfo" : { },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 09:57:13"
        }, {
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/yz2cm/items/77b98658bfd922236817",
          "advertiserInfo" : {
            "advertiserName" : "フーティ / 転職ドラフト【公式】",
            "screenName" : "@tensyoku_draft"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 09:57:13",
          "additionalParameters" : { }
        }, {
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/yz2cm/items/77b98658bfd922236817",
          "advertiserInfo" : { },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 09:57:12",
          "additionalParameters" : { }
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/yz2cm/items/77b98658bfd922236817",
          "advertiserInfo" : {
            "advertiserName" : "moffers by CodeIQ",
            "screenName" : "@codeiq_moffers"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 09:57:12"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/yz2cm/items/77b98658bfd922236817",
          "advertiserInfo" : {
            "advertiserName" : "【公式】FINDJOB!＠9月1日に生まれ変わりました",
            "screenName" : "@find_job"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 09:57:12"
        }, {
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/yz2cm/items/77b98658bfd922236817",
          "advertiserInfo" : {
            "advertiserName" : "moffers by CodeIQ",
            "screenName" : "@codeiq_moffers"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 09:57:12",
          "additionalParameters" : { }
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/yz2cm/items/77b98658bfd922236817",
          "advertiserInfo" : { },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 09:57:12"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/yz2cm/items/77b98658bfd922236817",
          "advertiserInfo" : {
            "advertiserName" : "geek.info",
            "screenName" : "@geek_info_"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 09:57:12"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/yz2cm/items/77b98658bfd922236817",
          "advertiserInfo" : {
            "advertiserName" : "クラウドテック",
            "screenName" : "@crowdtech_cw"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 09:57:12"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/yz2cm/items/77b98658bfd922236817",
          "advertiserInfo" : {
            "advertiserName" : "株式会社PE-BANK",
            "screenName" : "@ProEngineerBank"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 09:57:12"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/yz2cm/items/77b98658bfd922236817",
          "advertiserInfo" : {
            "advertiserName" : "Midworks",
            "screenName" : "@mid_works"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 09:57:12"
        }, {
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/yz2cm/items/77b98658bfd922236817",
          "advertiserInfo" : {
            "advertiserName" : "moffers by CodeIQ",
            "screenName" : "@codeiq_moffers"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 09:57:13",
          "additionalParameters" : { }
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/yz2cm/items/77b98658bfd922236817",
          "advertiserInfo" : {
            "advertiserName" : "Udemy Japan",
            "screenName" : "@UdemyJapan"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 09:57:12"
        }, {
          "conversionTime" : "2020-10-01 09:57:11",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/"
        }, {
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : { },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:17",
          "additionalParameters" : { }
        }, {
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : {
            "advertiserName" : "侍エンジニア塾",
            "screenName" : "@samuraijuku"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:17",
          "additionalParameters" : { }
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : {
            "advertiserName" : "FLEXY",
            "screenName" : "@flexy_circu"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:17"
        }, {
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : {
            "advertiserName" : "Green",
            "screenName" : "@green_japan"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:17",
          "additionalParameters" : { }
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : {
            "advertiserName" : "techcareer haken",
            "screenName" : "@tc_haken"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:17"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : {
            "advertiserName" : "techcareer",
            "screenName" : "@techcareer0808"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:17"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : { },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:17"
        }, {
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : {
            "advertiserName" : "フーティ / 転職ドラフト【公式】",
            "screenName" : "@tensyoku_draft"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:17",
          "additionalParameters" : { }
        }, {
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : { },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:16",
          "additionalParameters" : { }
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : {
            "advertiserName" : "Udemy Japan",
            "screenName" : "@UdemyJapan"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:16"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : {
            "advertiserName" : "moffers by CodeIQ",
            "screenName" : "@codeiq_moffers"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:16"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : {
            "advertiserName" : "【公式】FINDJOB!＠9月1日に生まれ変わりました",
            "screenName" : "@find_job"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:16"
        }, {
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : {
            "advertiserName" : "moffers by CodeIQ",
            "screenName" : "@codeiq_moffers"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:16",
          "additionalParameters" : { }
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : { },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:16"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : {
            "advertiserName" : "geek.info",
            "screenName" : "@geek_info_"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:16"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : {
            "advertiserName" : "クラウドテック",
            "screenName" : "@crowdtech_cw"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:16"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : {
            "advertiserName" : "株式会社PE-BANK",
            "screenName" : "@ProEngineerBank"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:16"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : {
            "advertiserName" : "Midworks",
            "screenName" : "@mid_works"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:16"
        }, {
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : {
            "advertiserName" : "moffers by CodeIQ",
            "screenName" : "@codeiq_moffers"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:17",
          "additionalParameters" : { }
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/morikooooo/items/9fd41bcd8d1ce9170301",
          "advertiserInfo" : {
            "advertiserName" : "Udemy Japan",
            "screenName" : "@UdemyJapan"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 11:05:16"
        }, {
          "conversionTime" : "2020-10-01 11:05:16",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/"
        }, {
          "conversionTime" : "2020-10-01 12:49:29",
          "conversionPlatform" : "Desktop"
        }, {
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/seriru13/items/c2f5192615162c4c3f47",
          "advertiserInfo" : { },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 07:59:00",
          "additionalParameters" : { }
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/seriru13/items/c2f5192615162c4c3f47",
          "advertiserInfo" : {
            "advertiserName" : "moffers by CodeIQ",
            "screenName" : "@codeiq_moffers"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 07:59:00"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/seriru13/items/c2f5192615162c4c3f47",
          "advertiserInfo" : {
            "advertiserName" : "【公式】FINDJOB!＠9月1日に生まれ変わりました",
            "screenName" : "@find_job"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 07:59:00"
        }, {
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/seriru13/items/c2f5192615162c4c3f47",
          "advertiserInfo" : {
            "advertiserName" : "moffers by CodeIQ",
            "screenName" : "@codeiq_moffers"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 07:59:00",
          "additionalParameters" : { }
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/seriru13/items/c2f5192615162c4c3f47",
          "advertiserInfo" : { },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 07:59:00"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/seriru13/items/c2f5192615162c4c3f47",
          "advertiserInfo" : {
            "advertiserName" : "geek.info",
            "screenName" : "@geek_info_"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 07:59:00"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/seriru13/items/c2f5192615162c4c3f47",
          "advertiserInfo" : {
            "advertiserName" : "クラウドテック",
            "screenName" : "@crowdtech_cw"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 07:59:00"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/seriru13/items/c2f5192615162c4c3f47",
          "advertiserInfo" : {
            "advertiserName" : "株式会社PE-BANK",
            "screenName" : "@ProEngineerBank"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 07:59:00"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/seriru13/items/c2f5192615162c4c3f47",
          "advertiserInfo" : {
            "advertiserName" : "Midworks",
            "screenName" : "@mid_works"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 07:59:00"
        }, {
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/seriru13/items/c2f5192615162c4c3f47",
          "advertiserInfo" : {
            "advertiserName" : "Udemy Japan",
            "screenName" : "@UdemyJapan"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-10-01 07:59:00"
        }, {
          "conversionTime" : "2020-10-01 07:58:59",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://qiita.com/"
        } ]
      }
    }
  }
} ]