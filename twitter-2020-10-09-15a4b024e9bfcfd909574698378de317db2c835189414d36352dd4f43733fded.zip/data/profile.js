window.YTD.profile.part0 = [ {
  "profile" : {
    "description" : {
      "bio" : "PiscineSeptember受験済み、地方大学3年🥺絶賛42不合格発表待ち✌︎('ω'✌︎ )下ネタ、ラーメン、生活メモに使う予定です、アウトな方ブロおなしゃす\ngit : https://t.co/3ljZgJTlSb\nqiita : https://t.co/Z2NVrUb6Q2",
      "website" : "",
      "location" : ""
    },
    "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1228560309754839042/KIXYm2gC.jpg",
    "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/1228559135093821441/1581746605"
  }
} ]