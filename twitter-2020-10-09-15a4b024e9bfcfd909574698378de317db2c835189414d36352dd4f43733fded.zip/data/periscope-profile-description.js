window.YTD.periscope_profile_description.part0 = [ {
  "periscopeProfileDescription" : {
    "bio" : "42Tokyo用のアカウント作成しました🤤 4月piscineに参加予定でした…。(7/17追記:9月piscineに参加します！誕生月！お祝いください(嘘)！)お気軽にお声がけください(訳:話しかけてください((((()🤦‍♀️地方大学3年"
  }
} ]