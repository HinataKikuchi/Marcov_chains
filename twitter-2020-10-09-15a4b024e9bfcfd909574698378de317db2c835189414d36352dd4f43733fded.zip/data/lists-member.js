window.YTD.lists_member.part0 = [ {
  "userListInfo" : {
    "url" : "https://twitter.com/suminabee/lists/9-picsiner"
  }
}, {
  "userListInfo" : {
    "url" : "https://twitter.com/_unlimish/lists/42"
  }
}, {
  "userListInfo" : {
    "url" : "https://twitter.com/Kahorin_42Tokyo/lists/9-pisciner"
  }
}, {
  "userListInfo" : {
    "url" : "https://twitter.com/bundoki360/lists/l42tokyopiscinemar"
  }
} ]