window.YTD.ad_online_conversions_attributed.part0 = [ {
  "ad" : {
    "adsUserData" : {
      "attributedOnlineConversions" : {
        "conversions" : [ {
          "attributedConversionType" : "PageView",
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://www.pc-koubou.jp/magazine/39579",
          "advertiserInfo" : {
            "advertiserName" : "パソコン工房WEB通販公式",
            "screenName" : "@pc_koubou_web"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-08-25 11:26:07",
          "additionalParameters" : { }
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "attributedOnlineConversions" : {
        "conversions" : [ {
          "attributedConversionType" : "PageView",
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://prtimes.jp/main/html/rd/p/000000021.000008352.html",
          "advertiserInfo" : {
            "advertiserName" : "PR TIMES",
            "screenName" : "@PRTIMES_JP"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-09-09 15:50:47",
          "additionalParameters" : { }
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "attributedOnlineConversions" : {
        "conversions" : [ {
          "attributedConversionType" : "PageView",
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://prtimes.jp/main/html/rd/p/000000002.000061620.html",
          "advertiserInfo" : {
            "advertiserName" : "PR TIMES",
            "screenName" : "@PRTIMES_JP"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-09-20 17:27:09",
          "additionalParameters" : { }
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "attributedOnlineConversions" : {
        "conversions" : [ {
          "attributedConversionType" : "PageView",
          "eventType" : "pageview",
          "conversionPlatform" : "Desktop",
          "conversionUrl" : "https://17media.jp/corpinfo/",
          "advertiserInfo" : {
            "advertiserName" : "17LIVE(イチナナ)公式",
            "screenName" : "@17LiveJP"
          },
          "conversionValue" : "0",
          "conversionTime" : "2020-09-26 05:50:13",
          "additionalParameters" : { }
        } ]
      }
    }
  }
} ]